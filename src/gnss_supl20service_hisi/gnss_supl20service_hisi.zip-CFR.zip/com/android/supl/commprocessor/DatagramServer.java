/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.android.supl.commprocessor;

import android.util.Log;
import com.android.supl.commprocessor.ServerCommProcessor;
import java.net.DatagramSocket;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class DatagramServer {
    public static final int D_PORT_NO = 7275;
    public static final String D_SERVER_ADDRESS = "127.0.0.1";
    private static final String LOG = "SUPL20_DGS";
    private int iPortNo = 7275;
    private ServerCommProcessor scm = null;
    private ServerThread serverThread = null;
    private String stServerName = null;

    static /* synthetic */ int -get0(DatagramServer datagramServer) {
        return datagramServer.iPortNo;
    }

    static /* synthetic */ ServerCommProcessor -get1(DatagramServer datagramServer) {
        return datagramServer.scm;
    }

    public DatagramServer(int n, String string, ServerCommProcessor serverCommProcessor) {
        this.iPortNo = n;
        this.stServerName = string;
        this.scm = serverCommProcessor;
    }

    public void startServer() {
        Log.i((String)LOG, (String)"startServer invoked");
        this.serverThread = new ServerThread("UDP Server thread");
        this.serverThread.start();
    }

    public void stop() {
        if (this.serverThread == null) return;
        Log.i((String)LOG, (String)"stop invoked");
        this.serverThread.stopThread();
    }

    /*
     * Illegal identifiers - consider using --renameillegalidents true
     */
    private class ServerThread
    extends Thread {
        private boolean isStop;
        private byte[] receiveData;
        private DatagramSocket serverSocket;

        public ServerThread(String string) {
            super(string);
            this.receiveData = null;
            this.isStop = false;
            this.serverSocket = null;
            this.receiveData = new byte[4096];
        }

        private void stopThread() {
            this.interrupt();
            this.isStop = true;
            if (this.serverSocket == null) return;
            this.serverSocket.close();
        }

        /*
         * Exception decompiling
         */
        @Override
        public void run() {
            /*
             * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
             * 
             * org.benf.cfr.reader.util.ConfusedCFRException: Back jump on a try block [egrp 3[TRYBLOCK] [13 : 326->370)] java.net.SocketException
             *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.insertExceptionBlocks(Op02WithProcessedDataAndRefs.java:2289)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:414)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
             *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
             *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:910)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1022)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
             *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
             *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
             *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:73)
             *     at org.benf.cfr.reader.Main.main(Main.java:49)
             *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:303)
             *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$null$1(ResourceDecompiling.java:113)
             *     at java.base/java.lang.Thread.run(Unknown Source)
             */
            throw new IllegalStateException("Decompilation failed");
        }
    }
}

