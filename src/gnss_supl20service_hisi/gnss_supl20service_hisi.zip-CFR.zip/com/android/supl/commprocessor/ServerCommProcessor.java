/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.util.Log
 */
package com.android.supl.commprocessor;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;
import com.android.bytewriter.IO;
import com.android.supl.commprocessor.CommandProcessor;
import com.android.supl.commprocessor.FromServer;
import com.android.supl.commprocessor.NetworkCommandProcessor;
import com.android.supl.nc.NetworkController;
import com.android.supl.nc.SendToServer;
import com.android.supl.nc.SuplServiceMgr;
import java.util.Arrays;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class ServerCommProcessor
implements CommandProcessor {
    public static final int COMM_MSG_HELLO_TO_COMM_SRVC_MAGIC_CODE = -1724873644;
    public static final int COMM_MSG_HELLO_TO_SUPL_CLIENT_MAGIC_CODE = -2125961885;
    private static final String LOG_TAG = "SUPL20_SCM";
    public static final int MASTER_BUFF_LEN = 5000;
    public static final int MSG_SCM_BYE = 512;
    public static final int MSG_SCM_CONNECT = 514;
    public static final int MSG_SCM_DISCONNECT = 515;
    public static final int MSG_SCM_HELLO_TO_COMM_SRVC = 513;
    public static final int MSG_SCM_HELLO_TO_SUPL_CLIENT = 517;
    public static final int MSG_SCM_NW_CONNECTION_OFF = 523;
    public static final int MSG_SCM_NW_CONNECTION_ON = 522;
    public static final int MSG_SCM_ON_CONNECTED = 518;
    public static final int MSG_SCM_ON_NOT_CONNECTED = 519;
    public static final int MSG_SCM_ON_NW_SESSION_CLOSED = 521;
    public static final int MSG_SCM_ON_RECEIVE = 520;
    public static final int MSG_SCM_ON_RECEIVE_FROM_NON_TCP = 525;
    public static final int MSG_SCM_SEND = 516;
    public static final int MSG_SCM_SYS_IDLE = 524;
    private int iLastWritePostion = 0;
    private int iTotalArrival = 0;
    private boolean isPause = false;
    private Context mContext = null;
    private boolean mListening = false;
    private NetworkCommandProcessor mNetworkCommandProcessor = null;
    private ConnectivityBroadcastReceiver mReceiver;
    private byte[] m_bMasterBuffer = null;
    private NetworkController nc = null;
    private ReadPacket packet = null;
    private final Object pauseLock = new Object();

    static /* synthetic */ boolean -set0(ServerCommProcessor serverCommProcessor, boolean bl) {
        serverCommProcessor.isPause = bl;
        return bl;
    }

    public ServerCommProcessor() {
        this.nc = new NetworkController(0, "10.4.0.51", 4444, this, "SCM read thread", "SCM write thread", true);
        this.packet = new ReadPacket("SCM command process thread");
        SuplServiceMgr.getInstance().setScmCommandProcessor(this);
    }

    public ServerCommProcessor(boolean bl, String string, int n, int n2, int n3) {
        this.msgBufferReset();
        this.nc = new NetworkController(0, string, n, this, "SCM read thread", "SCM write thread", true);
        this.nc.setServer_conn_Timeout_Retries(n2, n3);
        this.packet = new ReadPacket("SCM command process thread");
        this.mNetworkCommandProcessor = new NetworkCommandProcessor(this);
        SuplServiceMgr.getInstance().setScmCommandProcessor(this);
    }

    private void msgBufferReset() {
        this.m_bMasterBuffer = new byte[5000];
        Arrays.fill(this.m_bMasterBuffer, (byte)0);
    }

    @Override
    public boolean init() {
        Log.i((String)LOG_TAG, (String)"calling nc.connect for scm");
        return this.nc.connect(null, false);
    }

    public void pause() {
        Object object = new Thread(){

            @Override
            public void run() {
                Object object = ServerCommProcessor.this.pauseLock;
                synchronized (object) {
                    if (ServerCommProcessor.this.isPause) return;
                    Log.i((String)ServerCommProcessor.LOG_TAG, (String)"SCM pause invoked");
                    ServerCommProcessor.this.nc.stop(false, ServerCommProcessor.this.pauseLock, false);
                    try {
                        ServerCommProcessor.this.pauseLock.wait();
                    }
                    catch (InterruptedException interruptedException) {
                        interruptedException.printStackTrace();
                    }
                    Log.i((String)ServerCommProcessor.LOG_TAG, (String)"SCM pauseLock release");
                    ServerCommProcessor.this.packet.stopRead();
                    ServerCommProcessor.this.stopListening();
                    ServerCommProcessor.this.mNetworkCommandProcessor.disConnectAllNetWork();
                    ServerCommProcessor.-set0(ServerCommProcessor.this, true);
                    return;
                }
            }
        };
        ((Thread)object).start();
        try {
            ((Thread)object).join();
            object = new StringBuilder();
            Log.i((String)LOG_TAG, (String)((StringBuilder)object).append("SCM pause finished:").append(this.isPause).toString());
            return;
        }
        catch (InterruptedException interruptedException) {
            Log.e((String)LOG_TAG, (String)interruptedException.getMessage(), (Throwable)interruptedException);
            return;
        }
    }

    /*
     * Exception decompiling
     */
    @Override
    public void process(FromServer var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Back jump on a try block [egrp 7[TRYBLOCK] [8 : 502->516)] java.io.IOException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.insertExceptionBlocks(Op02WithProcessedDataAndRefs.java:2289)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:414)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:73)
         *     at org.benf.cfr.reader.Main.main(Main.java:49)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:303)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$null$1(ResourceDecompiling.java:113)
         *     at java.base/java.lang.Thread.run(Unknown Source)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public void reInit() {
        Object object = this.pauseLock;
        synchronized (object) {
            ReadPacket readPacket;
            if (!this.isPause) return;
            Log.i((String)LOG_TAG, (String)"SCM reInit invoked");
            String string = this.packet.getThreadName();
            this.packet = readPacket = new ReadPacket(string);
            this.nc.initRead_WriteThread();
            this.isPause = false;
            return;
        }
    }

    @Override
    public void sendByeMessage() {
        SendToServer sendToServer = new SendToServer();
        byte[] byArray = new byte[12];
        IO.put4(byArray, IO.put4(byArray, 0, 8), 512);
        sendToServer.m_bPacket = byArray;
        this.nc.addPacket(sendToServer);
    }

    @Override
    public void sendHelloMessage() {
        SendToServer sendToServer = new SendToServer();
        byte[] byArray = new byte[12];
        IO.put4(byArray, IO.put4(byArray, IO.put4(byArray, 0, 8), 517), -2125961885);
        sendToServer.m_bPacket = byArray;
        this.nc.addPacket(sendToServer);
        this.startListening();
        Log.i((String)LOG_TAG, (String)"sendHelloMessage");
    }

    public void sendServer(SendToServer sendToServer) {
        this.nc.addPacket(sendToServer);
    }

    public void setContext(Context context) {
        this.mReceiver = new ConnectivityBroadcastReceiver();
        this.mContext = context;
    }

    public void startListening() {
        synchronized (this) {
            if (this.mListening) return;
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
            this.mContext.registerReceiver((BroadcastReceiver)this.mReceiver, intentFilter, "supl20servicePermission", null);
            this.mListening = true;
            return;
        }
    }

    public void stopListening() {
        synchronized (this) {
            if (!this.mListening) return;
            this.mContext.unregisterReceiver((BroadcastReceiver)this.mReceiver);
            this.mListening = false;
            return;
        }
    }

    public void stopNetWork() {
        Log.i((String)LOG_TAG, (String)"SCM stopNetWork invoked");
        this.packet.stopRead();
        this.stopListening();
        this.nc.stop(true, null, false);
        this.mNetworkCommandProcessor.disConnectAllNetWork();
    }

    public String toString() {
        return this.nc.getServerIPAddr() + " ," + this.nc.getNetWorkID() + " " + this.nc.toString();
    }

    @Override
    public void writePacket(FromServer fromServer) throws NullPointerException {
        if (fromServer == null) {
            throw new NullPointerException("fromServer object must not be null");
        }
        try {
            if (this.packet != null && this.packet.myJobDeque != null) {
                this.packet.myJobDeque.put(fromServer);
                return;
            }
            Log.i((String)LOG_TAG, (String)"packet is null or deque is null");
            return;
        }
        catch (InterruptedException interruptedException) {
            Log.e((String)LOG_TAG, (String)interruptedException.getMessage(), (Throwable)interruptedException);
            return;
        }
    }

    private class ConnectivityBroadcastReceiver
    extends BroadcastReceiver {
        private ConnectivityBroadcastReceiver() {
        }

        public void onReceive(Context object, Intent object2) {
            if (!object2.getAction().equals("android.net.conn.CONNECTIVITY_CHANGE")) return;
            if (!ServerCommProcessor.this.mListening) {
                return;
            }
            boolean bl = object2.getBooleanExtra("noConnectivity", false);
            object2 = new SendToServer();
            object = new byte[8];
            int n = IO.put4((byte[])object, 0, 4);
            if (bl) {
                IO.put4((byte[])object, n, 523);
            } else {
                IO.put4((byte[])object, n, 522);
            }
            Log.i((String)ServerCommProcessor.LOG_TAG, (String)("Network connection " + (bl ^ true)));
            object2.m_bPacket = (byte[])object;
            ServerCommProcessor.this.nc.addPacket((SendToServer)object2);
        }
    }

    /*
     * Illegal identifiers - consider using --renameillegalidents true
     */
    private class ReadPacket
    extends Thread {
        private boolean isStopRead = false;
        private BlockingQueue<FromServer> myJobDeque = new LinkedBlockingQueue<FromServer>();

        public ReadPacket(String string) {
            this.setName(string);
            this.start();
        }

        public String getThreadName() {
            return this.getName();
        }

        @Override
        public void run() {
            while (!this.isStopRead) {
                try {
                    if (Thread.interrupted()) {
                        return;
                    }
                    FromServer fromServer = this.myJobDeque.take();
                    if (fromServer == null) continue;
                    ServerCommProcessor.this.process(fromServer);
                }
                catch (InterruptedException interruptedException) {
                    Log.i((String)ServerCommProcessor.LOG_TAG, (String)(this.getName() + " allowed to exit"));
                    return;
                }
            }
        }

        public void stopRead() {
            this.interrupt();
            this.isStopRead = true;
        }
    }
}

