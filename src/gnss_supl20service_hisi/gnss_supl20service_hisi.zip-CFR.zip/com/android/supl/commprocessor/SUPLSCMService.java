/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.Service
 *  android.content.Context
 *  android.content.Intent
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo$State
 *  android.os.Binder
 *  android.os.IBinder
 *  android.telephony.TelephonyManager
 *  android.util.Log
 */
package com.android.supl.commprocessor;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Binder;
import android.os.IBinder;
import android.telephony.TelephonyManager;
import android.util.Log;
import com.android.supl.GpsOnOffListener;
import com.android.supl.SUPLManager;
import com.android.supl.bearer.BearerNetwork;
import com.android.supl.commprocessor.DatagramServer;
import com.android.supl.commprocessor.ServerCommProcessor;
import com.android.supl.config.ConfigManager;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.PriorityQueue;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class SUPLSCMService
extends Service
implements GpsOnOffListener {
    private static final int HOST_ADDRESS = 2130706433;
    public static final String SERVICE_NAME = SUPLSCMService.class.getCanonicalName();
    private final String LOG_TAG;
    DatagramServer datagramServer = null;
    private boolean isInit = false;
    private final IBinder mBinder = new MyBinder();
    private Context mContext = null;
    private ServerCommProcessor mServerCommProcessor = null;
    private Thread scmThread = null;

    static /* synthetic */ ServerCommProcessor -get0(SUPLSCMService sUPLSCMService) {
        return sUPLSCMService.mServerCommProcessor;
    }

    public SUPLSCMService() {
        this.LOG_TAG = "SUPL20_SCMService";
        this.mContext = this;
    }

    public SUPLSCMService(Context context) {
        this.LOG_TAG = "SUPL20_SCMService";
        this.mContext = context;
        this.onCreate();
    }

    private void checkSupportMultiBearer() {
        if (ConfigManager.getInstance().isMultipleBearNetworkSupport()) {
            new Thread(){

                @Override
                public void run() {
                    Log.i((String)"SUPL20_SCMService", (String)"Support for MultiBearer");
                    SUPLSCMService.this.supportMultipleBearerNetwork(mContext);
                }
            }.start();
            return;
        }
        Log.i((String)"SUPL20_SCMService", (String)"No Support for MultiBearer");
    }

    private boolean isBearerNetWorkSupported(int n, String[] stringArray) {
        boolean bl = false;
        String string = null;
        boolean bl2 = bl;
        String string2 = string;
        switch (n) {
            default: {
                string2 = string;
                bl2 = bl;
                break;
            }
            case 2: {
                string2 = "gsm";
                bl2 = true;
                break;
            }
            case 1: {
                string2 = "gsm";
                bl2 = true;
                break;
            }
            case 3: {
                string2 = "umb";
                bl2 = true;
                break;
            }
            case 4: {
                string2 = "cdma";
                bl2 = true;
                break;
            }
            case 13: {
                string2 = "lte";
                bl2 = true;
                break;
            }
            case 14: {
                string2 = "hrpd";
                bl2 = true;
                break;
            }
            case 0: {
                string2 = "UNKNOWN";
                bl2 = bl;
                break;
            }
            case 10: {
                string2 = "wcdma";
                bl2 = true;
                break;
            }
            case 8: {
                string2 = "wcdma";
                bl2 = true;
            }
            case 5: 
            case 6: 
            case 7: 
            case 11: 
            case 12: {
                break;
            }
            case 9: {
                string2 = "wcdma";
                bl2 = true;
            }
        }
        Log.i((String)"SUPL20_SCMService", (String)("network type:" + n + " ," + string2));
        if (stringArray == null) return bl2;
        if (stringArray.length == 0) return bl2;
        stringArray[0] = string2;
        return bl2;
    }

    private boolean isMobileDataEnabled(Context object) {
        boolean bl = false;
        ConnectivityManager connectivityManager = (ConnectivityManager)object.getSystemService("connectivity");
        try {
            object = Class.forName(connectivityManager.getClass().getName()).getDeclaredMethod("getMobileDataEnabled", new Class[0]);
            ((AccessibleObject)object).setAccessible(true);
            boolean bl2 = (Boolean)((Method)object).invoke(connectivityManager, new Object[0]);
            return bl2;
        }
        catch (Exception exception) {
            return bl;
        }
    }

    private Boolean isRoaming(Context context) {
        return ((TelephonyManager)context.getSystemService("phone")).isNetworkRoaming();
    }

    private void start() {
        this.isInit = true;
        ConfigManager configManager = ConfigManager.getInstance();
        int n = configManager.getSCMPort();
        this.mServerCommProcessor = new ServerCommProcessor(false, configManager.getSCMIpAdress(), n, configManager.getNwTimeout(), configManager.getNwRetries());
        if (configManager.isNiUdpEnabled()) {
            this.datagramServer = new DatagramServer(7275, "UDP SUPL server", this.mServerCommProcessor);
            Log.d((String)"SUPL20_SCMService", (String)"DataGramServer Created");
        }
        this.mServerCommProcessor.setContext(this.mContext);
        this.scmThread = new Thread(new SCMConnectionThread());
        this.scmThread.setName("SCM handsake thread");
        this.scmThread.start();
        Log.d((String)"SUPL20_SCMService", (String)"SCM Service Created");
    }

    private void startSCM() {
        Log.d((String)"SUPL20_SCMService", (String)"Send startSCM");
        if (this.isInit) {
            this.mServerCommProcessor.reInit();
            return;
        }
        this.start();
    }

    /*
     * Enabled unnecessary exception pruning
     */
    private void supportMultipleBearerNetwork(Context object) {
        Object object2 = ConfigManager.getInstance();
        TelephonyManager telephonyManager = (TelephonyManager)object.getSystemService("phone");
        ConnectivityManager connectivityManager = (ConnectivityManager)object.getSystemService("connectivity");
        if (!this.isMobileDataEnabled((Context)object)) return;
        if ((object2 = ((ConfigManager)object2).getRoamingBearerNetwork()) == null) return;
        if ((object = (PriorityQueue)((HashMap)object2).get((boolean)this.isRoaming((Context)object))) == null) return;
        object = object.iterator();
        while (object.hasNext()) {
            String[] stringArray;
            int n;
            object2 = (BearerNetwork)object.next();
            if (object2 == null || !this.isBearerNetWorkSupported(n = telephonyManager.getNetworkType(), stringArray = new String[1]) || !((BearerNetwork)object2).getBearerNetWorkName().equals(stringArray[0])) continue;
            int n2 = connectivityManager.startUsingNetworkFeature(0, "enableHIPRI");
            if (-1 == n2) {
                Log.e((String)"SUPL20_SCMService", (String)"Wrong result of startUsingNetworkFeature, maybe problems");
                return;
            }
            if (n2 == 0) {
                Log.d((String)"SUPL20_SCMService", (String)"No need to perform additional network settings");
                return;
            }
            for (n = 0; n < 30; ++n) {
                try {
                    int n3 = connectivityManager.getNetworkInfo(5).getState().compareTo(NetworkInfo.State.CONNECTED);
                    if (n3 == 0) break;
                    Thread.sleep(1000L);
                    continue;
                }
                catch (InterruptedException interruptedException) {}
                break;
            }
            n = connectivityManager.getNetworkInfo(5).getState().compareTo(NetworkInfo.State.CONNECTED) == 0 ? 1 : 0;
            Log.d((String)"SUPL20_SCMService", (String)("startUsingNetworkFeature enableHIPRI status" + n2));
            boolean bl = connectivityManager.requestRouteToHost(5, 2130706433);
            Log.d((String)"SUPL20_SCMService", (String)("requestRouteToHost result: " + bl));
            if (!bl) {
                Log.e((String)"SUPL20_SCMService", (String)"Wrong requestRouteToHost result: expected true, but was false");
            }
            if (n != 0) return;
        }
    }

    public IBinder onBind(Intent intent) {
        return this.mBinder;
    }

    public void onCreate() {
        ConfigManager.getInstance();
        Log.d((String)"SUPL20_SCMService", (String)"SUPL20 service version :2.13.2.0");
        this.start();
    }

    public void onDestroy() {
        if (this.mServerCommProcessor != null) {
            if (this.datagramServer != null) {
                this.datagramServer.stop();
            }
            this.mServerCommProcessor.stopListening();
            this.mServerCommProcessor.stopNetWork();
        }
        this.scmThread.interrupt();
        SUPLManager.getInstance(this.mContext).removeGpsListener(this);
    }

    @Override
    public void onGPSLocationProviderDisabled() {
        Log.d((String)"SUPL20_SCMService", (String)" onGPSLocationProviderDisabled");
        if (this.isInit) {
            Log.d((String)"SUPL20_SCMService", (String)"SCM Service is running. Will pause it");
            this.mServerCommProcessor.pause();
            return;
        }
        Log.e((String)"SUPL20_SCMService", (String)"SCM Service not already created");
    }

    @Override
    public void onGPSLocationProviderEnabled() {
        Log.d((String)"SUPL20_SCMService", (String)" onGPSLocationProviderEnabled");
        this.startSCM();
    }

    public void onStart(Intent intent, int n) {
    }

    public int onStartCommand(Intent intent, int n, int n2) {
        return 1;
    }

    public class MyBinder
    extends Binder {
        public SUPLSCMService getService() {
            return SUPLSCMService.this;
        }
    }

    public class SCMConnectionThread
    implements Runnable {
        /*
         * Exception decompiling
         */
        @Override
        public void run() {
            /*
             * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
             * 
             * org.benf.cfr.reader.util.ConfusedCFRException: Back jump on a try block [egrp 2[TRYBLOCK] [17, 18 : 193->204)] java.lang.InterruptedException
             *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.insertExceptionBlocks(Op02WithProcessedDataAndRefs.java:2289)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:414)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
             *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
             *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:910)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1022)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
             *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
             *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
             *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:73)
             *     at org.benf.cfr.reader.Main.main(Main.java:49)
             *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:303)
             *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$null$1(ResourceDecompiling.java:113)
             *     at java.base/java.lang.Thread.run(Unknown Source)
             */
            throw new IllegalStateException("Decompilation failed");
        }
    }
}

