/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.commprocessor;

public class FromServer {
    public byte[] m_bPacket = null;
}

