/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.android.supl.commprocessor;

import android.util.Log;
import com.android.bytewriter.IO;
import com.android.supl.commprocessor.CommandProcessor;
import com.android.supl.commprocessor.FromServer;
import com.android.supl.commprocessor.ServerCommProcessor;
import com.android.supl.config.ConfigManager;
import com.android.supl.nc.NetworkController;
import com.android.supl.nc.SendToServer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class NetworkCommandProcessor
implements CommandProcessor {
    private static final String LOG_TAG = "SUPL20_NetCP";
    private static final int MAX_NETWORK_ID = 255;
    public static int sNetworkID = -1;
    private ConfigManager configManager = ConfigManager.getInstance();
    private HashSet<Integer> netWorkIDSet = null;
    private ServerCommProcessor scp = null;
    private HashMap<String, NetworkController> slpSession = null;

    public NetworkCommandProcessor(ServerCommProcessor serverCommProcessor) {
        this.scp = serverCommProcessor;
    }

    private void removeConnectFailerSession(NetworkController object, String object2) {
        HashMap<String, NetworkController> hashMap = this.slpSession;
        synchronized (hashMap) {
            if (((NetworkController)object).getConnectionCount() == 1) {
                object2 = this.slpSession.remove(object2);
                object = new StringBuilder();
                Log.i((String)LOG_TAG, (String)((StringBuilder)object).append("Removed Session  :").append(object2).toString());
            } else {
                ((NetworkController)object).decrementConnectionCount();
            }
            return;
        }
    }

    public boolean connect(String object, int n, int n2, final int n3, final int n4, int n5, int n6) {
        final NetworkController networkController = this.getSNC((String)object, n, n2);
        object = new Thread((String)object, n, n2, n5, n6){
            final /* synthetic */ int val$iConnTimeOut;
            final /* synthetic */ int val$iHandShakeTimeOut;
            final /* synthetic */ int val$iSecure;
            final /* synthetic */ int val$port;
            final /* synthetic */ String val$stIP;
            {
                this.val$stIP = string;
                this.val$port = n32;
                this.val$iSecure = n42;
                this.val$iHandShakeTimeOut = n5;
                this.val$iConnTimeOut = n6;
            }

            @Override
            public void run() {
                int[] nArray = new int[1];
                if (networkController == null) {
                    Log.e((String)NetworkCommandProcessor.LOG_TAG, (String)("id :" + n3 + " Req id :" + n4 + " is not connect for no more connection allowed"));
                    NetworkCommandProcessor.this.sendNotConnectionStatus(n3, n4, nArray);
                    return;
                }
                String string = NetworkCommandProcessor.this.getNetKey(this.val$stIP, this.val$port, this.val$iSecure, networkController.getNetWorkID());
                Log.i((String)NetworkCommandProcessor.LOG_TAG, (String)("id :" + n3 + " Req id :" + n4 + " is trying to connect to " + networkController.getServerIPAddr()));
                networkController.SetTimeOuts(this.val$iHandShakeTimeOut, this.val$iConnTimeOut);
                networkController.setServer_conn_Timeout_Retries(this.val$iConnTimeOut, 1);
                if (networkController.connect(nArray, false)) {
                    Log.i((String)NetworkCommandProcessor.LOG_TAG, (String)("id :" + n3 + " Req id :" + n4 + " is connected to " + networkController.getServerIPAddr()));
                    NetworkCommandProcessor.this.sendOnConnectionStatus(n3, n4, networkController.getNetWorkID());
                    return;
                }
                Log.e((String)NetworkCommandProcessor.LOG_TAG, (String)("id :" + n3 + " Req id :" + n4 + " is not connected to " + networkController.getServerIPAddr()));
                NetworkCommandProcessor.this.netWorkIDSet.remove(networkController.getNetWorkID());
                NetworkCommandProcessor.this.removeConnectFailerSession(networkController, string);
                NetworkCommandProcessor.this.sendNotConnectionStatus(n3, n4, nArray);
            }
        };
        if (networkController == null) {
            Log.e((String)LOG_TAG, (String)("id :" + n3 + " Req id :" + n4 + " is not connect for no more connection allowed"));
            this.sendNotConnectionStatus(n3, n4, new int[]{1});
            return false;
        }
        networkController.setNetworkCommProceeor(this);
        if (!networkController.isConnected()) {
            ((Thread)object).setName("NetCM connection thread SID:" + n3);
            ((Thread)object).start();
            return false;
        }
        Log.i((String)LOG_TAG, (String)("id :" + n3 + " Req id :" + n4 + " is connected to " + networkController.getServerIPAddr()));
        this.sendOnConnectionStatus(n3, n4, networkController.getNetWorkID());
        return false;
    }

    /*
     * Enabled unnecessary exception pruning
     */
    public void disConnectAllNetWork() {
        Log.d((String)LOG_TAG, (String)"disConnectAllNetWork Entry");
        if (this.slpSession != null) {
            HashMap<String, NetworkController> hashMap = this.slpSession;
            synchronized (hashMap) {
                Object object = new ArrayList(this.slpSession.keySet());
                object = object.iterator();
                while (object.hasNext()) {
                    CharSequence charSequence = (String)object.next();
                    NetworkController networkController = this.slpSession.get(charSequence);
                    networkController.stop(true, null, false);
                    charSequence = new StringBuilder();
                    Log.i((String)LOG_TAG, (String)((StringBuilder)charSequence).append("Stop network ").append(networkController.toString()).toString());
                }
                this.slpSession.clear();
                Log.d((String)LOG_TAG, (String)"Cleared slpSession");
                this.netWorkIDSet.clear();
            }
        }
        Log.d((String)LOG_TAG, (String)"disConnectAllNetWork Exit");
    }

    public void disconnectByNetworkID(int n) {
        if (this.slpSession == null) return;
        HashMap<String, NetworkController> hashMap = this.slpSession;
        synchronized (hashMap) {
            Object object;
            Object object2 = this.slpSession.keySet().iterator();
            do {
                if (!object2.hasNext()) return;
                object = (String)object2.next();
            } while (!((NetworkController)(object = this.slpSession.get(object))).isNetWorkMatch(n));
            object2 = new StringBuilder();
            Log.i((String)LOG_TAG, (String)((StringBuilder)object2).append("Stop network by NeworkID").append(n).toString());
            ((NetworkController)object).stop(true, null, false);
            return;
        }
    }

    public String getNetKey(String string, int n, int n2, int n3) {
        Log.d((String)LOG_TAG, (String)("getNetKey Entry with stIP" + string + "port:" + n + "iSecure:" + n2 + "NWID:" + n3));
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(string);
        stringBuffer.append(n);
        stringBuffer.append(n2);
        return stringBuffer.toString();
    }

    /*
     * Unable to fully structure code
     * Enabled unnecessary exception pruning
     */
    public NetworkController getSNC(String var1_1, int var2_5, int var3_6) {
        Log.d((String)"SUPL20_NetCP", (String)"getSNC Entry");
        if (this.slpSession == null) {
            this.slpSession = new HashMap<K, V>();
        }
        if (this.netWorkIDSet == null) {
            this.netWorkIDSet = new HashSet<E>(1);
        }
        var4_5 = 0;
        var8_6 = null;
        if (NetworkCommandProcessor.sNetworkID == 255) {
            NetworkCommandProcessor.sNetworkID = -1;
        }
        var6_8 = var4_5 + 1;
        var8_6 = this.getNetKey(var1_1, (int)var2_3, (int)var3_4, ++NetworkCommandProcessor.sNetworkID);
        var9_10 = this.slpSession;
        synchronized (var9_10) {
            if (!this.slpSession.containsKey(var8_6)) {
                var8_6 = new NetworkController((int)var3_4, var1_1, (int)var2_3, this, "NetCM read thread", "NetCM write thread", false);
                var4_5 = 0;
                try {
                    do {
                        if (!this.netWorkIDSet.contains(NetworkCommandProcessor.sNetworkID)) {
                            this.netWorkIDSet.add(NetworkCommandProcessor.sNetworkID);
                            var5_7 = true;
                            continue;
                        }
                        var5_7 = false;
                        var7_9 = var4_5 + 1;
                        if (++NetworkCommandProcessor.sNetworkID == 255) {
                            NetworkCommandProcessor.sNetworkID = -1;
                        }
                        var10_11 /* !! */  = new StringBuilder();
                        Log.i((String)"SUPL20_NetCP", (String)var10_11 /* !! */ .append("No free Network id :").append(NetworkCommandProcessor.sNetworkID).toString());
                        var4_5 = var7_9;
                        if (var7_9 != 255) continue;
                        Log.i((String)"SUPL20_NetCP", (String)"Never obtained free Network id ");
                        return null;
                    } while (!var5_7);
                    var10_11 /* !! */  = new StringBuilder();
                    Log.i((String)"SUPL20_NetCP", (String)var10_11 /* !! */ .append("New Network id :").append(NetworkCommandProcessor.sNetworkID).append(" is created").toString());
                    var8_6.setNetWorkID(NetworkCommandProcessor.sNetworkID);
                    var10_11 /* !! */  = this.getNetKey(var1_1, (int)var2_3, (int)var3_4, NetworkCommandProcessor.sNetworkID);
                    this.slpSession.put((String)var10_11 /* !! */ , (NetworkController)var8_6);
lbl45:
                    // 2 sources

                    while (true) {
                        var8_6.upDateConnectionCount();
                        var10_11 /* !! */  = new StringBuilder();
                        Log.d((String)"SUPL20_NetCP", (String)var10_11 /* !! */ .append("getSNC Exit with concount:").append(var8_6.getConnectionCount()).toString());
                        return var8_6;
                    }
                }
                catch (Throwable var1_2) {}
            } else {
                --NetworkCommandProcessor.sNetworkID;
                var8_6 = this.slpSession.get(var8_6);
                ** continue;
            }
            throw var1_2;
        }
    }

    @Override
    public boolean init() {
        return false;
    }

    @Override
    public void process(FromServer fromServer) {
    }

    public void removeFailerSession(String object) {
        HashMap<String, NetworkController> hashMap = this.slpSession;
        synchronized (hashMap) {
            object = this.slpSession.remove(object);
            StringBuilder stringBuilder = new StringBuilder();
            Log.i((String)LOG_TAG, (String)stringBuilder.append("Removed Session  :").append(object).toString());
            return;
        }
    }

    @Override
    public void sendByeMessage() {
    }

    public boolean sendDataByNetworkID(byte[] object, int n) {
        boolean bl = false;
        HashMap<String, NetworkController> hashMap = this.slpSession;
        synchronized (hashMap) {
            boolean bl2;
            NetworkController networkController;
            Object object2 = this.slpSession.keySet().iterator();
            do {
                bl2 = bl;
                if (!object2.hasNext()) return bl2;
                String string = (String)object2.next();
                networkController = this.slpSession.get(string);
                StringBuilder stringBuilder = new StringBuilder();
                Log.i((String)LOG_TAG, (String)stringBuilder.append("nc stNetKey").append(string).toString());
                stringBuilder = new StringBuilder();
                Log.i((String)LOG_TAG, (String)stringBuilder.append("incoming network id =").append(n).append("session networkid =").append(networkController.getNetWorkID()).toString());
            } while (!networkController.isNetWorkMatch(n));
            object2 = new SendToServer();
            ((SendToServer)object2).m_bPacket = object;
            object = new StringBuilder;
            ((StringBuilder)object)();
            Log.i((String)LOG_TAG, (String)((StringBuilder)object).append("NetworkCP Send to server ").append(networkController.toString()).toString());
            networkController.addPacket((SendToServer)object2);
            bl2 = true;
            return bl2;
        }
    }

    @Override
    public void sendHelloMessage() {
    }

    public void sendNotConnectionStatus(int n, int n2, int[] object) {
        byte[] byArray = new byte[15];
        IO.put4(byArray, IO.put1(byArray, IO.put2(byArray, IO.put4(byArray, IO.put4(byArray, 0, 11), 519), n), n2), object[0]);
        object = new FromServer();
        object.m_bPacket = byArray;
        this.writePacket((FromServer)object);
    }

    public void sendOnConnectionStatus(int n, int n2, int n3) {
        Log.i((String)LOG_TAG, (String)"send sendOnConnectionStatus ");
        byte[] byArray = new byte[12];
        IO.put1(byArray, IO.put1(byArray, IO.put2(byArray, IO.put4(byArray, IO.put4(byArray, 0, 8), 518), n), n2), n3);
        FromServer fromServer = new FromServer();
        fromServer.m_bPacket = byArray;
        this.writePacket(fromServer);
    }

    public void sendOnNetWorkSessionClose(int n) {
        Log.i((String)LOG_TAG, (String)("Network id :" + n + " is closed"));
        Object object = new byte[13];
        if (IO.put4(object, IO.put1(object, IO.put4(object, IO.put4(object, 0, 9), 521), n), 0) - 4 != 9) {
            System.out.println(" invalid length");
        }
        Object object2 = new FromServer();
        ((FromServer)object2).m_bPacket = object;
        this.writePacket((FromServer)object2);
        object = this.slpSession;
        synchronized (object) {
            String string;
            Object object3 = this.slpSession.keySet().iterator();
            do {
                if (!object3.hasNext()) return;
            } while (!((NetworkController)(object2 = this.slpSession.get(string = (String)object3.next()))).isNetWorkMatch(n));
            this.slpSession.remove(string);
            this.netWorkIDSet.remove(n);
            object3 = new StringBuilder();
            Log.i((String)LOG_TAG, (String)((StringBuilder)object3).append(((NetworkController)object2).toString()).append(" remove from SLP session ").toString());
            return;
        }
    }

    public String toString() {
        return "NetworkController" + sNetworkID;
    }

    @Override
    public void writePacket(FromServer fromServer) throws NullPointerException {
        SendToServer sendToServer = new SendToServer();
        sendToServer.m_bPacket = fromServer.m_bPacket;
        this.scp.sendServer(sendToServer);
    }
}

