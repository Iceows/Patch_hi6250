/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Message
 *  android.util.Log
 */
package com.android.supl.commprocessor;

import android.os.Handler;
import android.os.Message;
import android.util.Log;
import com.android.bytewriter.IO;
import com.android.supl.commprocessor.CommandProcessor;
import com.android.supl.commprocessor.FromServer;
import com.android.supl.loc.SETLocationManager;
import com.android.supl.nc.NetworkController;
import com.android.supl.nc.SendToServer;
import com.android.supl.nc.SuplServiceMgr;
import com.android.supl.trigger.PeriodicTriggerHandler;
import java.util.Arrays;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import javax.crypto.SecretKey;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class NDKCommProcessor
implements CommandProcessor {
    private static final int EMERGENCY_REGISTER = 1;
    private static final int EMERGENCY_UN_REGISTER = 2;
    private static final int LOCATION_REGISTER = 3;
    private static final int LOCATION_UN_REGISTER = 4;
    private static final String LOG_TAG = "SUPL20_PCM";
    public static final int MASTER_BUFF_LEN = 5000;
    private static final int MSG_PCM_BYE = 256;
    public static final int MSG_PCM_EMERGENCY_CALL = 278;
    public static final int MSG_PCM_GET_HIST_KEY = 282;
    private static final int MSG_PCM_GET_LOCATION_ID = 259;
    public static final int MSG_PCM_GET_OTHER_MEAS = 275;
    private static final int MSG_PCM_GET_SET_ID = 258;
    public static final int MSG_PCM_GET_SIM_MCC_MNC = 280;
    private static final int MSG_PCM_HELLO_TO_PLAT_SRVC = 257;
    private static final int MSG_PCM_HELLO_TO_SUPL_CLIENT = 265;
    private static final int MSG_PCM_ON_SI_FAILURE = 264;
    private static final int MSG_PCM_ON_SI_LOCATION_REPORT = 262;
    public static final int MSG_PCM_ON_SI_SESSION_COMPLETE = 263;
    public static final int MSG_PCM_ON_SYSTEM_SHUTDOWN = 273;
    public static final int MSG_PCM_SYS_IDLE = 274;
    public static final int MSG_PCM_UPDATE_HIST_KEY = 283;
    public static final int MSG_PCM_UPDATE_LOCATION_ID = 267;
    public static final int MSG_PCM_UPDATE_OTHER_MEAS = 276;
    public static final int MSG_PCM_UPDATE_SET_ID = 266;
    public static final int MSG_PCM_UPDATE_SIM_MCC_MNC = 281;
    public static final int MSG_PCM_UPDATE_SLP_CONFIG = 277;
    private static final int PLAT_MSG_HELLO_TO_PLAT_SRVC_MAGIC_CODE = 1398314899;
    private static final int PLAT_MSG_HELLO_TO_SUPL_CLIENT_MAGIC_CODE = 826366246;
    private SecretKey final_key = null;
    private int iLastWritePostion = 0;
    private int iTotalArrival = 0;
    private boolean isPause = false;
    private SETLocationManager locationID_Manager = null;
    private Handler mHandler = new Handler(){

        public void handleMessage(Message message) {
            switch (message.what) {
                case 1: {
                    if (NDKCommProcessor.this.locationID_Manager == null) break;
                    try {
                        NDKCommProcessor.this.locationID_Manager.registerEmergencyReceiver();
                    }
                    catch (IllegalArgumentException illegalArgumentException) {}
                    break;
                }
                case 2: {
                    if (NDKCommProcessor.this.locationID_Manager == null) break;
                    try {
                        NDKCommProcessor.this.locationID_Manager.unregisterEmergencyReceiver();
                    }
                    catch (IllegalArgumentException illegalArgumentException) {}
                    break;
                }
                case 3: {
                    if (NDKCommProcessor.this.locationID_Manager == null) break;
                    NDKCommProcessor.this.locationID_Manager.startLocationIdListener();
                    break;
                }
                case 4: {
                    if (NDKCommProcessor.this.locationID_Manager == null) break;
                    NDKCommProcessor.this.locationID_Manager.stopListening();
                    break;
                }
            }
            super.handleMessage(message);
        }
    };
    private PeriodicTriggerHandler mPeriodicTriggerHandler = null;
    private byte[] m_bMasterBuffer = null;
    private NetworkController nc = null;
    private final Object pauseLock = new Object();
    private ReadPacket readPacket = null;

    static /* synthetic */ boolean -set0(NDKCommProcessor nDKCommProcessor, boolean bl) {
        nDKCommProcessor.isPause = bl;
        return bl;
    }

    public NDKCommProcessor(boolean bl, String string, int n, SETLocationManager sETLocationManager, int n2, int n3) {
        this.msgBufferReset();
        this.nc = new NetworkController(0, string, n, this, "PCM read thread", "PCM write thread", false);
        this.nc.setServer_conn_Timeout_Retries(n2, n3);
        this.readPacket = new ReadPacket("PCM command process thread");
        this.locationID_Manager = sETLocationManager;
        this.locationID_Manager.setCommProcessor(this);
        SuplServiceMgr.getInstance().setPcmCommandProcessor(this);
        this.mPeriodicTriggerHandler = PeriodicTriggerHandler.getInstance();
        this.mPeriodicTriggerHandler.setNdkCommProcessor(this);
    }

    private void msgBufferReset() {
        this.m_bMasterBuffer = new byte[5000];
        Arrays.fill(this.m_bMasterBuffer, (byte)0);
    }

    @Override
    public boolean init() {
        Log.i((String)LOG_TAG, (String)"calling nc.connect for pcm");
        return this.nc.connect(null, false);
    }

    public void pause() {
        Object object = this.mHandler.obtainMessage();
        ((Message)object).what = 2;
        this.mHandler.sendMessage((Message)object);
        object = this.mHandler.obtainMessage();
        ((Message)object).what = 4;
        this.mHandler.sendMessage((Message)object);
        object = new Thread(){

            @Override
            public void run() {
                Object object = NDKCommProcessor.this.pauseLock;
                synchronized (object) {
                    if (NDKCommProcessor.this.isPause) return;
                    Log.i((String)NDKCommProcessor.LOG_TAG, (String)"PCM pause invoked");
                    NDKCommProcessor.this.nc.stop(false, NDKCommProcessor.this.pauseLock, false);
                    try {
                        NDKCommProcessor.this.pauseLock.wait();
                    }
                    catch (InterruptedException interruptedException) {
                        interruptedException.printStackTrace();
                    }
                    Log.i((String)NDKCommProcessor.LOG_TAG, (String)"PCM pauseLock release");
                    NDKCommProcessor.this.readPacket.stopRead();
                    PeriodicTriggerHandler.getInstance().pause();
                    NDKCommProcessor.-set0(NDKCommProcessor.this, true);
                    return;
                }
            }
        };
        ((Thread)object).start();
        try {
            ((Thread)object).join();
            object = new StringBuilder();
            Log.i((String)LOG_TAG, (String)((StringBuilder)object).append("PCM pause finished:").append(this.isPause).toString());
            return;
        }
        catch (InterruptedException interruptedException) {
            Log.e((String)LOG_TAG, (String)interruptedException.getMessage(), (Throwable)interruptedException);
            return;
        }
    }

    /*
     * Exception decompiling
     */
    @Override
    public void process(FromServer var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Back jump on a try block [egrp 3[TRYBLOCK] [4 : 321->364)] java.io.IOException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.insertExceptionBlocks(Op02WithProcessedDataAndRefs.java:2289)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:414)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:73)
         *     at org.benf.cfr.reader.Main.main(Main.java:49)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:303)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$null$1(ResourceDecompiling.java:113)
         *     at java.base/java.lang.Thread.run(Unknown Source)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public void reInit() {
        Object object = this.pauseLock;
        synchronized (object) {
            ReadPacket readPacket;
            if (!this.isPause) return;
            Log.i((String)LOG_TAG, (String)"PCM reInit invoked");
            String string = this.readPacket.getThreadName();
            this.readPacket = readPacket = new ReadPacket(string);
            this.nc.initRead_WriteThread();
            this.isPause = false;
            return;
        }
    }

    @Override
    public void sendByeMessage() {
        SendToServer sendToServer = new SendToServer();
        byte[] byArray = new byte[12];
        IO.put4(byArray, IO.put4(byArray, 0, 8), 256);
        sendToServer.m_bPacket = byArray;
        this.nc.addPacket(sendToServer);
        Log.i((String)LOG_TAG, (String)"sendByeMessage");
    }

    @Override
    public void sendHelloMessage() {
        SendToServer sendToServer = new SendToServer();
        byte[] byArray = new byte[12];
        IO.put4(byArray, IO.put4(byArray, IO.put4(byArray, 0, 8), 265), 826366246);
        sendToServer.m_bPacket = byArray;
        this.nc.addPacket(sendToServer);
        Log.i((String)LOG_TAG, (String)"sendHelloMessage");
        sendToServer = this.mHandler.obtainMessage();
        ((Message)sendToServer).what = 1;
        this.mHandler.sendMessage((Message)sendToServer);
    }

    public void sendServer(SendToServer sendToServer) {
        this.nc.addPacket(sendToServer);
    }

    public void stopNetWork() {
        Log.i((String)LOG_TAG, (String)"PCM stopNetWork invoked");
        this.readPacket.stopRead();
        this.nc.stop(true, null, false);
    }

    public String toString() {
        return this.nc.getServerIPAddr() + " ," + this.nc.getNetWorkID() + " " + this.nc.toString();
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled unnecessary exception pruning
     */
    @Override
    public void writePacket(FromServer var1_1) throws NullPointerException {
        if (var1_1 != null) ** GOTO lbl-1000
        try {
            var1_1 = new NullPointerException("fromServer object must not be null");
            throw var1_1;
        }
        catch (InterruptedException var1_2) {
            Log.e((String)"SUPL20_PCM", (String)var1_2.getMessage(), (Throwable)var1_2);
            return;
        }
lbl-1000:
        // 1 sources

        {
            if (this.readPacket == null) return;
            if (ReadPacket.-get0(this.readPacket) == null) return;
            ReadPacket.-get0(this.readPacket).put(var1_1);
            return;
        }
    }

    /*
     * Illegal identifiers - consider using --renameillegalidents true
     */
    private class ReadPacket
    extends Thread {
        private boolean isStopRead = false;
        private BlockingQueue<FromServer> myJobDeque = new LinkedBlockingQueue<FromServer>();

        static /* synthetic */ BlockingQueue -get0(ReadPacket readPacket) {
            return readPacket.myJobDeque;
        }

        public ReadPacket(String string) {
            this.setName(string);
            this.start();
        }

        public String getThreadName() {
            return this.getName();
        }

        @Override
        public void run() {
            while (!this.isStopRead) {
                try {
                    if (Thread.interrupted()) {
                        return;
                    }
                    FromServer fromServer = this.myJobDeque.take();
                    if (fromServer == null) continue;
                    NDKCommProcessor.this.process(fromServer);
                }
                catch (InterruptedException interruptedException) {
                    Log.i((String)NDKCommProcessor.LOG_TAG, (String)(this.getName() + " allowed to exit"));
                    return;
                }
            }
        }

        public void stopRead() {
            this.interrupt();
            this.isStopRead = true;
        }
    }
}

