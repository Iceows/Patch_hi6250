/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.commprocessor;

import com.android.supl.commprocessor.FromServer;

public interface CommandProcessor {
    public static final int BYE_MSG_LEN = 8;
    public static final int BYTE_SIZE = 1;
    public static final int CANT_RESOLVE_FQDN = 0;
    public static final int CLIENT_NOT_AUTHENTICATED = 3;
    public static final int CONNECTION_ERROR_CODE_CANT_RESOLVE_FQDN = 0;
    public static final int CONNECTION_ERROR_CODE_CLIENT_NOT_AUTHENTICATED = 3;
    public static final int CONNECTION_ERROR_CODE_CONNECTION_FAILURE = 1;
    public static final int CONNECTION_ERROR_CODE_NO_NETWORK = 5;
    public static final int CONNECTION_ERROR_CODE_SERVER_NOT_AUTHENTICATED = 2;
    public static final int CONNECTION_ERROR_CODE_TLS_ERROR = 4;
    public static final int CONNECTION_FAILURE = 1;
    public static final int CONNECT_MSG_LEN = 8;
    public static final int HELLO_MSG_LEN = 8;
    public static final int INT_SIZE = 4;
    public static final int LONG_SIZE = 8;
    public static final int MSG_CODE_LEN = 4;
    public static final int MSG_COMMON_ALIVE = 768;
    public static final int NW_SEESSIONID_LEN = 1;
    public static final int ON_COMM_INTERFACE_STATUS_CHANGE_MSG_LEN = 8;
    public static final int ON_NOT_CONNECT_MSG_LEN = 11;
    public static final int ON_NW_SESSION_CLOSED_MSG_LEN = 9;
    public static final int PACKET_LEN = 4;
    public static final int REC_BUFF_LEN = 4;
    public static final int REQ_ID_LEN = 1;
    public static final int SERVER_NOT_AUTHENTICATED = 2;
    public static final int SHORT_SIZE = 2;

    public boolean init();

    public void process(FromServer var1);

    public void sendByeMessage();

    public void sendHelloMessage();

    public void writePacket(FromServer var1) throws NullPointerException;
}

