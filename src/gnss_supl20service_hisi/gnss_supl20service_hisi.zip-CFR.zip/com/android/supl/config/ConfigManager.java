/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.android.supl.config;

import android.util.Log;
import com.android.bytewriter.IO;
import com.android.supl.bearer.BearerNetwork;
import com.android.supl.bearer.BearerNetworkComparater;
import com.android.supl.config.NetworkConnectionParam;
import java.util.HashMap;
import java.util.PriorityQueue;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class ConfigManager
extends DefaultHandler {
    private static final String BEARER_NETWORK_ENABLE = "bearer_network_enable";
    private static final String BEARER_NETWORK_PRIORITY = "bearer_network_priority";
    private static final String BEARER_NETWORK_SUPPORT = "bearer_network_support";
    public static final String CDMA = "cdma";
    private static final String CERT = "cert";
    private static final String CHECK_GPS = "checkgps";
    private static final String CI = "ci";
    private static final String CONFIG_START = "config_start";
    private static final String CUST_SUPL_CONFIG_PATH = "/data/cust/xml/gnss_suplconfig_hisi.xml";
    private static final String DEFAULT_SUPL_CONFIG_PATH = "/vendor/etc/gnss/config/gnss_suplconfig_hisi.xml";
    private static final String FILLTAANDNMR = "filltaandnmr";
    private static final String FORCETESTVALUE = "forcetestvalue";
    public static final String GSM = "gsm";
    public static final String HRPD = "hrpd";
    private static final String IPADDRESS = "ipaddress";
    private static final String LAC = "lac";
    public static final String LTE = "lte";
    private static final String MCC = "mcc";
    private static final String MNC = "mnc";
    private static final String MSISDN = "msisdn";
    private static final String NETCONT_PARAMS = "netcont_params";
    private static final String NI_UDP_ENABLED = "ni_udp_enabled";
    private static final String NMR = "nmr";
    private static final String NW_RETRIES = "nw_retries";
    private static final String NW_TIMEOUT = "nw_timeout";
    private static final String PATH = "path";
    private static final String PCM = "pcm";
    private static final String PORT = "port";
    private static final String PREF_SETID = "pref_setid";
    private static final String PWD = "pwd";
    private static final String SCM = "scm";
    private static String ST_LOG;
    public static final String SUPL_Services_Version = "2.13.2.0";
    private static final String SUPL_VERSION = "suplver";
    private static final String SWITCH_APN_ENABLE = "switch_apn_enable";
    private static final String TA = "ta";
    public static final String UMB = "umb";
    private static final String UNIXSOCPATH = "unixsocketpath";
    private static final String VALID = "valid";
    public static final String WCDMA = "wcdma";
    public static final String WIMAX = "wimax";
    public static final String WLAN = "wlan";
    private static ConfigManager sConfigManager;
    private int iConfigStartVersion = 0;
    private int iSUPLVersion = 1;
    private boolean isBearNetworkFound = false;
    private boolean isCertFound = false;
    private boolean isCertVaild = false;
    private boolean isCheckGPSEnabled = false;
    private boolean isForceTest = false;
    private boolean isMultipleBearNetworkSupport = false;
    private boolean isMultipleBearNetworkSupportRoaming = false;
    private boolean isNiUdpEnabled = false;
    private boolean isPCMFound = false;
    private boolean isRequiredTag = false;
    private boolean isSCMFound = false;
    private boolean isSwitchApnEnabled = false;
    private BearerNetworkComparater mComparater = new BearerNetworkComparater();
    private NetworkConnectionParam m_connectionParam = null;
    private PriorityQueue<BearerNetwork> queue = null;
    private HashMap<Boolean, PriorityQueue<BearerNetwork>> roamingBearerNetwork = null;
    private String stCurrentBearerNetWork = null;
    private String stData = null;
    private String stKeyStoreConv = "format-convert";
    private String stKeyStorePath = null;
    private String stPerfSetId = null;
    private String stPrivateKeyStore = null;
    private String stPrivateKeyStoreConv = null;
    private ForceTestValue testValue = null;

    static {
        sConfigManager = null;
        ST_LOG = "SUPL20_Config";
    }

    private ConfigManager() {
        this.init();
        if (this.m_connectionParam != null) {
            Log.i((String)ST_LOG, (String)this.m_connectionParam.toString());
        }
        this.setKeyStore_ConvFromConfig();
    }

    public static ConfigManager getInstance() {
        synchronized (ConfigManager.class) {
            ConfigManager configManager;
            if (sConfigManager == null) {
                sConfigManager = configManager = new ConfigManager();
            }
            configManager = sConfigManager;
            return configManager;
        }
    }

    private void setKeyStore_ConvFromConfig() {
        this.stPrivateKeyStore = this.getKeyStorePath();
        this.stPrivateKeyStoreConv = this.getKeyStoreConv();
    }

    @Override
    public void characters(char[] cArray, int n, int n2) throws SAXException {
        if (!this.isRequiredTag) return;
        this.stData = new String(cArray, n, n2).trim();
        this.isRequiredTag = false;
    }

    public boolean checkGPSEnabled() {
        return this.isCheckGPSEnabled;
    }

    /*
     * Enabled unnecessary exception pruning
     */
    @Override
    public void endElement(String object, String charSequence, String string) throws SAXException {
        boolean bl;
        boolean bl2;
        block45: {
            boolean bl3 = true;
            boolean bl4 = true;
            bl2 = true;
            bl = true;
            boolean bl5 = true;
            try {
                if (((String)charSequence).equals(SUPL_VERSION)) {
                    if (this.stData == null) return;
                    this.iSUPLVersion = Integer.parseInt(this.stData);
                    charSequence = ST_LOG;
                    object = new StringBuilder();
                    Log.i((String)charSequence, (String)((StringBuilder)object).append(" supl version ").append(this.iSUPLVersion).toString());
                    return;
                }
                if (this.iConfigStartVersion != this.iSUPLVersion) return;
                if (((String)charSequence).equals(SWITCH_APN_ENABLE)) {
                    if (this.stData == null) return;
                    this.isSwitchApnEnabled = "true".equals(this.stData);
                    return;
                }
                if (((String)charSequence).equals(PREF_SETID)) {
                    if (this.stData == null) return;
                    this.stPerfSetId = this.stData;
                    charSequence = ST_LOG;
                    object = new StringBuilder();
                    Log.i((String)charSequence, (String)((StringBuilder)object).append("pref_setid is ").append(this.stPerfSetId).toString());
                    return;
                }
                if (((String)charSequence).equals(NW_TIMEOUT)) {
                    if (this.m_connectionParam == null) return;
                    this.m_connectionParam.m_iConnectionTimeOut = Integer.parseInt(this.stData);
                    return;
                }
                if (((String)charSequence).equals(NW_RETRIES)) {
                    if (this.m_connectionParam == null) return;
                    this.m_connectionParam.m_iConnectionRetries = Integer.parseInt(this.stData);
                    return;
                }
                if (((String)charSequence).equals(PCM)) {
                    this.isPCMFound = false;
                    return;
                }
                if (((String)charSequence).equals(SCM)) {
                    this.isSCMFound = false;
                    return;
                }
                if (((String)charSequence).equals(PORT)) {
                    if (this.m_connectionParam != null && this.isPCMFound) {
                        this.m_connectionParam.m_iPCMPort = Integer.parseInt(this.stData);
                        return;
                    }
                    if (this.m_connectionParam == null) return;
                    if (!this.isSCMFound) return;
                    this.m_connectionParam.m_iSCMPort = Integer.parseInt(this.stData);
                    return;
                }
                if (((String)charSequence).equals(IPADDRESS)) {
                    if (this.m_connectionParam != null && this.isPCMFound) {
                        if (this.stData == null) return;
                        this.m_connectionParam.m_stPCMFQDN = this.stData;
                        return;
                    }
                    if (this.m_connectionParam == null) return;
                    if (!this.isSCMFound) return;
                    if (this.stData == null) return;
                    this.m_connectionParam.m_stSCMFQDN = this.stData;
                    return;
                }
                if (((String)charSequence).equals(UNIXSOCPATH)) {
                    if (this.m_connectionParam != null && this.isPCMFound) {
                        charSequence = ST_LOG;
                        object = new StringBuilder();
                        Log.i((String)charSequence, (String)((StringBuilder)object).append("pcm socketpath is ").append(this.m_connectionParam.m_sPCMUnixSocPath).toString());
                        return;
                    }
                    if (this.m_connectionParam == null) return;
                    if (!this.isSCMFound) return;
                    object = ST_LOG;
                    charSequence = new StringBuilder();
                    Log.i((String)object, (String)((StringBuilder)charSequence).append("scm socketpath is ").append(this.m_connectionParam.m_sSCMUnixSocPath).toString());
                    return;
                }
                if (((String)charSequence).equals(NI_UDP_ENABLED)) {
                    bl2 = Integer.parseInt(this.stData) > 0 ? bl5 : false;
                    this.isNiUdpEnabled = bl2;
                    object = ST_LOG;
                    charSequence = new StringBuilder();
                    Log.i((String)object, (String)((StringBuilder)charSequence).append("UDP socket enabled = ").append(this.isNiUdpEnabled).toString());
                    return;
                }
                if (((String)charSequence).equals(CERT)) {
                    this.isCertFound = false;
                    return;
                }
                if (((String)charSequence).equals(VALID)) {
                    if (!this.isCertFound) return;
                    bl2 = Integer.parseInt(this.stData) > 0 ? bl3 : false;
                    this.isCertVaild = bl2;
                    return;
                }
                if (((String)charSequence).equals(PATH)) {
                    if (!this.isCertFound) return;
                    if (!this.isCertVaild) return;
                    if (this.stData == null) return;
                    this.stKeyStorePath = this.stData;
                    return;
                }
                if (((String)charSequence).equals(PWD)) {
                    if (!this.isCertFound) return;
                    if (!this.isCertVaild) return;
                    if (this.stData == null) return;
                    this.stKeyStoreConv = this.stData;
                    return;
                }
                if (((String)charSequence).equals(FORCETESTVALUE)) {
                    if (Integer.parseInt(this.stData) != 1) return;
                    this.testValue = object = new ForceTestValue();
                    return;
                }
                if (this.testValue != null && ((String)charSequence).equals(MCC)) {
                    this.testValue.iMcc = Integer.parseInt(this.stData);
                    return;
                }
                if (this.testValue != null && ((String)charSequence).equals(MNC)) {
                    this.testValue.iMnc = Integer.parseInt(this.stData);
                    return;
                }
                if (this.testValue != null && ((String)charSequence).equals(LAC)) {
                    this.testValue.iLac = Integer.parseInt(this.stData);
                    return;
                }
                if (this.testValue != null && ((String)charSequence).equals(CI)) {
                    this.testValue.iCI = Integer.parseInt(this.stData);
                    return;
                }
                if (this.testValue != null && ((String)charSequence).equals(MSISDN)) {
                    this.testValue.iMSISDN = Long.parseLong(this.stData);
                    return;
                }
                if (this.testValue != null && ((String)charSequence).equals(FILLTAANDNMR)) {
                    object = this.testValue;
                    bl2 = Integer.parseInt(this.stData) == 1 ? bl4 : false;
                    ((ForceTestValue)object).isFillTAandNMR = bl2;
                    return;
                }
                if (this.testValue != null && ((String)charSequence).equals(TA)) {
                    this.testValue.iTA = Integer.parseInt(this.stData);
                    return;
                }
                if (this.testValue != null && ((String)charSequence).equals(NMR)) {
                    if (this.stData == null) return;
                    charSequence = this.stData.split(",");
                    object = new int[((CharSequence)charSequence).length];
                    int n = ((CharSequence)charSequence).length;
                    int n2 = 0;
                    for (int i = 0; i < n; ++i, ++n2) {
                        object[n2] = (HashMap)Integer.parseInt((String)charSequence[i]);
                    }
                    this.testValue.aNMR = (int[])object;
                    return;
                }
                bl5 = ((String)charSequence).equals(CHECK_GPS);
                if (!bl5) break block45;
            }
            catch (NumberFormatException numberFormatException) {
                Log.e((String)ST_LOG, (String)"NumberFormatException error ");
                return;
            }
            try {
                if (Integer.parseInt(this.stData) != 1) {
                    bl2 = false;
                }
                this.isCheckGPSEnabled = bl2;
                return;
            }
            catch (NumberFormatException numberFormatException) {
                return;
            }
        }
        if (((String)charSequence).equals(BEARER_NETWORK_ENABLE)) {
            bl2 = Integer.parseInt(this.stData) == 1 ? bl : false;
            this.isMultipleBearNetworkSupport = bl2;
            if (!this.isMultipleBearNetworkSupport) return;
            object = new HashMap(2);
            this.roamingBearerNetwork = object;
            return;
        }
        if (((String)charSequence).equals(BEARER_NETWORK_SUPPORT)) {
            this.queue = null;
            this.isBearNetworkFound = false;
            return;
        }
        if (!this.isBearNetworkFound) return;
        if (((String)charSequence).equals(WLAN)) {
            if (!this.isMultipleBearNetworkSupport) return;
            object = new BearerNetwork(WLAN, Integer.parseInt(this.stData));
            this.queue.add((BearerNetwork)object);
            return;
        }
        if (((String)charSequence).equals(LTE)) {
            if (!this.isMultipleBearNetworkSupport) return;
            object = new BearerNetwork(LTE, Integer.parseInt(this.stData));
            this.queue.add((BearerNetwork)object);
            return;
        }
        if (((String)charSequence).equals(GSM)) {
            if (!this.isMultipleBearNetworkSupport) return;
            object = new BearerNetwork(GSM, Integer.parseInt(this.stData));
            this.queue.add((BearerNetwork)object);
            return;
        }
        if (((String)charSequence).equals(CDMA)) {
            if (!this.isMultipleBearNetworkSupport) return;
            object = new BearerNetwork(CDMA, Integer.parseInt(this.stData));
            this.queue.add((BearerNetwork)object);
            return;
        }
        if (((String)charSequence).equals(WCDMA)) {
            if (!this.isMultipleBearNetworkSupport) return;
            object = new BearerNetwork(WCDMA, Integer.parseInt(this.stData));
            this.queue.add((BearerNetwork)object);
            return;
        }
        if (((String)charSequence).equals(UMB)) {
            if (!this.isMultipleBearNetworkSupport) return;
            object = new BearerNetwork(UMB, Integer.parseInt(this.stData));
            this.queue.add((BearerNetwork)object);
            return;
        }
        if (((String)charSequence).equals(WIMAX)) {
            if (!this.isMultipleBearNetworkSupport) return;
            object = new BearerNetwork(WIMAX, Integer.parseInt(this.stData));
            this.queue.add((BearerNetwork)object);
            return;
        }
        if (!((String)charSequence).equals(HRPD)) return;
        if (!this.isMultipleBearNetworkSupport) return;
        object = new BearerNetwork(HRPD, Integer.parseInt(this.stData));
        this.queue.add((BearerNetwork)object);
    }

    public byte[] getForceTestvalue() {
        byte[] byArray = null;
        if (this.testValue == null) return byArray;
        return this.testValue.getForceTest();
    }

    public String getKeyStoreConv() {
        return this.stKeyStoreConv;
    }

    public String getKeyStorePath() {
        return this.stKeyStorePath;
    }

    public int getNwRetries() {
        int n = 5;
        if (this.m_connectionParam == null) return n;
        return this.m_connectionParam.m_iConnectionRetries;
    }

    public int getNwTimeout() {
        int n = 5000;
        if (this.m_connectionParam == null) return n;
        return this.m_connectionParam.m_iConnectionTimeOut;
    }

    public String getPCMIpAdress() {
        String string = "127.0.0.1";
        if (this.m_connectionParam == null) return string;
        return this.m_connectionParam.m_stPCMFQDN;
    }

    public int getPCMPort() {
        int n = 9001;
        if (this.m_connectionParam == null) return n;
        return this.m_connectionParam.m_iPCMPort;
    }

    public String getPCMUnixSocketPath() {
        String string = "/data/gnss/pcm_soc";
        if (this.m_connectionParam == null) return string;
        return this.m_connectionParam.m_sPCMUnixSocPath;
    }

    public String getPrefSetId() {
        return this.stPerfSetId;
    }

    public String getPrivateKeyStore() {
        return this.stPrivateKeyStore;
    }

    public String getPrivateKeyStoreConv() {
        return this.stPrivateKeyStoreConv;
    }

    public HashMap<Boolean, PriorityQueue<BearerNetwork>> getRoamingBearerNetwork() {
        return this.roamingBearerNetwork;
    }

    public String getSCMIpAdress() {
        String string = "127.0.0.1";
        if (this.m_connectionParam == null) return string;
        return this.m_connectionParam.m_stSCMFQDN;
    }

    public int getSCMPort() {
        int n = 9002;
        if (this.m_connectionParam == null) return n;
        return this.m_connectionParam.m_iSCMPort;
    }

    public String getSCMUnixSocketPath() {
        String string = "/data/gnss/scm_soc";
        if (this.m_connectionParam == null) return string;
        return this.m_connectionParam.m_sSCMUnixSocPath;
    }

    public int getSUPLVersion() {
        return this.iSUPLVersion;
    }

    /*
     * Exception decompiling
     */
    public void init() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:412)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:487)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:845)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:73)
         *     at org.benf.cfr.reader.Main.main(Main.java:49)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:303)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$null$1(ResourceDecompiling.java:113)
         *     at java.base/java.lang.Thread.run(Unknown Source)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public boolean isCertVaild() {
        return this.isCertVaild;
    }

    public boolean isForceTest() {
        return this.isForceTest;
    }

    public boolean isMultipleBearNetworkSupport() {
        return this.isMultipleBearNetworkSupport;
    }

    public boolean isNiUdpEnabled() {
        return this.isNiUdpEnabled;
    }

    @Override
    public void startElement(String string, String string2, String string3, Attributes attributes) throws SAXException {
        boolean bl = true;
        if (string2.equals(SUPL_VERSION)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(CONFIG_START)) {
            try {
                this.iConfigStartVersion = Math.round(Float.parseFloat(attributes.getValue("", "version")));
                return;
            }
            catch (NumberFormatException numberFormatException) {
                return;
            }
            catch (NullPointerException nullPointerException) {
                return;
            }
        }
        if (this.iConfigStartVersion != this.iSUPLVersion) return;
        if (string2.equals(SWITCH_APN_ENABLE)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(PREF_SETID)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(NETCONT_PARAMS)) {
            this.m_connectionParam = new NetworkConnectionParam();
            return;
        }
        if (string2.equals(NW_TIMEOUT)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(NW_RETRIES)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(PCM)) {
            this.isPCMFound = true;
            return;
        }
        if (string2.equals(SCM)) {
            this.isSCMFound = true;
            return;
        }
        if (string2.equals(PORT)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(IPADDRESS)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(UNIXSOCPATH)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(NI_UDP_ENABLED)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(CERT)) {
            this.isCertFound = true;
            return;
        }
        if (string2.equals(VALID)) {
            if (!this.isCertFound) return;
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(PATH)) {
            if (!this.isCertFound) return;
            if (!this.isCertVaild) return;
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(PWD)) {
            if (!this.isCertFound) return;
            if (!this.isCertVaild) return;
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(FORCETESTVALUE)) {
            this.isRequiredTag = true;
            return;
        }
        if (this.testValue != null && string2.equals(MCC)) {
            this.isRequiredTag = true;
            return;
        }
        if (this.testValue != null && string2.equals(MNC)) {
            this.isRequiredTag = true;
            return;
        }
        if (this.testValue != null && string2.equals(LAC)) {
            this.isRequiredTag = true;
            return;
        }
        if (this.testValue != null && string2.equals(CI)) {
            this.isRequiredTag = true;
            return;
        }
        if (this.testValue != null && string2.equals(MSISDN)) {
            this.isRequiredTag = true;
            return;
        }
        if (this.testValue != null && string2.equals(FILLTAANDNMR)) {
            this.isRequiredTag = true;
            return;
        }
        if (this.testValue != null && string2.equals(TA)) {
            this.isRequiredTag = true;
            return;
        }
        if (this.testValue != null && string2.equals(NMR)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(CHECK_GPS)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(BEARER_NETWORK_ENABLE)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(BEARER_NETWORK_SUPPORT)) {
            this.isBearNetworkFound = true;
            if (Integer.parseInt(attributes.getValue("", "roaming")) != 1) {
                bl = false;
            }
            this.isMultipleBearNetworkSupportRoaming = bl;
            if (!this.isMultipleBearNetworkSupport) return;
            this.queue = new PriorityQueue<BearerNetwork>(10, this.mComparater);
            this.roamingBearerNetwork.put(this.isMultipleBearNetworkSupportRoaming, this.queue);
            return;
        }
        if (!this.isBearNetworkFound) return;
        if (string2.equals(WLAN)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(LTE)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(GSM)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(CDMA)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(WCDMA)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(UMB)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(WIMAX)) {
            this.isRequiredTag = true;
            return;
        }
        if (!string2.equals(HRPD)) return;
        this.isRequiredTag = true;
    }

    public boolean switchApnEnabled() {
        return this.isSwitchApnEnabled;
    }

    public class ForceTestValue {
        public int[] aNMR = null;
        public int iCI = 0;
        public int iLac = 0;
        public long iMSISDN = 0L;
        public int iMcc = 0;
        public int iMnc = 0;
        public int iTA = 0;
        public boolean isFillTAandNMR = false;

        public byte[] getForceTest() {
            int n = 0;
            int n2 = 32;
            if (this.isFillTAandNMR) {
                n2 = 36;
            }
            int n3 = n2;
            if (this.aNMR != null) {
                n3 = n2 + 4 + this.aNMR.length * 4;
            }
            byte[] byArray = new byte[n3];
            n3 = IO.put8(byArray, IO.put4(byArray, IO.put4(byArray, IO.put4(byArray, IO.put4(byArray, IO.put4(byArray, IO.put4(byArray, 0, 111), n3 - 4), this.iMcc), this.iMnc), this.iLac), this.iCI), this.iMSISDN);
            n2 = this.isFillTAandNMR ? 1 : 0;
            n2 = n3 = IO.put4(byArray, n3, n2);
            if (this.isFillTAandNMR) {
                n2 = IO.put4(byArray, n3, this.iTA);
            }
            if (this.aNMR == null) {
                IO.put4(byArray, n2, 0);
                return byArray;
            }
            n3 = IO.put4(byArray, n2, this.aNMR.length);
            int[] nArray = this.aNMR;
            int n4 = nArray.length;
            n2 = n;
            while (n2 < n4) {
                n3 = IO.put4(byArray, n3, nArray[n2]);
                ++n2;
            }
            return byArray;
        }
    }
}

