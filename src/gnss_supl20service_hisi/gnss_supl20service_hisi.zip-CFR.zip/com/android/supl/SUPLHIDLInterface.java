/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.IHwBinder$DeathRecipient
 *  android.os.RemoteException
 */
package com.android.supl;

import android.content.Context;
import android.os.IHwBinder;
import android.os.RemoteException;
import com.android.supl.Log;
import com.android.supl.commprocessor.FromServer;
import com.android.supl.nc.SendToServer;
import com.android.supl.nc.SuplServiceMgr;
import vendor.huawei.hardware.hisupl.V1_0.ISuplclienttoserverCallbacks;
import vendor.huawei.hardware.hisupl.V1_0.ISuplclienttoserverInterface;
import vendor.huawei.hardware.hisupl.V1_0.client2server;
import vendor.huawei.hardware.hisupl.V1_0.server2client;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class SUPLHIDLInterface {
    private static final String LOG_TAG = "SUPLHIDL";
    private static HiSuplCallback mHiSuplCb;
    private static SUPLHIDLInterface mSUPLHIDLInterface;
    private static final Object sWatcherLock;
    private Context mContext;
    private HidlServiceDeathHandler mHidlDeathHandler;
    private ISuplclienttoserverInterface mISupl = null;
    private final Object mObject = new Object();
    private SuplServiceMgr mSuplServiceMgr = null;

    static /* synthetic */ ISuplclienttoserverInterface -set0(SUPLHIDLInterface sUPLHIDLInterface, ISuplclienttoserverInterface iSuplclienttoserverInterface) {
        sUPLHIDLInterface.mISupl = iSuplclienttoserverInterface;
        return iSuplclienttoserverInterface;
    }

    static {
        sWatcherLock = new Object();
        mHiSuplCb = null;
    }

    public SUPLHIDLInterface(Context context) {
        this.mContext = context;
        mHiSuplCb = new HiSuplCallback();
        Log.d(LOG_TAG, "getISuplService");
        this.getISuplService();
    }

    public static SUPLHIDLInterface createSUPLHIDLInterface(Context context) {
        Object object = sWatcherLock;
        synchronized (object) {
            SUPLHIDLInterface sUPLHIDLInterface;
            if (mSUPLHIDLInterface != null) return mSUPLHIDLInterface;
            Log.i(LOG_TAG, "new one");
            mSUPLHIDLInterface = sUPLHIDLInterface = new SUPLHIDLInterface(context);
            return mSUPLHIDLInterface;
        }
    }

    /*
     * Enabled unnecessary exception pruning
     * Converted monitor instructions to comments
     */
    private void getISuplService() {
        // MONITORENTER : this
        if (this.mISupl != null) {
            Log.d(LOG_TAG, "Get getISuplService service not null.");
            // MONITOREXIT : this
            return;
        }
        try {
            this.mISupl = ISuplclienttoserverInterface.getService();
            if (this.mISupl != null) {
                HidlServiceDeathHandler hidlServiceDeathHandler;
                Log.d(LOG_TAG, "Get mISupl service success.");
                this.mISupl.setCallback(mHiSuplCb);
                this.mHidlDeathHandler = hidlServiceDeathHandler = new HidlServiceDeathHandler();
                this.mISupl.linkToDeath(this.mHidlDeathHandler, 0L);
                // MONITOREXIT : this
                return;
            }
            Log.d(LOG_TAG, "mISupl return null");
            return;
        }
        catch (RemoteException remoteException) {
            StringBuilder stringBuilder = new StringBuilder();
            Log.e(LOG_TAG, stringBuilder.append("Exception getting ISupl: ").append(remoteException.getMessage()).toString());
            return;
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            Log.e(LOG_TAG, stringBuilder.append("Exception: ").append(exception.getMessage()).toString());
            return;
        }
    }

    /*
     * Enabled unnecessary exception pruning
     * Converted monitor instructions to comments
     */
    public void SendMsg2PCM(SendToServer sendToServer) {
        // MONITORENTER : this
        if (sendToServer != null && sendToServer.m_bPacket != null && sendToServer.m_iPacketSize < 16384) {
            client2server client2server2 = new client2server();
            client2server2.packetSize = sendToServer.m_bPacket.length;
            System.arraycopy((byte[])sendToServer.m_bPacket, (int)0, (byte[])client2server2.c2s_packet, (int)0, (int)client2server2.packetSize);
            try {
                if (this.mISupl != null) {
                    this.mISupl.suplPlatformServiceSend2server(client2server2);
                    Log.i(LOG_TAG, "suplPlatformServiceSend2server send.");
                }
                // MONITOREXIT : this
                return;
            }
            catch (RemoteException remoteException) {
                remoteException.printStackTrace();
                return;
            }
        }
        Log.e(LOG_TAG, "msg is null or msg size too big");
    }

    /*
     * Enabled unnecessary exception pruning
     * Converted monitor instructions to comments
     */
    public void SendMsg2SCM(SendToServer sendToServer) {
        // MONITORENTER : this
        if (sendToServer != null && sendToServer.m_bPacket != null && sendToServer.m_bPacket.length < 16384) {
            client2server client2server2 = new client2server();
            client2server2.packetSize = sendToServer.m_bPacket.length;
            System.arraycopy((byte[])sendToServer.m_bPacket, (int)0, (byte[])client2server2.c2s_packet, (int)0, (int)client2server2.packetSize);
            try {
                if (this.mISupl != null) {
                    this.mISupl.suplCommServiceSend2server(client2server2);
                    Log.i(LOG_TAG, "suplCommServiceSend2server send.");
                }
                // MONITOREXIT : this
                return;
            }
            catch (RemoteException remoteException) {
                remoteException.printStackTrace();
                return;
            }
        }
        Log.e(LOG_TAG, "msg is null or msg size too big");
    }

    public void setSuplServiceMgr(SuplServiceMgr suplServiceMgr) {
        this.mSuplServiceMgr = suplServiceMgr;
    }

    class HiSuplCallback
    extends ISuplclienttoserverCallbacks.Stub {
        HiSuplCallback() {
        }

        @Override
        public void suplPcmCb(server2client server2client2) throws RemoteException {
            Object object = SUPLHIDLInterface.this.mObject;
            synchronized (object) {
                Log.d(SUPLHIDLInterface.LOG_TAG, "suplPcmCb enter");
                FromServer fromServer = new FromServer();
                fromServer.m_bPacket = new byte[server2client2.packetSize];
                System.arraycopy((byte[])server2client2.s2c_packet, (int)0, (byte[])fromServer.m_bPacket, (int)0, (int)server2client2.packetSize);
                if (SUPLHIDLInterface.this.mSuplServiceMgr != null) {
                    SUPLHIDLInterface.this.mSuplServiceMgr.addPcmPacket(fromServer);
                } else {
                    Log.e(SUPLHIDLInterface.LOG_TAG, "mSuplServiceMgr is null");
                }
                return;
            }
        }

        @Override
        public void suplScmCb(server2client server2client2) throws RemoteException {
            Object object = SUPLHIDLInterface.this.mObject;
            synchronized (object) {
                Log.d(SUPLHIDLInterface.LOG_TAG, "suplScmCb enter.");
                FromServer fromServer = new FromServer();
                fromServer.m_bPacket = new byte[server2client2.packetSize];
                System.arraycopy((byte[])server2client2.s2c_packet, (int)0, (byte[])fromServer.m_bPacket, (int)0, (int)server2client2.packetSize);
                if (SUPLHIDLInterface.this.mSuplServiceMgr != null) {
                    SUPLHIDLInterface.this.mSuplServiceMgr.addScmPacket(fromServer);
                } else {
                    Log.e(SUPLHIDLInterface.LOG_TAG, "mSuplServiceMgr is null");
                }
                return;
            }
        }
    }

    private class HidlServiceDeathHandler
    implements IHwBinder.DeathRecipient {
        private HidlServiceDeathHandler() {
        }

        public void serviceDied(long l) {
            try {
                Log.d(SUPLHIDLInterface.LOG_TAG, "HISUPL server died.");
                if (SUPLHIDLInterface.this.mISupl == null) return;
                Log.d(SUPLHIDLInterface.LOG_TAG, "HISUPL server died 00.");
                SUPLHIDLInterface.this.mISupl.unlinkToDeath(SUPLHIDLInterface.this.mHidlDeathHandler);
                Log.d(SUPLHIDLInterface.LOG_TAG, "HISUPL server died 01.");
                SUPLHIDLInterface.-set0(SUPLHIDLInterface.this, null);
                return;
            }
            catch (RemoteException remoteException) {
                Log.e(SUPLHIDLInterface.LOG_TAG, "Exception unlinkToDeath: " + remoteException.getMessage());
                return;
            }
        }
    }
}

