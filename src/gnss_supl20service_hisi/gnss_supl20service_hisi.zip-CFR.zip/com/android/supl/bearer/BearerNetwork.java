/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.bearer;

public class BearerNetwork {
    private int iPriority = 0;
    private String stBearerNetWorkName = null;

    public BearerNetwork(String string, int n) {
        this.stBearerNetWorkName = string;
        this.iPriority = n;
    }

    public String getBearerNetWorkName() {
        return this.stBearerNetWorkName;
    }

    public int getPriority() {
        return this.iPriority;
    }

    public String toString() {
        return this.stBearerNetWorkName + ":" + this.iPriority;
    }
}

