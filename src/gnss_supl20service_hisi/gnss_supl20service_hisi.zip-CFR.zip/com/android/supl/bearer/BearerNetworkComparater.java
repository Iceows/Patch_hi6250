/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.bearer;

import com.android.supl.bearer.BearerNetwork;
import java.util.Comparator;

public class BearerNetworkComparater
implements Comparator<BearerNetwork> {
    @Override
    public int compare(BearerNetwork bearerNetwork, BearerNetwork bearerNetwork2) {
        if (bearerNetwork.getPriority() > bearerNetwork2.getPriority()) {
            return -1;
        }
        if (bearerNetwork.getPriority() >= bearerNetwork2.getPriority()) return 0;
        return 1;
    }
}

