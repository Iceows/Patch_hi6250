/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.nc;

public class SendToServer {
    public byte[] m_bPacket = null;
    public int m_iPacketSize = 0;
    public int m_iPacketType = 0;
}

