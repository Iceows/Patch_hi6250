/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.ConnectivityManager
 *  android.net.ConnectivityManager$NetworkCallback
 *  android.net.LocalSocket
 *  android.net.LocalSocketAddress
 *  android.net.LocalSocketAddress$Namespace
 *  android.net.Network
 *  android.net.NetworkInfo
 *  android.net.NetworkRequest
 *  android.net.NetworkRequest$Builder
 *  android.util.Log
 */
package com.android.supl.nc;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LocalSocket;
import android.net.LocalSocketAddress;
import android.net.Network;
import android.net.NetworkInfo;
import android.net.NetworkRequest;
import android.util.Log;
import com.android.supl.SuplApplication;
import com.android.supl.commprocessor.CommandProcessor;
import com.android.supl.commprocessor.NetworkCommandProcessor;
import com.android.supl.config.ConfigManager;
import com.android.supl.nc.MySSLSocketFactory;
import com.android.supl.nc.ReaderThread;
import com.android.supl.nc.SSLX509TrustManager;
import com.android.supl.nc.SendToServer;
import com.android.supl.nc.WriterThread;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.UnknownHostException;
import java.security.GeneralSecurityException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import javax.net.ssl.HandshakeCompletedEvent;
import javax.net.ssl.HandshakeCompletedListener;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class NetworkController {
    private static final String CONNECTION_CLOSE_THREAD = "Connection close thread";
    public static final int CONNECTION_TYPE_TLS = 1;
    public static final int CONNECTION_TYPE_TLS_PKS = 4;
    public static final int CONNECTION_TYPE_TLSv1_1 = 2;
    public static final int CONNECTION_TYPE_TLSv1_2 = 3;
    public static final int CONNECTION_TYPE_UDP = 0;
    private static final String LOG_TAG = "SUPL20_NC";
    public static final int STOP_WRITE_THREAD = 101;
    private static KeyStore keyStore = null;
    private static List<KeyStore> keyStoreList = new ArrayList<KeyStore>(2);
    private static final int m_iBufferSize = 10;
    private int MAX_SUPL_NETWORK_REQUEST_TIMEOUT = 60000;
    InetAddress agpsDataConnectionIpAddr = null;
    private CommandProcessor cp = null;
    private BlockingQueue<SendToServer> deque = null;
    String[] eSlpList;
    private int iConnType = 0;
    private int iConnectionCount = 0;
    private int iFailerStatus = 0;
    private int iNetWorkID = -1;
    private boolean isConnectionError = false;
    private boolean isSCM = false;
    private ConnectivityManager mConnMgr;
    private Context mContext;
    private boolean mNeedEmergencyApn = false;
    private final ConnectivityManager.NetworkCallback mSuplConnectivityCallback;
    private Socket m_CilentSocket = null;
    private int m_iConnTimeOut = 2000;
    private int m_iHandShakeTimeOut = 2000;
    private int m_iServerPortNo = 7275;
    private LocalSocket m_localSocket = null;
    private boolean m_open_supl_apn_ok = false;
    private String m_stReadThreadName = null;
    private String m_stServerIPAddr = "supl.google.com";
    private String m_stWriteThreadName = null;
    private NetworkCommandProcessor networkCommandProcessor = null;
    public final Object objLock = new Object();
    private ReaderThread readerThread = null;
    private int server_conn_retry = 1;
    private int server_conn_timeout = 5000;
    private SSLContext ssl_Context = null;
    private WriterThread writerThread = null;

    static /* synthetic */ boolean -set0(NetworkController networkController, boolean bl) {
        networkController.m_open_supl_apn_ok = bl;
        return bl;
    }

    public NetworkController(int n, String string, int n2, CommandProcessor commandProcessor, String string2, String string3, boolean bl) {
        this.mSuplConnectivityCallback = new ConnectivityManager.NetworkCallback(){

            public void onAvailable(Network object) {
                NetworkInfo networkInfo = NetworkController.this.mConnMgr.getNetworkInfo((Network)object);
                if (networkInfo == null) {
                    return;
                }
                Log.d((String)NetworkController.LOG_TAG, (String)("Network onAvailable NetworkInfo: " + networkInfo));
                if (!networkInfo.isConnected()) return;
                if (NetworkController.this.mNeedEmergencyApn && NetworkController.this.agpsDataConnectionIpAddr == null) {
                    try {
                        object = object.getAllByName(NetworkController.this.getServerIPAddr());
                        NetworkController.this.agpsDataConnectionIpAddr = object[0];
                        object = new StringBuilder();
                        Log.v((String)NetworkController.LOG_TAG, (String)((StringBuilder)object).append("DNS query(use network.getAllByName) success: ").append(NetworkController.this.agpsDataConnectionIpAddr).toString());
                    }
                    catch (UnknownHostException unknownHostException) {
                        Log.e((String)NetworkController.LOG_TAG, (String)("DNS query(use network.getAllByName) fail: " + NetworkController.this.getServerIPAddr()), (Throwable)unknownHostException);
                        NetworkController.this.agpsDataConnectionIpAddr = null;
                        return;
                    }
                }
                NetworkController.-set0(NetworkController.this, true);
            }

            public void onLost(Network network) {
                network = NetworkController.this.mConnMgr.getNetworkInfo(network);
                if (network == null) {
                    return;
                }
                Log.d((String)NetworkController.LOG_TAG, (String)("Network onLost NetworkInfo: " + network));
            }

            public void onUnavailable() {
                Log.d((String)NetworkController.LOG_TAG, (String)"Network onUnavailable");
            }
        };
        this.eSlpList = new String[]{"e-slp.e911.kddi.ne.jp"};
        Log.d((String)LOG_TAG, (String)("iConnType = " + n));
        this.iConnType = n;
        this.m_stServerIPAddr = string;
        this.m_iServerPortNo = n2;
        this.cp = commandProcessor;
        this.m_stReadThreadName = string2;
        this.m_stWriteThreadName = string3;
        this.isSCM = bl;
        this.mContext = SuplApplication.getContext();
        this.mConnMgr = (ConnectivityManager)this.mContext.getSystemService("connectivity");
        if (!ConfigManager.getInstance().switchApnEnabled()) return;
        this.checkIfNeedEmergencyApn(string);
    }

    private void checkIfNeedEmergencyApn(String string) {
        Log.d((String)LOG_TAG, (String)("checkIfNeedEmergencyApn: " + string));
        String[] stringArray = this.eSlpList;
        int n = stringArray.length;
        int n2 = 0;
        while (true) {
            if (n2 >= n) {
                this.mNeedEmergencyApn = false;
                return;
            }
            if (stringArray[n2].equals(string)) {
                Log.d((String)LOG_TAG, (String)"eslp match, need to open emergency apn.");
                this.mNeedEmergencyApn = true;
                return;
            }
            ++n2;
        }
    }

    /*
     * Unable to fully structure code
     */
    private boolean checkSuplApnState() {
        var1_1 = 0;
        block2: while (var1_1 < 40) {
            Log.d((String)"SUPL20_NC", (String)("checkSuplApnState wait for open supl apn ok : " + var1_1));
            if (this.m_open_supl_apn_ok) {
                this.setRouting();
                return true;
            }
            try {
                Thread.sleep(500L);
lbl10:
                // 2 sources

                while (true) {
                    ++var1_1;
                    continue block2;
                    break;
                }
            }
            catch (InterruptedException var2_2) {
                var2_2.printStackTrace();
                ** continue;
            }
        }
        return false;
    }

    private SSLContext createSSLContext() throws NoSuchAlgorithmException, KeyManagementException {
        SSLContext sSLContext;
        block9: {
            sSLContext = null;
            SSLContext sSLContext2 = null;
            if (1 == this.iConnType) {
                Log.i((String)LOG_TAG, (String)"Creating TLSv1 Context");
                sSLContext = SSLContext.getInstance("TLS");
            } else {
                if (2 == this.iConnType) {
                    try {
                        sSLContext2 = sSLContext = SSLContext.getInstance("TLSv1.1");
                        Log.i((String)LOG_TAG, (String)"TLSv1.1 Context created succesfully");
                    }
                    catch (NoSuchAlgorithmException noSuchAlgorithmException) {
                        sSLContext = sSLContext2;
                        if (sSLContext2 == null) {
                            Log.i((String)LOG_TAG, (String)"TLSv1.1 Context creation failed , so falling back to TLSv1");
                            sSLContext = SSLContext.getInstance("TLS");
                        }
                        break block9;
                    }
                }
                if (3 != this.iConnType) {
                    Log.i((String)LOG_TAG, (String)"Valid CONNECTION_TYPE not found");
                    return null;
                }
                sSLContext2 = sSLContext;
                try {
                    sSLContext2 = sSLContext = SSLContext.getInstance("TLSv1.2");
                    Log.i((String)LOG_TAG, (String)"TLSv1.2 Context created succesfully");
                }
                catch (NoSuchAlgorithmException noSuchAlgorithmException) {
                    sSLContext = sSLContext2;
                    if (sSLContext2 != null) break block9;
                    Log.i((String)LOG_TAG, (String)"TLSv1.2 Context creation failed , so falling back to TLSv1.1");
                    sSLContext = SSLContext.getInstance("TLSv1.1");
                }
            }
        }
        sSLContext.init(null, this.getTrustManagers(), null);
        return sSLContext;
    }

    private Socket createSSLSocket() throws NoSuchAlgorithmException, ConnectException, IOException, KeyManagementException {
        Object object = this.getSSLContext();
        if (object == null) {
            Log.e((String)LOG_TAG, (String)("The SSLSocket connection failed with the TLS connection type " + this.iConnType));
            throw new ConnectException();
        }
        MySSLSocketFactory mySSLSocketFactory = new MySSLSocketFactory(((SSLContext)object).getSocketFactory());
        Socket socket = new Socket();
        object = ConfigManager.getInstance().switchApnEnabled() ? new InetSocketAddress(this.agpsDataConnectionIpAddr, this.getPortNumber()) : new InetSocketAddress(this.getServerIPAddr(), this.getPortNumber());
        socket.connect((SocketAddress)object, this.m_iConnTimeOut);
        return mySSLSocketFactory.createSocket(socket, this.getServerIPAddr(), this.getPortNumber(), true);
    }

    /*
     * Unable to fully structure code
     * Enabled unnecessary exception pruning
     */
    private KeyStore getKeyStore() {
        if (NetworkController.keyStore != null) {
            return NetworkController.keyStore;
        }
        var1_1 = ConfigManager.getInstance();
        var6_7 = var1_1.getPrivateKeyStore();
        var7_8 = var1_1.getPrivateKeyStoreConv();
        if (var6_7 == null) {
            Log.e((String)"SUPL20_NC", (String)"stKeyStorePath == null");
            return null;
        }
        if (var7_8 == null) {
            Log.e((String)"SUPL20_NC", (String)"stKeyStoreConv == null");
            return null;
        }
        var5_9 = null;
        var3_10 = null;
        var4_15 = null;
        var1_1 = var3_10;
        var1_1 = var3_10;
        var2_16 = new FileInputStream(var6_7);
        var1_1 = KeyStore.getInstance("BKS", "BC");
        var1_1.load((InputStream)var2_16, var7_8.toCharArray());
        NetworkController.keyStore = var1_1;
        ** if (var2_16 == null) goto lbl33
lbl-1000:
        // 1 sources

        {
            try {
                var2_16.close();
            }
            catch (IOException var1_2) {
                Log.e((String)"SUPL20_NC", (String)"Error closing keystore file");
                NetworkController.keyStore = null;
            }
        }
lbl33:
        // 2 sources

        ** GOTO lbl82
        catch (GeneralSecurityException var3_11) {
            var2_16 = var4_15;
            ** GOTO lbl70
            catch (IOException var3_12) {
                block22: {
                    block23: {
                        var2_16 = var5_9;
                        break block23;
                        catch (Throwable var1_6) {
                            var3_10 = var2_16;
                            var2_16 = var1_6;
                            ** GOTO lbl53
                        }
                        catch (IOException var3_13) {}
                    }
                    var1_1 = var2_16;
                    try {
                        Log.e((String)"SUPL20_NC", (String)"Error Loading keystore: ", (Throwable)var3_10);
                        if (var2_16 == null) break block22;
                    }
                    catch (Throwable var2_17) {
                        var3_10 = var1_1;
lbl53:
                        // 2 sources

                        if (var3_10 == null) throw var2_16;
                        try {
                            var3_10.close();
                        }
                        catch (IOException var1_5) {
                            Log.e((String)"SUPL20_NC", (String)"Error closing keystore file");
                            NetworkController.keyStore = null;
                            throw var2_16;
                        }
                        throw var2_16;
                    }
                    try {
                        var2_16.close();
                        break block22;
                    }
                    catch (IOException var1_4) {
                        Log.e((String)"SUPL20_NC", (String)"Error closing keystore file");
                        ** GOTO lbl81
                    }
                    catch (GeneralSecurityException var3_14) {}
lbl70:
                    // 2 sources

                    var1_1 = var2_16;
                    Log.e((String)"SUPL20_NC", (String)"Error Loading keystore: ", (Throwable)var3_10);
                    if (var2_16 == null) break block22;
                    try {
                        var2_16.close();
                    }
                    catch (IOException var1_3) {
                        Log.e((String)"SUPL20_NC", (String)"Error closing keystore file");
lbl81:
                        // 2 sources

                        NetworkController.keyStore = null;
                    }
                }
                if (NetworkController.keyStore == null) return NetworkController.keyStore;
                Log.i((String)"SUPL20_NC", (String)"Successfully loaded Keystore");
                return NetworkController.keyStore;
            }
        }
    }

    private List<KeyStore> getKeyStoreAll() {
        if (!keyStoreList.isEmpty()) {
            return keyStoreList;
        }
        Object object = ConfigManager.getInstance();
        String string = ((ConfigManager)object).getPrivateKeyStore();
        object = ((ConfigManager)object).getPrivateKeyStoreConv();
        if (string == null) {
            Log.w((String)LOG_TAG, (String)"KeyStore is empty!");
            return null;
        }
        String[] stringArray = new File(string);
        if (stringArray == null) {
            Log.e((String)LOG_TAG, (String)"dir is null!");
            return null;
        }
        if (!stringArray.exists()) {
            Log.e((String)LOG_TAG, (String)(string + "is not exist!"));
            return null;
        }
        if (!stringArray.isDirectory()) {
            Log.e((String)LOG_TAG, (String)(string + "is not directory!"));
            return null;
        }
        stringArray = stringArray.list();
        int n = 0;
        int n2 = stringArray.length;
        while (n < n2) {
            Object object2 = stringArray[n];
            if (((String)object2).endsWith(".bks") && !((String)object2).equals("gnss_hiskey_hisi.bks") && (object2 = this.getKeyStoreByPath(string + "/" + (String)object2, (String)object)) != null) {
                keyStoreList.add((KeyStore)object2);
            }
            ++n;
        }
        return keyStoreList;
    }

    /*
     * Unable to fully structure code
     * Enabled unnecessary exception pruning
     */
    private KeyStore getKeyStoreByPath(String var1_1, String var2_10) {
        if (var1_1 == null) {
            Log.e((String)"SUPL20_NC", (String)"stKeyStorePath == null");
            return null;
        }
        if (var2_10 == null) {
            Log.e((String)"SUPL20_NC", (String)"stKeyStoreConv == null");
            return null;
        }
        var6_12 = null;
        var10_13 = null;
        var5_14 = null;
        var8_18 = null;
        var11_19 = null;
        var9_20 = null;
        var7_21 = null;
        var3_22 = var10_13;
        var3_22 = var10_13;
        var4_23 = new FileInputStream((String)var1_1);
        var1_1 = var11_19;
        var3_22 = var9_20;
        var5_14 = KeyStore.getInstance("BKS", "BC");
        var1_1 = var5_14;
        var3_22 = var5_14;
        var5_14.load((InputStream)var4_23, var2_10.toCharArray());
        var1_1 = var5_14;
        ** if (var4_23 == null) goto lbl37
lbl-1000:
        // 1 sources

        {
            try {
                var4_23.close();
                var1_1 = var5_14;
            }
            catch (IOException var1_2) {
                Log.e((String)"SUPL20_NC", (String)"Error closing keystore file");
                var1_1 = null;
            }
        }
lbl37:
        // 2 sources

        ** GOTO lbl92
        catch (GeneralSecurityException var1_3) {
            var2_10 = var7_21;
            var4_23 = var5_14;
            ** GOTO lbl78
            catch (IOException var5_15) {
                block21: {
                    block22: {
                        var4_23 = var8_18;
                        var2_10 = var6_12;
                        break block22;
                        catch (Throwable var1_8) {
                            var3_22 = var4_23;
                            ** GOTO lbl-1000
                        }
                        catch (IOException var5_17) {
                            var2_10 = var4_23;
                            var4_23 = var1_1;
                        }
                    }
                    var3_22 = var2_10;
                    try {
                        Log.e((String)"SUPL20_NC", (String)"Error Loading keystore: ", (Throwable)var5_16);
                        var1_1 = var4_23;
                        if (var2_10 == null) break block21;
                    }
                    catch (Throwable var1_6) lbl-1000:
                    // 2 sources

                    {
                        if (var3_22 == null) throw var1_7;
                        try {
                            var3_22.close();
                        }
                        catch (IOException var2_11) {
                            Log.e((String)"SUPL20_NC", (String)"Error closing keystore file");
                            throw var1_7;
                        }
                        throw var1_7;
                    }
                    try {
                        var2_10.close();
                        var1_1 = var4_23;
                        break block21;
                    }
                    catch (IOException var1_5) {
                        Log.e((String)"SUPL20_NC", (String)"Error closing keystore file");
                        ** GOTO lbl91
                    }
                    catch (GeneralSecurityException var1_9) {
                        var2_10 = var3_22;
                    }
lbl78:
                    // 2 sources

                    var3_22 = var4_23;
                    Log.e((String)"SUPL20_NC", (String)"Error Loading keystore: ", (Throwable)var1_1);
                    var1_1 = var2_10;
                    if (var4_23 == null) break block21;
                    try {
                        var4_23.close();
                        var1_1 = var2_10;
                    }
                    catch (IOException var1_4) {
                        Log.e((String)"SUPL20_NC", (String)"Error closing keystore file");
lbl91:
                        // 2 sources

                        var1_1 = null;
                    }
                }
                if (var1_1 == null) return var1_1;
                Log.i((String)"SUPL20_NC", (String)"Successfully loaded Keystore");
                return var1_1;
            }
        }
    }

    private LocalSocket getLocalSocket(String string) throws IOException {
        LocalSocketAddress localSocketAddress = new LocalSocketAddress(string, LocalSocketAddress.Namespace.FILESYSTEM);
        string = new LocalSocket();
        try {
            string.connect(localSocketAddress);
            return string;
        }
        catch (IOException iOException) {
            Log.e((String)LOG_TAG, (String)"Exception caught while connecting the unix socket");
            return string;
        }
    }

    private int getPortNumber() {
        return this.m_iServerPortNo;
    }

    private SSLContext getSSLContext() throws NoSuchAlgorithmException, KeyManagementException {
        if (this.ssl_Context != null) return this.ssl_Context;
        this.ssl_Context = this.createSSLContext();
        return this.ssl_Context;
    }

    private Socket getSocket() throws NoSuchAlgorithmException, ConnectException, IOException, KeyManagementException {
        Object object;
        if (ConfigManager.getInstance().switchApnEnabled()) {
            if (!this.mNeedEmergencyApn) {
                try {
                    this.agpsDataConnectionIpAddr = InetAddress.getByName(this.getServerIPAddr());
                    object = new StringBuilder();
                    Log.v((String)LOG_TAG, (String)((StringBuilder)object).append("DNS query success: ").append(this.agpsDataConnectionIpAddr).toString());
                }
                catch (UnknownHostException unknownHostException) {
                    Log.e((String)LOG_TAG, (String)("DNS query fail: " + this.getServerIPAddr()), (Throwable)unknownHostException);
                    this.agpsDataConnectionIpAddr = null;
                }
            } else {
                this.agpsDataConnectionIpAddr = null;
            }
        }
        if (!this.prepareNetwork()) {
            Log.e((String)LOG_TAG, (String)"Network unavailable, throw exception");
            throw new ConnectException("failed to switch to supl apn!");
        }
        if (this.iConnType == 0) {
            Socket socket = new Socket();
            object = ConfigManager.getInstance().switchApnEnabled() ? new InetSocketAddress(this.agpsDataConnectionIpAddr, this.getPortNumber()) : new InetSocketAddress(this.getServerIPAddr(), this.getPortNumber());
            socket.connect((SocketAddress)object, this.server_conn_timeout);
            return socket;
        }
        object = (SSLSocket)this.createSSLSocket();
        if (object == null) {
            return null;
        }
        Log.d((String)LOG_TAG, (String)"NO_FALLBACK");
        Object object2 = ((SSLSocket)object).getSupportedCipherSuites();
        if (object2 != null && ((String[])object2).length > 1) {
            String[] stringArray = new String[((String[])object2).length - 1];
            int n = ((String[])object2).length;
            int n2 = 0;
            for (int i = 0; i < n; ++i) {
                String string = object2[i];
                if (string.equals("TLS_FALLBACK_SCSV")) continue;
                int n3 = n2 + 1;
                stringArray[n2] = string;
                n2 = n3;
            }
            ((SSLSocket)object).setEnabledCipherSuites(stringArray);
        }
        if (1 == this.iConnType) {
            Log.i((String)LOG_TAG, (String)"Enabling TLSv1");
            ((SSLSocket)object).setEnabledProtocols(new String[]{"TLSv1"});
        } else if (2 == this.iConnType) {
            Log.i((String)LOG_TAG, (String)"Enabling TLSv1 and TLSv1.1");
            ((SSLSocket)object).setEnabledProtocols(new String[]{"TLSv1.1", "TLSv1"});
        } else if (3 == this.iConnType) {
            Log.i((String)LOG_TAG, (String)"Enabling TLSv1.2 and TLSv1.1");
            ((SSLSocket)object).setEnabledProtocols(new String[]{"TLSv1.2", "TLSv1.1", "TLSv1"});
        }
        ((SSLSocket)object).setUseClientMode(true);
        ((Socket)object).setSoTimeout(this.m_iHandShakeTimeOut);
        ((SSLSocket)object).addHandshakeCompletedListener(new HandshakeCompletedListener(){

            @Override
            public void handshakeCompleted(HandshakeCompletedEvent handshakeCompletedEvent) {
                Log.i((String)NetworkController.LOG_TAG, (String)("Cipher Suite : " + handshakeCompletedEvent.getSession().getCipherSuite()));
                Log.i((String)NetworkController.LOG_TAG, (String)("Handshake Completed. Protocol: " + handshakeCompletedEvent.getSession().getProtocol()));
            }
        });
        ((SSLSocket)object).startHandshake();
        ((Socket)object).setSoTimeout(0);
        object2 = ((SSLSocket)object).getSession();
        Log.i((String)LOG_TAG, (String)("The SSL Protocol used is " + object2.getProtocol()));
        if (object2.isValid()) {
            Log.i((String)LOG_TAG, (String)"Connection Secured.");
            return object;
        }
        Log.i((String)LOG_TAG, (String)"Connection Not Secured.");
        return object;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     */
    private void initReadThread() {
        if (this.readerThread == null) {
            this.readerThread = new ReaderThread(this.cp, this.iNetWorkID);
            this.readerThread.setNetworkController(this);
            Log.i((String)LOG_TAG, (String)"readerThread initialized");
        } else {
            Log.i((String)LOG_TAG, (String)"readerThread already initialized");
        }
        try {
            if (this.iNetWorkID == -1) {
                Log.i((String)LOG_TAG, (String)"don't need reader thread, it replace by hisupl_adapter socket");
                return;
            }
        }
        catch (IllegalArgumentException illegalArgumentException) {
            Log.e((String)LOG_TAG, (String)illegalArgumentException.getMessage(), (Throwable)illegalArgumentException);
            return;
        }
        catch (IllegalStateException illegalStateException) {
            Log.e((String)LOG_TAG, (String)illegalStateException.getMessage(), (Throwable)illegalStateException);
            return;
        }
        {
            this.readerThread.setClientSocket(this.m_CilentSocket, this.m_stReadThreadName);
            return;
        }
    }

    /*
     * Enabled unnecessary exception pruning
     */
    private void initWriteThread() {
        try {
            Object object;
            if (this.deque == null) {
                object = new LinkedBlockingQueue(10);
                this.deque = object;
                Log.i((String)LOG_TAG, (String)"deque initialized");
            } else {
                object = new StringBuilder();
                Log.i((String)LOG_TAG, (String)((StringBuilder)object).append("deque has packet size:").append(this.deque.size()).toString());
            }
            if (this.writerThread == null) {
                Log.i((String)LOG_TAG, (String)"WriterThread initialize");
                this.writerThread = object = new WriterThread(this.deque, this, this.iNetWorkID);
            } else {
                Log.i((String)LOG_TAG, (String)"WriterThread already initialized");
            }
            try {
                if (this.iNetWorkID == -1) {
                    this.writerThread.startThread();
                    return;
                }
                this.writerThread.setClientSocket(this.m_CilentSocket, this.m_stWriteThreadName);
                return;
            }
            catch (IllegalArgumentException illegalArgumentException) {
                Log.e((String)LOG_TAG, (String)illegalArgumentException.getMessage(), (Throwable)illegalArgumentException);
                return;
            }
            catch (IllegalStateException illegalStateException) {
                Log.e((String)LOG_TAG, (String)illegalStateException.getMessage(), (Throwable)illegalStateException);
                return;
            }
        }
        catch (Exception exception) {
            Log.e((String)LOG_TAG, (String)exception.getMessage(), (Throwable)exception);
            return;
        }
    }

    public static final boolean isThreadRunning(String string) {
        boolean bl = false;
        boolean bl2 = false;
        if (string == null) return false;
        if (string.length() == 0) {
            return false;
        }
        boolean bl3 = bl;
        if (Thread.getAllStackTraces() == null) return bl3;
        Object object = Thread.getAllStackTraces().keySet();
        bl3 = bl;
        if (object == null) return bl3;
        Thread[] threadArray = object.toArray(new Thread[object.size()]);
        int n = 0;
        while (true) {
            bl3 = bl2;
            if (n >= threadArray.length) return bl3;
            object = threadArray[n];
            if (object != null) {
                bl2 = bl3 = string.equals(((Thread)object).getName());
                if (bl3) {
                    return bl3;
                }
            }
            ++n;
        }
    }

    private boolean prepareNetwork() {
        if (!ConfigManager.getInstance().switchApnEnabled()) {
            return true;
        }
        Log.i((String)LOG_TAG, (String)"request network");
        NetworkRequest.Builder builder = new NetworkRequest.Builder();
        builder.addTransportType(0);
        if (this.mNeedEmergencyApn) {
            builder.addCapability(10);
        } else {
            builder.addCapability(1);
        }
        builder = builder.build();
        this.m_open_supl_apn_ok = false;
        this.mConnMgr.requestNetwork((NetworkRequest)builder, this.mSuplConnectivityCallback, this.MAX_SUPL_NETWORK_REQUEST_TIMEOUT);
        return this.checkSuplApnState();
    }

    private void reconnectAgain() {
        Log.i((String)LOG_TAG, (String)"Trying to connect again");
        this.connect(null, true);
    }

    private void releaseNetwork() {
        if (!ConfigManager.getInstance().switchApnEnabled()) {
            return;
        }
        Log.i((String)LOG_TAG, (String)"unregister network callback");
        try {
            this.mConnMgr.unregisterNetworkCallback(this.mSuplConnectivityCallback);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            Log.e((String)LOG_TAG, (String)"Invalid NetworkCallback");
        }
        this.agpsDataConnectionIpAddr = null;
    }

    private void setRouting() {
        boolean bl;
        if (this.agpsDataConnectionIpAddr == null) {
            try {
                this.agpsDataConnectionIpAddr = InetAddress.getByName(this.getServerIPAddr());
                StringBuilder stringBuilder = new StringBuilder();
                Log.v((String)LOG_TAG, (String)stringBuilder.append("DNS re-query success: ").append(this.agpsDataConnectionIpAddr).toString());
            }
            catch (UnknownHostException unknownHostException) {
                Log.e((String)LOG_TAG, (String)("DNS re-query fail: " + this.getServerIPAddr()), (Throwable)unknownHostException);
                this.agpsDataConnectionIpAddr = null;
                return;
            }
        }
        if (!(bl = this.mNeedEmergencyApn ? this.mConnMgr.requestRouteToHostAddress(15, this.agpsDataConnectionIpAddr) : this.mConnMgr.requestRouteToHostAddress(3, this.agpsDataConnectionIpAddr))) {
            Log.e((String)LOG_TAG, (String)("Error requesting route to host: " + this.agpsDataConnectionIpAddr));
            return;
        }
        Log.i((String)LOG_TAG, (String)("Successfully requested route to host: " + this.agpsDataConnectionIpAddr));
    }

    private void startCloseConnectionThread(Thread thread) {
        if (NetworkController.isThreadRunning(CONNECTION_CLOSE_THREAD)) {
            return;
        }
        thread.setName(CONNECTION_CLOSE_THREAD);
        thread.start();
    }

    public void CloseReadWriteStreams() {
        Log.i((String)LOG_TAG, (String)"Start CloseReadWriteStreams");
        this.readerThread.closeConnection();
        this.writerThread.closeWrite();
        Log.i((String)LOG_TAG, (String)"End CloseReadWriteStreams");
    }

    public boolean IsSCM() {
        return this.isSCM;
    }

    public void SetTimeOuts(int n, int n2) {
        this.m_iHandShakeTimeOut = n;
        this.m_iConnTimeOut = n2;
    }

    /*
     * Unable to fully structure code
     */
    public void addPacket(SendToServer var1_1) {
        if (this.writerThread != null) {
            this.writerThread.addPacket(var1_1);
            return;
        }
        var2_2 = 0;
        do {
            block5: {
                Log.i((String)"SUPL20_NC", (String)"writerThread is null, wait and re-try");
                try {
                    Thread.sleep(500L);
lbl10:
                    // 2 sources

                    while (true) {
                        var3_3 = var2_2 + 1;
                        if (this.writerThread == null) break block5;
                        this.writerThread.addPacket(var1_1);
                        break;
                    }
                }
                catch (InterruptedException var4_4) {
                    ** continue;
                }
                Log.w((String)"SUPL20_NC", (String)("addPacket try times " + var3_3));
            }
            if (this.writerThread != null) break;
            var2_2 = var3_3;
        } while (var3_3 < 120);
        if (this.writerThread != null) return;
        Log.e((String)"SUPL20_NC", (String)"writerThread is still null, donot addPacket!!");
    }

    public void closeConnection() {
        if (this.iNetWorkID == -1) {
            return;
        }
        if (this.m_CilentSocket == null) return;
        try {
            this.m_CilentSocket.close();
            StringBuilder stringBuilder = new StringBuilder();
            Log.i((String)LOG_TAG, (String)stringBuilder.append("m_CilentSocket is closed ").append(this.toString()).toString());
            stringBuilder = new StringBuilder();
            Log.i((String)LOG_TAG, (String)stringBuilder.append("Socket isBound:").append(this.m_CilentSocket.isBound()).toString());
            stringBuilder = new StringBuilder();
            Log.i((String)LOG_TAG, (String)stringBuilder.append("Socket isClosed:").append(this.m_CilentSocket.isClosed()).toString());
            stringBuilder = new StringBuilder();
            Log.i((String)LOG_TAG, (String)stringBuilder.append("Socket isInputShutdown:").append(this.m_CilentSocket.isInputShutdown()).toString());
            stringBuilder = new StringBuilder();
            Log.i((String)LOG_TAG, (String)stringBuilder.append("Socket isOutputShutdown:").append(this.m_CilentSocket.isOutputShutdown()).toString());
            stringBuilder = new StringBuilder();
            Log.i((String)LOG_TAG, (String)stringBuilder.append("Socket isConnected:").append(this.m_CilentSocket.isConnected()).toString());
            this.releaseNetwork();
            return;
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return;
        }
    }

    /*
     * Exception decompiling
     */
    public boolean connect(int[] var1_1, boolean var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Back jump on a try block [egrp 5[TRYBLOCK] [35 : 333->367)] java.lang.Throwable
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.insertExceptionBlocks(Op02WithProcessedDataAndRefs.java:2289)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:414)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:73)
         *     at org.benf.cfr.reader.Main.main(Main.java:49)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:303)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$null$1(ResourceDecompiling.java:113)
         *     at java.base/java.lang.Thread.run(Unknown Source)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public void decrementConnectionCount() {
        --this.iConnectionCount;
    }

    public int getConnectionCount() {
        return this.iConnectionCount;
    }

    protected KeyManager[] getKeyManagers() {
        try {
            KeyManager[] keyManagerArray = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            keyManagerArray.init(this.getKeyStore(), ConfigManager.getInstance().getPrivateKeyStoreConv().toCharArray());
            return keyManagerArray.getKeyManagers();
        }
        catch (GeneralSecurityException generalSecurityException) {
            Log.e((String)LOG_TAG, (String)"Error while creating Keymaanger: ", (Throwable)generalSecurityException);
            return null;
        }
    }

    public int getNetWorkID() {
        return this.iNetWorkID;
    }

    public NetworkCommandProcessor getNetworkCommandProcessor() {
        return this.networkCommandProcessor;
    }

    public String getServerIPAddr() {
        return this.m_stServerIPAddr;
    }

    protected TrustManager[] getTrustManagers() {
        try {
            SSLX509TrustManager sSLX509TrustManager = new SSLX509TrustManager(this.getKeyStoreAll(), this.getServerIPAddr());
            return new TrustManager[]{sSLX509TrustManager};
        }
        catch (KeyStoreException keyStoreException) {
            Log.e((String)LOG_TAG, (String)"Error while creating TrustManager: ", (Throwable)keyStoreException);
            return null;
        }
        catch (NoSuchAlgorithmException noSuchAlgorithmException) {
            Log.e((String)LOG_TAG, (String)"Error while creating TrustManager: ", (Throwable)noSuchAlgorithmException);
            return null;
        }
    }

    public void initRead_WriteThread() {
        this.readerThread = null;
        this.writerThread = null;
        if (this.iNetWorkID != -1) {
            Log.i((String)LOG_TAG, (String)("m_CilentSocket isClosed:" + this.m_CilentSocket.isClosed()));
        }
        this.initWriteThread();
        this.initReadThread();
    }

    public boolean isConnected() {
        boolean bl = false;
        if (this.iNetWorkID == -1) {
            return true;
        }
        if (this.m_CilentSocket == null) return bl;
        return this.m_CilentSocket.isConnected();
    }

    public boolean isNetWorkMatch(int n) {
        if (this.iNetWorkID != n) return false;
        return true;
    }

    public void removeSLPSession() {
        if (this.networkCommandProcessor == null) return;
        String string = this.networkCommandProcessor.getNetKey(this.m_stServerIPAddr, this.m_iServerPortNo, this.iConnType, this.iNetWorkID);
        this.networkCommandProcessor.removeFailerSession(string);
    }

    public void setNetWorkID(int n) {
        this.iNetWorkID = n;
    }

    public void setNetworkCommProceeor(NetworkCommandProcessor networkCommandProcessor) {
        this.networkCommandProcessor = networkCommandProcessor;
    }

    public void setServer_conn_Timeout_Retries(int n, int n2) {
        this.server_conn_timeout = n;
        this.server_conn_retry = n2;
    }

    /*
     * Enabled unnecessary exception pruning
     */
    public boolean stop(final boolean bl, final Object object, final boolean bl2) {
        synchronized (this) {
            Thread thread = new StringBuilder();
            Log.i((String)LOG_TAG, (String)((StringBuilder)((Object)thread)).append("stop() isStop:").append(bl).append(",ConnectAgain:").append(bl2).toString());
            thread = new Thread(){

                /*
                 * Loose catch block
                 * Enabled unnecessary exception pruning
                 * Converted monitor instructions to comments
                 */
                @Override
                public void run() {
                    if (!bl2 && NetworkController.this.iConnectionCount != 0) {
                        Log.i((String)NetworkController.LOG_TAG, (String)("Close connection Thread Connection Count:" + NetworkController.this.iConnectionCount));
                        return;
                    }
                    if (NetworkController.this.writerThread != null) {
                        NetworkController.this.writerThread.setStopLock(NetworkController.this.objLock);
                        NetworkController.this.writerThread.stopWrite();
                    }
                    Object object2 = NetworkController.this.objLock;
                    // MONITORENTER : object2
                    try {
                        while (NetworkController.this.writerThread != null && NetworkController.this.writerThread.isReadyForColse() ^ true) {
                            Log.i((String)NetworkController.LOG_TAG, (String)"On write wait");
                            NetworkController.this.objLock.wait();
                            Log.i((String)NetworkController.LOG_TAG, (String)"On write notified");
                        }
                    }
                    catch (InterruptedException interruptedException) {
                        interruptedException.printStackTrace();
                    }
                    if (NetworkController.this.writerThread != null) {
                        NetworkController.this.writerThread.closeWrite();
                    }
                    Log.i((String)NetworkController.LOG_TAG, (String)"On write wait release");
                    if (NetworkController.this.readerThread != null) {
                        NetworkController.this.readerThread.setStopLock(NetworkController.this.objLock);
                        NetworkController.this.readerThread.stopRead();
                    }
                    if (bl) {
                        NetworkController.this.closeConnection();
                    }
                    object2 = NetworkController.this.objLock;
                    // MONITORENTER : object2
                    while (NetworkController.this.readerThread != null && NetworkController.this.readerThread.isReadyForColse() ^ true) {
                        Log.i((String)NetworkController.LOG_TAG, (String)"On read wait");
                        NetworkController.this.objLock.wait();
                        Log.i((String)NetworkController.LOG_TAG, (String)"On read notified");
                    }
                    catch (InterruptedException interruptedException) {
                        interruptedException.printStackTrace();
                    }
                    // MONITOREXIT : object2
                    Log.i((String)NetworkController.LOG_TAG, (String)"On read wait release");
                    if (object != null) {
                        object2 = object;
                        // MONITORENTER : object2
                        object.notify();
                        // MONITOREXIT : object2
                        Log.i((String)NetworkController.LOG_TAG, (String)"On pauseLock notify");
                    }
                    if (!bl2) return;
                    Log.i((String)NetworkController.LOG_TAG, (String)"Trying to reconnect again");
                    NetworkController.this.reconnectAgain();
                }
            };
            object = new StringBuilder();
            Log.i((String)LOG_TAG, (String)((StringBuilder)object).append("Before decrement Connection Count:").append(this.iConnectionCount).toString());
            if (!bl2 && this.iConnectionCount > 0) {
                --this.iConnectionCount;
            }
            object = new StringBuilder();
            Log.i((String)LOG_TAG, (String)((StringBuilder)object).append("After decrement Connection Count:").append(this.iConnectionCount).toString());
            if (this.iConnectionCount == 0) {
                if (!bl2 && this.cp instanceof NetworkCommandProcessor) {
                    object = (NetworkCommandProcessor)this.cp;
                    Log.i((String)LOG_TAG, (String)"sendOnNetWorkSessionClose() ");
                    ((NetworkCommandProcessor)object).sendOnNetWorkSessionClose(this.iNetWorkID);
                }
                Log.i((String)LOG_TAG, (String)"Starting startCloseConnectionThread");
                this.startCloseConnectionThread(thread);
            } else if (bl2) {
                this.startCloseConnectionThread(thread);
            } else {
                object = new StringBuilder();
                Log.i((String)LOG_TAG, (String)((StringBuilder)object).append("Not stoping NetworkController \"").append(this.toString()).append("\" because connection count = ").append(this.iConnectionCount).toString());
            }
            return false;
        }
    }

    public String toString() {
        return this.m_stServerIPAddr + ":" + this.m_iServerPortNo + " NI:" + this.iNetWorkID + " CC:" + this.iConnectionCount;
    }

    public void upDateConnectionCount() {
        ++this.iConnectionCount;
    }
}

