/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  org.apache.http.conn.ssl.StrictHostnameVerifier
 */
package com.android.supl.nc;

import android.util.Log;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import javax.net.ssl.SSLException;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import org.apache.http.conn.ssl.StrictHostnameVerifier;

public class SSLX509TrustManager
implements X509TrustManager {
    private static final String LOG = "SUPL20_TrustManager";
    private Vector<X509TrustManager> allx509TrustManager = null;
    private Vector<TrustManagerFactory> factories = null;
    private String fqdn = null;

    public SSLX509TrustManager(List<KeyStore> object, String string) throws NoSuchAlgorithmException, KeyStoreException {
        if (string == null) {
            Log.e((String)LOG, (String)"fqdn == null");
            throw new KeyStoreException("fqdn == null");
        }
        this.fqdn = string;
        this.allx509TrustManager = new Vector(3);
        if (object != null && object.isEmpty() ^ true) {
            object = object.iterator();
            while (object.hasNext()) {
                this.addKeyStore((KeyStore)object.next(), false);
            }
        }
        this.addKeyStore(null, false);
        if (this.allx509TrustManager.isEmpty()) {
            Log.e((String)LOG, (String)"No Trust Manager Found");
            throw new NoSuchAlgorithmException("No Trust Manager Found");
        }
        Log.i((String)LOG, (String)("Added " + this.allx509TrustManager.size() + " Trust Managers"));
    }

    private Vector<X509Certificate[]> splitByIssuers(X509Certificate[] x509CertificateArray) {
        Vector<X509Certificate[]> vector = new Vector<X509Certificate[]>(1);
        boolean bl = false;
        int n = 0;
        int n2 = 0;
        while (n2 < x509CertificateArray.length) {
            if (!bl) {
                n = n2;
            }
            X509Certificate x509Certificate = x509CertificateArray[n2];
            X509Certificate[] x509CertificateArray2 = null;
            if (n2 != x509CertificateArray.length - 1) {
                x509CertificateArray2 = x509CertificateArray[n2 + 1];
            }
            if (!(bl = x509CertificateArray2 != null && x509Certificate.getIssuerDN().equals(x509CertificateArray2.getSubjectDN()))) {
                x509CertificateArray2 = new X509Certificate[n2 - n + 1];
                System.arraycopy(x509CertificateArray, n, x509CertificateArray2, 0, x509CertificateArray2.length);
                vector.add(x509CertificateArray2);
            }
            ++n2;
        }
        return vector;
    }

    public void addKeyStore(KeyStore trustManagerArray, boolean bl) throws KeyStoreException, NoSuchAlgorithmException {
        TrustManagerFactory object = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        object.init((KeyStore)trustManagerArray);
        trustManagerArray = object.getTrustManagers();
        int n = trustManagerArray.length;
        int n2 = 0;
        while (n2 < n) {
            TrustManager trustManager = trustManagerArray[n2];
            if (trustManager instanceof X509TrustManager) {
                X509TrustManager x509TrustManager = (X509TrustManager)trustManager;
                this.allx509TrustManager.add(x509TrustManager);
                if (bl) {
                    Log.i((String)LOG, (String)"Added new Trust Manager. It contains the following Accepted Issuer Certificates:");
                    for (X509Certificate x509Certificate : x509TrustManager.getAcceptedIssuers()) {
                        Log.i((String)LOG, (String)("Certificate: " + x509Certificate));
                    }
                }
                Log.i((String)LOG, (String)("Number of accepted issuers: " + x509TrustManager.getAcceptedIssuers().length));
            }
            ++n2;
        }
    }

    @Override
    public void checkClientTrusted(X509Certificate[] x509CertificateArray, String string) throws CertificateException {
        throw new CertificateException(new UnsupportedOperationException());
    }

    @Override
    public void checkServerTrusted(X509Certificate[] x509CertificateArray, String object) throws CertificateException {
        int n;
        Object object2;
        Object object3;
        if (x509CertificateArray == null || x509CertificateArray.length == 0) {
            Log.e((String)LOG, (String)"Server didn't provide any certificate");
            throw new CertificateException("Server didn't provide any certificate");
        }
        try {
            object3 = new StrictHostnameVerifier();
            object3.verify(this.fqdn, x509CertificateArray[0]);
            object2 = null;
        }
        catch (SSLException sSLException) {
            Log.e((String)LOG, (String)("Certificate SubjectDN : " + x509CertificateArray[0].getSubjectDN().toString()));
            Log.e((String)LOG, (String)("But trying to connect to FQDN: " + this.fqdn));
            throw new CertificateException(sSLException);
        }
        if (x509CertificateArray.length > 1) {
            object3 = this.splitByIssuers(x509CertificateArray);
        } else {
            object3 = new Vector(1);
            ((Vector)object3).add(x509CertificateArray);
        }
        int n2 = 0;
        Iterator iterator = object3.iterator();
        object3 = object2;
        do {
            n = n2;
            object2 = object3;
            if (!iterator.hasNext()) break;
            X509Certificate[] x509CertificateArray2 = (X509Certificate[])iterator.next();
            Iterator iterator2 = this.allx509TrustManager.iterator();
            object2 = object3;
            while (true) {
                n = n2;
                if (!iterator2.hasNext()) break;
                object3 = (X509TrustManager)iterator2.next();
                try {
                    object3.checkServerTrusted(x509CertificateArray2, (String)object);
                    n = 1;
                }
                catch (CertificateException certificateException) {
                    continue;
                }
                break;
            }
            n2 = n;
            object3 = object2;
        } while (n == 0);
        if (n == 0) {
            Log.e((String)LOG, (String)"Couldn't find trusted anchor for certificate chain");
            throw object2;
        }
        n2 = 0;
        n = x509CertificateArray.length;
        while (n2 < n) {
            object = x509CertificateArray[n2];
            try {
                ((X509Certificate)object).checkValidity();
                ++n2;
            }
            catch (CertificateException certificateException) {
                Log.e((String)LOG, (String)("The following certificate in the chain is invalid: " + object));
                throw certificateException;
            }
        }
    }

    @Override
    public X509Certificate[] getAcceptedIssuers() {
        ArrayList<X509Certificate> arrayList = new ArrayList<X509Certificate>();
        Iterator iterator = this.allx509TrustManager.iterator();
        while (iterator.hasNext()) {
            arrayList.addAll(Arrays.asList(((X509TrustManager)iterator.next()).getAcceptedIssuers()));
        }
        return arrayList.toArray(new X509Certificate[arrayList.size()]);
    }
}

