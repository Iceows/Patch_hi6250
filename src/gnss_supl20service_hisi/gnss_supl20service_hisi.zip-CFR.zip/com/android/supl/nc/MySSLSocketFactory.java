/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.nc;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import javax.net.ssl.SSLSocketFactory;

public class MySSLSocketFactory
extends SSLSocketFactory {
    private SSLSocketFactory delegate = null;

    public MySSLSocketFactory(SSLSocketFactory sSLSocketFactory) {
        this.delegate = sSLSocketFactory;
    }

    @Override
    public Socket createSocket() throws IOException {
        return this.delegate.createSocket();
    }

    @Override
    public Socket createSocket(String string, int n) throws IOException, UnknownHostException {
        return this.delegate.createSocket(string, n);
    }

    @Override
    public Socket createSocket(String string, int n, InetAddress inetAddress, int n2) throws IOException, UnknownHostException {
        return this.delegate.createSocket(string, n, inetAddress, n2);
    }

    @Override
    public Socket createSocket(InetAddress inetAddress, int n) throws IOException {
        return this.delegate.createSocket(inetAddress, n);
    }

    @Override
    public Socket createSocket(InetAddress inetAddress, int n, InetAddress inetAddress2, int n2) throws IOException {
        return this.delegate.createSocket(inetAddress, n, inetAddress2, n2);
    }

    @Override
    public Socket createSocket(Socket socket, String string, int n, boolean bl) throws IOException {
        return this.delegate.createSocket(socket, string, n, bl);
    }

    @Override
    public String[] getDefaultCipherSuites() {
        return this.delegate.getDefaultCipherSuites();
    }

    @Override
    public String[] getSupportedCipherSuites() {
        return this.delegate.getSupportedCipherSuites();
    }
}

