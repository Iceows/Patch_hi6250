/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.android.supl.nc;

import android.util.Log;
import com.android.bytewriter.IO;
import com.android.supl.commprocessor.CommandProcessor;
import com.android.supl.commprocessor.FromServer;
import com.android.supl.commprocessor.NetworkCommandProcessor;
import com.android.supl.nc.NetworkController;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;
import java.util.Date;

public class ReaderThread
implements Runnable {
    private static final String LOG_TAG = "SUPL20_SLP-RECEIVING";
    private CommandProcessor cp = null;
    private int iNetworkID = -1;
    private BufferedInputStream in = null;
    private boolean isRead = false;
    private boolean isReadyForClose = false;
    private Socket m_CilentSocket = null;
    private NetworkController nc = null;
    public Object objMyReadLock = null;
    private Thread workerThread = null;

    public ReaderThread(CommandProcessor commandProcessor, int n) {
        this.cp = commandProcessor;
        this.iNetworkID = n;
    }

    private void closeInputStream() {
        if (this.in == null) return;
        try {
            if (this.iNetworkID != -1) {
                this.in.close();
                StringBuilder stringBuilder = new StringBuilder();
                Log.i((String)LOG_TAG, (String)stringBuilder.append(this.workerThread.getName()).append(" InputStream closed").toString());
            }
        }
        catch (IOException iOException) {
            Log.e((String)LOG_TAG, (String)(this.workerThread.getName() + " close exception"), (Throwable)iOException);
        }
        Log.i((String)LOG_TAG, (String)(this.workerThread.getName() + " close"));
    }

    private void sendError() {
        if (this.iNetworkID == -1) return;
        if (this.cp == null) return;
        if (!(this.cp instanceof NetworkCommandProcessor)) return;
        byte[] byArray = new byte[13];
        IO.put4(byArray, IO.put1(byArray, IO.put4(byArray, IO.put4(byArray, 0, 9), 521), this.iNetworkID), 1);
        FromServer fromServer = new FromServer();
        fromServer.m_bPacket = byArray;
        Log.i((String)LOG_TAG, (String)(this.workerThread.getName() + " send connection error msg "));
        this.cp.writePacket(fromServer);
    }

    private void sendOnReceiveData(int n, byte[] byArray, FromServer fromServer) {
        int n2 = n + 8 + 1;
        fromServer.m_bPacket = new byte[n2 + 4];
        n2 = IO.put4(fromServer.m_bPacket, 0, n2);
        n2 = IO.put4(fromServer.m_bPacket, n2, 520);
        n2 = IO.put4(fromServer.m_bPacket, n2, n);
        System.arraycopy((byte[])byArray, (int)0, (byte[])fromServer.m_bPacket, (int)n2, (int)n);
        IO.put1(fromServer.m_bPacket, n2 + n, this.iNetworkID);
        Log.i((String)LOG_TAG, (String)(this.workerThread.getName() + " " + new Date().toString() + " OnReceiveData from the " + this.cp.toString()));
    }

    public void closeConnection() {
        if (this.objMyReadLock != null) {
            Object object = this.objMyReadLock;
            synchronized (object) {
                this.isReadyForClose = true;
                StringBuilder stringBuilder = new StringBuilder();
                Log.i((String)LOG_TAG, (String)stringBuilder.append(this.workerThread.getName()).append(" notify ").toString());
                this.objMyReadLock.notify();
            }
        }
        if (this.workerThread != null) {
            this.workerThread.interrupt();
        }
        this.closeInputStream();
    }

    public boolean isReadyForColse() {
        return this.isReadyForClose;
    }

    /*
     * Exception decompiling
     */
    @Override
    public void run() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Back jump on a try block [egrp 6[TRYBLOCK] [40, 41, 42, 43 : 210->248)] java.net.SocketTimeoutException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.insertExceptionBlocks(Op02WithProcessedDataAndRefs.java:2289)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:414)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:73)
         *     at org.benf.cfr.reader.Main.main(Main.java:49)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:303)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$null$1(ResourceDecompiling.java:113)
         *     at java.base/java.lang.Thread.run(Unknown Source)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public void setClientSocket(Socket socket, String string) throws IllegalArgumentException, IllegalStateException {
        if (socket == null) {
            throw new IllegalArgumentException("socket object must not be null");
        }
        if (!socket.isConnected()) {
            throw new IllegalStateException("socket is not connected");
        }
        if (socket.isClosed()) throw new IllegalStateException("socket is closed");
        if (socket.isInputShutdown()) {
            throw new IllegalStateException("socket is closed");
        }
        String string2 = string;
        if (string == null) {
            string2 = "ReadThread";
        }
        if (this.iNetworkID != -1) {
            Log.i((String)LOG_TAG, (String)"readerThread initialized");
            string2 = string2 + " NW:" + this.iNetworkID;
        } else {
            try {
                socket.setSoTimeout(200);
            }
            catch (SocketException socketException) {
                socketException.printStackTrace();
            }
        }
        this.m_CilentSocket = socket;
        this.isRead = true;
        this.workerThread = new Thread((Runnable)this, string2);
        this.workerThread.start();
    }

    public void setNetworkController(NetworkController networkController) {
        this.nc = networkController;
    }

    public void setStopLock(Object object) {
        this.objMyReadLock = object;
    }

    public void stopRead() {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            Log.i((String)LOG_TAG, (String)stringBuilder.append(this.workerThread.getName()).append(" stopRead invoked").toString());
            this.isRead = false;
            Log.i((String)LOG_TAG, (String)" stopRead by invoke closeInputStream()");
            this.closeInputStream();
            this.isReadyForClose = true;
            if (this.m_CilentSocket != null) {
                this.m_CilentSocket.close();
            }
            this.workerThread.interrupt();
            Log.i((String)LOG_TAG, (String)" stopRead by isReadyForClose is true");
            return;
        }
        catch (Exception exception) {
            Log.e((String)LOG_TAG, (String)exception.getMessage(), (Throwable)exception);
            return;
        }
    }
}

