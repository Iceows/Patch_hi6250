/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.android.supl.nc;

import android.util.Log;
import com.android.bytewriter.IO;
import com.android.supl.commprocessor.FromServer;
import com.android.supl.commprocessor.NetworkCommandProcessor;
import com.android.supl.nc.NetworkController;
import com.android.supl.nc.SendToServer;
import com.android.supl.nc.SuplServiceMgr;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.util.Date;
import java.util.concurrent.BlockingQueue;
import javax.net.ssl.SSLProtocolException;

public class WriterThread
implements Runnable {
    private static final String LOG_TAG = "SUPL20_SPIMESLP-SENDING";
    private static final int m_iBufferSize = 10;
    private BlockingQueue<SendToServer> deque = null;
    private int iNetWorkID = -1;
    private int iNumberOfMessageOnQueue = 0;
    private transient boolean isBrokenPipe = false;
    private boolean isReadyForColse = false;
    private boolean isStopWrite = false;
    private Socket m_CilentSocket = null;
    private NetworkController nc = null;
    private Object objMyWriteLock = null;
    private OutputStream out = null;
    private Thread workerThread = null;

    public WriterThread(BlockingQueue<SendToServer> blockingQueue, NetworkController networkController, int n) throws IllegalArgumentException {
        if (blockingQueue == null) {
            throw new IllegalArgumentException("deque object  must not be null");
        }
        this.deque = blockingQueue;
        this.iNetWorkID = n;
        this.nc = networkController;
    }

    private void notifyToCloseConnection() {
        Object object = this.objMyWriteLock;
        synchronized (object) {
            this.isReadyForColse = true;
            this.objMyWriteLock.notify();
            return;
        }
    }

    private void sendError() {
        if (this.nc == null) return;
        NetworkCommandProcessor networkCommandProcessor = this.nc.getNetworkCommandProcessor();
        if (this.iNetWorkID == -1) return;
        if (networkCommandProcessor == null) return;
        if (!(networkCommandProcessor instanceof NetworkCommandProcessor)) return;
        byte[] byArray = new byte[13];
        IO.put4(byArray, IO.put1(byArray, IO.put4(byArray, IO.put4(byArray, 0, 9), 521), this.iNetWorkID), 1);
        FromServer fromServer = new FromServer();
        fromServer.m_bPacket = byArray;
        Log.i((String)LOG_TAG, (String)(this.workerThread.getName() + " send connection error msg"));
        networkCommandProcessor.writePacket(fromServer);
    }

    /*
     * Enabled unnecessary exception pruning
     */
    private void write(SendToServer sendToServer) {
        try {
            if (this.iNetWorkID == -1) {
                if (this.nc.IsSCM()) {
                    SuplServiceMgr.getInstance().writeToScm(sendToServer);
                    return;
                }
                SuplServiceMgr.getInstance().writeToPcm(sendToServer);
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder = stringBuilder.append(this.workerThread.getName()).append(" ");
            Date date = new Date();
            Log.i((String)LOG_TAG, (String)stringBuilder.append(date.toString()).append(" onSendData").toString());
            this.out.write(sendToServer.m_bPacket);
            this.out.flush();
            stringBuilder = new StringBuilder();
            Log.i((String)LOG_TAG, (String)stringBuilder.append("m_bPacket.length ").append(sendToServer.m_bPacket.length).toString());
            return;
        }
        catch (SSLProtocolException sSLProtocolException) {
            Log.e((String)LOG_TAG, (String)sSLProtocolException.getMessage(), (Throwable)sSLProtocolException);
            this.sendError();
            if (this.nc == null) return;
            if (this.isBrokenPipe) return;
            StringBuilder stringBuilder = new StringBuilder();
            Log.d((String)LOG_TAG, (String)stringBuilder.append("Removing SLP Session for nc=").append(this.nc).toString());
            this.nc.removeSLPSession();
            return;
        }
        catch (SocketException socketException) {
            this.sendError();
            Log.e((String)LOG_TAG, (String)socketException.getMessage(), (Throwable)socketException);
            boolean bl = this.isBrokenPipe;
            return;
        }
        catch (IOException iOException) {
            Log.i((String)LOG_TAG, (String)"Inside the IOException block of write--brokenpipe");
            this.sendError();
            Log.e((String)LOG_TAG, (String)iOException.getMessage(), (Throwable)iOException);
            this.isBrokenPipe = true;
            Log.i((String)LOG_TAG, (String)"calling nc.stop with reconnect as true");
            this.nc.stop(true, null, true);
            Log.i((String)LOG_TAG, (String)"addPacket after broken pipe");
            return;
        }
        finally {
            Log.i((String)LOG_TAG, (String)("bBrokenPipe = " + this.isBrokenPipe));
            if (!this.isBrokenPipe) return;
            Log.i((String)LOG_TAG, (String)"Adding packet to queue since pipe is broken");
            this.addPacket(sendToServer);
            return;
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled unnecessary exception pruning
     */
    public void addPacket(SendToServer var1_1) throws NullPointerException {
        if (var1_1 != null) ** GOTO lbl-1000
        try {
            var1_1 = new NullPointerException("packet must not be null");
            throw var1_1;
        }
        catch (InterruptedException var1_2) {
            Log.e((String)"SUPL20_SPIMESLP-SENDING", (String)var1_2.getMessage(), (Throwable)var1_2);
            return;
        }
lbl-1000:
        // 1 sources

        {
            if (this.deque.size() == 10) {
                var2_3 = new StringBuilder();
                Log.w((String)"SUPL20_SPIMESLP-SENDING", (String)var2_3.append("isBrokenPipe: ").append(this.isBrokenPipe).append("isStopWrite: ").append(this.isStopWrite).toString());
            }
            this.incrementMessageCount();
            this.deque.put((SendToServer)var1_1);
            return;
        }
    }

    public void closeWrite() {
        try {
            if (this.out == null) return;
            if (this.iNetWorkID == -1) return;
            this.out.close();
            StringBuilder stringBuilder = new StringBuilder();
            Log.i((String)LOG_TAG, (String)stringBuilder.append(this.workerThread.getName()).append(" close the write ").toString());
            return;
        }
        catch (IOException iOException) {
            Log.e((String)LOG_TAG, (String)iOException.getMessage(), (Throwable)iOException);
            return;
        }
    }

    public void decrementMessageCount() {
        synchronized (this) {
            --this.iNumberOfMessageOnQueue;
            return;
        }
    }

    public int getMessageCount() {
        synchronized (this) {
            return this.iNumberOfMessageOnQueue;
        }
    }

    public void incrementMessageCount() {
        synchronized (this) {
            ++this.iNumberOfMessageOnQueue;
            return;
        }
    }

    public boolean isReadyForColse() {
        return this.isReadyForColse;
    }

    public boolean isSessionRunning() {
        boolean bl = true;
        boolean bl2 = this.deque.isEmpty();
        Log.i((String)LOG_TAG, (String)("isSessionRunning deque size:" + this.deque.size() + ", getMessageCount:" + this.getMessageCount() + ", isBrokenPipe : " + this.isBrokenPipe));
        boolean bl3 = bl;
        if (bl2 ^ true) return bl3;
        if (this.getMessageCount() <= 0) return false;
        return bl;
    }

    @Override
    public void run() {
        while (!(this.isBrokenPipe || this.isStopWrite && !this.isSessionRunning())) {
            try {
                SendToServer sendToServer = this.deque.take();
                if (sendToServer == null) continue;
                this.write(sendToServer);
                this.decrementMessageCount();
            }
            catch (InterruptedException interruptedException) {
                Log.i((String)LOG_TAG, (String)(this.workerThread.getName() + " Allowed to exit"));
                break;
            }
        }
        if (!this.isStopWrite) return;
        if (this.isSessionRunning()) return;
        this.notifyToCloseConnection();
    }

    /*
     * Unable to fully structure code
     */
    public void setClientSocket(Socket var1_1, String var2_2) throws IllegalStateException, IllegalArgumentException {
        if (var1_1 == null) {
            throw new IllegalArgumentException("socket object must not be null");
        }
        if (!var1_1.isConnected()) {
            throw new IllegalStateException("socket is not connected");
        }
        if (var1_1.isClosed() != false) throw new IllegalStateException("socket is closed");
        if (var1_1.isOutputShutdown()) {
            throw new IllegalStateException("socket is closed");
        }
        var3_3 = var2_2;
        if (var2_2 == null) {
            var3_3 = "WriterThread";
        }
        var2_2 = var3_3;
        if (this.iNetWorkID != -1) {
            var2_2 = var3_3 + " NW:" + this.iNetWorkID;
            Log.i((String)"SUPL20_SPIMESLP-SENDING", (String)("setClientSocket :" + this.iNetWorkID));
        }
        this.m_CilentSocket = var1_1;
        try {
            this.out = var1_1.getOutputStream();
lbl19:
            // 2 sources

            while (true) {
                this.isBrokenPipe = false;
                this.workerThread = new Thread((Runnable)this, var2_2);
                this.workerThread.start();
                this.m_CilentSocket = var1_1;
                return;
            }
        }
        catch (IOException var3_4) {
            var3_4.printStackTrace();
            ** continue;
        }
    }

    public void setStopLock(Object object) {
        this.objMyWriteLock = object;
    }

    public void startThread() {
        Log.i((String)LOG_TAG, (String)"startThread");
        if (this.iNetWorkID == -1) {
            this.isBrokenPipe = false;
            this.workerThread = new Thread((Runnable)this, "WriterThread");
            this.workerThread.start();
            SuplServiceMgr.getInstance().getSUPLHILDInterface();
            return;
        }
        Log.e((String)LOG_TAG, (String)"socket don't start write thread here.");
    }

    public void stopWrite() {
        if (this.isBrokenPipe || this.isSessionRunning() ^ true) {
            if (this.workerThread != null) {
                this.workerThread.interrupt();
            }
            this.notifyToCloseConnection();
        }
        this.isStopWrite = true;
    }
}

