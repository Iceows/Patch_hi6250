/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.android.supl.nc;

import android.util.Log;
import com.android.supl.SUPLHIDLInterface;
import com.android.supl.SuplApplication;
import com.android.supl.commprocessor.CommandProcessor;
import com.android.supl.commprocessor.FromServer;
import com.android.supl.nc.SendToServer;

public class SuplServiceMgr {
    private static final String LOG_TAG = "SuplServiceMgr";
    private static SuplServiceMgr mInstance = null;
    private CommandProcessor mPcmCommandProcessor = null;
    private CommandProcessor mScmCommandProcessor = null;
    private SUPLHIDLInterface mSuplHidl = null;

    private SuplServiceMgr() {
    }

    public static SuplServiceMgr getInstance() {
        synchronized (SuplServiceMgr.class) {
            SuplServiceMgr suplServiceMgr;
            if (mInstance == null) {
                Log.i((String)LOG_TAG, (String)"new one");
                mInstance = suplServiceMgr = new SuplServiceMgr();
            }
            suplServiceMgr = mInstance;
            return suplServiceMgr;
        }
    }

    public void addPcmPacket(FromServer fromServer) {
        if (this.mPcmCommandProcessor != null) {
            this.mPcmCommandProcessor.writePacket(fromServer);
            return;
        }
        Log.e((String)LOG_TAG, (String)"mPcmCommandProcessor is null");
    }

    public void addScmPacket(FromServer fromServer) {
        if (this.mScmCommandProcessor != null) {
            this.mScmCommandProcessor.writePacket(fromServer);
            return;
        }
        Log.e((String)LOG_TAG, (String)"mScmCommandProcessor is null");
    }

    public void getSUPLHILDInterface() {
        if (this.mSuplHidl == null) {
            Log.i((String)LOG_TAG, (String)"getSUPLHILDInterface");
            this.mSuplHidl = SUPLHIDLInterface.createSUPLHIDLInterface(SuplApplication.getContext());
            this.mSuplHidl.setSuplServiceMgr(this);
            return;
        }
        Log.i((String)LOG_TAG, (String)"SUPLHIDL interface already exist");
    }

    public void setPcmCommandProcessor(CommandProcessor commandProcessor) {
        this.mPcmCommandProcessor = commandProcessor;
    }

    public void setScmCommandProcessor(CommandProcessor commandProcessor) {
        this.mScmCommandProcessor = commandProcessor;
    }

    public void writeToPcm(SendToServer sendToServer) {
        if (this.mSuplHidl != null) {
            this.mSuplHidl.SendMsg2PCM(sendToServer);
            return;
        }
        Log.e((String)LOG_TAG, (String)"mSuplHidl is null");
    }

    public void writeToScm(SendToServer sendToServer) {
        if (this.mSuplHidl != null) {
            this.mSuplHidl.SendMsg2SCM(sendToServer);
            return;
        }
        Log.e((String)LOG_TAG, (String)"mSuplHidl is null");
    }
}

