/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.content.Context
 *  android.content.Intent
 *  android.os.SystemProperties
 */
package com.android.supl;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.SystemProperties;
import com.android.supl.Log;
import com.android.supl.commprocessor.SUPLSCMService;
import com.android.supl.loc.SUPLPlatformService;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class SuplApplication
extends Application {
    private static final String TAG = "SUPL20_Main";
    private static Context context;

    public static Context getContext() {
        return context;
    }

    private void startSuplServices() {
        if (!"1".equals(SystemProperties.get((String)"is_hisi_connectivity_chip"))) {
            Log.d(TAG, "Not hisi chip, quit now!");
            return;
        }
        new Thread(){

            @Override
            public void run() {
                Intent intent = new Intent(context, SUPLPlatformService.class);
                context.startService(intent);
                Log.d(SuplApplication.TAG, "Starting platform service");
                intent = new Intent(context, SUPLSCMService.class);
                context.startService(intent);
                Log.d(SuplApplication.TAG, "Starting scm service");
            }
        }.start();
    }

    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "Starting supl application");
        context = this.getApplicationContext();
        this.startSuplServices();
    }
}

