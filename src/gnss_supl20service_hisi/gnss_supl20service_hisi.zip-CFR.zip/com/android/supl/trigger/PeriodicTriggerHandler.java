/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.android.supl.trigger;

import android.util.Log;
import com.android.bytewriter.IO;
import com.android.supl.commprocessor.NDKCommProcessor;
import com.android.supl.nc.SendToServer;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Timer;
import java.util.TimerTask;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class PeriodicTriggerHandler {
    private static final String LOG_TAG = "SUPL20_Trigger";
    public static final int MSG_PCM_ON_ERROR_TRIGGER_PERIODIC = 272;
    public static final int MSG_PCM_ON_TRIGGER_PERIODIC = 268;
    public static final int MSG_PCM_START_TRIGGER_PERIODIC = 260;
    public static final int MSG_PCM_STOP_TRIGGER_PERIODIC = 261;
    private static final int PERIODIC_TRIGGER_ERROR_CODE_CANT_SET_TRIGGER = 1;
    private static final int PERIODIC_TRIGGER_ERROR_CODE_OTHER = 2;
    private static final int PERIODIC_TRIGGER_ERROR_CODE_TRIGGER_NOT_AVAILABLE = 0;
    private static PeriodicTriggerHandler sPeriodicTriggerHandler = null;
    private HashMap<String, RemainderTask> hsTrigger = new HashMap();
    private NDKCommProcessor mNdkCommProcessor = null;

    private PeriodicTriggerHandler() {
    }

    public static PeriodicTriggerHandler getInstance() {
        if (sPeriodicTriggerHandler != null) return sPeriodicTriggerHandler;
        sPeriodicTriggerHandler = new PeriodicTriggerHandler();
        return sPeriodicTriggerHandler;
    }

    private String makeKey(int n, short s) {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(n);
        stringBuffer.append(":");
        stringBuffer.append(s);
        return stringBuffer.toString();
    }

    public void OnErrorTriggerPeriodic(int n, int n2, int n3) {
        byte[] byArray = new byte[15];
        if (IO.put4(byArray, IO.put1(byArray, IO.put2(byArray, IO.put4(byArray, IO.put4(byArray, 0, 11), 272), n), n2), n3) - 4 != 11) {
            System.out.println("OnErrorTriggerPeriodic length invalid");
        }
        Log.e((String)LOG_TAG, (String)("OnErrorTriggerPeriodic " + n + " " + n2 + " " + n3));
        SendToServer sendToServer = new SendToServer();
        sendToServer.m_bPacket = byArray;
        this.mNdkCommProcessor.sendServer(sendToServer);
    }

    public void clear() {
        Iterator iterator = this.hsTrigger.keySet().iterator();
        while (true) {
            if (!iterator.hasNext()) {
                this.hsTrigger.clear();
                sPeriodicTriggerHandler = null;
                return;
            }
            String string = (String)iterator.next();
            this.hsTrigger.get(string).stopTrigger();
        }
    }

    public void pause() {
        Iterator iterator = this.hsTrigger.keySet().iterator();
        while (true) {
            if (!iterator.hasNext()) {
                this.hsTrigger.clear();
                return;
            }
            String string = (String)iterator.next();
            this.hsTrigger.get(string).stopTrigger();
        }
    }

    public void sendOnTriggerPeriodic(int n, int n2, int n3) {
        byte[] byArray = new byte[15];
        if (IO.put4(byArray, IO.put1(byArray, IO.put2(byArray, IO.put4(byArray, IO.put4(byArray, 0, 11), 268), n), n2), n3) - 4 != 11) {
            System.out.println("sendOnTriggerPeriodic length invalid");
        }
        SendToServer sendToServer = new SendToServer();
        sendToServer.m_bPacket = byArray;
        this.mNdkCommProcessor.sendServer(sendToServer);
    }

    public void setNdkCommProcessor(NDKCommProcessor nDKCommProcessor) {
        this.mNdkCommProcessor = nDKCommProcessor;
    }

    public boolean startTriggerPeriodic(DataInputStream object) throws IOException {
        int n = ((DataInputStream)object).readUnsignedShort();
        short s = (short)((DataInputStream)object).readUnsignedByte();
        int n2 = ((DataInputStream)object).readInt();
        int n3 = ((DataInputStream)object).readInt();
        object = this.makeKey(n, s);
        if (this.hsTrigger.get(object) != null && n2 <= 0) {
            this.OnErrorTriggerPeriodic(n, s, 1);
            return true;
        }
        RemainderTask remainderTask = new RemainderTask(n, n2, n2, s, n3);
        this.hsTrigger.put((String)object, remainderTask);
        return true;
    }

    public boolean stopTriggerPeriodic(DataInputStream object) throws IOException {
        short s;
        int n = ((DataInputStream)object).readUnsignedShort();
        RemainderTask remainderTask = this.hsTrigger.get(object = this.makeKey(n, s = (short)((DataInputStream)object).readUnsignedByte()));
        if (remainderTask == null) {
            this.OnErrorTriggerPeriodic(n, s, 0);
            Log.e((String)LOG_TAG, (String)"stopTriggerPeriodic invalid id or trigger id");
            return true;
        }
        remainderTask.stopTrigger();
        this.hsTrigger.remove(object);
        return true;
    }

    private class RemainderTask
    extends TimerTask {
        private Timer mTimer = null;
        private short m_ucTriggerId = 0;
        private int m_unPeriod = 0;
        private int m_unTime = 0;
        private int sSessionID = -1;

        public RemainderTask(int n, int n2, int n3, short s, int n4) {
            this.sSessionID = n;
            this.m_unPeriod = n3;
            this.m_ucTriggerId = s;
            this.m_unTime = n4;
            this.mTimer = new Timer("Trigger thr " + n + ":" + s);
            this.mTimer.schedule((TimerTask)this, n2, (long)this.m_unPeriod);
            Log.i((String)PeriodicTriggerHandler.LOG_TAG, (String)("start Trigger SID:" + n + " TI:" + s + " TimeCount:" + n4 + " Delay to Start:" + n2 + " Interval Time:" + n3));
        }

        @Override
        public void run() {
            Log.i((String)PeriodicTriggerHandler.LOG_TAG, (String)("sendOnTriggerPeriodic SID:" + this.sSessionID + " TI:" + this.m_ucTriggerId + " TimeIX:" + this.m_unTime));
            PeriodicTriggerHandler.this.sendOnTriggerPeriodic(this.sSessionID, this.m_ucTriggerId, this.m_unTime);
            if (this.m_unTime == 0) return;
            --this.m_unTime;
            if (this.m_unTime != 0) return;
            this.stopTrigger();
        }

        public void stopTrigger() {
            Log.i((String)PeriodicTriggerHandler.LOG_TAG, (String)("stopTrigger SID:" + this.sSessionID + " TI:" + this.m_ucTriggerId + " TimeIX:" + this.m_unTime));
            this.m_unTime = 0;
            String string = PeriodicTriggerHandler.this.makeKey(this.sSessionID, this.m_ucTriggerId);
            PeriodicTriggerHandler.this.hsTrigger.remove(string);
            this.mTimer.cancel();
            this.cancel();
        }
    }
}

