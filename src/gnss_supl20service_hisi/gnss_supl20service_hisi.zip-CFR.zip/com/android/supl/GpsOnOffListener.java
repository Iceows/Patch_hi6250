/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl;

public interface GpsOnOffListener {
    public void onGPSLocationProviderDisabled();

    public void onGPSLocationProviderEnabled();
}

