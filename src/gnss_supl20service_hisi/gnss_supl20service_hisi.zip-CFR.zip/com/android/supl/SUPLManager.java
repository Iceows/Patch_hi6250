/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.ContentQueryMap
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.os.Handler
 *  android.provider.Settings$Secure
 *  android.util.Log
 */
package com.android.supl;

import android.content.ContentQueryMap;
import android.content.ContentResolver;
import android.content.Context;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import com.android.supl.GpsOnOffListener;
import com.android.supl.commprocessor.SUPLSCMService;
import com.android.supl.config.ConfigManager;
import com.android.supl.loc.SUPLPlatformService;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;
import java.util.Vector;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class SUPLManager {
    private static final String LOG_TAG = "SUPL20_SUPLManager";
    public static final String SUPL_SI = "supl20mgr";
    private static SUPLManager suplManager = null;
    private boolean isGpsEnableReceReg = false;
    private Context mContext = null;
    private SUPLPlatformService mPlatformService = null;
    private ContentQueryMap mSettings = null;
    private SUPLSCMService mSuplscmService = null;
    private Handler m_Handler = null;
    private SettingsObserver settingsObserver = null;
    private Vector<GpsOnOffListener> vecGpsListeners = null;

    private SUPLManager() {
    }

    public SUPLManager(Context context) {
        if (suplManager != null) throw new IllegalAccessError("Instance already created. call getIntance method");
        suplManager = this;
        this.mContext = context;
        this.init();
        this.mPlatformService = new SUPLPlatformService(context);
        this.mSuplscmService = new SUPLSCMService(context);
    }

    private static boolean delimitedStringContains(String string, char c, String string2) {
        int n;
        if (SUPLManager.isEmpty(string)) return false;
        if (SUPLManager.isEmpty(string2)) {
            return false;
        }
        int n2 = -1;
        int n3 = string.length();
        while ((n = string.indexOf(string2, n2 + 1)) != -1) {
            int n4;
            if (n > 0) {
                n2 = n;
                if (string.charAt(n - 1) != c) continue;
            }
            if ((n4 = n + string2.length()) == n3) {
                return true;
            }
            n2 = n;
            if (string.charAt(n4) == c) return true;
        }
        return false;
    }

    private void deregisterSettingObserver() {
        if (!this.isGpsEnableReceReg) return;
        this.mSettings.deleteObserver(this.settingsObserver);
        this.isGpsEnableReceReg = false;
    }

    public static SUPLManager getInstance(Context object) {
        synchronized (SUPLManager.class) {
            if (suplManager == null) {
                SUPLManager sUPLManager;
                suplManager = sUPLManager = new SUPLManager();
                SUPLManager.suplManager.mContext = object;
                suplManager.init();
            }
            object = suplManager;
            return object;
        }
    }

    private void init() {
        this.m_Handler = new Handler();
        if (ConfigManager.getInstance().getSUPLVersion() != 1) return;
        this.vecGpsListeners = new Vector(2);
        this.registerSettingObserver();
    }

    private static boolean isEmpty(CharSequence charSequence) {
        if (charSequence == null) return true;
        if (charSequence.length() != 0) return false;
        return true;
    }

    private boolean isLocationProviderEnabled(ContentResolver contentResolver, String string) {
        return SUPLManager.delimitedStringContains(Settings.Secure.getString((ContentResolver)contentResolver, (String)"location_providers_allowed"), ',', string);
    }

    private void notifytoALLGpsDisableChanges() {
        if (this.vecGpsListeners == null) return;
        Iterator iterator = this.vecGpsListeners.iterator();
        while (iterator.hasNext()) {
            GpsOnOffListener gpsOnOffListener = (GpsOnOffListener)iterator.next();
            if (gpsOnOffListener == null) continue;
            gpsOnOffListener.onGPSLocationProviderDisabled();
        }
    }

    private void notifytoALLGpsEnableChanges() {
        if (this.vecGpsListeners == null) return;
        Iterator iterator = this.vecGpsListeners.iterator();
        while (iterator.hasNext()) {
            GpsOnOffListener gpsOnOffListener = (GpsOnOffListener)iterator.next();
            if (gpsOnOffListener == null) continue;
            gpsOnOffListener.onGPSLocationProviderEnabled();
        }
    }

    private void registerSettingObserver() {
        if (this.isGpsEnableReceReg) return;
        this.mSettings = new ContentQueryMap(this.mContext.getContentResolver().query(Settings.Secure.CONTENT_URI, null, "(name=?)", new String[]{"location_providers_allowed"}, null), "name", true, this.m_Handler);
        this.settingsObserver = new SettingsObserver();
        this.mSettings.addObserver(this.settingsObserver);
        this.isGpsEnableReceReg = true;
    }

    private void startCommnMgrs(String string) {
        if (this.isLocationProviderEnabled(this.mContext.getContentResolver(), string)) {
            Log.d((String)LOG_TAG, (String)"Send GPS enable info");
            this.notifytoALLGpsEnableChanges();
            return;
        }
        Log.d((String)LOG_TAG, (String)"Send GPS disable info");
        this.notifytoALLGpsDisableChanges();
    }

    public boolean addGpsListener(GpsOnOffListener gpsOnOffListener) {
        boolean bl;
        boolean bl2 = bl = false;
        if (this.vecGpsListeners == null) return bl2;
        bl2 = bl;
        if (gpsOnOffListener == null) return bl2;
        if (this.vecGpsListeners.size() != 0) return this.vecGpsListeners.add(gpsOnOffListener);
        this.registerSettingObserver();
        return this.vecGpsListeners.add(gpsOnOffListener);
    }

    public boolean removeGpsListener(GpsOnOffListener gpsOnOffListener) {
        boolean bl;
        boolean bl2 = bl = false;
        if (this.vecGpsListeners == null) return bl2;
        bl2 = bl;
        if (gpsOnOffListener == null) return bl2;
        bl2 = bl = this.vecGpsListeners.remove(gpsOnOffListener);
        if (this.vecGpsListeners.size() != 0) return bl2;
        this.deregisterSettingObserver();
        return bl;
    }

    private final class SettingsObserver
    implements Observer {
        private SettingsObserver() {
        }

        @Override
        public void update(Observable observable, Object object) {
            SUPLManager.this.startCommnMgrs("gps");
        }
    }
}

