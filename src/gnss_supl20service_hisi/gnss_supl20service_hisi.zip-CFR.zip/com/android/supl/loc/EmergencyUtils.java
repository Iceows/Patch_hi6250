/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc;

public class EmergencyUtils {
    public static String[] NUMBER = new String[]{"15", "14", "16", "17", "18", "19", "011", "022", "033", "019", "000", "066", "065", "068", "100", "101", "102", "103", "105", "107", "108", "111", "110", "112", "113", "114", "115", "116", "117", "118", "119", "120", "122", "123", "124", "125", "127", "128", "129", "133", "132", "131", "140", "155", "156", "171", "177", "175", "180", "190", "191", "192", "193", "197", "198", "199", "211", "311", "511", "991", "993", "994", "995", "997", "998", "999", "901", "902", "903", "911", "990", "912", "913", "10111", "10177", "1298", "1122", "1669", "9170", "2611"};

    public static boolean isEmergencyNumber(String string) {
        boolean bl = false;
        if (string == null) {
            return false;
        }
        try {
            String[] stringArray = NUMBER;
            int n = 0;
            int n2 = stringArray.length;
            while (true) {
                boolean bl2 = bl;
                if (n >= n2) return bl2;
                bl2 = string.equals(stringArray[n]);
                if (bl2) {
                    return true;
                }
                ++n;
            }
        }
        catch (NumberFormatException numberFormatException) {
            return bl;
        }
    }
}

