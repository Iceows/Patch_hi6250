/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.telephony.CellLocation
 *  android.telephony.gsm.GsmCellLocation
 */
package com.android.supl.loc;

import android.telephony.CellLocation;
import android.telephony.gsm.GsmCellLocation;
import com.android.bytewriter.IO;
import com.android.supl.loc.measure.FrequencyInfo;
import com.android.supl.loc.measure.MeasuredResultsList;
import com.android.supl.loc.measure.TimingAdvance;

public class WcdmaCellInfo {
    public boolean IsMeasuredResultsListPresent = false;
    public boolean bIsCellParametersIdPresent;
    public boolean isFrequencyInfoPresent = false;
    public boolean isPrimaryScramblingCodePresent = false;
    public boolean isTimingAdvancePresent;
    public FrequencyInfo mFrequencyInfo = null;
    public short m_sLAC = 0;
    public short m_sMCC = 0;
    public short m_sMNC = 0;
    public MeasuredResultsList stMeasuredResultsList;
    public TimingAdvance stTimingAdvance;
    public short ucCellParametersId;
    public int uiRefUC = 0;
    public short usPrimaryScramblingCode;

    public WcdmaCellInfo(CellLocation cellLocation, int n, int n2) {
        cellLocation = (GsmCellLocation)cellLocation;
        this.m_sMNC = (short)n;
        this.m_sMCC = (short)n2;
        this.m_sLAC = (short)cellLocation.getLac();
        this.uiRefUC = cellLocation.getCid();
    }

    public byte[] getWCDMAInfo() {
        byte[] byArray;
        byte[] byArray2;
        int n = 30;
        byte[] byArray3 = byArray2 = null;
        int n2 = n;
        if (this.isFrequencyInfoPresent) {
            byArray3 = byArray2;
            n2 = n;
            if (this.mFrequencyInfo != null) {
                byArray3 = byArray2 = this.mFrequencyInfo.getFrequencyInfo();
                n2 = n;
                if (byArray2 != null) {
                    n2 = byArray2.length + 30;
                    byArray3 = byArray2;
                }
            }
        }
        int n3 = n2;
        if (this.isPrimaryScramblingCodePresent) {
            n3 = n2 + 2;
        }
        byArray2 = byArray = null;
        n = n3;
        if (this.IsMeasuredResultsListPresent) {
            byArray2 = byArray;
            n = n3;
            if (this.stMeasuredResultsList != null) {
                byArray2 = this.stMeasuredResultsList.getMeasuredResultsListInfo();
                n = n3 + byArray2.length;
            }
        }
        n2 = n;
        if (this.bIsCellParametersIdPresent) {
            n2 = n + 1;
        }
        byte[] byArray4 = null;
        byArray = byArray4;
        n = n2;
        if (this.isTimingAdvancePresent) {
            byArray = byArray4;
            n = n2;
            if (this.stTimingAdvance != null) {
                byArray = this.stTimingAdvance.getTimingAdvanceInfo();
                n = n2 + byArray.length;
            }
        }
        byArray4 = new byte[n];
        n2 = IO.put4(byArray4, IO.put2(byArray4, IO.put2(byArray4, IO.put2(byArray4, 0, this.m_sMCC), this.m_sMNC), this.m_sLAC), this.uiRefUC);
        if (this.isFrequencyInfoPresent && byArray3 != null) {
            n2 = IO.put4(byArray4, n2, 1);
            System.arraycopy((byte[])byArray3, (int)0, (byte[])byArray4, (int)n2, (int)byArray3.length);
            n2 += byArray3.length;
        } else {
            n2 = IO.put4(byArray4, n2, 0);
        }
        n2 = this.isPrimaryScramblingCodePresent ? IO.put2(byArray4, IO.put4(byArray4, n2, 1), this.usPrimaryScramblingCode) + 2 : IO.put4(byArray4, n2, 0);
        if (this.IsMeasuredResultsListPresent && byArray2 != null) {
            n2 = IO.put4(byArray4, n2, 1);
            System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray4, (int)n2, (int)byArray2.length);
            n2 += byArray2.length;
        } else {
            n2 = IO.put4(byArray4, n2, 0);
        }
        n2 = this.bIsCellParametersIdPresent ? IO.put1(byArray4, IO.put4(byArray4, n2, 1), this.ucCellParametersId) + 1 : IO.put4(byArray4, n2, 0);
        if (this.isTimingAdvancePresent && byArray != null) {
            n2 = IO.put4(byArray4, n2, 1);
            System.arraycopy((byte[])byArray, (int)0, (byte[])byArray4, (int)n2, (int)byArray.length);
            n2 += byArray.length;
        } else {
            n2 = IO.put4(byArray4, n2, 0);
        }
        if (n2 == n) return byArray4;
        System.out.println("getWCDMAInfo invalid length");
        return byArray4;
    }
}

