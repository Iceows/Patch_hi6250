/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc;

import com.android.bytewriter.IO;

public class StaleLocationInfo {
    private byte[] bLocInfo = null;
    private int iStaleBitlocat = 0;

    public StaleLocationInfo(byte[] byArray, int n) {
        this.bLocInfo = byArray;
        this.iStaleBitlocat = n;
    }

    public byte[] getStaleLocation() {
        if (IO.get1(this.bLocInfo, this.iStaleBitlocat) == 1) {
            IO.put1(this.bLocInfo, this.iStaleBitlocat, 0);
            return this.bLocInfo;
        }
        System.out.println("Stale Location error");
        return this.bLocInfo;
    }

    public void upDateInfo(byte[] byArray, int n) {
        this.bLocInfo = byArray;
        this.iStaleBitlocat = n;
    }
}

