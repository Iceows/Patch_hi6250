/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.Service
 *  android.content.Context
 *  android.content.Intent
 *  android.os.IBinder
 *  android.util.Log
 */
package com.android.supl.loc;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import com.android.supl.GpsOnOffListener;
import com.android.supl.SUPLManager;
import com.android.supl.commprocessor.NDKCommProcessor;
import com.android.supl.config.ConfigManager;
import com.android.supl.loc.SETLocationManager;
import com.android.supl.trigger.PeriodicTriggerHandler;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class SUPLPlatformService
extends Service
implements GpsOnOffListener {
    private final String LOG_TAG;
    private boolean isInit = false;
    private Context mContext = null;
    private SETLocationManager mLocationManager = null;
    private NDKCommProcessor mNDKCommProcessor = null;
    private Thread pcmThread = null;

    static /* synthetic */ NDKCommProcessor -get0(SUPLPlatformService sUPLPlatformService) {
        return sUPLPlatformService.mNDKCommProcessor;
    }

    public SUPLPlatformService() {
        this.LOG_TAG = "SUPL20_PCMService";
        this.mContext = this;
    }

    public SUPLPlatformService(Context context) {
        this.LOG_TAG = "SUPL20_PCMService";
        this.mContext = context;
        this.onCreate();
    }

    private void start() {
        this.isInit = true;
        this.mLocationManager = new SETLocationManager(this.mContext);
        ConfigManager configManager = ConfigManager.getInstance();
        int n = configManager.getPCMPort();
        String string = configManager.getPCMIpAdress();
        int n2 = configManager.getNwTimeout();
        int n3 = configManager.getNwRetries();
        this.mNDKCommProcessor = new NDKCommProcessor(false, string, n, this.mLocationManager, n2, n3);
        this.pcmThread = new Thread(new PCMConnectionThread());
        this.pcmThread.setName("PCM handsake thread");
        this.pcmThread.start();
        Log.d((String)"SUPL20_PCMService", (String)"SUPL20 service version :2.13.2.0");
        Log.d((String)"SUPL20_PCMService", (String)"Platform Service Created");
    }

    private void startPCM() {
        Log.d((String)"SUPL20_PCMService", (String)"Send startPCM ");
        if (this.isInit) {
            this.mNDKCommProcessor.reInit();
        } else {
            this.start();
        }
        Log.d((String)"SUPL20_PCMService", (String)"Send startPCM finished");
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        ConfigManager.getInstance();
        Log.d((String)"SUPL20_PCMService", (String)"SUPL20 service version :2.13.2.0");
        this.start();
    }

    /*
     * Unable to fully structure code
     */
    public void onDestroy() {
        PeriodicTriggerHandler.getInstance().clear();
        if (this.mLocationManager != null) {
            this.mLocationManager.stopListening();
        }
        if (this.mNDKCommProcessor != null) {
            this.mNDKCommProcessor.sendByeMessage();
        }
        try {
            Thread.sleep(1000L);
lbl8:
            // 2 sources

            while (true) {
                if (this.mNDKCommProcessor != null) {
                    this.mNDKCommProcessor.stopNetWork();
                }
                this.pcmThread.interrupt();
                SUPLManager.getInstance(this.mContext).removeGpsListener(this);
                return;
            }
        }
        catch (InterruptedException var1_1) {
            var1_1.printStackTrace();
            ** continue;
        }
    }

    @Override
    public void onGPSLocationProviderDisabled() {
        Log.d((String)"SUPL20_PCMService", (String)" onGPSLocationProviderDisabled");
        if (this.isInit) {
            Log.d((String)"SUPL20_PCMService", (String)"PCM Service running. Will pause it.");
            this.mNDKCommProcessor.pause();
            return;
        }
        Log.e((String)"SUPL20_PCMService", (String)"PCM Service not already created");
    }

    @Override
    public void onGPSLocationProviderEnabled() {
        this.startPCM();
    }

    public void onStart(Intent intent, int n) {
        Log.d((String)"SUPL20_PCMService", (String)"onStart");
    }

    public int onStartCommand(Intent intent, int n, int n2) {
        return 1;
    }

    public class PCMConnectionThread
    implements Runnable {
        /*
         * Exception decompiling
         */
        @Override
        public void run() {
            /*
             * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
             * 
             * org.benf.cfr.reader.util.ConfusedCFRException: Back jump on a try block [egrp 3[TRYBLOCK] [13, 14 : 164->175)] java.lang.InterruptedException
             *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.insertExceptionBlocks(Op02WithProcessedDataAndRefs.java:2289)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:414)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
             *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
             *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:910)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1022)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
             *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
             *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
             *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:73)
             *     at org.benf.cfr.reader.Main.main(Main.java:49)
             *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:303)
             *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$null$1(ResourceDecompiling.java:113)
             *     at java.base/java.lang.Thread.run(Unknown Source)
             */
            throw new IllegalStateException("Decompilation failed");
        }
    }
}

