/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.lpp;

import com.android.bytewriter.IO;

public class SUPL_LPP_OTDOA_MMT_QUALITY {
    public boolean bNumberofSamplesPresent = true;
    public byte byErrorResolution = (byte)2;
    public byte byErrorValue = (byte)2;
    public byte byNumberofSamples = (byte)4;

    public byte[] getOTDOA_MMT_QUALITY() {
        int n = 6;
        if (this.bNumberofSamplesPresent) {
            n = 7;
        }
        byte[] byArray = new byte[n];
        int n2 = IO.put1(byArray, IO.put1(byArray, 0, this.byErrorResolution), this.byErrorValue);
        n = this.bNumberofSamplesPresent ? 1 : 0;
        n = IO.put4(byArray, n2, n);
        if (!this.bNumberofSamplesPresent) return byArray;
        IO.put1(byArray, n, this.byNumberofSamples);
        return byArray;
    }
}

