/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.aflt;

import com.android.bytewriter.IO;

public class SUPL_AFLT_PilotPhaseRecord {
    public int PilotMeasuredPhase;
    public int PilotPhaseDoppler;
    public int PilotPhaseMeasurementError;
    public int PilotStrength;
    public int PilotphaseFalseAlarmProbability;
    public int PilotphaseFalseAlarmRange;
    public int PseudoDopplerRMSError;
    public int RMSErrorPhase;
    public int RepeaterDetectionStatus;
    public byte[] RepeaterID = new byte[8];
    public int RepeaterType;

    public byte[] getAfltPilotPhaseRecord() {
        byte[] byArray = new byte[72];
        int n = IO.put4(byArray, IO.put4(byArray, IO.put4(byArray, IO.put4(byArray, IO.put4(byArray, IO.put4(byArray, 0, this.PilotMeasuredPhase), this.PilotStrength), this.RMSErrorPhase), this.PilotPhaseMeasurementError), this.RepeaterDetectionStatus), this.RepeaterType);
        int n2 = 0;
        while (true) {
            if (n2 >= 8) {
                IO.put4(byArray, IO.put4(byArray, IO.put4(byArray, IO.put4(byArray, n, this.PilotPhaseDoppler), this.PseudoDopplerRMSError), this.PilotphaseFalseAlarmProbability), this.PilotphaseFalseAlarmRange);
                return byArray;
            }
            n = IO.put1(byArray, n, this.RepeaterID[n2]);
            ++n2;
        }
    }
}

