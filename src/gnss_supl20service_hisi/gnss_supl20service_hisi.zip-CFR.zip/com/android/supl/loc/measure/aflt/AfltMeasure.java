/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.aflt;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.aflt.SUPL_AFLT_PilotPhaseRecord;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

public class AfltMeasure {
    public int BandClass;
    public int BaseStationID;
    public int CDMAFrequency;
    public boolean IsOffsetIncluded;
    public int MSTimeOffset;
    public int NetworkIdentification;
    public int ReferencePN;
    public int ReferencePilotStrength;
    public int SystemIdentification;
    public int TimeReference;
    public int TotalNumberOfPilots;
    public int TotalReceivedPower;
    public boolean bMeasurementValid;
    ArrayList<SUPL_AFLT_PilotPhaseRecord> phaseRecord = null;

    public byte[] getAFLTMeasInfo(int n) {
        Iterator iterator;
        int n2 = 1;
        int n3 = 12 + 4;
        Object object = null;
        int n4 = n3;
        Object object2 = object;
        if (this.bMeasurementValid) {
            n3 = n4 = n3 + 44;
            if (this.IsOffsetIncluded) {
                n3 = n4 + 4;
            }
            n4 = n3;
            object2 = object;
            if (this.TotalNumberOfPilots > 0) {
                n4 = n3;
                object2 = object;
                if (this.phaseRecord != null) {
                    object = new Vector(this.phaseRecord.size());
                    iterator = this.phaseRecord.iterator();
                    while (true) {
                        n4 = n3;
                        object2 = object;
                        if (!iterator.hasNext()) break;
                        object2 = (SUPL_AFLT_PilotPhaseRecord)iterator.next();
                        if (object2 == null || (object2 = (Object)object2.getAfltPilotPhaseRecord()) == null) continue;
                        ((Vector)object).add(object2);
                        n3 += ((byte[])object2).length;
                    }
                }
            }
        }
        object = new byte[n4];
        n3 = IO.put4((byte[])object, IO.put4((byte[])object, IO.put4((byte[])object, 0, n4 - 4), 276), n);
        n = this.bMeasurementValid ? 1 : 0;
        n = IO.put4((byte[])object, n3, n);
        if (!this.bMeasurementValid) return object;
        n3 = IO.put4((byte[])object, n, this.TimeReference);
        n = this.IsOffsetIncluded ? n2 : 0;
        n = n3 = IO.put4((byte[])object, n3, n);
        if (this.IsOffsetIncluded) {
            n = IO.put4((byte[])object, n3, this.MSTimeOffset);
        }
        n = IO.put4((byte[])object, IO.put4((byte[])object, IO.put4((byte[])object, IO.put4((byte[])object, IO.put4((byte[])object, IO.put4((byte[])object, IO.put4((byte[])object, IO.put4((byte[])object, IO.put4((byte[])object, n, this.ReferencePN), this.ReferencePilotStrength), this.BandClass), this.CDMAFrequency), this.BaseStationID), this.SystemIdentification), this.NetworkIdentification), this.TotalReceivedPower), this.TotalNumberOfPilots);
        if (this.TotalNumberOfPilots <= 0) return object;
        if (object2 == null) return object;
        iterator = object2.iterator();
        while (iterator.hasNext()) {
            object2 = (byte[])iterator.next();
            if (object2 == null) continue;
            System.arraycopy((byte[])object2, (int)0, (byte[])object, (int)n, (int)((byte[])object2).length);
            n += ((byte[])object2).length;
        }
        return object;
    }
}

