/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;

public class OTD_MSREleCommon {
    public short ucNumOfMeasurements;
    public short ucRefQuality;
    public short ucReferenceTimeSlot;
    public short ucStdResolution;
    public int usRefFrameNumber;
    public int usTACorrection;

    public byte[] getOTSMSREle() {
        byte[] byArray = new byte[8];
        IO.put2(byArray, IO.put1(byArray, IO.put1(byArray, IO.put1(byArray, IO.put1(byArray, IO.put2(byArray, 0, this.usRefFrameNumber), this.ucReferenceTimeSlot), this.ucRefQuality), this.ucNumOfMeasurements), this.ucStdResolution), this.usTACorrection);
        return byArray;
    }
}

