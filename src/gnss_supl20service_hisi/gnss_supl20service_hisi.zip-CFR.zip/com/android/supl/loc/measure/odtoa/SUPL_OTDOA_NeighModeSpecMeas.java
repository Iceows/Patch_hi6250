/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.odtoa;

import com.android.supl.loc.measure.odtoa.SUPL_OTDOA_MDSpecINF_TDD;
import com.android.supl.loc.measure.odtoa.SUPL_OTDOA_ModeSpecMeasFDD;

public class SUPL_OTDOA_NeighModeSpecMeas {
    public SUPL_OTDOA_ModeSpecMeasFDD stModeSpecificFDDMeas;
    public SUPL_OTDOA_MDSpecINF_TDD stModeSpecificTDDMeas;

    public byte[] getNeighModeSpecMeas() {
        byte[] byArray = null;
        if (this.stModeSpecificFDDMeas != null) {
            return this.stModeSpecificFDDMeas.getModeSpecMeasFDD();
        }
        if (this.stModeSpecificTDDMeas == null) return byArray;
        return this.stModeSpecificTDDMeas.getMDSpecINF_TDD();
    }
}

