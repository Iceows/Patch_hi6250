/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.eotd.OTD_MSR_OtherSets_Union;

public class OTD_MSRofOtherSets {
    public boolean bIsIdentityPresent;
    public OTD_MSR_OtherSets_Union stOTDMsr;

    public byte[] getOTD_MSRofOtherSets() {
        int n = 4;
        byte[] byArray = null;
        if (this.stOTDMsr != null) {
            byArray = this.stOTDMsr.getOTDOtherSets();
            n = byArray.length + 4;
        }
        byte[] byArray2 = new byte[n];
        n = this.bIsIdentityPresent ? 1 : 0;
        n = IO.put4(byArray2, 0, n);
        if (byArray == null) return byArray2;
        System.arraycopy((byte[])byArray, (int)0, (byte[])byArray2, (int)n, (int)byArray.length);
        n = byArray.length;
        return byArray2;
    }
}

