/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure;

import com.android.bytewriter.IO;

public class TimingAdvance {
    public static final int CHIP_RATE_TDD128 = 0;
    public static final int CHIP_RATE_TDD384 = 1;
    public static final int CHIP_RATE_TDD768 = 2;
    public static final int TA_RESOLUTION_RES0125CHIP = 2;
    public static final int TA_RESOLUTION_RES10CHIP = 0;
    public static final int TA_RESOLUTION_RES5CHIP = 1;
    private int enChipRate;
    private int enTAResolution;
    private boolean isChipRatePresent;
    private boolean isTAResolutionPresent;
    private short usTA;

    public TimingAdvance(short s, int n, int n2) {
        boolean bl = true;
        this.isTAResolutionPresent = false;
        this.enTAResolution = -1;
        this.isChipRatePresent = false;
        this.enChipRate = -1;
        this.usTA = s;
        this.enTAResolution = n;
        this.enChipRate = n2;
        boolean bl2 = n != -1;
        this.isTAResolutionPresent = bl2;
        bl2 = n2 != -1 ? bl : false;
        this.isChipRatePresent = bl2;
    }

    public byte[] getTimingAdvanceInfo() {
        int n = 10;
        if (this.isTAResolutionPresent) {
            n = 14;
        }
        int n2 = n;
        if (this.isChipRatePresent) {
            n2 = n + 4;
        }
        byte[] byArray = new byte[n2];
        n = IO.put2(byArray, 0, this.usTA);
        n = this.isTAResolutionPresent ? IO.put4(byArray, IO.put4(byArray, n, 1), this.enTAResolution) : IO.put4(byArray, n, 0);
        n = this.isChipRatePresent ? IO.put4(byArray, IO.put4(byArray, n, 1), this.enChipRate) : IO.put4(byArray, n, 0);
        if (n == n2) return byArray;
        System.out.println("TimingAdvance length error");
        return byArray;
    }
}

