/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.eotd.OTDMeans_WithID;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

public class OTD_MeasR98Ext {
    public ArrayList<OTDMeans_WithID> otd_FirstSetMsrs;
    public short ucCount;

    public byte[] getOTD_MeasR98Ext() {
        Iterator iterator;
        Object object;
        int n = 1;
        int n2 = 1;
        Object object2 = null;
        if (this.otd_FirstSetMsrs != null) {
            object = new Vector(this.otd_FirstSetMsrs.size());
            iterator = this.otd_FirstSetMsrs.iterator();
            while (true) {
                n = n2;
                object2 = object;
                if (!iterator.hasNext()) break;
                object2 = (OTDMeans_WithID)iterator.next();
                if (object2 == null || (object2 = (Object)((OTDMeans_WithID)object2).getOTDMeans_WithID()) == null) continue;
                ((Vector)object).add(object2);
                n2 += ((Object)object2).length;
            }
        }
        object = new byte[n];
        n2 = IO.put1((byte[])object, 0, this.ucCount);
        if (object2 == null) return object;
        iterator = object2.iterator();
        while (iterator.hasNext()) {
            object2 = (byte[])iterator.next();
            if (object2 == null) continue;
            System.arraycopy((byte[])object2, (int)0, (byte[])object, (int)n2, (int)((Object)object2).length);
            n2 += ((Object)object2).length;
        }
        return object;
    }
}

