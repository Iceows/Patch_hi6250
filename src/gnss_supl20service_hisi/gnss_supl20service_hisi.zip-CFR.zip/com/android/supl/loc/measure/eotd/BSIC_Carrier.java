/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;

public class BSIC_Carrier {
    public short cBsic;
    public int usCarrier;

    public byte[] getBSIC_Carrier() {
        byte[] byArray = new byte[3];
        IO.put1(byArray, IO.put2(byArray, 0, this.usCarrier), this.cBsic);
        return byArray;
    }
}

