/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.lpp;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.lpp.SUPL_LPP_EGCI;
import com.android.supl.loc.measure.lpp.SUPL_LPP_NEIGHBOUR_OTDOA_MMT;
import com.android.supl.loc.measure.lpp.SUPL_LPP_OTDOA_MMT_QUALITY;

public class SUPL_LPP_OTDOA_SIGNAL_MMT {
    public boolean bArfcnPresent = true;
    public boolean bMeasureQualityPresent = true;
    public boolean bNeighbourMMTValid = true;
    public boolean bOTDOAEGCIValid = true;
    public int lArfcnEUTRAValue = 415;
    public SUPL_LPP_NEIGHBOUR_OTDOA_MMT stLPPOTDOANeighbourLst = null;
    public SUPL_LPP_EGCI stOTDOAEGCIInfo = null;
    public SUPL_LPP_OTDOA_MMT_QUALITY stOTDOAMeasureQuality = null;
    public short usPhysCellID;
    public short wSignalFrameNo = (short)412;

    public SUPL_LPP_OTDOA_SIGNAL_MMT() {
        this.usPhysCellID = (short)413;
        this.stOTDOAEGCIInfo = new SUPL_LPP_EGCI();
        this.stOTDOAMeasureQuality = new SUPL_LPP_OTDOA_MMT_QUALITY();
        this.stLPPOTDOANeighbourLst = new SUPL_LPP_NEIGHBOUR_OTDOA_MMT();
    }

    public byte[] getSIGNAL_MMT() {
        byte[] byArray;
        byte[] byArray2;
        int n = 1;
        int n2 = 20;
        byte[] byArray3 = byArray2 = null;
        int n3 = n2;
        if (this.bOTDOAEGCIValid) {
            byArray3 = byArray2;
            n3 = n2;
            if (this.stOTDOAEGCIInfo != null) {
                byArray3 = byArray2 = this.stOTDOAEGCIInfo.getLPP_EGCI();
                n3 = n2;
                if (byArray2 != null) {
                    n3 = byArray2.length + 20;
                    byArray3 = byArray2;
                }
            }
        }
        n2 = n3;
        if (this.bArfcnPresent) {
            n2 = n3 + 4;
        }
        byArray2 = byArray = null;
        n3 = n2;
        if (this.bMeasureQualityPresent) {
            byArray2 = byArray;
            n3 = n2;
            if (this.stOTDOAMeasureQuality != null) {
                byArray2 = byArray = this.stOTDOAMeasureQuality.getOTDOA_MMT_QUALITY();
                n3 = n2;
                if (byArray != null) {
                    n3 = n2 + byArray.length;
                    byArray2 = byArray;
                }
            }
        }
        byte[] byArray4 = null;
        byArray = byArray4;
        n2 = n3;
        if (this.bNeighbourMMTValid) {
            byArray = byArray4;
            n2 = n3;
            if (this.stLPPOTDOANeighbourLst != null) {
                byArray4 = this.stLPPOTDOANeighbourLst.get_NEIGHBOUR_OTDOA_MMT();
                byArray = byArray4;
                n2 = n3;
                if (byArray4 != null) {
                    n2 = n3 + byArray4.length;
                    byArray = byArray4;
                }
            }
        }
        byArray4 = new byte[n2];
        n3 = IO.put2(byArray4, IO.put2(byArray4, 0, this.wSignalFrameNo), this.usPhysCellID);
        n2 = this.bOTDOAEGCIValid ? 1 : 0;
        n2 = n3 = IO.put4(byArray4, n3, n2);
        if (this.bOTDOAEGCIValid) {
            n2 = n3;
            if (byArray3 != null) {
                System.arraycopy((byte[])byArray3, (int)0, (byte[])byArray4, (int)n3, (int)byArray3.length);
                n2 = n3 + byArray3.length;
            }
        }
        n3 = this.bArfcnPresent ? 1 : 0;
        n2 = n3 = IO.put4(byArray4, n2, n3);
        if (this.bArfcnPresent) {
            n2 = IO.put4(byArray4, n3, this.lArfcnEUTRAValue);
        }
        n3 = this.bMeasureQualityPresent ? 1 : 0;
        n2 = n3 = IO.put4(byArray4, n2, n3);
        if (this.bMeasureQualityPresent) {
            n2 = n3;
            if (byArray2 != null) {
                System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray4, (int)n3, (int)byArray2.length);
                n2 = n3 + byArray2.length;
            }
        }
        n3 = this.bNeighbourMMTValid ? n : 0;
        n2 = IO.put4(byArray4, n2, n3);
        if (!this.bNeighbourMMTValid) return byArray4;
        if (byArray == null) return byArray4;
        System.arraycopy((byte[])byArray, (int)0, (byte[])byArray4, (int)n2, (int)byArray.length);
        n2 = byArray.length;
        return byArray4;
    }
}

