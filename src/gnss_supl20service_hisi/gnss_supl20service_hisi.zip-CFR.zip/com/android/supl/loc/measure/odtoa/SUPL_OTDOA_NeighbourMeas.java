/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.odtoa;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.odtoa.SUPL_OTDOA_NeighModeSpecMeas;

public class SUPL_OTDOA_NeighbourMeas {
    public int eModeType;
    public long lSFNSFNObsTimeDiff2;
    public SUPL_OTDOA_NeighModeSpecMeas stNeighbourMeasInfo;
    public short ucNoOfMeasurements;
    public short ucStdDevOTDOAMeas;
    public short ucStdValue;

    public byte[] getNeighbourMeas() {
        int n;
        int n2 = 11;
        byte[] byArray = null;
        if (this.stNeighbourMeasInfo != null) {
            byArray = this.stNeighbourMeasInfo.getNeighModeSpecMeas();
            n2 = byArray.length + 11;
        }
        byte[] byArray2 = new byte[n2];
        n2 = n = IO.put4(byArray2, 0, this.eModeType);
        if (this.stNeighbourMeasInfo != null) {
            System.arraycopy((byte[])byArray, (int)0, (byte[])byArray2, (int)n, (int)byArray.length);
            n2 = n + byArray.length;
        }
        IO.put4(byArray2, IO.put1(byArray2, IO.put1(byArray2, IO.put1(byArray2, n2, this.ucStdValue), this.ucNoOfMeasurements), this.ucStdDevOTDOAMeas), (int)this.lSFNSFNObsTimeDiff2);
        return byArray2;
    }
}

