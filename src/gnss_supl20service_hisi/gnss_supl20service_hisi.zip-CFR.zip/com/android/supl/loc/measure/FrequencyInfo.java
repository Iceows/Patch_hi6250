/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.FrequencyInfoFdd;
import com.android.supl.loc.measure.FrequencyInfoTdd;

public class FrequencyInfo {
    public static final int MODE_SPECIFIC_INFO_TYPE_FDD = 1;
    public static final int MODE_SPECIFIC_INFO_TYPE_TDD = 2;
    private int ienModeSpecificInfoType = 0;
    private FrequencyInfoFdd mFdd = null;
    private FrequencyInfoTdd mFrequencyInfoTdd = null;

    public FrequencyInfo(int n, Object object) {
        this.ienModeSpecificInfoType = n;
        if (n == 1) {
            this.mFdd = (FrequencyInfoFdd)object;
            return;
        }
        if (n != 2) throw new IllegalArgumentException("FrequencyInfo mode value is invalid");
        this.mFrequencyInfoTdd = (FrequencyInfoTdd)object;
    }

    public byte[] getFrequencyInfo() {
        int n = 0;
        int n2 = 4;
        byte[] byArray = null;
        if (this.ienModeSpecificInfoType == 1) {
            byArray = this.mFdd.getFrequencyInfoFdd();
        } else if (this.ienModeSpecificInfoType == 2) {
            byArray = this.mFrequencyInfoTdd.getFrequencyInfoTdd();
        }
        byte[] byArray2 = null;
        if (byArray != null) {
            n2 = byArray.length + 4;
            byArray2 = new byte[n2];
            n = IO.put4(byArray2, 0, this.ienModeSpecificInfoType);
            System.arraycopy((byte[])byArray, (int)0, (byte[])byArray2, (int)n, (int)byArray.length);
            n += byArray.length;
        }
        if (n == n2) return byArray2;
        System.out.println("FrequencyInfo length error");
        return byArray2;
    }
}

