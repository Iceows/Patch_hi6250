/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.CellMeasuredResultsList;
import com.android.supl.loc.measure.FrequencyInfo;

public class MeasuredResults {
    private boolean bIsCellMeasuredResultsListPresent;
    private boolean bIsFrequencyInfoPresent;
    private boolean bIsUtra_CarrierRSSIPresent;
    private FrequencyInfo mFrequencyInfo;
    private CellMeasuredResultsList stCellMeasuredResultsList;
    private short ucUtra_CarrierRSSI;

    public MeasuredResults(FrequencyInfo frequencyInfo, short s, CellMeasuredResultsList cellMeasuredResultsList) {
        boolean bl = true;
        this.mFrequencyInfo = null;
        this.stCellMeasuredResultsList = null;
        this.mFrequencyInfo = frequencyInfo;
        this.ucUtra_CarrierRSSI = s;
        this.stCellMeasuredResultsList = cellMeasuredResultsList;
        boolean bl2 = frequencyInfo != null;
        this.bIsFrequencyInfoPresent = bl2;
        bl2 = s != -1;
        this.bIsUtra_CarrierRSSIPresent = bl2;
        bl2 = cellMeasuredResultsList != null ? bl : false;
        this.bIsCellMeasuredResultsListPresent = bl2;
    }

    public byte[] getMeasuredResultsInfo() {
        byte[] byArray;
        int n = 12;
        byte[] byArray2 = null;
        int n2 = n;
        if (this.bIsFrequencyInfoPresent) {
            byArray2 = byArray = this.mFrequencyInfo.getFrequencyInfo();
            n2 = n;
            if (byArray != null) {
                n2 = byArray.length + 12;
                byArray2 = byArray;
            }
        }
        n = n2;
        if (this.bIsUtra_CarrierRSSIPresent) {
            n = n2 + 1;
        }
        byArray = null;
        n2 = n;
        if (this.bIsCellMeasuredResultsListPresent) {
            byArray = this.stCellMeasuredResultsList.getCellMeasuredResultList();
            n2 = n + byArray.length;
        }
        byte[] byArray3 = new byte[n2];
        if (this.bIsFrequencyInfoPresent) {
            int n3;
            n = n3 = IO.put4(byArray3, 0, 1);
            if (byArray2 != null) {
                System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray3, (int)n3, (int)byArray2.length);
                n = n3 + byArray2.length;
            }
        } else {
            n = IO.put4(byArray3, 0, 0);
        }
        n = this.bIsUtra_CarrierRSSIPresent ? IO.put1(byArray3, IO.put4(byArray3, n, 1), this.ucUtra_CarrierRSSI) : IO.put4(byArray3, n, 0);
        if (this.bIsCellMeasuredResultsListPresent) {
            n = IO.put4(byArray3, n, 1);
            System.arraycopy((byte[])byArray, (int)0, (byte[])byArray3, (int)n, (int)byArray.length);
            n += byArray.length;
        } else {
            n = IO.put4(byArray3, n, 0);
        }
        if (n == n2) return byArray3;
        System.out.println("MeasuredResultsInfo length error");
        return byArray3;
    }
}

