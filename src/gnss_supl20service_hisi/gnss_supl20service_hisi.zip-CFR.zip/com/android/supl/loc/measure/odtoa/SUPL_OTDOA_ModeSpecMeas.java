/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.odtoa;

import com.android.supl.loc.measure.odtoa.SUPL_OTDOA_ModeSpecMeansTDD;
import com.android.supl.loc.measure.odtoa.SUPL_OTDOA_ModeSpecMeasFDD;

public class SUPL_OTDOA_ModeSpecMeas {
    public SUPL_OTDOA_ModeSpecMeasFDD stModeSpecificFDDMeas;
    public SUPL_OTDOA_ModeSpecMeansTDD stModeSpecificTDDMeas;

    public byte[] getModeSpecMeas() {
        byte[] byArray = null;
        if (this.stModeSpecificFDDMeas != null) {
            return this.stModeSpecificFDDMeas.getModeSpecMeasFDD();
        }
        if (this.stModeSpecificTDDMeas == null) return byArray;
        return this.stModeSpecificTDDMeas.getModeSpecMeansTDD();
    }
}

