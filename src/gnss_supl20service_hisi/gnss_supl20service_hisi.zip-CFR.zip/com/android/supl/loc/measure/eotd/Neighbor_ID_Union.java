/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.eotd.BSIC_Carrier;
import com.android.supl.loc.measure.eotd.CellID_LAC;
import com.android.supl.loc.measure.eotd.MultiFrameCarrier;

public class Neighbor_ID_Union {
    public static final int NEIGHBORIDENTITY_BSICANDCARRIER = 1;
    public static final int NEIGHBORIDENTITY_CI = 2;
    public static final int NEIGHBORIDENTITY_CIANDLAC = 6;
    public static final int NEIGHBORIDENTITY_MULTIFRAMECARRIER = 3;
    public static final int NEIGHBORIDENTITY_REQUESTINDEX = 4;
    public static final int NEIGHBORIDENTITY_SYSTEMINFOINDEX = 5;
    public static final int NeighborIdentity_NOTHING = 0;
    public BSIC_Carrier bsicAndCarrier;
    public CellID_LAC ciandlac;
    public MultiFrameCarrier multiFrameCarrier;
    public short ucRequestIndex;
    public short ucSystemInfoIndex;
    public short usCellID;

    /*
     * Handled duff style switch with additional control
     */
    public byte[] getNeighborIDUnion(int n) {
        byte[] byArray;
        byte[] byArray2 = byArray = null;
        int n2 = Integer.MIN_VALUE;
        block9: do {
            switch (n2 == Integer.MIN_VALUE ? n : n2) {
                default: {
                    byArray2 = byArray;
                    n2 = 0;
                    continue block9;
                }
                case 1: {
                    byArray2 = byArray;
                    if (this.bsicAndCarrier == null) return byArray2;
                    byArray2 = this.bsicAndCarrier.getBSIC_Carrier();
                    n2 = 0;
                    continue block9;
                }
                case 2: {
                    byArray2 = new byte[2];
                    IO.put2(byArray2, 0, this.usCellID);
                    n2 = 0;
                    continue block9;
                }
                case 3: {
                    byArray2 = byArray;
                    if (this.multiFrameCarrier == null) return byArray2;
                    byArray2 = this.multiFrameCarrier.getMultiFrameCarrier();
                    n2 = 0;
                    continue block9;
                }
                case 4: {
                    byArray2 = new byte[1];
                    IO.put1(byArray2, 0, this.ucRequestIndex);
                    n2 = 0;
                    continue block9;
                }
                case 5: {
                    byArray2 = new byte[1];
                    IO.put1(byArray2, 0, this.ucSystemInfoIndex);
                }
                case 0: {
                    return byArray2;
                }
                case 6: 
            }
            break;
        } while (true);
        byArray2 = byArray;
        if (this.ciandlac == null) return byArray2;
        return this.ciandlac.getCellID_LAC();
    }
}

