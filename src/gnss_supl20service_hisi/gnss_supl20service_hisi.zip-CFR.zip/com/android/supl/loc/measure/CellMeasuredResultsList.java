/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.CellMeasuredResults;
import java.util.Iterator;
import java.util.Vector;

public class CellMeasuredResultsList {
    private CellMeasuredResults[] astCellMeasuredResults = null;
    private short ucCellMeasuredResultsCnt;

    public CellMeasuredResultsList(CellMeasuredResults[] cellMeasuredResultsArray) {
        if (cellMeasuredResultsArray == null) {
            throw new IllegalArgumentException("CellMeasuredResults should not be n");
        }
        this.astCellMeasuredResults = cellMeasuredResultsArray;
        this.ucCellMeasuredResultsCnt = (short)cellMeasuredResultsArray.length;
    }

    public byte[] getCellMeasuredResultList() {
        int n = 1;
        Object object2 = new Vector<byte[]>(this.ucCellMeasuredResultsCnt);
        for (CellMeasuredResults cellMeasuredResults : this.astCellMeasuredResults) {
            if (cellMeasuredResults == null) continue;
            byte[] byArray = cellMeasuredResults.getCellMeasuredResults();
            n += byArray.length;
            ((Vector)object2).add(byArray);
        }
        byte[] byArray = new byte[n];
        int n2 = IO.put1(byArray, 0, this.ucCellMeasuredResultsCnt);
        Iterator iterator = object2.iterator();
        while (true) {
            if (!iterator.hasNext()) {
                if (n2 == n) return byArray;
                System.out.println("CellMeasuredResultList length error");
                return byArray;
            }
            object2 = (byte[])iterator.next();
            System.arraycopy((byte[])object2, (int)0, (byte[])byArray, (int)n2, (int)((Object)object2).length);
            n2 += ((Object)object2).length;
        }
    }
}

