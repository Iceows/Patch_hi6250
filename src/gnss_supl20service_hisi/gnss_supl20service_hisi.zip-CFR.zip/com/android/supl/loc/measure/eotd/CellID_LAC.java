/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;

public class CellID_LAC {
    public short usReferenceCI;
    public short usReferenceLAC;

    public byte[] getCellID_LAC() {
        byte[] byArray = new byte[4];
        IO.put2(byArray, IO.put2(byArray, 0, this.usReferenceLAC), this.usReferenceCI);
        return byArray;
    }
}

