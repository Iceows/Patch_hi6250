/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure;

import com.android.bytewriter.IO;

public class TimeSlotISCPList {
    private byte[] aucTimeslotISCP = null;
    private short ucTimeslotISCPsCnt;

    public TimeSlotISCPList(byte[] byArray) {
        if (byArray == null) {
            throw new IllegalArgumentException("TimeslotISCP should not be null");
        }
        this.aucTimeslotISCP = byArray;
        this.ucTimeslotISCPsCnt = (short)this.aucTimeslotISCP.length;
    }

    public byte[] getTimeslotISCPListInfo() {
        int n = 1;
        if (this.aucTimeslotISCP != null) {
            n = this.aucTimeslotISCP.length + 1;
        }
        byte[] byArray = new byte[n];
        n = IO.put1(byArray, 0, this.ucTimeslotISCPsCnt);
        System.arraycopy((byte[])this.aucTimeslotISCP, (int)0, (byte[])byArray, (int)n, (int)this.ucTimeslotISCPsCnt);
        n = this.ucTimeslotISCPsCnt;
        return byArray;
    }
}

