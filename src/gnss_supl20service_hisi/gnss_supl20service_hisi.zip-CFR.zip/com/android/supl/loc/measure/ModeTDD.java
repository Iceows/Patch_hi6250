/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.TimeSlotISCPList;

public class ModeTDD {
    private boolean isPathLossPresent;
    private boolean isPrimaryCCPCH_RSCPPresent;
    private boolean isProposedTGSNPresent;
    private boolean isTimeslotISCP_ListPresent;
    private TimeSlotISCPList stTimeslotISCP_List;
    private short ucCellParametersID;
    private short ucPathloss;
    private short ucPrimaryCCPCH_RSCP;
    private short ucProposedTGSN;

    public ModeTDD(short s, short s2, short s3, short s4, TimeSlotISCPList timeSlotISCPList) {
        boolean bl = true;
        this.isProposedTGSNPresent = false;
        this.ucProposedTGSN = (short)-1;
        this.isPrimaryCCPCH_RSCPPresent = false;
        this.ucPrimaryCCPCH_RSCP = (short)-1;
        this.isPathLossPresent = false;
        this.ucPathloss = (short)-1;
        this.isTimeslotISCP_ListPresent = false;
        this.stTimeslotISCP_List = null;
        this.ucCellParametersID = s;
        this.ucProposedTGSN = s2;
        this.ucPrimaryCCPCH_RSCP = s3;
        this.ucPathloss = s4;
        this.stTimeslotISCP_List = timeSlotISCPList;
        boolean bl2 = s2 != -1;
        this.isProposedTGSNPresent = bl2;
        bl2 = s3 != -1;
        this.isPrimaryCCPCH_RSCPPresent = bl2;
        bl2 = s4 != -1;
        this.isPathLossPresent = bl2;
        bl2 = timeSlotISCPList != null ? bl : false;
        this.isTimeslotISCP_ListPresent = bl2;
    }

    public byte[] getModeTDDInfo() {
        int n = 17;
        if (this.isProposedTGSNPresent) {
            n = 18;
        }
        int n2 = n;
        if (this.isPrimaryCCPCH_RSCPPresent) {
            n2 = n + 1;
        }
        n = n2;
        if (this.isPathLossPresent) {
            n = n2 + 1;
        }
        byte[] byArray = null;
        int n3 = n;
        if (this.isTimeslotISCP_ListPresent) {
            byArray = this.stTimeslotISCP_List.getTimeslotISCPListInfo();
            n3 = n + byArray.length;
        }
        byte[] byArray2 = new byte[n3];
        n = n2 = IO.put1(byArray2, 0, this.ucCellParametersID);
        if (this.isProposedTGSNPresent) {
            n = IO.put1(byArray2, n2, this.ucProposedTGSN);
        }
        n2 = n;
        if (this.isPrimaryCCPCH_RSCPPresent) {
            n2 = IO.put1(byArray2, n, this.ucPrimaryCCPCH_RSCP);
        }
        n = n2;
        if (this.isPathLossPresent) {
            n = IO.put1(byArray2, n2, this.ucPathloss);
        }
        n2 = n;
        if (this.isTimeslotISCP_ListPresent) {
            System.arraycopy((byte[])byArray, (int)0, (byte[])byArray2, (int)n, (int)byArray.length);
            n2 = n + byArray.length;
        }
        if (n2 == n3) return byArray2;
        System.out.println("ModeTDD length error");
        return byArray2;
    }
}

