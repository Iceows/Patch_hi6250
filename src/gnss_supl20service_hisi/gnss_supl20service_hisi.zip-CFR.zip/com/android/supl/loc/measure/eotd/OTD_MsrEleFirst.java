/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.eotd.OTDMeans_WithID;
import com.android.supl.loc.measure.eotd.OTD_MSREleCommon;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

public class OTD_MsrEleFirst {
    public ArrayList<OTDMeans_WithID> aWithIDs = null;
    public OTD_MSREleCommon otd_MsrComm;
    public short ucSetCount;

    public byte[] getOTD_MsrEleFirst() {
        Object object;
        int n = 1;
        int n2 = 0;
        Object object2 = null;
        if (this.otd_MsrComm != null) {
            object2 = this.otd_MsrComm.getOTSMSREle();
            n = ((byte[])object2).length + 1;
        }
        Object object3 = null;
        int n3 = n;
        if (this.aWithIDs != null) {
            object = new Vector(this.aWithIDs.size());
            Iterator iterator = this.aWithIDs.iterator();
            while (true) {
                n3 = n;
                object3 = object;
                if (!iterator.hasNext()) break;
                object3 = (OTDMeans_WithID)iterator.next();
                if (object3 == null || (object3 = object3.getOTDMeans_WithID()) == null) continue;
                ((Vector)object).add(object3);
                n += ((byte[])object3).length;
            }
        }
        object = new byte[n3];
        n = n2;
        if (object2 != null) {
            System.arraycopy((byte[])object2, (int)0, (byte[])object, (int)0, (int)((byte[])object2).length);
            n = ((byte[])object2).length + 0;
        }
        n = IO.put1((byte[])object, n, this.ucSetCount);
        if (object3 == null) return object;
        object2 = object3.iterator();
        while (object2.hasNext()) {
            object3 = (byte[])object2.next();
            if (object3 == null) continue;
            System.arraycopy((byte[])object3, (int)0, (byte[])object, (int)n, (int)((byte[])object3).length);
            n += ((byte[])object3).length;
        }
        return object;
    }
}

