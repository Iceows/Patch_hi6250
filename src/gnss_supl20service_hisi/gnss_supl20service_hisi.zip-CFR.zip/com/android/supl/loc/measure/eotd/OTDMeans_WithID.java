/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.eotd.EOTDQuality;
import com.android.supl.loc.measure.eotd.Neighbor_Identity;

public class OTDMeans_WithID {
    public EOTDQuality eotdQuality;
    public Neighbor_Identity neighborIdentity;
    public short ucNborTimeSlot;
    public int usOTDValue;

    public byte[] getOTDMeans_WithID() {
        int n = 0;
        int n2 = 3;
        byte[] byArray = null;
        byte[] byArray2 = null;
        if (this.neighborIdentity != null) {
            byArray = this.neighborIdentity.getNeighbor_Identity();
            n2 = byArray.length + 3;
        }
        int n3 = n2;
        if (this.eotdQuality != null) {
            byArray2 = this.eotdQuality.getEOTDQulaity();
            n3 = n2 + byArray2.length;
        }
        byte[] byArray3 = new byte[n3];
        n2 = n;
        if (byArray != null) {
            System.arraycopy((byte[])byArray, (int)0, (byte[])byArray3, (int)0, (int)byArray.length);
            n2 = byArray.length + 0;
        }
        n2 = n3 = IO.put1(byArray3, n2, this.ucNborTimeSlot);
        if (byArray2 != null) {
            System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray3, (int)n3, (int)byArray2.length);
            n2 = n3 + byArray2.length;
        }
        IO.put2(byArray3, n2, this.usOTDValue);
        return byArray3;
    }
}

