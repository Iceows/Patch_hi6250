/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure;

import com.android.bytewriter.IO;

public class ModeFDD {
    private boolean isCpich_Ec_N0Present;
    private boolean isCpich_RSCPPresent;
    private boolean isPathLossPresent;
    private short ucCpich_Ec_N0;
    private short ucCpich_RSCP;
    private short ucPathloss;
    private short usPrimaryScramblingCode;

    public ModeFDD(short s, short s2, short s3, short s4) {
        boolean bl = true;
        this.usPrimaryScramblingCode = s;
        this.ucCpich_Ec_N0 = s2;
        this.ucCpich_RSCP = s3;
        this.ucPathloss = s4;
        boolean bl2 = s2 != -1;
        this.isCpich_Ec_N0Present = bl2;
        bl2 = s3 != -1;
        this.isCpich_RSCPPresent = bl2;
        bl2 = s4 != -1 ? bl : false;
        this.isPathLossPresent = bl2;
    }

    public byte[] getModeFDDInfo() {
        int n = 14;
        if (this.isCpich_Ec_N0Present) {
            n = 15;
        }
        int n2 = n;
        if (this.isCpich_RSCPPresent) {
            n2 = n + 1;
        }
        int n3 = n2;
        if (this.isPathLossPresent) {
            n3 = n2 + 1;
        }
        byte[] byArray = new byte[n3];
        n = n2 = IO.put2(byArray, 0, this.usPrimaryScramblingCode);
        if (this.isCpich_Ec_N0Present) {
            n = IO.put1(byArray, n2, this.ucCpich_Ec_N0);
        }
        n2 = n;
        if (this.isCpich_RSCPPresent) {
            n2 = IO.put1(byArray, n, this.ucCpich_RSCP);
        }
        n = n2;
        if (this.isPathLossPresent) {
            n = IO.put1(byArray, n2, this.ucPathloss);
        }
        if (n3 == n) return byArray;
        System.out.println("ModeFDD length error");
        return byArray;
    }
}

