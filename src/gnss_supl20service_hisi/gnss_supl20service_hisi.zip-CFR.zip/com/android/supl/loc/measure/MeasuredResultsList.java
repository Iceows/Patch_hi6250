/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.MeasuredResults;
import java.util.Iterator;
import java.util.Vector;

public class MeasuredResultsList {
    public MeasuredResults[] astMeasuredResults = null;
    public short ucMeasuredResultsCnt;

    public MeasuredResultsList(MeasuredResults[] measuredResultsArray) {
        if (measuredResultsArray == null) {
            throw new IllegalArgumentException("MeasuredResults should not be n");
        }
        this.astMeasuredResults = measuredResultsArray;
        this.ucMeasuredResultsCnt = (short)measuredResultsArray.length;
    }

    public byte[] getMeasuredResultsListInfo() {
        int n = 1;
        Object object2 = new Vector<byte[]>(this.ucMeasuredResultsCnt);
        for (MeasuredResults measuredResults : this.astMeasuredResults) {
            if (measuredResults == null) continue;
            byte[] byArray = measuredResults.getMeasuredResultsInfo();
            n += byArray.length;
            ((Vector)object2).add(byArray);
        }
        byte[] byArray = new byte[n];
        int n2 = IO.put1(byArray, 0, this.ucMeasuredResultsCnt);
        Iterator iterator = object2.iterator();
        while (true) {
            if (!iterator.hasNext()) {
                if (n2 == n) return byArray;
                System.out.println("MeasuredResultList length error");
                return byArray;
            }
            object2 = (byte[])iterator.next();
            System.arraycopy((byte[])object2, (int)0, (byte[])byArray, (int)n2, (int)((Object)object2).length);
            n2 += ((Object)object2).length;
        }
    }
}

