/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.odtoa;

import com.android.supl.loc.measure.odtoa.SUPL_OTDOA_MDSpecINF_TDD;
import com.android.supl.loc.measure.odtoa.SUPL_OTDOA_Measurement;
import com.android.supl.loc.measure.odtoa.SUPL_OTDOA_ModeSpecMeansTDD;
import com.android.supl.loc.measure.odtoa.SUPL_OTDOA_ModeSpecMeas;
import com.android.supl.loc.measure.odtoa.SUPL_OTDOA_ModeSpecMeasFDD;
import com.android.supl.loc.measure.odtoa.SUPL_OTDOA_NeighModeSpecMeas;
import com.android.supl.loc.measure.odtoa.SUPL_OTDOA_NeighbourMeas;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class OTDOAConfigParser
extends DefaultHandler {
    private static final String BCELLIDPARAMVALID = "bcellidparamvalid";
    private static final String BURSTTYPE = "bursttype";
    private static final String CELLPARAMID = "cellparamid";
    private static final String CELLPARAMSID = "cellparamsid";
    private static final String MEASUREINFOTYPE = "measureinfotype";
    private static final String MIDAMBLESHIFT = "midambleshift";
    private static final String MODEFDD = "modeFDD";
    private static final String MODESPECIFICMEASURE = "modespecificmeasure";
    private static final String MODETDD = "modeTDD";
    private static final String MODETYPE = "modetype";
    private static final String NEIGHBOURCOUNT = "neighbourcount";
    private static final String NEIGHBOURLIST = "neighbourlist";
    private static final String NEIGHBOURMEAS = "neighbourmeas";
    private static final String NEIGHBOURPRESENT = "neighbourpresent";
    private static final String NOOFMEASUREMENTS = "noofmeasurements";
    private static final String OTDOAMEASURE = "otdoameasure";
    private static final String PRIMSCRAMBCODE = "primscrambcode";
    private static final String PRIMSCRAMBCODEPRESENT = "primscrambcodepresent";
    private static final String RXTXTIMEDIFFTYPE = "rxtxtimedifftype";
    private static final String RXTXTIMEDIFFVALID = "rxtxtimediffvalid";
    private static final String SFN = "sfn";
    private static final String SFNSFNOBSTIMEDIFF = "sfnsfnobstimediff";
    private static final String STDDEVOTDOAMEAS = "stddevOTDOAmeas";
    private static final String STDVALUE = "stdvalue";
    private static final String TIMESLOT = "timeslot";
    private static final String VALID = "valid";
    private int iMeasIndex = -1;
    private boolean isModeSpecMeas = false;
    private boolean isNeighbourMeas = false;
    private boolean isNeighbourMeasData = false;
    private boolean isRequiredTag = false;
    private SUPL_OTDOA_Measurement otdoa_Measurement = null;
    private String stData = null;

    public OTDOAConfigParser() {
        this.init();
    }

    @Override
    public void characters(char[] cArray, int n, int n2) throws SAXException {
        if (this.isRequiredTag) {
            this.stData = new String(cArray, n, n2).trim();
            this.isRequiredTag = false;
            return;
        }
        this.stData = null;
    }

    @Override
    public void endElement(String object, String string, String string2) throws SAXException {
        boolean bl = false;
        boolean bl2 = true;
        boolean bl3 = true;
        boolean bl4 = true;
        boolean bl5 = true;
        boolean bl6 = true;
        boolean bl7 = true;
        if (string.equals(VALID)) {
            object = this.otdoa_Measurement;
            bl = Integer.parseInt(this.stData) == 1 ? bl7 : false;
            ((SUPL_OTDOA_Measurement)object).bMeasurementValid = bl;
            return;
        }
        if (string.equals(SFN)) {
            this.otdoa_Measurement.lSFN = Long.parseLong(this.stData);
            return;
        }
        if (string.equals(MEASUREINFOTYPE)) {
            this.otdoa_Measurement.eModeSpecInfoType = Integer.parseInt(this.stData);
            return;
        }
        if (string.equals(MODESPECIFICMEASURE)) {
            this.isModeSpecMeas = false;
            return;
        }
        if (string.equals(PRIMSCRAMBCODEPRESENT)) {
            if (this.isModeSpecMeas) {
                if (this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas == null) return;
                object = this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas;
                bl = Integer.parseInt(this.stData) == 1 ? bl2 : false;
                ((SUPL_OTDOA_ModeSpecMeasFDD)object).bPrimaryScramblingCodePresent = bl;
                return;
            }
            if (!this.isNeighbourMeas) return;
            if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas == null) return;
            object = this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas;
            bl = Integer.parseInt(this.stData) == 1 ? bl3 : false;
            ((SUPL_OTDOA_ModeSpecMeasFDD)object).bPrimaryScramblingCodePresent = bl;
            return;
        }
        if (string.equals(PRIMSCRAMBCODE)) {
            if (this.isModeSpecMeas) {
                if (this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas == null) return;
                this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas.lPrimaryScramblingCode = Long.parseLong(this.stData);
                return;
            }
            if (!this.isNeighbourMeas) return;
            if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas == null) return;
            this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas.lPrimaryScramblingCode = Long.parseLong(this.stData);
            return;
        }
        if (string.equals(RXTXTIMEDIFFVALID)) {
            if (this.isModeSpecMeas) {
                if (this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas == null) return;
                object = this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas;
                bl = Integer.parseInt(this.stData) == 1 ? bl4 : false;
                ((SUPL_OTDOA_ModeSpecMeasFDD)object).bRxTxTimeDiffValid = bl;
                return;
            }
            if (!this.isNeighbourMeas) return;
            if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas == null) return;
            object = this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas;
            bl = Integer.parseInt(this.stData) == 1 ? bl5 : false;
            ((SUPL_OTDOA_ModeSpecMeasFDD)object).bRxTxTimeDiffValid = bl;
            return;
        }
        if (string.equals(RXTXTIMEDIFFTYPE)) {
            if (this.isModeSpecMeas) {
                if (this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas == null) return;
                this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas.lRxTxTimeDiffType2 = Long.parseLong(this.stData);
                return;
            }
            if (!this.isNeighbourMeas) return;
            if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas == null) return;
            this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas.lRxTxTimeDiffType2 = Long.parseLong(this.stData);
            return;
        }
        if (string.equals(STDVALUE)) {
            if (this.isModeSpecMeas) {
                if (this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas == null) return;
                this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas.ucStdValue = Short.parseShort(this.stData);
                return;
            }
            if (!this.isNeighbourMeas) return;
            if (this.isNeighbourMeasData) {
                this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].ucStdValue = Short.parseShort(this.stData);
                return;
            }
            if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas == null) return;
            this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas.ucStdValue = Short.parseShort(this.stData);
            return;
        }
        if (string.equals(NOOFMEASUREMENTS)) {
            if (this.isModeSpecMeas) {
                if (this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas == null) return;
                this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas.ucNoOfMeasurements = Short.parseShort(this.stData);
                return;
            }
            if (!this.isNeighbourMeas) return;
            if (this.isNeighbourMeasData) {
                this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].ucNoOfMeasurements = Short.parseShort(this.stData);
                return;
            }
            if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas == null) return;
            this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas.ucNoOfMeasurements = Short.parseShort(this.stData);
            return;
        }
        if (string.equals(STDDEVOTDOAMEAS)) {
            if (this.isModeSpecMeas) {
                if (this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas == null) return;
                this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas.ucStdDevOTDOAMeas = Short.parseShort(this.stData);
                return;
            }
            if (!this.isNeighbourMeas) return;
            if (this.isNeighbourMeasData) {
                this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].ucStdDevOTDOAMeas = Short.parseShort(this.stData);
                return;
            }
            if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas == null) return;
            this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas.ucStdDevOTDOAMeas = Short.parseShort(this.stData);
            return;
        }
        if (string.equals(SFNSFNOBSTIMEDIFF)) {
            if (!this.isNeighbourMeasData) return;
            this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].lSFNSFNObsTimeDiff2 = Long.parseLong(this.stData);
            return;
        }
        if (string.equals(BCELLIDPARAMVALID)) {
            if (this.otdoa_Measurement.stModeSpecMeas.stModeSpecificTDDMeas == null) return;
            object = this.otdoa_Measurement.stModeSpecMeas.stModeSpecificTDDMeas;
            bl = Integer.parseInt(this.stData) == 1 ? bl6 : false;
            ((SUPL_OTDOA_ModeSpecMeansTDD)object).bCellIDParamValid = bl;
            return;
        }
        if (string.equals(CELLPARAMSID)) {
            if (this.otdoa_Measurement.stModeSpecMeas.stModeSpecificTDDMeas == null) return;
            this.otdoa_Measurement.stModeSpecMeas.stModeSpecificTDDMeas.lCellParamsID = Long.parseLong(this.stData);
            return;
        }
        if (string.equals(NEIGHBOURPRESENT)) {
            object = this.otdoa_Measurement;
            if (Integer.parseInt(this.stData) == 1) {
                bl = true;
            }
            ((SUPL_OTDOA_Measurement)object).bNeighbourListPresent = bl;
            if (!this.otdoa_Measurement.bNeighbourListPresent) return;
            this.isNeighbourMeas = true;
            return;
        }
        if (string.equals(NEIGHBOURCOUNT)) {
            this.otdoa_Measurement.ucNoOfNeighbourList = Short.parseShort(this.stData);
            this.otdoa_Measurement.stNeighbourMeasList = new SUPL_OTDOA_NeighbourMeas[this.otdoa_Measurement.ucNoOfNeighbourList];
            return;
        }
        if (string.equals(NEIGHBOURMEAS)) {
            this.isNeighbourMeasData = false;
            return;
        }
        if (string.equals(NEIGHBOURLIST)) {
            this.isNeighbourMeas = false;
            return;
        }
        if (string.equals(MODETYPE)) {
            this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].eModeType = Integer.parseInt(this.stData);
            return;
        }
        if (string.equals(BURSTTYPE)) {
            if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificTDDMeas == null) return;
            this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificTDDMeas.eBurstType = Integer.parseInt(this.stData);
            return;
        }
        if (string.equals(MIDAMBLESHIFT)) {
            if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificTDDMeas == null) return;
            this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificTDDMeas.lMidAmbleShift = Long.parseLong(this.stData);
            return;
        }
        if (string.equals(TIMESLOT)) {
            if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificTDDMeas == null) return;
            this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificTDDMeas.lTimeSlot = Long.parseLong(this.stData);
            return;
        }
        if (string.equals(CELLPARAMID)) {
            if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificTDDMeas == null) return;
            this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificTDDMeas.lCellParamID = Long.parseLong(this.stData);
            return;
        }
        if (!string.equals(MODETDD)) return;
        if (this.isNeighbourMeas) {
            this.isNeighbourMeasData = true;
            return;
        }
        this.isNeighbourMeasData = false;
    }

    public SUPL_OTDOA_Measurement getOtdoa_Measurement() {
        return this.otdoa_Measurement;
    }

    /*
     * Exception decompiling
     */
    public void init() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 6 blocks at once
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:412)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:487)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:845)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:73)
         *     at org.benf.cfr.reader.Main.main(Main.java:49)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:303)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$null$1(ResourceDecompiling.java:113)
         *     at java.base/java.lang.Thread.run(Unknown Source)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public void startElement(String string, String string2, String string3, Attributes attributes) throws SAXException {
        if (string2.equals(OTDOAMEASURE)) {
            this.otdoa_Measurement = new SUPL_OTDOA_Measurement();
            return;
        }
        if (string2.equals(VALID)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(SFN)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(MEASUREINFOTYPE)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(MODESPECIFICMEASURE)) {
            this.otdoa_Measurement.stModeSpecMeas = new SUPL_OTDOA_ModeSpecMeas();
            this.isModeSpecMeas = true;
            return;
        }
        if (string2.equals(MODEFDD)) {
            if (this.isModeSpecMeas) {
                if (this.otdoa_Measurement.eModeSpecInfoType != 1) return;
                this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas = new SUPL_OTDOA_ModeSpecMeasFDD();
                return;
            }
            if (!this.isNeighbourMeas) return;
            if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].eModeType != 1) return;
            this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas = new SUPL_OTDOA_ModeSpecMeasFDD();
            return;
        }
        if (string2.equals(PRIMSCRAMBCODEPRESENT)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(PRIMSCRAMBCODE)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(RXTXTIMEDIFFVALID)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(RXTXTIMEDIFFTYPE)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(STDVALUE)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(NOOFMEASUREMENTS)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(STDDEVOTDOAMEAS)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(MODETDD)) {
            if (this.isModeSpecMeas) {
                if (this.otdoa_Measurement.eModeSpecInfoType != 2) return;
                this.otdoa_Measurement.stModeSpecMeas.stModeSpecificTDDMeas = new SUPL_OTDOA_ModeSpecMeansTDD();
                return;
            }
            if (!this.isNeighbourMeas) return;
            if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].eModeType != 2) return;
            this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificTDDMeas = new SUPL_OTDOA_MDSpecINF_TDD();
            return;
        }
        if (string2.equals(BCELLIDPARAMVALID)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(CELLPARAMSID)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(NEIGHBOURPRESENT)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(NEIGHBOURCOUNT)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(NEIGHBOURMEAS)) {
            ++this.iMeasIndex;
            this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex] = new SUPL_OTDOA_NeighbourMeas();
            this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo = new SUPL_OTDOA_NeighModeSpecMeas();
            return;
        }
        if (string2.equals(MODETYPE)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(BURSTTYPE)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(MIDAMBLESHIFT)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(TIMESLOT)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(CELLPARAMID)) {
            this.isRequiredTag = true;
            return;
        }
        if (!string2.equals(SFNSFNOBSTIMEDIFF)) return;
        this.isRequiredTag = true;
    }
}

