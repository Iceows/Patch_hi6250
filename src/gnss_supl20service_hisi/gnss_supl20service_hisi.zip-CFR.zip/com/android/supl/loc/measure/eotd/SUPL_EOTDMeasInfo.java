/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.android.supl.loc.measure.eotd;

import android.util.Log;
import com.android.bytewriter.IO;
import com.android.supl.loc.measure.eotd.OTD_MSREleRest;
import com.android.supl.loc.measure.eotd.OTD_MeasR98Ext;
import com.android.supl.loc.measure.eotd.OTD_MeasREL5Ext;
import com.android.supl.loc.measure.eotd.OTD_MsrEleFirst;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

public class SUPL_EOTDMeasInfo {
    public boolean bIsValidEOTDMeasurement;
    public boolean bOTDRel5Present;
    public boolean bOTDRel98Present;
    public int nNoOfValidSets;
    public OTD_MsrEleFirst otdMsrFirstSet;
    public ArrayList<OTD_MSREleRest> otdMsrRestSets;
    public OTD_MeasR98Ext otd_MeasureInfo_R98_Ext;
    public OTD_MeasREL5Ext otd_MeasureInfo_Rel_5_Ext;

    public byte[] getEOTDMeasInfo(int n) {
        Object object;
        int n2;
        int n3 = 4;
        byte[] byArray = null;
        byte[] byArray2 = null;
        Object object2 = null;
        Object object3 = null;
        Object object4 = null;
        Vector vector = null;
        Object object5 = null;
        Log.i((String)"SUPL20_EOTD", (String)("EOTD bValid value is " + this.bIsValidEOTDMeasurement));
        Object object6 = object5;
        if (this.bIsValidEOTDMeasurement) {
            n2 = n3 = 16;
            if (this.otdMsrFirstSet != null) {
                object = this.otdMsrFirstSet.getOTD_MsrEleFirst();
                byArray2 = object;
                n2 = n3;
                if (object != null) {
                    n2 = ((byte[])object).length + 16;
                    byArray2 = object;
                }
            }
            n3 = n2;
            object = object3;
            if (this.nNoOfValidSets > 0) {
                n3 = n2;
                object = object3;
                if (this.otdMsrRestSets != null) {
                    object3 = new Vector(this.nNoOfValidSets);
                    object6 = this.otdMsrRestSets.iterator();
                    while (true) {
                        n3 = n2;
                        object = object3;
                        if (!object6.hasNext()) break;
                        object = (OTD_MSREleRest)object6.next();
                        if (object == null || (object = (Object)((OTD_MSREleRest)object).getOTD_MSREleRest()) == null) continue;
                        n2 += ((byte[])object).length;
                        ((Vector)object3).add((byte[])object);
                    }
                }
            }
            object3 = vector;
            n2 = n3;
            if (this.bOTDRel98Present) {
                object3 = vector;
                n2 = n3;
                if (this.otd_MeasureInfo_R98_Ext != null) {
                    object3 = object6 = (Object)this.otd_MeasureInfo_R98_Ext.getOTD_MeasR98Ext();
                    n2 = n3;
                    if (object6 != null) {
                        n2 = n3 + ((Iterator<T>)object6).length;
                        object3 = object6;
                    }
                }
            }
            byArray = byArray2;
            object6 = object5;
            object4 = object3;
            n3 = n2;
            object2 = object;
            if (this.bOTDRel5Present) {
                byArray = byArray2;
                object6 = object5;
                object4 = object3;
                n3 = n2;
                object2 = object;
                if (this.otd_MeasureInfo_Rel_5_Ext != null) {
                    object5 = this.otd_MeasureInfo_Rel_5_Ext.getOTD_MeasRel5Ext();
                    byArray = byArray2;
                    object6 = object5;
                    object4 = object3;
                    n3 = n2;
                    object2 = object;
                    if (object5 != null) {
                        n3 = n2 + ((Object)object5).length;
                        object2 = object;
                        object4 = object3;
                        object6 = object5;
                        byArray = byArray2;
                    }
                }
            }
        }
        n2 = n3 + 8 + 4;
        byArray2 = new byte[n2];
        n2 = IO.put4(byArray2, IO.put4(byArray2, IO.put4(byArray2, 0, n2 - 4), 276), n);
        n = this.bIsValidEOTDMeasurement ? 1 : 0;
        n2 = IO.put4(byArray2, n2, n);
        if (this.bIsValidEOTDMeasurement) {
            n = n2;
            if (byArray != null) {
                System.arraycopy((byte[])byArray, (int)0, (byte[])byArray2, (int)n2, (int)byArray.length);
                n = n2 + byArray.length;
            }
            n2 = n = IO.put4(byArray2, n, this.nNoOfValidSets);
            if (this.nNoOfValidSets > 0) {
                n2 = n;
                if (object2 != null) {
                    object = object2.iterator();
                    while (true) {
                        n2 = n;
                        if (!object.hasNext()) break;
                        object3 = (byte[])object.next();
                        System.arraycopy((byte[])object3, (int)0, (byte[])byArray2, (int)n, (int)((Object)object3).length);
                        n += ((Object)object3).length;
                    }
                }
            }
            n = this.bOTDRel98Present ? 1 : 0;
            n = n2 = IO.put4(byArray2, n2, n);
            if (object4 != null) {
                System.arraycopy(object4, (int)0, (byte[])byArray2, (int)n2, (int)((Iterator<T>)object4).length);
                n = n2 + ((Object)object4).length;
            }
            n2 = this.bOTDRel5Present ? 1 : 0;
            n = IO.put4(byArray2, n, n2);
            if (object6 != null) {
                System.arraycopy((byte[])object6, (int)0, (byte[])byArray2, (int)n, (int)((Object)object6).length);
                n = ((Object)object6).length;
            }
        }
        Log.i((String)"SUPL20_EOTD", (String)("EOTD msg has send :" + byArray2.length + " " + 276));
        return byArray2;
    }
}

