/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.android.supl.loc.measure.aflt;

import android.util.Log;
import com.android.supl.loc.measure.aflt.AfltMeasure;
import com.android.supl.loc.measure.aflt.SUPL_AFLT_PilotPhaseRecord;
import java.util.ArrayList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class AfltConfigParser
extends DefaultHandler {
    private static final String AFLTMEASUREMENT = "afltmeasurement";
    private static final String BANDCLASS = "bandclass";
    private static final String BASESTATIONID = "basestationid";
    private static final String BMEASUREMENTVALID = "bmeasurementvalid";
    private static final String CDMAFREQUENCY = "cdmafrequency";
    private static final String ISOFFSETINCLUDED = "isOffsetincluded";
    private static final String MSTIMEOFFSET = "mstimeOffset";
    private static final String NETWORKIDENTIFICATION = "networkidentification";
    private static final String PILOTMEASUREDPHASE = "pilotmeasuredphase";
    private static final String PILOTPHASEDOPPLER = "pilotphasedoppler";
    private static final String PILOTPHASEFALSEALARMPROBABILITY = "pilotphasefalsealarmprobability";
    private static final String PILOTPHASEFALSEALARMRANGE = "pilotphasefalsealarmrange";
    private static final String PILOTPHASEMEASUREMENTERROR = "pilotphasemeasurementerror";
    private static final String PILOTPHASERECORD = "pilotphaserecord";
    private static final String PILOTSTRENGTH = "pilotstrength";
    private static final String PSEUDODOPPLERRMSERROR = "pseudodopplerrmserror";
    private static final String REFERENCEPILOTSTRENGTH = "referencepilotstrength";
    private static final String REFERENCEPN = "referencepn";
    private static final String REPEATERDETECTIONSTATUS = "repeaterdetectionstatus";
    private static final String REPEATERID = "repeaterid";
    private static final String REPEATERTYPE = "repeatertype";
    private static final String RMSERRORPHASE = "rmserrorphase";
    private static final String SYSTEMIDENTIFICATION = "systemidentification";
    private static final String TIMEREFERENCE = "timereference";
    private static final String TOTALNUMBEROFPILOTS = "totalnumberofpilots";
    private static final String TOTALRECEIVEDPOWER = "totalreceivedpower";
    public AfltMeasure afltmeasure = null;
    private int iIndex = -1;
    private boolean isMeasurementValid = false;
    private boolean isOffsetIncluded = false;
    private boolean isRequiredTag = false;
    private String repeaterId = null;
    private String stData = null;

    public AfltConfigParser() {
        this.init();
    }

    @Override
    public void characters(char[] cArray, int n, int n2) throws SAXException {
        if (this.isRequiredTag) {
            this.stData = new String(cArray, n, n2).trim();
            this.isRequiredTag = false;
            return;
        }
        this.stData = null;
    }

    @Override
    public void endElement(String object, String string, String string2) throws SAXException {
        boolean bl = true;
        boolean bl2 = true;
        if (string.equals(BMEASUREMENTVALID)) {
            object = this.afltmeasure;
            if (Integer.parseInt(this.stData) != 1) {
                bl2 = false;
            }
            ((AfltMeasure)object).bMeasurementValid = bl2;
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.bMeasurementValid : " + this.afltmeasure.bMeasurementValid));
            return;
        }
        if (string.equals(TIMEREFERENCE)) {
            this.afltmeasure.TimeReference = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.TimeReference : " + this.afltmeasure.TimeReference));
            return;
        }
        if (string.equals(ISOFFSETINCLUDED)) {
            object = this.afltmeasure;
            bl2 = Integer.parseInt(this.stData) == 1 ? bl : false;
            ((AfltMeasure)object).IsOffsetIncluded = bl2;
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.IsOffsetIncluded : " + this.afltmeasure.IsOffsetIncluded));
            return;
        }
        if (string.equals(MSTIMEOFFSET)) {
            this.afltmeasure.MSTimeOffset = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.MSTimeOffset : " + this.afltmeasure.MSTimeOffset));
            return;
        }
        if (string.equals(REFERENCEPN)) {
            this.afltmeasure.ReferencePN = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.ReferencePN : " + this.afltmeasure.ReferencePN));
            return;
        }
        if (string.equals(REFERENCEPILOTSTRENGTH)) {
            this.afltmeasure.ReferencePilotStrength = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.ReferencePilotStrength : " + this.afltmeasure.ReferencePilotStrength));
            return;
        }
        if (string.equals(BANDCLASS)) {
            this.afltmeasure.BandClass = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.BandClass : " + this.afltmeasure.BandClass));
            return;
        }
        if (string.equals(CDMAFREQUENCY)) {
            this.afltmeasure.CDMAFrequency = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.CDMAFrequency : " + this.afltmeasure.CDMAFrequency));
            return;
        }
        if (string.equals(BASESTATIONID)) {
            this.afltmeasure.BaseStationID = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.BaseStationID : " + this.afltmeasure.BaseStationID));
            return;
        }
        if (string.equals(SYSTEMIDENTIFICATION)) {
            this.afltmeasure.SystemIdentification = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.SystemIdentification : " + this.afltmeasure.SystemIdentification));
            return;
        }
        if (string.equals(NETWORKIDENTIFICATION)) {
            this.afltmeasure.NetworkIdentification = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.NetworkIdentification : " + this.afltmeasure.NetworkIdentification));
            return;
        }
        if (string.equals(TOTALRECEIVEDPOWER)) {
            this.afltmeasure.TotalReceivedPower = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.TotalReceivedPower : " + this.afltmeasure.TotalReceivedPower));
            return;
        }
        if (string.equals(TOTALNUMBEROFPILOTS)) {
            this.afltmeasure.TotalNumberOfPilots = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.TotalNumberOfPilots : " + this.afltmeasure.TotalNumberOfPilots));
            return;
        }
        if (string.equals(PILOTPHASERECORD)) {
            ++this.iIndex;
            this.afltmeasure.phaseRecord.add(this.iIndex, new SUPL_AFLT_PilotPhaseRecord());
            return;
        }
        if (string.equals(PILOTMEASUREDPHASE)) {
            this.afltmeasure.phaseRecord.get((int)this.iIndex).PilotMeasuredPhase = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.phaseRecord.get(iIndex).PilotMeasuredPhase : " + this.afltmeasure.phaseRecord.get((int)this.iIndex).PilotMeasuredPhase));
            return;
        }
        if (string.equals(PILOTSTRENGTH)) {
            this.afltmeasure.phaseRecord.get((int)this.iIndex).PilotStrength = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.phaseRecord.get(iIndex).PilotStrength : " + this.afltmeasure.phaseRecord.get((int)this.iIndex).PilotStrength));
            return;
        }
        if (string.equals(RMSERRORPHASE)) {
            this.afltmeasure.phaseRecord.get((int)this.iIndex).RMSErrorPhase = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.phaseRecord.get(iIndex).RMSErrorPhase : " + this.afltmeasure.phaseRecord.get((int)this.iIndex).RMSErrorPhase));
            return;
        }
        if (string.equals(PILOTPHASEMEASUREMENTERROR)) {
            this.afltmeasure.phaseRecord.get((int)this.iIndex).PilotPhaseMeasurementError = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.phaseRecord.get(iIndex).PilotPhaseMeasurementError : " + this.afltmeasure.phaseRecord.get((int)this.iIndex).PilotPhaseMeasurementError));
            return;
        }
        if (string.equals(REPEATERDETECTIONSTATUS)) {
            this.afltmeasure.phaseRecord.get((int)this.iIndex).RepeaterDetectionStatus = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.phaseRecord.get(iIndex).RepeaterDetectionStatus : " + this.afltmeasure.phaseRecord.get((int)this.iIndex).RepeaterDetectionStatus));
            return;
        }
        if (string.equals(REPEATERTYPE)) {
            this.afltmeasure.phaseRecord.get((int)this.iIndex).RepeaterType = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.phaseRecord.get(iIndex).RepeaterType : " + this.afltmeasure.phaseRecord.get((int)this.iIndex).RepeaterType));
            return;
        }
        if (string.equals(REPEATERID)) {
            this.afltmeasure.phaseRecord.get((int)this.iIndex).RepeaterID = this.stData.getBytes();
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.phaseRecord.get(iIndex).RepeaterID : " + this.afltmeasure.phaseRecord.get((int)this.iIndex).RepeaterID));
            return;
        }
        if (string.equals(PILOTPHASEDOPPLER)) {
            this.afltmeasure.phaseRecord.get((int)this.iIndex).PilotPhaseDoppler = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.phaseRecord.get(iIndex).PilotPhaseDoppler : " + this.afltmeasure.phaseRecord.get((int)this.iIndex).PilotPhaseDoppler));
            return;
        }
        if (string.equals(PSEUDODOPPLERRMSERROR)) {
            this.afltmeasure.phaseRecord.get((int)this.iIndex).PseudoDopplerRMSError = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.phaseRecord.get(iIndex).PseudoDopplerRMSError : " + this.afltmeasure.phaseRecord.get((int)this.iIndex).PseudoDopplerRMSError));
            return;
        }
        if (string.equals(PILOTPHASEFALSEALARMPROBABILITY)) {
            this.afltmeasure.phaseRecord.get((int)this.iIndex).PilotphaseFalseAlarmProbability = Integer.parseInt(this.stData);
            Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.phaseRecord.get(iIndex).PilotphaseFalseAlarmRange : " + this.afltmeasure.phaseRecord.get((int)this.iIndex).PilotphaseFalseAlarmProbability));
            return;
        }
        if (!string.equals(PILOTPHASEFALSEALARMRANGE)) return;
        this.afltmeasure.phaseRecord.get((int)this.iIndex).PilotphaseFalseAlarmRange = Integer.parseInt(this.stData);
        Log.i((String)"AFLT_CONFIG", (String)("afltmeasure.phaseRecord.get(iIndex).PilotphaseFalseAlarmRange : " + this.afltmeasure.phaseRecord.get((int)this.iIndex).PilotphaseFalseAlarmRange));
    }

    public AfltMeasure getAFLTMeasInfo() {
        return this.afltmeasure;
    }

    /*
     * Exception decompiling
     */
    public void init() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 6 blocks at once
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:412)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:487)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:845)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:73)
         *     at org.benf.cfr.reader.Main.main(Main.java:49)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:303)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$null$1(ResourceDecompiling.java:113)
         *     at java.base/java.lang.Thread.run(Unknown Source)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public void startElement(String string, String string2, String string3, Attributes attributes) throws SAXException {
        if (string2.equals(AFLTMEASUREMENT)) {
            this.afltmeasure = new AfltMeasure();
            return;
        }
        if (string2.equals(BMEASUREMENTVALID)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(TIMEREFERENCE)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(ISOFFSETINCLUDED)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(MSTIMEOFFSET)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(REFERENCEPN)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(REFERENCEPILOTSTRENGTH)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(BANDCLASS)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(CDMAFREQUENCY)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(BASESTATIONID)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(SYSTEMIDENTIFICATION)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(NETWORKIDENTIFICATION)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(TOTALRECEIVEDPOWER)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(TOTALNUMBEROFPILOTS)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(PILOTPHASERECORD)) {
            ++this.iIndex;
            if (this.afltmeasure.phaseRecord == null) {
                this.afltmeasure.phaseRecord = new ArrayList();
            }
            this.afltmeasure.phaseRecord.add(this.iIndex, new SUPL_AFLT_PilotPhaseRecord());
            return;
        }
        if (string2.equals(PILOTMEASUREDPHASE)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(PILOTSTRENGTH)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(RMSERRORPHASE)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(PILOTPHASEMEASUREMENTERROR)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(REPEATERDETECTIONSTATUS)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(REPEATERTYPE)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(REPEATERID)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(PILOTPHASEDOPPLER)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(PSEUDODOPPLERRMSERROR)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(PILOTPHASEFALSEALARMPROBABILITY)) {
            this.isRequiredTag = true;
            return;
        }
        if (!string2.equals(PILOTPHASEFALSEALARMRANGE)) return;
        this.isRequiredTag = true;
    }
}

