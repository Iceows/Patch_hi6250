/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.ModeSpecificInfo;

public class CellMeasuredResults {
    private boolean bIsCellIdentityPresent;
    private ModeSpecificInfo mModeSpecificInfo = null;
    private int unCellIdentity;

    public CellMeasuredResults(int n, ModeSpecificInfo modeSpecificInfo) {
        if (modeSpecificInfo == null) {
            throw new IllegalArgumentException("ModeSpecificInfo should not be null");
        }
        this.unCellIdentity = n;
        this.mModeSpecificInfo = modeSpecificInfo;
        boolean bl = n != -1;
        this.bIsCellIdentityPresent = bl;
    }

    public byte[] getCellMeasuredResults() {
        int n = 4;
        if (this.bIsCellIdentityPresent) {
            n = 8;
        }
        byte[] byArray = this.mModeSpecificInfo.getModeSpecificInfo();
        int n2 = n + byArray.length;
        byte[] byArray2 = new byte[n2];
        n = this.bIsCellIdentityPresent ? IO.put4(byArray2, IO.put4(byArray2, 0, 1), this.unCellIdentity) : IO.put4(byArray2, 0, 0);
        System.arraycopy((byte[])byArray, (int)0, (byte[])byArray2, (int)n, (int)byArray.length);
        if (n + byArray.length == n2) return byArray2;
        System.out.println("CellMeasuredResults length error");
        return byArray2;
    }
}

