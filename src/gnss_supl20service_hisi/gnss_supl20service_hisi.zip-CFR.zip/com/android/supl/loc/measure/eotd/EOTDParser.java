/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.eotd;

import com.android.supl.loc.measure.eotd.BSIC_Carrier;
import com.android.supl.loc.measure.eotd.CellID_LAC;
import com.android.supl.loc.measure.eotd.EOTDQuality;
import com.android.supl.loc.measure.eotd.MultiFrameCarrier;
import com.android.supl.loc.measure.eotd.Neighbor_ID_Union;
import com.android.supl.loc.measure.eotd.Neighbor_Identity;
import com.android.supl.loc.measure.eotd.OTDMeans_WithID;
import com.android.supl.loc.measure.eotd.OTDMeas;
import com.android.supl.loc.measure.eotd.OTD_MSREleCommon;
import com.android.supl.loc.measure.eotd.OTD_MSREleRest;
import com.android.supl.loc.measure.eotd.OTD_MSR_OtherSets_Union;
import com.android.supl.loc.measure.eotd.OTD_MSRofOtherSets;
import com.android.supl.loc.measure.eotd.OTD_MeasR98Ext;
import com.android.supl.loc.measure.eotd.OTD_MeasREL5Ext;
import com.android.supl.loc.measure.eotd.OTD_MsrEleFirst;
import com.android.supl.loc.measure.eotd.SUPL_EOTDMeasInfo;
import java.util.ArrayList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class EOTDParser
extends DefaultHandler {
    private static final String BCCHCARRIER = "bcchcarrier";
    private static final String BSIC = "bsic";
    private static final String BSICANDCARRIER = "bsicandcarrier";
    private static final String CARRIER = "carrier";
    private static final String CELLIDANDLAC = "cellidandlac";
    private static final String COUNT = "count";
    private static final String EOTDMEAS = "eotdmeas";
    private static final String EOTDQUALITY = "eotdquality";
    private static final String ISIDENTITYPRESENT = "isidentitypresent";
    private static final String MEASR98EXT = "measr98ext";
    private static final String MEASREL5EXT = "measrel5ext";
    private static final String MEASWITHID = "measwithid";
    private static final String MSRELECOMMON = "msrelecommon";
    private static final String MSRELEFIRST = "msrelefirst";
    private static final String MSRELEREST = "msrelerest";
    private static final String MSROFOTHERSETS = "msrofothersets";
    private static final String MSROTHERSETSUNION = "msrothersetsunion";
    private static final String MULTIFRAMECARRIER = "multiframecarrier";
    private static final String MULTIFRAMEOFFSET = "multiframeoffset";
    private static final String NBORTIMESLOT = "nbortimeslot";
    private static final String NBROFMEASUREMENTS = "nbrofmeasurements";
    private static final String NEIGHBORIDENTITY = "neighboridentity";
    private static final String NEIGHBORIDTYPE = "neighboridtype";
    private static final String NEIGHBORIDUNION = "neighboridunion";
    private static final String NOOFVALIDSETS = "noofvalidsets";
    private static final String NUMOFMEASUREMENTS = "numofmeasurements";
    private static final String OTDMEAS = "otdmeas";
    private static final String OTDREL5PRESENT = "otdrel5present";
    private static final String OTDREL98PRESENT = "otdrel98present";
    private static final String OTDVALUE = "otdvalue";
    private static final String REFERENCECI = "referenceci";
    private static final String REFERENCELAC = "referencelac";
    private static final String REFERENCETIMESLOT = "referencetimeslot";
    private static final String REFFRAMENUMBER = "refframenumber";
    private static final String REFQUALITY = "refquality";
    private static final String REQUESTINDEX = "requestindex";
    private static final String SETCOUNT = "setcount";
    private static final String STDOFEOTD = "stdofeotd";
    private static final String STDRESOLUTION = "stdresolution";
    private static final String SYSTEMINFOINDEX = "systeminfoindex";
    private static final String TACORRECTION = "tacorrection";
    private static final String VALIDEOTDMEASUREMENT = "valideotdmeasurement";
    private OTD_MSREleCommon eleCommon = null;
    private OTD_MSREleRest eleRest = null;
    private SUPL_EOTDMeasInfo eotdMeasInfo = null;
    private int iSetCount = 0;
    private boolean isEleRest = false;
    private boolean isMesare98 = false;
    private boolean isMesarel5 = false;
    private boolean isMsrelefirst = false;
    private boolean isNotValideotdMeasurement = false;
    private boolean isOTDMeas = false;
    private boolean isRequiredTag;
    private OTDMeans_WithID means_WithID = null;
    private OTD_MSRofOtherSets otd_MSRofOtherSets = null;
    private EOTDQuality quality = null;
    private String stData;

    public EOTDParser() {
        this.init();
    }

    /*
     * Exception decompiling
     */
    private void init() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 6 blocks at once
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:412)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:487)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:845)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:73)
         *     at org.benf.cfr.reader.Main.main(Main.java:49)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:303)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$null$1(ResourceDecompiling.java:113)
         *     at java.base/java.lang.Thread.run(Unknown Source)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public void characters(char[] cArray, int n, int n2) throws SAXException {
        if (this.isRequiredTag) {
            this.stData = new String(cArray, n, n2).trim();
            this.isRequiredTag = false;
            return;
        }
        this.stData = null;
    }

    @Override
    public void endElement(String object, String string, String string2) throws SAXException {
        boolean bl = true;
        boolean bl2 = true;
        boolean bl3 = true;
        boolean bl4 = true;
        if (string.equals(VALIDEOTDMEASUREMENT)) {
            object = this.eotdMeasInfo;
            bl = Integer.parseInt(this.stData) != 0;
            ((SUPL_EOTDMeasInfo)object).bIsValidEOTDMeasurement = bl;
            bl = Integer.parseInt(this.stData) == 0 ? bl4 : false;
            this.isNotValideotdMeasurement = bl;
            return;
        }
        if (this.isNotValideotdMeasurement) {
            return;
        }
        if (string.equals(MSRELEFIRST)) {
            this.isMsrelefirst = false;
            return;
        }
        if (string.equals(MSRELECOMMON)) {
            if (this.isMsrelefirst) {
                this.eotdMeasInfo.otdMsrFirstSet.otd_MsrComm = this.eleCommon;
            } else if (this.isEleRest) {
                this.eleRest.otd_MsrComm = this.eleCommon;
            }
            this.eleCommon = null;
            return;
        }
        if (string.equals(REFFRAMENUMBER)) {
            this.eleCommon.usRefFrameNumber = Integer.parseInt(this.stData);
            return;
        }
        if (string.equals(REFERENCETIMESLOT)) {
            this.eleCommon.ucReferenceTimeSlot = Short.parseShort(this.stData);
            return;
        }
        if (string.equals(REFQUALITY)) {
            this.eleCommon.ucRefQuality = Short.parseShort(this.stData);
            return;
        }
        if (string.equals(NUMOFMEASUREMENTS)) {
            this.eleCommon.ucNumOfMeasurements = Short.parseShort(this.stData);
            return;
        }
        if (string.equals(STDRESOLUTION)) {
            this.eleCommon.ucStdResolution = Short.parseShort(this.stData);
            return;
        }
        if (string.equals(TACORRECTION)) {
            this.eleCommon.usTACorrection = Integer.parseInt(this.stData);
            return;
        }
        if (string.equals(MSRELECOMMON)) {
            if (this.isMsrelefirst) {
                this.eotdMeasInfo.otdMsrFirstSet.otd_MsrComm = this.eleCommon;
            } else if (this.isEleRest || this.eotdMeasInfo.bOTDRel5Present) {
                this.eleRest.otd_MsrComm = this.eleCommon;
            }
            this.eleCommon = null;
            return;
        }
        if (string.equals(SETCOUNT)) {
            if (this.isMsrelefirst) {
                this.eotdMeasInfo.otdMsrFirstSet.ucSetCount = Short.parseShort(this.stData);
                return;
            }
            if (!this.isEleRest) return;
            this.eleRest.ucSetCount = Short.parseShort(this.stData);
            return;
        }
        if (string.equals(MEASWITHID)) {
            if (this.isMsrelefirst) {
                if (this.eotdMeasInfo.otdMsrFirstSet.aWithIDs == null) {
                    this.eotdMeasInfo.otdMsrFirstSet.aWithIDs = new ArrayList(this.eotdMeasInfo.otdMsrFirstSet.ucSetCount);
                }
                this.eotdMeasInfo.otdMsrFirstSet.aWithIDs.add(this.means_WithID);
            } else if (this.isMesare98) {
                if (this.eotdMeasInfo.otd_MeasureInfo_R98_Ext.otd_FirstSetMsrs == null) {
                    this.eotdMeasInfo.otd_MeasureInfo_R98_Ext.otd_FirstSetMsrs = new ArrayList(this.eotdMeasInfo.otd_MeasureInfo_R98_Ext.ucCount);
                }
                this.eotdMeasInfo.otd_MeasureInfo_R98_Ext.otd_FirstSetMsrs.add(this.means_WithID);
            } else if (this.isMesarel5 && this.otd_MSRofOtherSets.bIsIdentityPresent) {
                this.otd_MSRofOtherSets.stOTDMsr.identityPresent = this.means_WithID;
            }
            this.means_WithID = null;
            return;
        }
        if (string.equals(NEIGHBORIDTYPE)) {
            this.means_WithID.neighborIdentity.enIdType = Integer.parseInt(this.stData);
            return;
        }
        if (string.equals(CARRIER)) {
            this.means_WithID.neighborIdentity.stNeigh.bsicAndCarrier.usCarrier = Integer.parseInt(this.stData);
            return;
        }
        if (string.equals(BSIC)) {
            this.means_WithID.neighborIdentity.stNeigh.bsicAndCarrier.cBsic = Short.parseShort(this.stData);
            return;
        }
        if (string.equals(REFERENCELAC)) {
            this.means_WithID.neighborIdentity.stNeigh.ciandlac.usReferenceLAC = Short.parseShort(this.stData);
            return;
        }
        if (string.equals(REFERENCECI)) {
            this.means_WithID.neighborIdentity.stNeigh.ciandlac.usReferenceCI = Short.parseShort(this.stData);
            return;
        }
        if (string.equals(BCCHCARRIER)) {
            this.means_WithID.neighborIdentity.stNeigh.multiFrameCarrier.usBCCHCarrier = Integer.parseInt(this.stData);
            return;
        }
        if (string.equals(MULTIFRAMEOFFSET)) {
            this.means_WithID.neighborIdentity.stNeigh.multiFrameCarrier.ucMultiFrameOffset = Short.parseShort(this.stData);
            return;
        }
        if (string.equals(NBORTIMESLOT)) {
            if (this.isOTDMeas) {
                this.otd_MSRofOtherSets.stOTDMsr.identityNotPresent.ucNborTimeSlot = Short.parseShort(this.stData);
                return;
            }
            this.means_WithID.ucNborTimeSlot = Short.parseShort(this.stData);
            return;
        }
        if (string.equals(NBROFMEASUREMENTS)) {
            this.quality.ucNbrOfMeasurements = Short.parseShort(this.stData);
            return;
        }
        if (string.equals(STDOFEOTD)) {
            this.quality.ucStdOfEOTD = Short.parseShort(this.stData);
            return;
        }
        if (string.equals(EOTDQUALITY)) {
            if (this.isOTDMeas) {
                this.otd_MSRofOtherSets.stOTDMsr.identityNotPresent.eotdQuality = this.quality;
                return;
            }
            this.means_WithID.eotdQuality = this.quality;
            return;
        }
        if (string.equals(OTDVALUE)) {
            if (this.isOTDMeas) {
                this.otd_MSRofOtherSets.stOTDMsr.identityNotPresent.usOTDValue = Integer.parseInt(this.stData);
                return;
            }
            this.means_WithID.usOTDValue = Integer.parseInt(this.stData);
            return;
        }
        if (string.equals(MSRELEFIRST)) {
            this.eotdMeasInfo.otdMsrFirstSet.ucSetCount = (short)this.iSetCount;
            return;
        }
        if (string.equals(NOOFVALIDSETS)) {
            this.eotdMeasInfo.nNoOfValidSets = Integer.parseInt(this.stData);
            if (this.eotdMeasInfo.nNoOfValidSets <= 0) return;
            this.eotdMeasInfo.otdMsrRestSets = new ArrayList(this.eotdMeasInfo.nNoOfValidSets);
            return;
        }
        if (string.equals(MSRELEREST)) {
            if (!this.isMesarel5 && this.isEleRest) {
                this.eotdMeasInfo.otdMsrRestSets.add(this.eleRest);
            } else if (this.isMesarel5) {
                this.eotdMeasInfo.otd_MeasureInfo_Rel_5_Ext.otdMsrRestSets.add(this.eleRest);
            }
            this.eleRest = null;
            return;
        }
        if (string.equals(MSROFOTHERSETS)) {
            if (this.isEleRest) {
                if (this.eleRest.otd_MsrsOfOtherSets == null) {
                    this.eleRest.otd_MsrsOfOtherSets = new ArrayList(this.eleRest.ucSetCount);
                }
                this.eleRest.otd_MsrsOfOtherSets.add(this.otd_MSRofOtherSets);
            } else if (this.eotdMeasInfo.bOTDRel5Present) {
                if (this.eleRest.otd_MsrsOfOtherSets == null) {
                    this.eleRest.otd_MsrsOfOtherSets = new ArrayList(this.eleRest.ucSetCount);
                }
                this.eleRest.otd_MsrsOfOtherSets.add(this.otd_MSRofOtherSets);
            }
            this.otd_MSRofOtherSets = null;
            return;
        }
        if (string.equals(ISIDENTITYPRESENT)) {
            object = this.otd_MSRofOtherSets;
            if (Integer.parseInt(this.stData) != 1) {
                bl = false;
            }
            ((OTD_MSRofOtherSets)object).bIsIdentityPresent = bl;
            return;
        }
        if (string.equals(NBORTIMESLOT)) {
            this.otd_MSRofOtherSets.stOTDMsr.identityNotPresent.ucNborTimeSlot = Short.parseShort(this.stData);
            return;
        }
        if (string.equals(OTDVALUE)) {
            this.otd_MSRofOtherSets.stOTDMsr.identityNotPresent.usOTDValue = Short.parseShort(this.stData);
            return;
        }
        if (string.equals(OTDMEAS)) {
            this.otd_MSRofOtherSets.stOTDMsr.identityNotPresent.eotdQuality = this.quality;
            this.isOTDMeas = false;
            return;
        }
        if (string.equals(OTDREL98PRESENT)) {
            object = this.eotdMeasInfo;
            bl = Integer.parseInt(this.stData) == 1 ? bl2 : false;
            ((SUPL_EOTDMeasInfo)object).bOTDRel98Present = bl;
            this.isMesare98 = this.eotdMeasInfo.bOTDRel98Present;
            if (!this.eotdMeasInfo.bOTDRel98Present) return;
            this.eotdMeasInfo.otd_MeasureInfo_R98_Ext = new OTD_MeasR98Ext();
            return;
        }
        if (string.equals(MEASR98EXT)) {
            this.isMesare98 = false;
            return;
        }
        if (string.equals(COUNT)) {
            if (this.isMesare98) {
                this.eotdMeasInfo.otd_MeasureInfo_R98_Ext.ucCount = Short.parseShort(this.stData);
                this.eotdMeasInfo.otd_MeasureInfo_R98_Ext.otd_FirstSetMsrs = new ArrayList(this.eotdMeasInfo.otd_MeasureInfo_R98_Ext.ucCount);
                return;
            }
            if (!this.isMesarel5) return;
            this.eotdMeasInfo.otd_MeasureInfo_Rel_5_Ext.ucCount = Short.parseShort(this.stData);
            this.eotdMeasInfo.otd_MeasureInfo_Rel_5_Ext.otdMsrRestSets = new ArrayList(this.eotdMeasInfo.otd_MeasureInfo_Rel_5_Ext.ucCount);
            return;
        }
        if (string.equals(OTDREL5PRESENT)) {
            object = this.eotdMeasInfo;
            bl = Integer.parseInt(this.stData) == 1;
            ((SUPL_EOTDMeasInfo)object).bOTDRel5Present = bl;
            if (this.eotdMeasInfo.bOTDRel5Present) {
                this.eotdMeasInfo.otd_MeasureInfo_Rel_5_Ext = new OTD_MeasREL5Ext();
            }
            bl = Integer.parseInt(this.stData) == 1 ? bl3 : false;
            this.isMesarel5 = bl;
            return;
        }
        if (string.equals(MEASREL5EXT)) {
            this.isMesarel5 = false;
            return;
        }
        if (string.equals(REQUESTINDEX)) {
            this.means_WithID.neighborIdentity.stNeigh.ucRequestIndex = Short.parseShort(this.stData);
            return;
        }
        if (!string.equals(SYSTEMINFOINDEX)) return;
        this.means_WithID.neighborIdentity.stNeigh.ucSystemInfoIndex = Short.parseShort(this.stData);
    }

    public SUPL_EOTDMeasInfo getEotdMeasInfo() {
        return this.eotdMeasInfo;
    }

    @Override
    public void startElement(String string, String string2, String string3, Attributes attributes) throws SAXException {
        if (string2.equals(VALIDEOTDMEASUREMENT)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(EOTDMEAS)) {
            this.eotdMeasInfo = new SUPL_EOTDMeasInfo();
            return;
        }
        if (this.isNotValideotdMeasurement) {
            return;
        }
        if (string2.equals(MSRELEFIRST)) {
            this.eotdMeasInfo.otdMsrFirstSet = new OTD_MsrEleFirst();
            this.isMsrelefirst = true;
            return;
        }
        if (string2.equals(MSRELECOMMON)) {
            this.eleCommon = new OTD_MSREleCommon();
            return;
        }
        if (string2.equals(REFFRAMENUMBER)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(REFERENCETIMESLOT)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(REFQUALITY)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(NUMOFMEASUREMENTS)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(STDRESOLUTION)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(TACORRECTION)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(SETCOUNT)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(MEASWITHID)) {
            this.means_WithID = new OTDMeans_WithID();
            return;
        }
        if (string2.equals(NEIGHBORIDENTITY)) {
            this.means_WithID.neighborIdentity = new Neighbor_Identity();
            return;
        }
        if (string2.equals(NEIGHBORIDTYPE)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(NEIGHBORIDUNION)) {
            this.means_WithID.neighborIdentity.stNeigh = new Neighbor_ID_Union();
            return;
        }
        if (string2.equals(BSICANDCARRIER)) {
            this.means_WithID.neighborIdentity.stNeigh.bsicAndCarrier = new BSIC_Carrier();
            return;
        }
        if (string2.equals(CELLIDANDLAC)) {
            this.means_WithID.neighborIdentity.stNeigh.ciandlac = new CellID_LAC();
            return;
        }
        if (string2.equals(MULTIFRAMECARRIER)) {
            this.means_WithID.neighborIdentity.stNeigh.multiFrameCarrier = new MultiFrameCarrier();
            return;
        }
        if (string2.equals(REQUESTINDEX)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(REFERENCELAC)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(REFERENCECI)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(BCCHCARRIER)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(MULTIFRAMEOFFSET)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(CARRIER)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(BSIC)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(NBORTIMESLOT)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(EOTDQUALITY)) {
            this.quality = new EOTDQuality();
            return;
        }
        if (string2.equals(NBROFMEASUREMENTS)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(STDOFEOTD)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(OTDVALUE)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(NOOFVALIDSETS)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(MSRELEREST)) {
            this.eleRest = new OTD_MSREleRest();
            this.isEleRest = true;
            return;
        }
        if (string2.equals(MSROFOTHERSETS)) {
            this.otd_MSRofOtherSets = new OTD_MSRofOtherSets();
            return;
        }
        if (string2.equals(ISIDENTITYPRESENT)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(MSROTHERSETSUNION)) {
            this.otd_MSRofOtherSets.stOTDMsr = new OTD_MSR_OtherSets_Union();
            return;
        }
        if (string2.equals(OTDMEAS)) {
            if (this.otd_MSRofOtherSets.bIsIdentityPresent) return;
            this.otd_MSRofOtherSets.stOTDMsr.identityNotPresent = new OTDMeas();
            if (this.otd_MSRofOtherSets.bIsIdentityPresent) return;
            this.isOTDMeas = true;
            return;
        }
        if (string2.equals(NBORTIMESLOT)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(OTDVALUE)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(OTDREL98PRESENT)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(COUNT)) {
            this.isRequiredTag = true;
            return;
        }
        if (string2.equals(OTDREL5PRESENT)) {
            this.isRequiredTag = true;
            return;
        }
        if (!string2.equals(SYSTEMINFOINDEX)) return;
        this.isRequiredTag = true;
    }
}

