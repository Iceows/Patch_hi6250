/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;

public class MultiFrameCarrier {
    public short ucMultiFrameOffset;
    public int usBCCHCarrier;

    public byte[] getMultiFrameCarrier() {
        byte[] byArray = new byte[3];
        IO.put1(byArray, IO.put2(byArray, 0, this.usBCCHCarrier), this.ucMultiFrameOffset);
        return byArray;
    }
}

