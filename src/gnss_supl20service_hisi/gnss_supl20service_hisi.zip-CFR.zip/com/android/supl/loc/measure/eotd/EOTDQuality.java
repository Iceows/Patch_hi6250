/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;

public class EOTDQuality {
    public short ucNbrOfMeasurements;
    public short ucStdOfEOTD;

    public byte[] getEOTDQulaity() {
        byte[] byArray = new byte[2];
        IO.put1(byArray, IO.put1(byArray, 0, this.ucNbrOfMeasurements), this.ucStdOfEOTD);
        return byArray;
    }
}

