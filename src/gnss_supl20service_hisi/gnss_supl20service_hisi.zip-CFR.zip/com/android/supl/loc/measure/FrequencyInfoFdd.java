/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure;

import com.android.bytewriter.IO;

public class FrequencyInfoFdd {
    private boolean bIsUarfcn_UL_Present;
    private short usUarfcn_DL;
    private short usUarfcn_UL;

    public FrequencyInfoFdd(short s, short s2) {
        this.usUarfcn_UL = s;
        this.usUarfcn_DL = s2;
        boolean bl = s != -1;
        this.bIsUarfcn_UL_Present = bl;
    }

    public byte[] getFrequencyInfoFdd() {
        int n = 4;
        if (this.bIsUarfcn_UL_Present) {
            n = 8;
        }
        byte[] byArray = new byte[n];
        int n2 = this.bIsUarfcn_UL_Present ? IO.put2(byArray, IO.put4(byArray, 0, 1), this.usUarfcn_UL) : IO.put4(byArray, 0, 0);
        if (IO.put2(byArray, n2, this.usUarfcn_DL) == n) return byArray;
        System.out.println("FrequencyInfoFdd length invalid");
        return byArray;
    }
}

