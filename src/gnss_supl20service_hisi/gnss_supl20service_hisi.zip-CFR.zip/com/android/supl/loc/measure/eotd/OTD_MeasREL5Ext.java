/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.eotd.OTD_MSREleRest;
import java.util.ArrayList;
import java.util.Vector;

public class OTD_MeasREL5Ext {
    public ArrayList<OTD_MSREleRest> otdMsrRestSets;
    public short ucCount;

    public byte[] getOTD_MeasRel5Ext() {
        Object object;
        Object object2;
        int n = 1;
        int n2 = 1;
        Object object3 = null;
        if (this.otdMsrRestSets != null) {
            object2 = new Vector(this.otdMsrRestSets.size());
            object = this.otdMsrRestSets.iterator();
            while (true) {
                n = n2;
                object3 = object2;
                if (!object.hasNext()) break;
                object3 = (OTD_MSREleRest)object.next();
                if (object3 == null || (object3 = (Object)((OTD_MSREleRest)object3).getOTD_MSREleRest()) == null) continue;
                ((Vector)object2).add(object3);
                n2 += ((Object)object3).length;
            }
        }
        object2 = new byte[n];
        n2 = IO.put1((byte[])object2, 0, this.ucCount);
        if (object3 == null) return object2;
        object3 = object3.iterator();
        while (object3.hasNext()) {
            object = (byte[])object3.next();
            if (object == null) continue;
            System.arraycopy((byte[])object, (int)0, (byte[])object2, (int)n2, (int)((Object)object).length);
            n2 += ((Object)object).length;
        }
        return object2;
    }
}

