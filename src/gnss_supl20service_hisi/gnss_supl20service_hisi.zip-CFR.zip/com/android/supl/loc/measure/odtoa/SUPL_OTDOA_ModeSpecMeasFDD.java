/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.odtoa;

import com.android.bytewriter.IO;

public class SUPL_OTDOA_ModeSpecMeasFDD {
    public boolean bPrimaryScramblingCodePresent;
    public boolean bRxTxTimeDiffValid;
    public long lPrimaryScramblingCode;
    public long lRxTxTimeDiffType2;
    public short ucNoOfMeasurements;
    public short ucStdDevOTDOAMeas;
    public short ucStdValue;

    public byte[] getModeSpecMeasFDD() {
        int n;
        int n2 = 1;
        int n3 = this.bPrimaryScramblingCodePresent ? 4 : 0;
        byte[] byArray = new byte[n3 + 12 + 3];
        n3 = this.bPrimaryScramblingCodePresent ? 1 : 0;
        n3 = n = IO.put4(byArray, 0, n3);
        if (this.bPrimaryScramblingCodePresent) {
            n3 = IO.put4(byArray, n, (int)this.lPrimaryScramblingCode);
        }
        if (!this.bRxTxTimeDiffValid) {
            n2 = 0;
        }
        IO.put1(byArray, IO.put1(byArray, IO.put1(byArray, IO.put4(byArray, IO.put4(byArray, n3, n2), (int)this.lRxTxTimeDiffType2), this.ucStdValue), this.ucNoOfMeasurements), this.ucStdDevOTDOAMeas);
        return byArray;
    }
}

