/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.lpp;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.lpp.SUPL_LPP_NEIGHBOUR_ELEM;
import java.util.Vector;

public class SUPL_LPP_NEIGHBOUR_OTDOA_MMT {
    public byte byNumberofNeighbourMmts = 1;
    SUPL_LPP_NEIGHBOUR_ELEM[] stLPPOTDOANeighbourElem = new SUPL_LPP_NEIGHBOUR_ELEM[]{new SUPL_LPP_NEIGHBOUR_ELEM()};

    public byte[] get_NEIGHBOUR_OTDOA_MMT() {
        Object[] objectArray;
        Object object;
        int n = 1;
        int n2 = 1;
        Object object2 = null;
        if (this.stLPPOTDOANeighbourElem != null) {
            object = new Vector(this.byNumberofNeighbourMmts);
            objectArray = this.stLPPOTDOANeighbourElem;
            int n3 = objectArray.length;
            int n4 = 0;
            while (true) {
                n = n2;
                object2 = object;
                if (n4 >= n3) break;
                object2 = objectArray[n4];
                n = n2;
                if (object2 != null) {
                    object2 = ((SUPL_LPP_NEIGHBOUR_ELEM)object2).getLPP_NEIGHBOUR_ELEM();
                    n = n2;
                    if (object2 != null) {
                        ((Vector)object).add(object2);
                        n = n2 + ((Object)object2).length;
                    }
                }
                ++n4;
                n2 = n;
            }
        }
        object = new byte[n];
        n2 = IO.put1((byte[])object, 0, this.byNumberofNeighbourMmts);
        if (this.byNumberofNeighbourMmts <= 0) return object;
        if (object2 == null) return object;
        object2 = object2.iterator();
        while (object2.hasNext()) {
            objectArray = (byte[])object2.next();
            if (objectArray == null) continue;
            System.arraycopy((byte[])objectArray, (int)0, (byte[])object, (int)n2, (int)objectArray.length);
            n2 += objectArray.length;
        }
        return object;
    }
}

