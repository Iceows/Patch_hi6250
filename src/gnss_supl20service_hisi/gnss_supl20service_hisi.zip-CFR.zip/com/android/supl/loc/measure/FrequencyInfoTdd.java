/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure;

import com.android.bytewriter.IO;

public class FrequencyInfoTdd {
    private short usUarfcn_Nt;

    public FrequencyInfoTdd(short s) {
        this.usUarfcn_Nt = s;
    }

    public byte[] getFrequencyInfoTdd() {
        byte[] byArray = new byte[2];
        IO.put2(byArray, 0, this.usUarfcn_Nt);
        return byArray;
    }
}

