/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.eotd.OTD_MSREleCommon;
import com.android.supl.loc.measure.eotd.OTD_MSRofOtherSets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

public class OTD_MSREleRest {
    public OTD_MSREleCommon otd_MsrComm;
    public ArrayList<OTD_MSRofOtherSets> otd_MsrsOfOtherSets;
    public short ucSetCount;

    public byte[] getOTD_MSREleRest() {
        Object object;
        int n = 1;
        int n2 = 0;
        byte[] byArray = null;
        if (this.otd_MsrComm != null) {
            byArray = this.otd_MsrComm.getOTSMSREle();
            n = byArray.length + 1;
        }
        Object object2 = null;
        int n3 = n;
        if (this.otd_MsrsOfOtherSets != null) {
            object = new Vector(this.otd_MsrsOfOtherSets.size());
            Iterator iterator = this.otd_MsrsOfOtherSets.iterator();
            while (true) {
                n3 = n;
                object2 = object;
                if (!iterator.hasNext()) break;
                object2 = (OTD_MSRofOtherSets)iterator.next();
                if (object2 == null || (object2 = (Object)object2.getOTD_MSRofOtherSets()) == null) continue;
                ((Vector)object).add(object2);
                n += ((byte[])object2).length;
            }
        }
        object = new byte[n3];
        n = n2;
        if (byArray != null) {
            System.arraycopy((byte[])byArray, (int)0, (byte[])object, (int)0, (int)byArray.length);
            n = byArray.length + 0;
        }
        n = IO.put1((byte[])object, n, this.ucSetCount);
        if (object2 == null) return object;
        object2 = object2.iterator();
        while (object2.hasNext()) {
            byArray = (byte[])object2.next();
            if (byArray == null) continue;
            System.arraycopy((byte[])byArray, (int)0, (byte[])object, (int)n, (int)byArray.length);
            n += byArray.length;
        }
        return object;
    }
}

