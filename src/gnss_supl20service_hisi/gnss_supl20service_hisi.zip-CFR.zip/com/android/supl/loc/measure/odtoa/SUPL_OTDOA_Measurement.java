/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.android.supl.loc.measure.odtoa;

import android.util.Log;
import com.android.bytewriter.IO;
import com.android.supl.loc.measure.odtoa.SUPL_OTDOA_ModeSpecMeas;
import com.android.supl.loc.measure.odtoa.SUPL_OTDOA_NeighbourMeas;
import java.util.Vector;

public class SUPL_OTDOA_Measurement {
    public static final int SUPL_OTDOA_MODE_SPEC_INFO_FDD = 1;
    public static final int SUPL_OTDOA_MODE_SPEC_INFO_NONE = 0;
    public static final int SUPL_OTDOA_MODE_SPEC_INFO_TDD = 2;
    public boolean bMeasurementValid;
    public boolean bNeighbourListPresent;
    public int eModeSpecInfoType;
    public long lSFN;
    public SUPL_OTDOA_ModeSpecMeas stModeSpecMeas;
    public SUPL_OTDOA_NeighbourMeas[] stNeighbourMeasList;
    public short ucNoOfNeighbourList;

    public byte[] getOTDOA_Measurement(int n) {
        int n2 = 16;
        Object object = null;
        if (this.stModeSpecMeas != null) {
            object = this.stModeSpecMeas.getModeSpecMeas();
            n2 = ((byte[])object).length + 16;
        }
        int n3 = n2;
        if (this.bNeighbourListPresent) {
            n3 = n2 + 1;
        }
        Object object2 = null;
        int n4 = n3;
        Object object3 = object2;
        if (this.bNeighbourListPresent) {
            n4 = n3;
            object3 = object2;
            if (this.stNeighbourMeasList != null) {
                object2 = new Vector(this.stNeighbourMeasList.length);
                SUPL_OTDOA_NeighbourMeas[] sUPL_OTDOA_NeighbourMeasArray = this.stNeighbourMeasList;
                n2 = 0;
                int n5 = sUPL_OTDOA_NeighbourMeasArray.length;
                while (true) {
                    n4 = n3;
                    object3 = object2;
                    if (n2 >= n5) break;
                    object3 = sUPL_OTDOA_NeighbourMeasArray[n2];
                    n4 = n3;
                    if (object3 != null) {
                        object3 = object3.getNeighbourMeas();
                        n4 = n3;
                        if (object3 != null) {
                            n4 = n3 + ((byte[])object3).length;
                            ((Vector)object2).add(object3);
                        }
                    }
                    ++n2;
                    n3 = n4;
                }
            }
        }
        n3 = n4 + 8 + 4;
        object2 = new byte[n3];
        n3 = IO.put4((byte[])object2, IO.put4((byte[])object2, IO.put4((byte[])object2, 0, n3 - 4), 276), n);
        n = this.bMeasurementValid ? 1 : 0;
        n = n3 = IO.put4((byte[])object2, IO.put4((byte[])object2, IO.put4((byte[])object2, n3, n), (int)this.lSFN), this.eModeSpecInfoType);
        if (object != null) {
            System.arraycopy((byte[])object, (int)0, (byte[])object2, (int)n3, (int)((byte[])object).length);
            n = n3 + ((byte[])object).length;
        }
        n3 = this.bNeighbourListPresent ? 1 : 0;
        n = IO.put4((byte[])object2, n, n3);
        if (this.bNeighbourListPresent) {
            n = IO.put1((byte[])object2, n, this.ucNoOfNeighbourList);
            if (object3 != null) {
                object = object3.iterator();
                while (object.hasNext()) {
                    object3 = (byte[])object.next();
                    if (object3 == null) continue;
                    System.arraycopy((byte[])object3, (int)0, (byte[])object2, (int)n, (int)((byte[])object3).length);
                    n += ((byte[])object3).length;
                }
            }
        }
        Log.i((String)"SUPL20_OTDOA", (String)("OTDOA msg has send :" + ((Object)object2).length + " " + 276));
        return object2;
    }
}

