/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.eotd.EOTDQuality;

public class OTDMeas {
    public EOTDQuality eotdQuality;
    public short ucNborTimeSlot;
    public int usOTDValue;

    public byte[] getOTDMeas() {
        int n;
        int n2 = 3;
        byte[] byArray = null;
        if (this.eotdQuality != null) {
            byArray = this.eotdQuality.getEOTDQulaity();
            n2 = byArray.length + 3;
        }
        byte[] byArray2 = new byte[n2];
        n2 = n = IO.put1(byArray2, 0, this.ucNborTimeSlot);
        if (byArray != null) {
            System.arraycopy((byte[])byArray, (int)0, (byte[])byArray2, (int)n, (int)byArray.length);
            n2 = n + byArray.length;
        }
        IO.put2(byArray2, n2, this.usOTDValue);
        return byArray2;
    }
}

