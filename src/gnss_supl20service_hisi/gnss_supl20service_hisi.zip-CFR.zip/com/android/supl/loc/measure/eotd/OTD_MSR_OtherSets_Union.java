/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.eotd;

import com.android.supl.loc.measure.eotd.OTDMeans_WithID;
import com.android.supl.loc.measure.eotd.OTDMeas;

public class OTD_MSR_OtherSets_Union {
    OTDMeas identityNotPresent;
    OTDMeans_WithID identityPresent;

    public byte[] getOTDOtherSets() {
        byte[] byArray = null;
        if (this.identityNotPresent != null) {
            return this.identityNotPresent.getOTDMeas();
        }
        if (this.identityPresent == null) return byArray;
        return this.identityPresent.getOTDMeans_WithID();
    }
}

