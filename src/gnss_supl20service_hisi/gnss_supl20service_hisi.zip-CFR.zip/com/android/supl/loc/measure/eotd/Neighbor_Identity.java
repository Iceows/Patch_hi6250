/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.eotd.Neighbor_ID_Union;

public class Neighbor_Identity {
    public int enIdType;
    public Neighbor_ID_Union stNeigh;

    public byte[] getNeighbor_Identity() {
        byte[] byArray = null;
        if (this.stNeigh == null) return byArray;
        byte[] byArray2 = this.stNeigh.getNeighborIDUnion(this.enIdType);
        byte[] byArray3 = new byte[byArray2.length + 4];
        int n = IO.put4(byArray3, 0, this.enIdType);
        byArray = byArray3;
        if (byArray2 == null) return byArray;
        System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray3, (int)n, (int)byArray2.length);
        n = byArray2.length;
        return byArray3;
    }
}

