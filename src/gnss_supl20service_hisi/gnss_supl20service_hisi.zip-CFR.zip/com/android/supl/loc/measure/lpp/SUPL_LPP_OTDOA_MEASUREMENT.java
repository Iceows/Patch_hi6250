/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.lpp;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.lpp.SUPL_LPP_OTDOA_ERRINFO;
import com.android.supl.loc.measure.lpp.SUPL_LPP_OTDOA_SIGNAL_MMT;

public class SUPL_LPP_OTDOA_MEASUREMENT {
    public boolean bErrorInfoPresent = true;
    public boolean bValidMmtPresent = true;
    public SUPL_LPP_OTDOA_ERRINFO stLPPOTDOAError = null;
    public SUPL_LPP_OTDOA_SIGNAL_MMT stLPPOTDOASignalMmt = new SUPL_LPP_OTDOA_SIGNAL_MMT();

    public SUPL_LPP_OTDOA_MEASUREMENT() {
        this.stLPPOTDOAError = new SUPL_LPP_OTDOA_ERRINFO();
    }

    public byte[] getOTDOA_MEASUREMENT(int n) {
        byte[] byArray;
        byte[] byArray2;
        int n2 = 1;
        int n3 = 12 + 4;
        byte[] byArray3 = null;
        Object var9_5 = null;
        byte[] byArray4 = byArray2 = null;
        int n4 = n3;
        if (this.bValidMmtPresent) {
            n4 = n3 + 4;
            byArray = var9_5;
            n3 = n4;
            if (this.bValidMmtPresent) {
                byArray = var9_5;
                n3 = n4;
                if (this.stLPPOTDOASignalMmt != null) {
                    byArray4 = this.stLPPOTDOASignalMmt.getSIGNAL_MMT();
                    byArray = byArray4;
                    n3 = n4;
                    if (byArray4 != null) {
                        n3 = byArray4.length + 20;
                        byArray = byArray4;
                    }
                }
            }
            byArray4 = byArray2;
            byArray3 = byArray;
            n4 = n3;
            if (this.bErrorInfoPresent) {
                byArray4 = byArray2;
                byArray3 = byArray;
                n4 = n3;
                if (this.stLPPOTDOAError != null) {
                    byArray4 = byArray2 = this.stLPPOTDOAError.getOTDOA_ERRINFO();
                    byArray3 = byArray;
                    n4 = n3;
                    if (byArray2 != null) {
                        n4 = n3 + byArray2.length;
                        byArray3 = byArray;
                        byArray4 = byArray2;
                    }
                }
            }
        }
        byArray = new byte[n4];
        n3 = IO.put4(byArray, IO.put4(byArray, IO.put4(byArray, 0, n4 - 4), 276), n);
        n = this.bValidMmtPresent ? 1 : 0;
        n3 = IO.put4(byArray, n3, n);
        if (!this.bValidMmtPresent) return byArray;
        n = n3;
        if (byArray3 != null) {
            System.arraycopy((byte[])byArray3, (int)0, (byte[])byArray, (int)n3, (int)byArray3.length);
            n = n3 + byArray3.length;
        }
        n3 = this.bErrorInfoPresent ? n2 : 0;
        n = IO.put4(byArray, n, n3);
        if (!this.bErrorInfoPresent) return byArray;
        if (byArray4 == null) return byArray;
        System.arraycopy((byte[])byArray4, (int)0, (byte[])byArray, (int)n, (int)byArray4.length);
        n = byArray4.length;
        return byArray;
    }
}

