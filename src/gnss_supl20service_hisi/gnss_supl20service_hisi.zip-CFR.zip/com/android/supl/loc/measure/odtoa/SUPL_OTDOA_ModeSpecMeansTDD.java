/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.odtoa;

import com.android.bytewriter.IO;

public class SUPL_OTDOA_ModeSpecMeansTDD {
    public boolean bCellIDParamValid;
    public long lCellParamsID;

    public byte[] getModeSpecMeansTDD() {
        byte[] byArray = new byte[8];
        int n = this.bCellIDParamValid ? 1 : 0;
        IO.put4(byArray, IO.put4(byArray, 0, n), (int)this.lCellParamsID);
        return byArray;
    }
}

