/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.lpp;

import com.android.bytewriter.IO;
import com.android.supl.loc.measure.lpp.SUPL_LPP_EGCI;
import com.android.supl.loc.measure.lpp.SUPL_LPP_OTDOA_MMT_QUALITY;

public class SUPL_LPP_NEIGHBOUR_ELEM {
    public boolean bArfcnPresent = true;
    public boolean bEGCIPresent = true;
    public int lArfcnEUTRAValue = 512;
    public SUPL_LPP_EGCI stLPPOTDOAEGCI = null;
    SUPL_LPP_OTDOA_MMT_QUALITY stOTDOAMeasureQuality = null;
    public int ulLPPrstd = 478;
    public short usPhysCellIDNeighbour = (short)412;

    public SUPL_LPP_NEIGHBOUR_ELEM() {
        this.stLPPOTDOAEGCI = new SUPL_LPP_EGCI();
        this.stOTDOAMeasureQuality = new SUPL_LPP_OTDOA_MMT_QUALITY();
    }

    public byte[] getLPP_NEIGHBOUR_ELEM() {
        byte[] byArray;
        byte[] byArray2;
        int n = 1;
        int n2 = 14;
        if (this.bArfcnPresent) {
            n2 = 18;
        }
        byte[] byArray3 = byArray2 = null;
        int n3 = n2;
        if (this.bEGCIPresent) {
            byArray3 = byArray2;
            n3 = n2;
            if (this.stLPPOTDOAEGCI != null) {
                byArray3 = byArray2 = this.stLPPOTDOAEGCI.getLPP_EGCI();
                n3 = n2;
                if (byArray2 != null) {
                    n3 = n2 + byArray2.length;
                    byArray3 = byArray2;
                }
            }
        }
        byArray2 = null;
        n2 = n3;
        if (this.stOTDOAMeasureQuality != null) {
            byArray = this.stOTDOAMeasureQuality.getOTDOA_MMT_QUALITY();
            byArray2 = byArray;
            n2 = n3;
            if (byArray != null) {
                n2 = n3 + byArray.length;
                byArray2 = byArray;
            }
        }
        byArray = new byte[n2];
        n2 = IO.put2(byArray, 0, this.usPhysCellIDNeighbour);
        n3 = this.bEGCIPresent ? 1 : 0;
        n3 = n2 = IO.put4(byArray, n2, n3);
        if (this.bEGCIPresent) {
            n3 = n2;
            if (byArray3 != null) {
                System.arraycopy((byte[])byArray3, (int)0, (byte[])byArray, (int)n2, (int)byArray3.length);
                n3 = n2 + byArray3.length;
            }
        }
        n2 = this.bArfcnPresent ? n : 0;
        n3 = n2 = IO.put4(byArray, n3, n2);
        if (this.bArfcnPresent) {
            n3 = IO.put4(byArray, n2, this.lArfcnEUTRAValue);
        }
        n3 = IO.put4(byArray, n3, this.ulLPPrstd);
        if (byArray2 == null) return byArray;
        System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray, (int)n3, (int)byArray2.length);
        n3 = byArray2.length;
        return byArray;
    }
}

