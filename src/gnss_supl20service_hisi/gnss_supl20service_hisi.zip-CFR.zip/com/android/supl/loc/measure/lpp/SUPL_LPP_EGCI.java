/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.lpp;

import com.android.bytewriter.IO;

public class SUPL_LPP_EGCI {
    public byte byValidMCCValues = (byte)3;
    public byte byValidMNCValues;
    public byte[] nMCC = new byte[this.byValidMCCValues];
    public byte[] nMNC = null;
    public int ulCellID;

    public SUPL_LPP_EGCI() {
        this.byValidMNCValues = (byte)2;
        this.nMNC = new byte[this.byValidMNCValues];
    }

    public byte[] getLPP_EGCI() {
        int n;
        byte[] byArray = new byte[this.byValidMCCValues * 1 + 6 + this.byValidMNCValues * 1];
        int n2 = n = IO.put1(byArray, 0, this.byValidMCCValues);
        if (this.byValidMCCValues > 0) {
            n2 = n;
            if (this.nMCC != null) {
                System.arraycopy((byte[])this.nMCC, (int)0, (byte[])byArray, (int)n, (int)this.byValidMCCValues);
                n2 = n + this.byValidMCCValues;
            }
        }
        n2 = n = IO.put1(byArray, n2, this.byValidMNCValues);
        if (this.byValidMNCValues > 0) {
            n2 = n;
            if (this.nMNC != null) {
                System.arraycopy((byte[])this.nMNC, (int)0, (byte[])byArray, (int)n, (int)this.byValidMNCValues);
                n2 = n + this.byValidMNCValues;
            }
        }
        IO.put4(byArray, n2, this.ulCellID);
        return byArray;
    }
}

