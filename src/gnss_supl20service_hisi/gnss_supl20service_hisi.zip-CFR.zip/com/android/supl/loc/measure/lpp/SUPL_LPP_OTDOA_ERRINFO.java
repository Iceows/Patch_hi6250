/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.measure.lpp;

import com.android.bytewriter.IO;

public class SUPL_LPP_OTDOA_ERRINFO {
    public static final int SUPL_OTDOA_DEV_ERR_ASST_DATA_MISSING = 1;
    public static final int SUPL_OTDOA_DEV_ERR_ATTEMPT_NEIGHBOUR_CELL_MMT = 4;
    public static final int SUPL_OTDOA_DEV_ERR_NEIGHBOUR_CELL_MMT = 3;
    public static final int SUPL_OTDOA_DEV_ERR_REF_CELL_MMT = 2;
    public static final int SUPL_OTDOA_SERVER_ERR_ASST_DATA_NOTSUPP = 1;
    public static final int SUPL_OTDOA_SERVER_ERR_ASST_DATA_NOTSUPP_CURRENT = 2;
    public static final int SUPL_OTODA_DEV_ERR_UNDEFINED = 0;
    public static final int SUPL_OTODA_SERVER_ERR_UNDEFINED = 0;
    public boolean bDevErr = true;
    public boolean bServerErr = true;
    public int eLPPOTDOADevErr = 3;
    public int eLPPOTDOAServerErr = 1;

    public byte[] getOTDOA_ERRINFO() {
        int n = 1;
        int n2 = 8;
        if (this.bServerErr) {
            n2 = 12;
        }
        int n3 = n2;
        if (this.bDevErr) {
            n3 = n2 + 4;
        }
        byte[] byArray = new byte[n3];
        n2 = this.bServerErr ? 1 : 0;
        n2 = n3 = IO.put4(byArray, 0, n2);
        if (this.bServerErr) {
            n2 = IO.put4(byArray, n3, this.eLPPOTDOAServerErr);
        }
        n3 = this.bDevErr ? n : 0;
        n2 = IO.put4(byArray, n2, n3);
        if (!this.bDevErr) return byArray;
        IO.put4(byArray, n2, this.eLPPOTDOADevErr);
        return byArray;
    }
}

