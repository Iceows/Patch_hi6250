/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.telephony.CellIdentityLte
 *  android.telephony.CellInfo
 *  android.telephony.CellInfoLte
 *  android.telephony.CellLocation
 *  android.telephony.NeighboringCellInfo
 *  android.telephony.TelephonyManager
 *  android.telephony.gsm.GsmCellLocation
 *  android.util.Log
 */
package com.android.supl.loc;

import android.content.Context;
import android.telephony.CellIdentityLte;
import android.telephony.CellInfo;
import android.telephony.CellInfoLte;
import android.telephony.CellLocation;
import android.telephony.NeighboringCellInfo;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.util.Log;
import com.android.bytewriter.IO;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class LTECellInfo {
    private static final String LOG = "SUPL20_LTECellInfo";
    public static boolean bIsMeasResultListEUTRA = false;
    public static boolean bIsRSRPInfoPresent = false;
    public static boolean bIsRSRQInfoPresent = false;
    public static boolean bIsTAInfoPresent = false;
    public static List<measResultEUTRA> listMRLEUTRA;
    public static short ucRSRPResult = 0;
    public static short ucRSRQResult = 0;
    public static final short usMaxCellReport = 8;
    public static short usTA;
    public Cell_Globalid_Eutra stCELLGlobalID = null;
    public short usPhysCellID;
    public char usTrackAreaCode;

    static {
        bIsRSRPInfoPresent = false;
        bIsRSRQInfoPresent = false;
        bIsTAInfoPresent = false;
        bIsMeasResultListEUTRA = false;
        listMRLEUTRA = new ArrayList<measResultEUTRA>();
    }

    public LTECellInfo(Cell_Globalid_Eutra cell_Globalid_Eutra, char c, short s) {
        if (cell_Globalid_Eutra == null) {
            throw new NullPointerException("Cell_Globalid_Eutra should not null");
        }
        if (c == '\u0000') {
            Log.w((String)LOG, (String)"TrackAreaCode should not be zero");
        }
        this.stCELLGlobalID = cell_Globalid_Eutra;
        this.usTrackAreaCode = c;
        this.usPhysCellID = s;
    }

    public static LTECellInfo getAPILTECellInfo(Context object) {
        Object object2 = (TelephonyManager)object.getSystemService("phone");
        Log.i((String)LOG, (String)("TelephonyManager class:" + object2.getClass().getCanonicalName()));
        object = object2.getAllCellInfo();
        if (object == null) {
            Log.e((String)LOG, (String)"getAllCellInfo function returns list is null");
            return null;
        }
        List list = object2.getNeighboringCellInfo();
        if (list == null) return LTECellInfo.getCellInfo_To_LTECellInfo((List<CellInfo>)object, list);
        Log.i((String)LOG, (String)("neighborCellInfoList size: " + list.size()));
        object2 = list.iterator();
        while (object2.hasNext()) {
            NeighboringCellInfo neighboringCellInfo = (NeighboringCellInfo)object2.next();
            if (neighboringCellInfo == null) continue;
            neighboringCellInfo.getLac();
            neighboringCellInfo.getCid();
            int n = neighboringCellInfo.getPsc();
            int n2 = neighboringCellInfo.getRssi();
            int n3 = neighboringCellInfo.getNetworkType();
            Log.i((String)LOG, (String)("neighborCellInfo psc:" + n + "rssi:" + n2 + "nwtype:" + n3));
        }
        return LTECellInfo.getCellInfo_To_LTECellInfo((List<CellInfo>)object, list);
    }

    public static LTECellInfo getCellInfo_To_LTECellInfo(List<CellInfo> object, List<NeighboringCellInfo> object2) {
        Log.i((String)LOG, (String)"start to get lte cell info");
        bIsMeasResultListEUTRA = false;
        listMRLEUTRA.clear();
        if (object == null) {
            Log.e((String)LOG, (String)"cellInfoList is null");
            return null;
        }
        object2 = null;
        Log.i((String)LOG, (String)("cellinfo list size: " + object.size()));
        Iterator iterator = object.iterator();
        object = object2;
        while (true) {
            int n;
            if (!iterator.hasNext()) {
                Log.i((String)LOG, (String)("listMRLEUTRA size: " + listMRLEUTRA.size()));
                return object;
            }
            object2 = (CellInfo)iterator.next();
            if (!(object2 instanceof CellInfoLte)) continue;
            if ((object2 = (CellInfoLte)object2).isRegistered()) {
                object = object2.getCellIdentity();
                if (object == null) {
                    Log.e((String)LOG, (String)"getCellIdentity function returns null");
                    return null;
                }
                int n2 = object.getMnc();
                n = object.getMcc();
                int n3 = object.getTac();
                int n4 = object.getCi();
                int n5 = object.getPci();
                char c = (char)(n / 100);
                char c2 = (char)(n % 100 / 10);
                char c3 = (char)(n % 10);
                if (n2 > 99) {
                    object = new char[3];
                    object[0] = (CellIdentityLte)((char)(n2 / 100));
                    object[1] = (CellIdentityLte)((char)(n2 % 100 / 10));
                    object[2] = (CellIdentityLte)((char)(n2 % 10));
                } else {
                    object = new char[2];
                    object[0] = (CellIdentityLte)((char)(n2 / 10));
                    object[1] = (CellIdentityLte)((char)(n2 % 10));
                }
                object = new MNCList((char[])object);
                object = new LTECellInfo(new Cell_Globalid_Eutra(new PlmnIdentity(true, new MCC_LIST(new char[]{c, c2, c3}), (MNCList)object), n4), (char)n3, (short)n5);
                if ((object2 = object2.getCellSignalStrength()) != null) {
                    ucRSRPResult = (short)object2.getDbm();
                    if ((ucRSRPResult = (short)(ucRSRPResult + 141)) < 0) {
                        ucRSRPResult = 0;
                    } else if (ucRSRPResult > 97) {
                        ucRSRPResult = (short)97;
                    }
                    bIsRSRPInfoPresent = true;
                    ucRSRQResult = (short)(object2.getRsrq() * 2 + 40);
                    if (ucRSRQResult < 0) {
                        ucRSRQResult = 0;
                    } else if (ucRSRQResult > 34) {
                        ucRSRQResult = (short)34;
                    }
                    bIsRSRQInfoPresent = true;
                    Log.i((String)LOG, (String)String.format("ucRSRPResult:%d, ucRSRQResult:%d", ucRSRPResult, (int)ucRSRQResult));
                    continue;
                }
                bIsRSRPInfoPresent = false;
                bIsRSRQInfoPresent = false;
                continue;
            }
            CellIdentityLte cellIdentityLte = object2.getCellIdentity();
            if (cellIdentityLte == null) {
                Log.w((String)LOG, (String)"get neighbor cell returns null");
                continue;
            }
            cellIdentityLte.getMnc();
            cellIdentityLte.getMcc();
            cellIdentityLte.getTac();
            cellIdentityLte.getCi();
            n = cellIdentityLte.getPci();
            int n6 = 0;
            int n7 = 0;
            object2 = object2.getCellSignalStrength();
            if (object2 != null) {
                short s;
                n7 = (short)object2.getDbm() + 141;
                if (n7 < 0) {
                    n6 = 0;
                } else {
                    n6 = n7;
                    if (n7 > 97) {
                        n6 = 97;
                    }
                }
                if ((s = (short)(object2.getRsrq() * 2 + 40)) < 0) {
                    n7 = 0;
                } else {
                    n7 = s;
                    if (s > 34) {
                        n7 = 34;
                    }
                }
                Log.i((String)LOG, (String)String.format("usMeasResultRSRP:%d, usMeasResultRSRQ:%d", n6, n7));
            }
            if (listMRLEUTRA.size() < 8) {
                object2 = new measResultEUTRA((short)n, (short)n6, (short)n7);
                listMRLEUTRA.add((measResultEUTRA)object2);
                bIsMeasResultListEUTRA = true;
                continue;
            }
            Log.w((String)LOG, (String)"listMRLEUTRA size > 8, discard!");
        }
    }

    public static LTECellInfo getCellLocation_To_LTECellInfo(CellLocation cellLocation, int n, int n2) {
        short s;
        if (!(cellLocation instanceof GsmCellLocation)) return null;
        char c = (char)(n / 100);
        char c2 = (char)(n % 100 / 10);
        char c3 = (char)(n % 10);
        Object object = n2 > 99 ? new char[]{(char)(n2 / 100), (char)(n2 % 100 / 10), (char)(n2 % 10)} : new char[]{(char)(n2 / 10), (char)(n2 % 10)};
        object = new MNCList((char[])object);
        object = new Cell_Globalid_Eutra(new PlmnIdentity(true, new MCC_LIST(new char[]{c, c2, c3}), (MNCList)object), cellLocation.getCid());
        short s2 = s = 0;
        if (cellLocation.getPsc() < 0) return new LTECellInfo((Cell_Globalid_Eutra)object, (char)cellLocation.getLac(), s2);
        s2 = s;
        if (503 < cellLocation.getPsc()) return new LTECellInfo((Cell_Globalid_Eutra)object, (char)cellLocation.getLac(), s2);
        s2 = (short)cellLocation.getPsc();
        return new LTECellInfo((Cell_Globalid_Eutra)object, (char)cellLocation.getLac(), s2);
    }

    private static Object getFunctionReturnValue(Object object, String object2, String string, Class<?>[] classArray, Object[] objectArray) {
        Object var5_12 = null;
        try {
            Class<?> clazz = Class.forName((String)object2);
            object2 = clazz.getDeclaredMethod(string, classArray);
            Log.i((String)LOG, (String)((Method)object2).getName());
            if (object != null) return ((Method)object2).invoke(object, objectArray);
            object = clazz.newInstance();
            return ((Method)object2).invoke(object, objectArray);
        }
        catch (ClassNotFoundException classNotFoundException) {
            Log.e((String)LOG, (String)classNotFoundException.getMessage(), (Throwable)classNotFoundException);
            return var5_12;
        }
        catch (SecurityException securityException) {
            Log.e((String)LOG, (String)securityException.getMessage(), (Throwable)securityException);
            return var5_12;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            Log.e((String)LOG, (String)noSuchMethodException.getMessage(), (Throwable)noSuchMethodException);
            return var5_12;
        }
        catch (IllegalAccessException illegalAccessException) {
            Log.e((String)LOG, (String)illegalAccessException.getMessage(), (Throwable)illegalAccessException);
            return var5_12;
        }
        catch (InvocationTargetException invocationTargetException) {
            Log.e((String)LOG, (String)invocationTargetException.getMessage(), (Throwable)invocationTargetException);
            return var5_12;
        }
        catch (IllegalArgumentException illegalArgumentException) {
            Log.e((String)LOG, (String)illegalArgumentException.getMessage(), (Throwable)illegalArgumentException);
            return var5_12;
        }
        catch (InstantiationException instantiationException) {
            Log.e((String)LOG, (String)instantiationException.getMessage(), (Throwable)instantiationException);
            return var5_12;
        }
    }

    public static LTECellInfo getNONAPILTECellInfo(Context object) {
        try {
            Object object2;
            Object object3;
            Object object4;
            block6: {
                if (TelephonyManager.class.getMethod("getAllCellInfo", null) == null) return null;
                object4 = new Class[]{};
                object = (TelephonyManager)object.getSystemService("phone");
                if ((object = LTECellInfo.getFunctionReturnValue(object, object.getClass().getCanonicalName(), "getAllCellInfo", object4, null)) == null) {
                    Log.e((String)LOG, (String)"getAllCellInfo function return null");
                    return null;
                }
                if (!object.getClass().equals(ArrayList.class)) return null;
                object = ((ArrayList)object).iterator();
                while (object.hasNext()) {
                    object3 = object.next();
                    if (object3 == null) continue;
                    Log.i((String)LOG, (String)object3.getClass().getCanonicalName());
                    object2 = LTECellInfo.getFunctionReturnValue(object3, object3.getClass().getCanonicalName(), "getCellIdentity", object4, null);
                    if (object2 == null || !object2.getClass().getCanonicalName().equals("android.telephony.LteCellIdentity")) {
                        continue;
                    }
                    break block6;
                }
                return null;
            }
            Object object5 = LTECellInfo.getFunctionReturnValue(object2, object2.getClass().getCanonicalName(), "getMcc", object4, null);
            Object object6 = LTECellInfo.getFunctionReturnValue(object2, object2.getClass().getCanonicalName(), "getMnc", object4, null);
            object = LTECellInfo.getFunctionReturnValue(object2, object2.getClass().getCanonicalName(), "getCi", object4, null);
            object3 = LTECellInfo.getFunctionReturnValue(object2, object2.getClass().getCanonicalName(), "getPci", object4, null);
            object4 = LTECellInfo.getFunctionReturnValue(object2, object2.getClass().getCanonicalName(), "getTac", object4, null);
            Log.i((String)LOG, (String)object5.toString());
            Log.i((String)LOG, (String)object6.toString());
            Log.i((String)LOG, (String)object.toString());
            Log.i((String)LOG, (String)object3.toString());
            Log.i((String)LOG, (String)object4.toString());
            object2 = new MNCList(new char[]{(char)Integer.parseInt(object6.toString())});
            object6 = new MCC_LIST(new char[]{(char)Integer.parseInt(object5.toString())});
            object5 = new PlmnIdentity(true, (MCC_LIST)object6, (MNCList)object2);
            object2 = new Cell_Globalid_Eutra((PlmnIdentity)object5, (char)Integer.parseInt(object.toString()));
            short s = Short.parseShort(object3.toString());
            return new LTECellInfo((Cell_Globalid_Eutra)object2, (char)Integer.parseInt(object4.toString()), s);
        }
        catch (SecurityException securityException) {
            Log.e((String)LOG, (String)securityException.getMessage(), (Throwable)securityException);
            return null;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            Log.e((String)LOG, (String)noSuchMethodException.getMessage(), (Throwable)noSuchMethodException);
            return null;
        }
    }

    public byte[] getLTECellInfo() {
        int n;
        byte[] byArray = this.stCELLGlobalID.getCellGlobalidInfo();
        int n2 = n = byArray.length + 0 + 2 + 2 + 16;
        if (bIsRSRPInfoPresent) {
            n2 = n + 1;
        }
        n = n2;
        if (bIsRSRQInfoPresent) {
            n = n2 + 1;
        }
        n2 = n;
        if (bIsTAInfoPresent) {
            n2 = n + 2;
        }
        Object object = null;
        byte[] byArray2 = object;
        n = n2;
        if (bIsMeasResultListEUTRA) {
            byArray2 = object;
            n = n2;
            if (listMRLEUTRA != null) {
                n = 0;
                byArray2 = new byte[listMRLEUTRA.size() * 6];
                object = listMRLEUTRA.iterator();
                while (object.hasNext()) {
                    System.arraycopy((byte[])((measResultEUTRA)object.next()).getMeasResultEUTRA(), (int)0, (byte[])byArray2, (int)n, (int)6);
                    n += 6;
                }
                n = n2 + 1 + byArray2.length;
            }
        }
        object = new byte[n];
        System.arraycopy((byte[])byArray, (int)0, (byte[])object, (int)0, (int)byArray.length);
        n2 = IO.put2((byte[])object, IO.put2((byte[])object, byArray.length + 0, this.usPhysCellID), this.usTrackAreaCode);
        n2 = bIsRSRPInfoPresent ? IO.put1((byte[])object, IO.put4((byte[])object, n2, 1), ucRSRPResult) : IO.put4((byte[])object, n2, 0);
        n2 = bIsRSRQInfoPresent ? IO.put1((byte[])object, IO.put4((byte[])object, n2, 1), ucRSRQResult) : IO.put4((byte[])object, n2, 0);
        n2 = bIsTAInfoPresent ? IO.put2((byte[])object, IO.put4((byte[])object, n2, 1), usTA) : IO.put4((byte[])object, n2, 0);
        if (bIsMeasResultListEUTRA && listMRLEUTRA != null) {
            n2 = IO.put1((byte[])object, IO.put4((byte[])object, n2, 1), listMRLEUTRA.size());
            System.arraycopy((byte[])byArray2, (int)0, (byte[])object, (int)n2, (int)byArray2.length);
            n2 += byArray2.length;
        } else {
            n2 = IO.put4((byte[])object, n2, 0);
        }
        if (n2 == n) return object;
        System.out.println("LTECellInfo length error");
        return object;
    }

    public static class Cell_Globalid_Eutra {
        private int iCellIdentity;
        private PlmnIdentity stPLMNIdentity;

        public Cell_Globalid_Eutra(PlmnIdentity plmnIdentity, int n) {
            if (plmnIdentity == null) {
                throw new NullPointerException("PlmnIdentity should not null");
            }
            if (n == 0) {
                Log.w((String)LTECellInfo.LOG, (String)"CellIdentity should not be zero");
            }
            this.stPLMNIdentity = plmnIdentity;
            this.iCellIdentity = n;
        }

        public byte[] getCellGlobalidInfo() {
            byte[] byArray = this.stPLMNIdentity.getPLMNIdentityInfo();
            byte[] byArray2 = new byte[byArray.length + 4];
            System.arraycopy((byte[])byArray, (int)0, (byte[])byArray2, (int)0, (int)byArray.length);
            IO.put4(byArray2, byArray.length + 0, this.iCellIdentity);
            return byArray2;
        }
    }

    public static class MCC_LIST {
        private char[] usRefMCC;

        public MCC_LIST(char[] cArray) {
            if (cArray == null) {
                throw new NullPointerException("MCC_LIST should not null");
            }
            if (cArray.length < 3) {
                Log.w((String)LTECellInfo.LOG, (String)"MCC_LIST should not be less than 3");
            }
            this.usRefMCC = cArray;
        }

        public char[] getMccListInfo() {
            return this.usRefMCC;
        }
    }

    public static class MNCList {
        private char[] ucRefMNC;
        private short ucRefMNCcnt;

        public MNCList(char[] cArray) {
            this.ucRefMNC = cArray;
            if (this.ucRefMNC != null) {
                this.ucRefMNCcnt = (short)this.ucRefMNC.length;
                return;
            }
            this.ucRefMNCcnt = 0;
        }

        public byte[] getMncListInfo() {
            byte[] byArray;
            if (this.ucRefMNCcnt <= 0) {
                byArray = new byte[1];
                IO.put1(byArray, 0, 0);
                return byArray;
            }
            byte[] byArray2 = new byte[this.ucRefMNCcnt * 2 + 1];
            int n = IO.put1(byArray2, 0, this.ucRefMNCcnt);
            int n2 = 0;
            while (true) {
                byArray = byArray2;
                if (n2 >= this.ucRefMNCcnt) return byArray;
                n = IO.put2(byArray2, n, this.ucRefMNC[n2]);
                ++n2;
            }
        }
    }

    public static class PlmnIdentity {
        private boolean bIsMCCPresent;
        private MCC_LIST stMCC;
        private MNCList stMNC;

        public PlmnIdentity(boolean bl, MCC_LIST mCC_LIST, MNCList mNCList) {
            if (mNCList == null) {
                throw new NullPointerException("MNCList should not null");
            }
            if (bl && mCC_LIST == null) {
                throw new NullPointerException("MCC_LIST should not null");
            }
            this.bIsMCCPresent = bl;
            this.stMCC = mCC_LIST;
            this.stMNC = mNCList;
        }

        public byte[] getPLMNIdentityInfo() {
            int n;
            int n2 = 4;
            char[] cArray = null;
            if (this.bIsMCCPresent) {
                cArray = this.stMCC.getMccListInfo();
                n2 = cArray.length * 2 + 4;
            }
            byte[] byArray = this.stMNC.getMncListInfo();
            int n3 = n2 + byArray.length;
            byte[] byArray2 = new byte[n3];
            if (this.bIsMCCPresent) {
                n2 = IO.put4(byArray2, 0, 1);
                int n4 = 0;
                while (true) {
                    n = n2;
                    if (n4 < cArray.length) {
                        n2 = IO.put2(byArray2, n2, cArray[n4]);
                        ++n4;
                        continue;
                    }
                    break;
                }
            } else {
                n = IO.put4(byArray2, 0, 0);
            }
            System.arraycopy((byte[])byArray, (int)0, (byte[])byArray2, (int)n, (int)byArray.length);
            if (n3 == n + byArray.length) return byArray2;
            Log.e((String)LTECellInfo.LOG, (String)"PLMNIdentity length error");
            return byArray2;
        }
    }

    public static class measResultEUTRA {
        public short sPhysCellID;
        public short sRSRPResult;
        public short sRSRQResult;

        public measResultEUTRA(short s, short s2, short s3) {
            this.sPhysCellID = s;
            this.sRSRPResult = s2;
            this.sRSRQResult = s3;
        }

        public byte[] getMeasResultEUTRA() {
            byte[] byArray = new byte[6];
            IO.put2(byArray, IO.put2(byArray, IO.put2(byArray, 0, this.sPhysCellID), this.sRSRPResult), this.sRSRQResult);
            return byArray;
        }
    }
}

