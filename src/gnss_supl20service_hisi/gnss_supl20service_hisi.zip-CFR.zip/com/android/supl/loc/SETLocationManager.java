/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.location.LocationManager
 *  android.net.wifi.ScanResult
 *  android.net.wifi.WifiManager
 *  android.os.Build$VERSION
 *  android.os.SystemProperties
 *  android.telephony.CellInfo
 *  android.telephony.CellLocation
 *  android.telephony.PhoneNumberUtils
 *  android.telephony.PhoneStateListener
 *  android.telephony.ServiceState
 *  android.telephony.TelephonyManager
 *  android.telephony.cdma.CdmaCellLocation
 *  android.telephony.gsm.GsmCellLocation
 *  android.util.Log
 */
package com.android.supl.loc;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.LocationManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.SystemProperties;
import android.telephony.CellInfo;
import android.telephony.CellLocation;
import android.telephony.PhoneNumberUtils;
import android.telephony.PhoneStateListener;
import android.telephony.ServiceState;
import android.telephony.TelephonyManager;
import android.telephony.cdma.CdmaCellLocation;
import android.telephony.gsm.GsmCellLocation;
import android.util.Log;
import com.android.bytewriter.IO;
import com.android.supl.commprocessor.NDKCommProcessor;
import com.android.supl.config.ConfigManager;
import com.android.supl.loc.CdmaCellInfo;
import com.android.supl.loc.EmergencyUtils;
import com.android.supl.loc.GsmCellInfo;
import com.android.supl.loc.LTECellInfo;
import com.android.supl.loc.NetInfo;
import com.android.supl.loc.SetID;
import com.android.supl.loc.StaleLocationInfo;
import com.android.supl.loc.UMBCellInfo;
import com.android.supl.loc.WcdmaCellInfo;
import com.android.supl.loc.wifi.WIFIParameter;
import com.android.supl.nc.SendToServer;
import java.util.List;
import java.util.Vector;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class SETLocationManager {
    public static final int JELLY_BEAN_MR1 = 17;
    public static final int LOCATION_ID_STATUS_CURRENT = 1;
    public static final int LOCATION_ID_STATUS_STALE = 0;
    public static final int LOCATION_ID_STATUS_UNKNOWN = 2;
    private static final String LOG_TAG = "SUPL20_LocMan";
    public static final int MAX_WLAN_INFO = 20;
    private static final int TD_SCDMA = 17;
    private static final int UMB_CELLINFO = 20;
    private static final int WIFI_CELLINFO = 21;
    public static final String outgoing = "android.intent.action.NEW_OUTGOING_CALL";
    private IntentFilter intentFilter = new IntentFilter("android.intent.action.NEW_OUTGOING_CALL");
    private boolean isEmergencyCall = false;
    private boolean isEmergencyCallListen = false;
    private boolean isLocationSwithEnable = false;
    private boolean isStartListen = false;
    private boolean isWifiRegister = false;
    private EmergencyCallListener mCallListener = null;
    private NDKCommProcessor mCommProcessor = null;
    private Context mContext = null;
    private MyPhoneStateListener mMyPhoneStateListener = null;
    private NetInfo mNetInfo = null;
    private StaleLocationInfo mStaleLocationInfo = null;
    private NetworkStateBroadcastReceiver mWIFIReceiver = null;
    private int m_iMcc = 0;
    private int m_iMnc = 0;
    private String m_stBearerNetworkType = null;
    private String m_stIMSI = null;
    private String m_stMSISDN = null;
    private String m_stPhoneType = null;
    private BroadcastReceiver outGoingCallReceiver = new BroadcastReceiver(){

        public void onReceive(Context object, Intent object2) {
            int n = 1;
            object2 = object2.getStringExtra("android.intent.extra.PHONE_NUMBER");
            object = SETLocationManager.this;
            boolean bl = !EmergencyUtils.isEmergencyNumber((String)object2) ? PhoneNumberUtils.isEmergencyNumber((String)object2) : true;
            SETLocationManager.-set0((SETLocationManager)object, bl);
            if (!SETLocationManager.this.isEmergencyCall) return;
            Log.i((String)SETLocationManager.LOG_TAG, (String)((String)object2 + " on Emergency call is going.."));
            object2 = new SendToServer();
            object2.m_bPacket = new byte[12];
            int n2 = IO.put4(object2.m_bPacket, 0, 8);
            n2 = IO.put4(object2.m_bPacket, n2, 278);
            object = object2.m_bPacket;
            if (!SETLocationManager.this.isEmergencyCall) {
                n = 0;
            }
            IO.put4((byte[])object, n2, n);
            SETLocationManager.this.mCommProcessor.sendServer((SendToServer)object2);
        }
    };
    private TelephonyManager tm = null;

    static /* synthetic */ boolean -set0(SETLocationManager sETLocationManager, boolean bl) {
        sETLocationManager.isEmergencyCall = bl;
        return bl;
    }

    static /* synthetic */ boolean -set1(SETLocationManager sETLocationManager, boolean bl) {
        sETLocationManager.isLocationSwithEnable = bl;
        return bl;
    }

    public SETLocationManager(Context context) {
        this.mContext = context;
        this.mNetInfo = new NetInfo(context);
        this.tm = (TelephonyManager)this.mContext.getSystemService("phone");
        this.mMyPhoneStateListener = new MyPhoneStateListener();
        this.isLocationSwithEnable = this.getLocationEnableState(context);
    }

    private boolean checkCdmaCellLocationVaild(CdmaCellLocation cdmaCellLocation) {
        if (cdmaCellLocation == null) {
            Log.e((String)LOG_TAG, (String)"cdmaCell is null.");
            return false;
        }
        if (cdmaCellLocation.getLac() < 0 || cdmaCellLocation.getLac() > Short.MAX_VALUE) {
            Log.e((String)LOG_TAG, (String)("cdmaCell sid is error! " + cdmaCellLocation.getLac()));
            return false;
        }
        if (cdmaCellLocation.getCid() < 0 || cdmaCellLocation.getCid() > 65535) {
            Log.e((String)LOG_TAG, (String)("cdmaCell nid is error! " + cdmaCellLocation.getCid()));
            return false;
        }
        if (cdmaCellLocation.getBaseStationId() < 0 || cdmaCellLocation.getBaseStationId() > 65535) {
            Log.e((String)LOG_TAG, (String)("cdmaCell base id is error! " + cdmaCellLocation.getBaseStationId()));
            return false;
        }
        if (cdmaCellLocation.getBaseStationLatitude() < -1296000 || cdmaCellLocation.getBaseStationLatitude() > 1296000) {
            Log.e((String)LOG_TAG, (String)("cdmaCell lat is error! " + cdmaCellLocation.getBaseStationLatitude()));
            return false;
        }
        if (cdmaCellLocation.getBaseStationLongitude() >= -2592000) {
            if (cdmaCellLocation.getBaseStationLongitude() <= 2592000) return true;
        }
        Log.e((String)LOG_TAG, (String)("cdmaCell lon is error! " + cdmaCellLocation.getBaseStationLongitude()));
        return false;
    }

    private boolean checkGsmCellLocationValid(GsmCellLocation gsmCellLocation) {
        if (gsmCellLocation == null) {
            Log.e((String)LOG_TAG, (String)"gsmCell is null.");
            return false;
        }
        if (gsmCellLocation.getCid() < 0 || gsmCellLocation.getCid() > 65535) {
            Log.e((String)LOG_TAG, (String)("gsmCell cid is error! " + gsmCellLocation.getCid()));
            return false;
        }
        if (gsmCellLocation.getLac() >= 0) {
            if (gsmCellLocation.getLac() <= 65535) return true;
        }
        Log.e((String)LOG_TAG, (String)("gsmCell lac is error! " + gsmCellLocation.getLac()));
        return false;
    }

    private boolean checkLteCellLocationValid(GsmCellLocation gsmCellLocation) {
        if (gsmCellLocation == null) {
            Log.e((String)LOG_TAG, (String)"lteCell is null.");
            return false;
        }
        if (gsmCellLocation.getCid() < 0 || gsmCellLocation.getCid() > 0xFFFFFFF) {
            Log.e((String)LOG_TAG, (String)("lteCell cid is error! " + gsmCellLocation.getCid()));
            return false;
        }
        if (gsmCellLocation.getLac() < 0 || gsmCellLocation.getLac() > 65535) {
            Log.e((String)LOG_TAG, (String)("lteCell lac is error! " + gsmCellLocation.getLac()));
            return false;
        }
        if (gsmCellLocation.getPsc() >= 0) {
            if (gsmCellLocation.getPsc() <= 503) return true;
        }
        Log.w((String)LOG_TAG, (String)("lteCell psc is error! " + gsmCellLocation.getPsc()));
        return true;
    }

    private boolean checkUmtsCellLocationValid(GsmCellLocation gsmCellLocation) {
        if (gsmCellLocation == null) {
            Log.e((String)LOG_TAG, (String)"umtsCell is null.");
            return false;
        }
        if (gsmCellLocation.getCid() < 0 || gsmCellLocation.getCid() > 0xFFFFFFF) {
            Log.e((String)LOG_TAG, (String)("umtsCell cid is error! " + gsmCellLocation.getCid()));
            return false;
        }
        if (gsmCellLocation.getLac() >= 0) {
            if (gsmCellLocation.getLac() <= 65535) return true;
        }
        Log.e((String)LOG_TAG, (String)("umtsCell lac is error! " + gsmCellLocation.getLac()));
        return false;
    }

    private void fakeGSMData() {
        GsmCellLocation gsmCellLocation = new GsmCellLocation();
        gsmCellLocation.setLacAndCid(3203, 13310261);
        this.m_iMcc = 404;
        this.m_iMnc = 64;
        Log.i((String)LOG_TAG, (String)"fakeGSMData called");
        this.fillCellInfo((CellLocation)gsmCellLocation, true, 2, null, null);
    }

    private void fakeLTEData() {
        Log.i((String)LOG_TAG, (String)"fakeLTEData called");
        this.fillCellInfo(null, true, 13, null, null);
    }

    private CdmaCellInfo fillCDMACellinfo(CellLocation cellLocation) {
        cellLocation = (CdmaCellLocation)cellLocation;
        CdmaCellInfo cdmaCellInfo = new CdmaCellInfo();
        cdmaCellInfo.m_iBASELAT = cellLocation.getBaseStationLatitude();
        cdmaCellInfo.m_iBASELONG = cellLocation.getBaseStationLongitude();
        cdmaCellInfo.m_sBASEID = (short)cellLocation.getBaseStationId();
        cdmaCellInfo.m_sSID = (short)cellLocation.getLac();
        cdmaCellInfo.m_sNID = (short)cellLocation.getCid();
        return cdmaCellInfo;
    }

    /*
     * Enabled unnecessary exception pruning
     */
    private void fillCellInfo(CellLocation object, boolean bl, int n, byte[] object2, List<CellInfo> object3) {
        synchronized (this) {
            boolean bl2;
            boolean bl3;
            int n2;
            boolean bl4;
            int n3;
            int n4;
            int n5;
            int n6;
            int n7;
            int n8;
            block46: {
                int n9;
                Object var20_12;
                boolean bl5;
                boolean bl6;
                block52: {
                    block51: {
                        boolean bl7;
                        block50: {
                            block49: {
                                block48: {
                                    block47: {
                                        block45: {
                                            if (!this.isLocationSwithEnable) {
                                                Log.i((String)LOG_TAG, (String)"Location switch is OFF");
                                                return;
                                            }
                                            this.upDatePhoneInfo();
                                            n8 = 0;
                                            bl6 = false;
                                            n7 = 0;
                                            n6 = 0;
                                            bl7 = false;
                                            bl5 = false;
                                            var20_12 = null;
                                            n9 = 0;
                                            this.m_stBearerNetworkType = this.getNetworkTypeString(n);
                                            StringBuilder stringBuilder = new StringBuilder();
                                            Log.i((String)LOG_TAG, (String)stringBuilder.append("cellInfo NetworkType:").append(this.m_stBearerNetworkType).append(",").append(n).toString());
                                            if (n != 2 && n != 1) break block45;
                                            if (object instanceof GsmCellLocation) {
                                                object2 = var20_12;
                                                n5 = n9;
                                                n4 = n7;
                                                n3 = n8;
                                                bl4 = bl7;
                                                n2 = n6;
                                                bl3 = bl6;
                                                bl2 = bl5;
                                                if (this.checkGsmCellLocationValid((GsmCellLocation)object)) {
                                                    n3 = 1;
                                                    object2 = this.fillGSMCellinfo((CellLocation)object).getGSMInfo();
                                                    n5 = ((byte[])object2).length;
                                                    bl2 = bl5;
                                                    bl3 = bl6;
                                                    n2 = n6;
                                                    bl4 = bl7;
                                                    n4 = n7;
                                                }
                                                break block46;
                                            } else {
                                                Log.d((String)LOG_TAG, (String)"Network type is UMTS but CellLocation is Cdma, just return.");
                                                object2 = var20_12;
                                                n5 = n9;
                                                n4 = n7;
                                                n3 = n8;
                                                bl4 = bl7;
                                                n2 = n6;
                                                bl3 = bl6;
                                                bl2 = bl5;
                                            }
                                            break block46;
                                        }
                                        if (n != 4) break block47;
                                        object2 = var20_12;
                                        n5 = n9;
                                        n4 = n7;
                                        n3 = n8;
                                        bl4 = bl7;
                                        n2 = n6;
                                        bl3 = bl6;
                                        bl2 = bl5;
                                        if (object instanceof CdmaCellLocation) {
                                            object2 = var20_12;
                                            n5 = n9;
                                            n4 = n7;
                                            n3 = n8;
                                            bl4 = bl7;
                                            n2 = n6;
                                            bl3 = bl6;
                                            bl2 = bl5;
                                            if (this.checkCdmaCellLocationVaild((CdmaCellLocation)object)) {
                                                n4 = 1;
                                                object2 = this.fillCDMACellinfo((CellLocation)object).getCDMAInfo();
                                                n5 = ((byte[])object2).length;
                                                n3 = n8;
                                                bl4 = bl7;
                                                n2 = n6;
                                                bl3 = bl6;
                                                bl2 = bl5;
                                            }
                                        }
                                        break block46;
                                    }
                                    if (n == 3 || n == 10 || n == 8 || n == 9 || n == 15 || n == 19 || n == 17) break block48;
                                    if (n != 20) break block49;
                                    n2 = 1;
                                    object = new UMBCellInfo();
                                    ((UMBCellInfo)object).setDummyData();
                                    object2 = ((UMBCellInfo)object).getUMBCellInfo();
                                    n5 = ((byte[])object2).length;
                                    n4 = n7;
                                    n3 = n8;
                                    bl4 = bl7;
                                    bl3 = bl6;
                                    bl2 = bl5;
                                    break block46;
                                }
                                object2 = new StringBuilder;
                                ((StringBuilder)object2)();
                                Log.i((String)LOG_TAG, (String)((StringBuilder)object2).append("Network type is 3G, type is ").append(n).toString());
                                if (object instanceof GsmCellLocation) {
                                    object2 = var20_12;
                                    n5 = n9;
                                    n4 = n7;
                                    n3 = n8;
                                    bl4 = bl7;
                                    n2 = n6;
                                    bl3 = bl6;
                                    bl2 = bl5;
                                    if (this.checkUmtsCellLocationValid((GsmCellLocation)object)) {
                                        bl3 = true;
                                        object2 = new WcdmaCellInfo;
                                        ((WcdmaCellInfo)object2)((CellLocation)object, this.m_iMnc, this.m_iMcc);
                                        object2 = ((WcdmaCellInfo)object2).getWCDMAInfo();
                                        n5 = ((byte[])object2).length;
                                        n4 = n7;
                                        n3 = n8;
                                        bl4 = bl7;
                                        n2 = n6;
                                        bl2 = bl5;
                                    }
                                    break block46;
                                } else {
                                    Log.d((String)LOG_TAG, (String)"Network type is UMTS but CellLocation is Cdma, just return.");
                                    object2 = var20_12;
                                    n5 = n9;
                                    n4 = n7;
                                    n3 = n8;
                                    bl4 = bl7;
                                    n2 = n6;
                                    bl3 = bl6;
                                    bl2 = bl5;
                                }
                                break block46;
                            }
                            if (n != 21) break block50;
                            bl2 = true;
                            if (object2 == null) {
                                object = new WIFIParameter(this.mNetInfo.getWiFiMACAddress());
                                object2 = ((WIFIParameter)object).getWIFIParameterInfo();
                            }
                            n5 = ((byte[])object2).length;
                            n4 = n7;
                            n3 = n8;
                            bl4 = bl7;
                            n2 = n6;
                            bl3 = bl6;
                            break block46;
                        }
                        object2 = var20_12;
                        n5 = n9;
                        n4 = n7;
                        n3 = n8;
                        bl4 = bl7;
                        n2 = n6;
                        bl3 = bl6;
                        bl2 = bl5;
                        if (n != 13) break block46;
                        object2 = new StringBuilder;
                        ((StringBuilder)object2)();
                        Log.i((String)LOG_TAG, (String)((StringBuilder)object2).append("Network type is 4G, type is ").append(n).toString());
                        object2 = null;
                        if (Build.VERSION.SDK_INT < 17) break block51;
                        if (object3 != null) {
                            object2 = LTECellInfo.getCellInfo_To_LTECellInfo((List<CellInfo>)object3, null);
                            break block52;
                        } else if ("true".equals(SystemProperties.get((String)"ro.config.report_cell_info_list"))) {
                            object2 = LTECellInfo.getAPILTECellInfo(this.mContext);
                        }
                        break block52;
                    }
                    object2 = LTECellInfo.getNONAPILTECellInfo(this.mContext);
                }
                object3 = object2;
                if (object2 == null) {
                    object3 = object2;
                    if (object instanceof GsmCellLocation) {
                        object3 = object2;
                        if (this.checkLteCellLocationValid((GsmCellLocation)object)) {
                            object3 = LTECellInfo.getCellLocation_To_LTECellInfo((CellLocation)object, this.m_iMcc, this.m_iMnc);
                        }
                    }
                }
                if (object3 != null) {
                    object2 = ((LTECellInfo)object3).getLTECellInfo();
                    n5 = ((byte[])object2).length;
                    object = new StringBuilder();
                    Log.i((String)LOG_TAG, (String)((StringBuilder)object).append("LTE data send..").append(n5).toString());
                    bl4 = true;
                    n4 = n7;
                    n3 = n8;
                    n2 = n6;
                    bl3 = bl6;
                    bl2 = bl5;
                } else {
                    bl4 = false;
                    Log.e((String)LOG_TAG, (String)"LTE data  is null");
                    object2 = var20_12;
                    n5 = n9;
                    n4 = n7;
                    n3 = n8;
                    n2 = n6;
                    bl3 = bl6;
                    bl2 = bl5;
                }
            }
            n8 = 0;
            object3 = new SendToServer();
            n6 = 4;
            n7 = n5;
            n = n6;
            if (n3 == 0) {
                n7 = n5;
                n = n6;
                if ((n4 ^ 1) != 0) {
                    n7 = n5;
                    n = n6;
                    if (bl3 ^ true) {
                        n7 = n5;
                        n = n6;
                        if (bl2 ^ true) {
                            n7 = n5;
                            n = n6;
                            if (bl4 ^ true) {
                                n7 = 0;
                                n = 0;
                            }
                        }
                    }
                }
            }
            n6 = n7 + n + 32 + 4;
            object = new byte[n6 + 4];
            n = IO.put4((byte[])object, 4, 267);
            if (n3 != 0) {
                n = IO.put4((byte[])object, n, 1);
                System.arraycopy((byte[])object2, (int)0, (byte[])object, (int)n, (int)n7);
                n = n5 = n + n7;
                n5 = IO.put4((byte[])object, n5, 1);
            } else {
                n5 = IO.put4((byte[])object, n, 0);
                n = n8;
            }
            if (bl3) {
                n = IO.put4((byte[])object, n5, 1);
                System.arraycopy((byte[])object2, (int)0, (byte[])object, (int)n, (int)n7);
                n = n5 = n + n7;
                n5 = IO.put4((byte[])object, n5, 1);
            } else {
                n5 = IO.put4((byte[])object, n5, 0);
            }
            if (n4 != 0) {
                n = IO.put4((byte[])object, n5, 1);
                System.arraycopy((byte[])object2, (int)0, (byte[])object, (int)n, (int)n7);
                n = n5 = n + n7;
                n5 = IO.put4((byte[])object, n5, 1);
            } else {
                n5 = IO.put4((byte[])object, n5, 0);
            }
            n5 = IO.put4((byte[])object, n5, 0);
            if (n2 == 0) {
                n5 = IO.put4((byte[])object, n5, 0);
            } else {
                n = IO.put4((byte[])object, n5, 1);
                System.arraycopy((byte[])object2, (int)0, (byte[])object, (int)n, (int)n7);
                n = n5 = n + n7;
                n5 = IO.put4((byte[])object, n5, 1);
            }
            if (bl4) {
                n = IO.put4((byte[])object, n5, 1);
                System.arraycopy((byte[])object2, (int)0, (byte[])object, (int)n, (int)n7);
                n = n5 = n + n7;
                n5 = IO.put4((byte[])object, n5, 1);
            } else {
                n5 = IO.put4((byte[])object, n5, 0);
            }
            if (bl2) {
                n = IO.put4((byte[])object, n5, 1);
                System.arraycopy((byte[])object2, (int)0, (byte[])object, (int)n, (int)n7);
                n = n5 = n + n7;
                n5 = IO.put4((byte[])object, n5, 1);
            } else {
                n5 = IO.put4((byte[])object, n5, 0);
            }
            n5 = IO.put4((byte[])object, n5, 0);
            if (n6 != n5 - 4) {
                object2 = new StringBuilder;
                ((StringBuilder)object2)();
                Log.e((String)LOG_TAG, (String)((StringBuilder)object2).append("invalid size ").append(n6).append(": ").append(n5 - 4).toString());
            }
            IO.put4((byte[])object, 0, n5 - 4);
            ((SendToServer)object3).m_bPacket = (byte[])object;
            this.mCommProcessor.sendServer((SendToServer)object3);
            if (n == 0) return;
            if (bl2) {
                this.mNetInfo.setStaleLocationInfo((byte[])object, n);
            } else if (this.mStaleLocationInfo == null) {
                this.mStaleLocationInfo = object2 = new StaleLocationInfo((byte[])object, n);
            } else {
                this.mStaleLocationInfo.upDateInfo((byte[])object, n);
            }
            return;
        }
    }

    private GsmCellInfo fillGSMCellinfo(CellLocation object) {
        GsmCellLocation gsmCellLocation = (GsmCellLocation)object;
        object = new GsmCellInfo();
        object.m_iMNC = this.m_iMnc;
        object.m_iMCC = this.m_iMcc;
        object.m_iLAC = gsmCellLocation.getLac();
        object.m_iCellID = gsmCellLocation.getCid();
        return object;
    }

    private boolean getLocationEnableState(Context context) {
        if (this.isGlobalVersion()) {
            return true;
        }
        context = (LocationManager)context.getApplicationContext().getSystemService("location");
        boolean bl = context.isProviderEnabled("gps");
        boolean bl2 = context.isProviderEnabled("network");
        Log.d((String)LOG_TAG, (String)("gps switch " + bl + " network switch " + bl2));
        if (bl) return true;
        if (!bl2) return false;
        return true;
    }

    private String getNetworkTypeString(int n) {
        switch (n) {
            default: {
                return "NOT RETERIVE";
            }
            case 2: {
                return "EDGE";
            }
            case 1: {
                return "GPRS";
            }
            case 3: {
                return "UMTS";
            }
            case 4: {
                return "CDMA";
            }
            case 0: {
                return "UNKNOWN";
            }
            case 7: {
                return "1xRTT";
            }
            case 5: {
                return "EVDO_0";
            }
            case 6: {
                return "EVDO_A";
            }
            case 10: {
                return "HSPA";
            }
            case 8: {
                return "HSDPA";
            }
            case 9: {
                return "HSUPA";
            }
            case 15: {
                return "HSPAP";
            }
            case 11: {
                return "IDEN";
            }
            case 12: {
                return "EVDO_B";
            }
            case 13: {
                return "LTE";
            }
            case 14: {
                return "EHRPD";
            }
            case 16: {
                return "GSM";
            }
            case 17: {
                return "TDS";
            }
            case 19: 
        }
        return "TDS-DPA";
    }

    private String getPhoneTypeString(int n) {
        switch (n) {
            default: {
                return "NOT RETERIVE";
            }
            case 1: {
                return "GSM";
            }
            case 2: {
                return "CDMA";
            }
            case 0: 
        }
        return "UNKNOWN";
    }

    private boolean isGlobalVersion() {
        if (!"zh".equals(SystemProperties.get((String)"ro.product.locale.language"))) return true;
        return "CN".equals(SystemProperties.get((String)"ro.product.locale.region")) ^ true;
    }

    private boolean isSIMEnabled() {
        int n = this.tm.getSimState();
        boolean bl = false;
        switch (n) {
            case 5: {
                bl = true;
                break;
            }
            case 0: 
            case 1: 
            case 2: 
            case 3: 
            case 4: {
                bl = false;
                break;
            }
        }
        Log.i((String)LOG_TAG, (String)("SIM state :" + n));
        return bl;
    }

    private void sendWIFIScanResult(List<ScanResult> object) {
        Object object2;
        int n;
        if (object == null) return;
        if (object.size() <= 0) return;
        int n2 = 0;
        int n3 = n = object.size();
        if (n > 20) {
            n3 = 20;
        }
        Object object3 = new Vector(n3);
        for (int i = 0; i < n3; ++i) {
            ScanResult scanResult = object.get(i);
            n = n2;
            if (scanResult != null) {
                n = n2;
                if (scanResult.BSSID != null) {
                    object2 = new WIFIParameter(scanResult.BSSID);
                    n = n2;
                    if (object2 != null) {
                        boolean bl;
                        boolean bl2 = bl = false;
                        if (this.mNetInfo != null) {
                            String string = this.mNetInfo.getWiFiMACAddress();
                            bl2 = bl;
                            if (string != null) {
                                bl2 = scanResult.BSSID.equals(string);
                            }
                        }
                        object2 = ((WIFIParameter)object2).getScanWIFIParameterInfo(bl2);
                        n = n2;
                        if (object2 != null) {
                            n = n2 + ((Object)object2).length;
                            ((Vector)object3).add(object2);
                        }
                    }
                }
            }
            n2 = n;
        }
        if (((Vector)object3).size() <= 0) return;
        object = new byte[++n2];
        n3 = IO.put1((byte[])object, 0, ((Vector)object3).size());
        object2 = object3.iterator();
        while (object2.hasNext()) {
            object3 = (byte[])object2.next();
            if (object3 == null) continue;
            System.arraycopy((byte[])object3, (int)0, (byte[])object, (int)n3, (int)((Object)object3).length);
            n3 += ((Object)object3).length;
        }
        if (n3 != n2) {
            Log.e((String)LOG_TAG, (String)("Wifi sacn result length invalid=" + n3 + ":" + n2));
            return;
        }
        Log.d((String)LOG_TAG, (String)"Wifi sacn result send");
        this.fillCellInfo(null, false, 21, (byte[])object, null);
    }

    private void startListener() {
        if (this.isStartListen) return;
        this.isStartListen = true;
        this.tm.listen((PhoneStateListener)this.mMyPhoneStateListener, 209);
        Log.i((String)LOG_TAG, (String)"Registered MyPhoneStateListener");
        if (this.isLocationSwithEnable) {
            CellLocation.requestLocationUpdate();
            this.forceCellLocationUpdate();
            return;
        }
        Log.i((String)LOG_TAG, (String)"Location switch is OFF");
    }

    private void upDatePhoneInfo() {
        CharSequence charSequence;
        this.m_stIMSI = this.tm.getSubscriberId();
        this.m_stPhoneType = this.getPhoneTypeString(this.tm.getPhoneType());
        Log.i((String)LOG_TAG, (String)("Phone type:" + this.m_stPhoneType));
        this.m_stBearerNetworkType = this.getNetworkTypeString(this.tm.getNetworkType());
        if ("msisdn".equals(ConfigManager.getInstance().getPrefSetId())) {
            this.m_stMSISDN = this.tm.getLine1Number();
        }
        if ((charSequence = this.tm.getNetworkOperator()) != null && ((String)charSequence).length() > 0) {
            try {
                this.m_iMcc = Integer.parseInt(((String)charSequence).substring(0, 3));
                this.m_iMnc = Integer.parseInt(((String)charSequence).substring(3));
                charSequence = new StringBuilder();
                Log.i((String)LOG_TAG, (String)((StringBuilder)charSequence).append("Network Op Mnc= ").append(this.m_iMnc).append(" MCC = ").append(this.m_iMcc).toString());
                return;
            }
            catch (NumberFormatException numberFormatException) {
                return;
            }
        }
        Log.i((String)LOG_TAG, (String)"NULL Value received for network operator");
    }

    private void updateNoSIM_MNC_MCC(SendToServer sendToServer, int n) {
        sendToServer.m_bPacket = new byte[14];
        int n2 = IO.put4(sendToServer.m_bPacket, 0, sendToServer.m_bPacket.length - 4);
        n2 = IO.put4(sendToServer.m_bPacket, n2, 281);
        n = IO.put2(sendToServer.m_bPacket, n2, n);
        IO.put4(sendToServer.m_bPacket, n, 0);
    }

    public void forceCellLocationUpdate() {
        new Thread(){

            @Override
            public void run() {
                if (!SETLocationManager.this.isLocationSwithEnable) {
                    Log.i((String)SETLocationManager.LOG_TAG, (String)"Location switch is OFF");
                    return;
                }
                int n = SETLocationManager.this.tm.getNetworkType();
                CellLocation cellLocation = SETLocationManager.this.tm.getCellLocation();
                if (cellLocation == null) {
                    Log.e((String)SETLocationManager.LOG_TAG, (String)"tm.getCellLocation() returned null");
                    return;
                }
                Log.i((String)SETLocationManager.LOG_TAG, (String)"tm.getCellLocation() returned non-null ");
                SETLocationManager.this.fillCellInfo(cellLocation, false, n, null, null);
            }
        }.start();
    }

    /*
     * Loose catch block
     * Enabled unnecessary exception pruning
     */
    public SendToServer getSIM_Mnc_MCC(int n) {
        SendToServer sendToServer;
        block6: {
            sendToServer = new SendToServer();
            if (this.tm != null) {
                CharSequence charSequence = this.tm.getSimOperator();
                if (charSequence != null && ((String)charSequence).length() > 0) {
                    sendToServer.m_bPacket = new byte[18];
                    this.m_iMcc = Integer.parseInt(((String)charSequence).substring(0, 3));
                    this.m_iMnc = Integer.parseInt(((String)charSequence).substring(3));
                    int n2 = IO.put4(sendToServer.m_bPacket, 0, sendToServer.m_bPacket.length - 4);
                    n2 = IO.put4(sendToServer.m_bPacket, n2, 281);
                    n = IO.put2(sendToServer.m_bPacket, n2, n);
                    n = IO.put4(sendToServer.m_bPacket, n, 1);
                    n = IO.put2(sendToServer.m_bPacket, n, this.m_iMcc);
                    IO.put2(sendToServer.m_bPacket, n, this.m_iMnc);
                    charSequence = new StringBuilder();
                    Log.i((String)LOG_TAG, (String)((StringBuilder)charSequence).append("Sim Operator Mnc= ").append(this.m_iMnc).append(" MCC = ").append(this.m_iMcc).toString());
                    break block6;
                } else {
                    this.updateNoSIM_MNC_MCC(sendToServer, n);
                    Log.i((String)LOG_TAG, (String)"NULL Value received for Sim Operator ");
                }
            } else {
                this.updateNoSIM_MNC_MCC(sendToServer, n);
                Log.i((String)LOG_TAG, (String)"NULL Value received for TelephonyManager ");
            }
            break block6;
            catch (NumberFormatException numberFormatException) {}
        }
        Log.i((String)LOG_TAG, (String)" Msg  MSG_PCM_UPDATE_SIM_MCC_MNC");
        return sendToServer;
    }

    public void registerEmergencyReceiver() {
        if (this.isEmergencyCallListen) return;
        Log.i((String)LOG_TAG, (String)"register the Emergency Receiver ");
        this.mContext.registerReceiver(this.outGoingCallReceiver, this.intentFilter, "supl20servicePermission", null);
        this.isEmergencyCallListen = true;
        if (this.mCallListener == null) {
            this.mCallListener = new EmergencyCallListener();
        }
        this.tm.listen((PhoneStateListener)this.mCallListener, 32);
    }

    public void sendCellStaleLocation() {
        if (this.mStaleLocationInfo == null) return;
        SendToServer sendToServer = new SendToServer();
        sendToServer.m_bPacket = this.mStaleLocationInfo.getStaleLocation();
        this.mCommProcessor.sendServer(sendToServer);
    }

    public void sendSETIDInfo(int n, int n2) {
        if (this.isLocationSwithEnable) {
            this.upDatePhoneInfo();
        }
        SetID setID = new SetID(n);
        SendToServer sendToServer = new SendToServer();
        switch (n) {
            default: {
                sendToServer.m_bPacket = setID.getSetIDBuff(n2, "");
                break;
            }
            case 1: {
                sendToServer.m_bPacket = setID.getSetIDBuff(n2, this.m_stMSISDN);
                break;
            }
            case 2: {
                sendToServer.m_bPacket = setID.getSetIDBuff(n2, "");
                break;
            }
            case 3: {
                sendToServer.m_bPacket = setID.getSetIDBuff(n2, "");
                break;
            }
            case 4: {
                sendToServer.m_bPacket = setID.getSetIDBuff(n2, this.m_stIMSI);
                break;
            }
            case 5: {
                sendToServer.m_bPacket = setID.getSetIDBuff(n2, "");
                break;
            }
            case 6: {
                sendToServer.m_bPacket = setID.getSetIDBuff(n2, this.mNetInfo.getIPAddress());
                break;
            }
            case 7: {
                sendToServer.m_bPacket = setID.getSetIDBuff(n2, "");
                break;
            }
            case 8: {
                sendToServer.m_bPacket = setID.getSetIDBuff(n2, "");
            }
        }
        this.mCommProcessor.sendServer(sendToServer);
    }

    public void setCommProcessor(NDKCommProcessor nDKCommProcessor) {
        this.mCommProcessor = nDKCommProcessor;
    }

    public void startLocationIdListener() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.net.wifi.SCAN_RESULTS");
        intentFilter.addAction("android.net.wifi.WIFI_STATE_CHANGED");
        intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        intentFilter.addAction("android.net.wifi.STATE_CHANGE");
        intentFilter.addAction("android.net.wifi.supplicant.CONNECTION_CHANGE");
        intentFilter.addAction("android.net.wifi.supplicant.STATE_CHANGE");
        intentFilter.addAction("android.location.PROVIDERS_CHANGED");
        if (this.mWIFIReceiver == null) {
            this.mWIFIReceiver = new NetworkStateBroadcastReceiver();
        }
        if (!this.isWifiRegister) {
            this.mContext.registerReceiver((BroadcastReceiver)this.mWIFIReceiver, intentFilter, "supl20servicePermission", null);
            this.isWifiRegister = true;
        }
        if (this.isSIMEnabled()) {
            Log.i((String)LOG_TAG, (String)" sim is enable on the SET");
            this.startListener();
            return;
        }
        this.startListener();
        Log.i((String)LOG_TAG, (String)" sim is not enabled on the SET");
    }

    public void stopListening() {
        if (this.mWIFIReceiver != null && this.isWifiRegister) {
            this.mContext.unregisterReceiver((BroadcastReceiver)this.mWIFIReceiver);
            this.isWifiRegister = false;
        }
        if (this.tm == null) return;
        if (this.mMyPhoneStateListener == null) return;
        if (!this.isStartListen) return;
        this.isStartListen = false;
        this.tm.listen((PhoneStateListener)this.mMyPhoneStateListener, 0);
        Log.i((String)LOG_TAG, (String)"De-Registered MyPhoneStateListener");
    }

    public void unregisterEmergencyReceiver() {
        if (!this.isEmergencyCallListen) return;
        this.mContext.unregisterReceiver(this.outGoingCallReceiver);
        this.tm.listen((PhoneStateListener)this.mCallListener, 0);
        this.isEmergencyCallListen = false;
        Log.i((String)LOG_TAG, (String)"unregister the Emergency Receiver ");
    }

    private class EmergencyCallListener
    extends PhoneStateListener {
        private EmergencyCallListener() {
        }

        public void onCallStateChanged(int n, String string) {
            int n2 = 0;
            switch (n) {
                case 0: {
                    if (!SETLocationManager.this.isEmergencyCall) break;
                    SETLocationManager.-set0(SETLocationManager.this, false);
                    SendToServer sendToServer = new SendToServer();
                    sendToServer.m_bPacket = new byte[12];
                    int n3 = IO.put4(sendToServer.m_bPacket, 0, 8);
                    n3 = IO.put4(sendToServer.m_bPacket, n3, 278);
                    byte[] byArray = sendToServer.m_bPacket;
                    if (SETLocationManager.this.isEmergencyCall) {
                        n2 = 1;
                    }
                    IO.put4(byArray, n3, n2);
                    SETLocationManager.this.mCommProcessor.sendServer(sendToServer);
                    Log.i((String)SETLocationManager.LOG_TAG, (String)("onCallStateChanged " + "IDLE" + " on Emergency call End"));
                    break;
                }
                case 1: {
                    String cfr_ignored_0 = "Ringing (" + string + ")";
                    break;
                }
                case 2: {
                    break;
                }
            }
            super.onCallStateChanged(n, string);
        }
    }

    private class MyPhoneStateListener
    extends PhoneStateListener {
        private MyPhoneStateListener() {
        }

        public void onCellInfoChanged(List<CellInfo> list) {
            int n = SETLocationManager.this.tm.getNetworkType();
            Log.i((String)SETLocationManager.LOG_TAG, (String)("onCellInfoChanged network type:" + n));
            if (n == 13) {
                SETLocationManager.this.fillCellInfo(null, false, n, null, list);
            }
            super.onCellInfoChanged(list);
        }

        public void onCellLocationChanged(CellLocation cellLocation) {
            int n = SETLocationManager.this.tm.getNetworkType();
            Log.i((String)SETLocationManager.LOG_TAG, (String)("onCellLocationChanged network type:" + n));
            SETLocationManager.this.fillCellInfo(cellLocation, false, n, null, null);
            super.onCellLocationChanged(cellLocation);
        }

        public void onDataConnectionStateChanged(int n) {
            String string;
            switch (n) {
                default: {
                    string = "Unknown: " + n;
                    break;
                }
                case 2: {
                    string = "Connected";
                    break;
                }
                case 1: {
                    string = "Connecting";
                    break;
                }
                case 0: {
                    string = "Disconnected";
                    break;
                }
                case 3: {
                    string = "Suspended";
                }
            }
            Log.i((String)SETLocationManager.LOG_TAG, (String)("onDataConnectionStateChanged " + string));
            SETLocationManager.this.forceCellLocationUpdate();
            super.onDataConnectionStateChanged(n);
        }

        public void onDataConnectionStateChanged(int n, int n2) {
            Log.i((String)SETLocationManager.LOG_TAG, (String)("onDataConnectionStateChanged networkType = " + n2));
            switch (n) {
                default: {
                    String cfr_ignored_0 = "Unknown: " + n;
                    Log.i((String)SETLocationManager.LOG_TAG, (String)("onDataConnectionStateChanged state = " + n));
                    break;
                }
                case 2: {
                    Log.i((String)SETLocationManager.LOG_TAG, (String)"onDataConnectionStateChanged TelephonyManager.DATA_CONNECTED");
                    break;
                }
                case 1: {
                    Log.i((String)SETLocationManager.LOG_TAG, (String)"onDataConnectionStateChanged TelephonyManager.DATA_CONNECTING");
                    break;
                }
                case 0: {
                    Log.i((String)SETLocationManager.LOG_TAG, (String)"onDataConnectionStateChanged TelephonyManager.DATA_DISCONNECTED");
                    break;
                }
                case 3: {
                    Log.i((String)SETLocationManager.LOG_TAG, (String)"onDataConnectionStateChanged TelephonyManager.DATA_SUSPENDED");
                }
            }
            SETLocationManager.this.forceCellLocationUpdate();
            super.onDataConnectionStateChanged(n);
        }

        public void onServiceStateChanged(ServiceState serviceState) {
            boolean bl = false;
            switch (serviceState.getState()) {
                default: {
                    bl = true;
                    Log.i((String)SETLocationManager.LOG_TAG, (String)("onServiceStateChanged " + serviceState.getState()));
                    break;
                }
                case 0: {
                    Log.i((String)SETLocationManager.LOG_TAG, (String)"onServiceStateChanged ServiceState.STATE_IN_SERVICE");
                    break;
                }
                case 2: {
                    bl = true;
                    Log.i((String)SETLocationManager.LOG_TAG, (String)"onServiceStateChanged ServiceState.STATE_EMERGENCY_ONLY");
                    break;
                }
                case 1: {
                    bl = true;
                    Log.i((String)SETLocationManager.LOG_TAG, (String)"onServiceStateChanged ServiceState.STATE_OUT_OF_SERVICE");
                    break;
                }
                case 3: {
                    bl = true;
                    Log.i((String)SETLocationManager.LOG_TAG, (String)"onServiceStateChanged ServiceState.STATE_POWER_OFF");
                }
            }
            if (bl) {
                SETLocationManager.this.sendCellStaleLocation();
                SETLocationManager.this.mNetInfo.sendStaleLocationInfo(SETLocationManager.this.mCommProcessor);
            } else {
                SETLocationManager.this.forceCellLocationUpdate();
            }
            super.onServiceStateChanged(serviceState);
        }
    }

    public class NetworkStateBroadcastReceiver
    extends BroadcastReceiver {
        public void onReceive(Context object, Intent object2) {
            CharSequence charSequence = object2.getAction();
            if (((String)charSequence).equals("android.net.wifi.SCAN_RESULTS")) {
                if (!SETLocationManager.this.isLocationSwithEnable) return;
                object2 = ((WifiManager)object.getSystemService("wifi")).getScanResults();
                charSequence = new StringBuilder().append(" num scan results=");
                object = object2 == null ? "0" : Integer.valueOf(object2.size());
                object = ((StringBuilder)charSequence).append(object).toString();
                Log.d((String)SETLocationManager.LOG_TAG, (String)("WIFI_STATE result" + (String)object));
                SETLocationManager.this.sendWIFIScanResult((List)object2);
                return;
            }
            if (((String)charSequence).equals("android.net.conn.CONNECTIVITY_CHANGE")) {
                object = object2.getBooleanExtra("noConnectivity", false) ? "no connectivity" : "connection available";
                Log.d((String)SETLocationManager.LOG_TAG, (String)("Connectivity result: " + (String)object));
                return;
            }
            if (((String)charSequence).equals("android.net.wifi.WIFI_STATE_CHANGED")) {
                int n = object2.getIntExtra("wifi_state", 4);
                object = "unknown";
                switch (n) {
                    case 1: {
                        object = "disabled";
                        SETLocationManager.this.mNetInfo.sendStaleLocationInfo(SETLocationManager.this.mCommProcessor);
                        break;
                    }
                    case 0: {
                        object = "disabling";
                        break;
                    }
                    case 3: {
                        object2 = "enabled";
                        object = object2;
                        if (!SETLocationManager.this.isLocationSwithEnable) break;
                        object = SETLocationManager.this.mNetInfo.getWiFiMACAddress();
                        if (object != null && ((String)object).trim().length() > 0) {
                            SETLocationManager.this.fillCellInfo(null, false, 21, null, null);
                            object = object2;
                            break;
                        }
                        Log.e((String)SETLocationManager.LOG_TAG, (String)"WIFI_STATE not have mac address");
                        object = object2;
                        break;
                    }
                    case 2: {
                        object = "enabling";
                        break;
                    }
                }
                Log.d((String)SETLocationManager.LOG_TAG, (String)("WIFI_STATE " + (String)object));
                return;
            }
            if (!((String)charSequence).equals("android.location.PROVIDERS_CHANGED")) return;
            SETLocationManager.-set1(SETLocationManager.this, SETLocationManager.this.getLocationEnableState((Context)object));
            if (SETLocationManager.this.isLocationSwithEnable && SETLocationManager.this.isGlobalVersion() ^ true) {
                SETLocationManager.this.forceCellLocationUpdate();
            }
            Log.d((String)SETLocationManager.LOG_TAG, (String)("Location switch " + SETLocationManager.this.isLocationSwithEnable));
        }
    }
}

