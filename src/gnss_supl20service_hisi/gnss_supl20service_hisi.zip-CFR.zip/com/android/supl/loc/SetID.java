/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.android.supl.loc;

import android.util.Log;
import com.android.bytewriter.IO;

public class SetID {
    private static final int SET_ID_DATA_LEN = 14;
    private static final int SET_ID_NODATA_LEN = 10;
    public static final int SUPL_SETID_TYPE_IMSI = 4;
    public static final int SUPL_SETID_TYPE_IPADDRESSV4 = 6;
    public static final int SUPL_SETID_TYPE_IPADDRESSV6 = 7;
    public static final int SUPL_SETID_TYPE_MDN = 2;
    public static final int SUPL_SETID_TYPE_MIN = 3;
    public static final int SUPL_SETID_TYPE_MSISDN = 1;
    public static final int SUPL_SETID_TYPE_NAI = 5;
    public static final int SUPL_SETID_TYPE_NONE = 8;
    private int iNumBytes = 0;
    private int m_iSetIDType;

    public SetID(int n) {
        switch (n) {
            default: {
                throw new IllegalArgumentException("invalid SETTYPE ");
            }
            case 1: {
                this.iNumBytes = 12;
                break;
            }
            case 2: {
                this.iNumBytes = 8;
                break;
            }
            case 3: {
                this.iNumBytes = 5;
                break;
            }
            case 4: {
                this.iNumBytes = 15;
                break;
            }
            case 5: {
                this.iNumBytes = 1000;
                break;
            }
            case 6: {
                this.iNumBytes = 4;
                break;
            }
            case 7: {
                this.iNumBytes = 16;
                break;
            }
            case 8: {
                this.iNumBytes = 0;
            }
        }
        this.m_iSetIDType = n;
    }

    private String addLeadingData(String string, String string2, int n) {
        if (string == null) {
            return null;
        }
        StringBuffer stringBuffer = new StringBuffer();
        int n2 = string.length();
        if (n2 >= n) {
            return string;
        }
        int n3 = 0;
        while (true) {
            if (n3 >= n - n2) {
                stringBuffer.append(string);
                return stringBuffer.toString();
            }
            stringBuffer.append(string2);
            ++n3;
        }
    }

    public static boolean isValidSetIDRequest(int n) {
        switch (n) {
            default: {
                return false;
            }
            case 1: 
            case 2: 
            case 3: 
            case 4: 
            case 5: 
            case 6: 
            case 7: {
                return true;
            }
            case 8: 
        }
        return false;
    }

    public byte[] getSetIDBuff(int n, String objectArray) {
        int n2;
        int n3;
        byte[] byArray;
        if (objectArray == null || objectArray.trim().length() == 0) {
            this.m_iSetIDType = 8;
            this.iNumBytes = 0;
        }
        if (this.m_iSetIDType != 8) {
            byArray = new byte[this.iNumBytes + 18];
            n3 = this.iNumBytes + 14;
        } else {
            byArray = new byte[14];
            n3 = this.iNumBytes + 10;
        }
        int n4 = n2 = IO.put4(byArray, IO.put4(byArray, IO.put4(byArray, 0, n3), 266), this.m_iSetIDType);
        if (this.m_iSetIDType != 8) {
            n4 = IO.put4(byArray, n2, this.iNumBytes);
            block0 : switch (this.m_iSetIDType) {
                case 4: {
                    System.arraycopy((byte[])this.addLeadingData((String)objectArray, "0", 15).getBytes(), (int)0, (byte[])byArray, (int)n4, (int)this.iNumBytes);
                    n4 += this.iNumBytes;
                    break;
                }
                case 6: {
                    objectArray = objectArray.split("\\.");
                    int n5 = 0;
                    int n6 = objectArray.length;
                    n2 = n4;
                    while (true) {
                        n4 = n2;
                        if (n5 >= n6) break block0;
                        n2 = IO.put1(byArray, n2, Integer.parseInt(objectArray[n5]));
                        ++n5;
                    }
                }
                case 3: {
                    n4 = IO.put5(byArray, n4, Long.parseLong((String)objectArray));
                    break;
                }
                case 1: {
                    byte[] byArray2 = objectArray.getBytes();
                    this.addLeadingData((String)objectArray, "0", 12);
                    System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray, (int)n4, (int)byArray2.length);
                    n4 += 12;
                    break;
                }
                case 7: {
                    objectArray = objectArray.split(":");
                    int n7 = 0;
                    int n8 = objectArray.length;
                    n2 = n4;
                    while (true) {
                        n4 = n2;
                        if (n7 >= n8) break block0;
                        String string = this.addLeadingData(objectArray[n7], "0", 4);
                        int n9 = Integer.parseInt(string.substring(0, 2), 16);
                        n4 = Integer.parseInt(string.substring(2), 16);
                        n2 = IO.put1(byArray, IO.put1(byArray, n2, n9), n4);
                        ++n7;
                    }
                }
                case 2: {
                    n4 = IO.put8(byArray, n4, Long.parseLong((String)objectArray));
                    break;
                }
                case 5: {
                    String string = this.addLeadingData((String)objectArray, "0", 1000);
                    objectArray = string.getBytes();
                    Log.i((String)"SUPL20_SETID", (String)("NAI " + string));
                    System.arraycopy((byte[])objectArray, (int)0, (byte[])byArray, (int)n4, (int)this.iNumBytes);
                    n4 += this.iNumBytes;
                    break;
                }
            }
        }
        if (n3 != (n4 = IO.put2(byArray, n4, n)) - 4) {
            System.err.println("invalid setid packet size " + n3 + ": " + (n4 - 4));
        }
        Log.i((String)"SUPL20_SETID", (String)(" set id " + this.m_iSetIDType + " send for id:" + n));
        return byArray;
    }
}

