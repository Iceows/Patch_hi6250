/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.net.NetworkInfo$State
 *  android.net.wifi.SupplicantState
 *  android.net.wifi.WifiInfo
 *  android.net.wifi.WifiManager
 */
package com.android.supl.loc;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.SupplicantState;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import com.android.supl.commprocessor.NDKCommProcessor;
import com.android.supl.loc.StaleLocationInfo;
import com.android.supl.nc.SendToServer;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

public class NetInfo {
    private ConnectivityManager connManager = null;
    private Context context = null;
    private StaleLocationInfo mStaleLocationInfo = null;
    private WifiInfo wifiInfo = null;
    private WifiManager wifiManager = null;

    public NetInfo(Context context) {
        this.connManager = (ConnectivityManager)context.getSystemService("connectivity");
        this.context = context;
        this.initWIFIManager();
    }

    public int getCurrentNetworkType() {
        int n = 0;
        if (this.connManager == null) {
            return 0;
        }
        NetworkInfo networkInfo = this.connManager.getActiveNetworkInfo();
        if (networkInfo == null) return n;
        return networkInfo.getType();
    }

    public String getIPAddress() {
        String string;
        String string2 = string = "";
        try {
            Enumeration<NetworkInterface> enumeration = NetworkInterface.getNetworkInterfaces();
            Object object = string;
            if (enumeration == null) return object;
            block2: while (true) {
                InetAddress inetAddress;
                string2 = string;
                object = string;
                if (!enumeration.hasMoreElements()) return object;
                string2 = string;
                object = enumeration.nextElement().getInetAddresses();
                do {
                    string2 = string;
                    if (!object.hasMoreElements()) continue block2;
                    string2 = string;
                    inetAddress = (InetAddress)object.nextElement();
                    string2 = string;
                } while (inetAddress.isLoopbackAddress());
                string2 = string;
                string = inetAddress.getHostAddress();
            }
        }
        catch (SocketException socketException) {
            socketException.printStackTrace();
            return string2;
        }
    }

    public String getLinkSpeed() {
        if (this.wifiManager == null) return "0Mbs";
        if (this.wifiInfo != null) return this.wifiInfo.getLinkSpeed() + "Mbs";
        return "0Mbs";
    }

    public String getSupplicantDeatils() {
        return WifiInfo.getDetailedStateOf((SupplicantState)this.wifiInfo.getSupplicantState()).name();
    }

    public String getWiFiBSSID() {
        if (this.wifiManager == null) return "";
        if (this.wifiInfo != null) return this.wifiInfo.getBSSID();
        return "";
    }

    public String getWiFiMACAddress() {
        if (this.wifiManager == null) return "";
        if (this.wifiInfo != null) return this.wifiInfo.getMacAddress();
        return "";
    }

    public int getWiFiRssi() {
        if (this.wifiManager == null) return 0;
        if (this.wifiInfo != null) return this.wifiInfo.getRssi();
        return 0;
    }

    public String getWiFiSSID() {
        if (this.wifiManager == null) return "";
        if (this.wifiInfo != null) return this.wifiInfo.getSSID();
        return "";
    }

    public String getWifiIpAddress() {
        if (this.wifiManager == null) return "";
        if (this.wifiInfo == null) {
            return "";
        }
        int n = this.wifiInfo.getIpAddress();
        return String.format("%d.%d.%d.%d", n & 0xFF, n >> 8 & 0xFF, n >> 16 & 0xFF, n >> 24 & 0xFF);
    }

    public void initWIFIManager() {
        this.wifiManager = (WifiManager)this.context.getSystemService("wifi");
        this.wifiInfo = this.wifiManager.getConnectionInfo();
    }

    public boolean isNetworkOn() {
        ConnectivityManager connectivityManager = (ConnectivityManager)this.context.getSystemService("connectivity");
        if (connectivityManager.getNetworkInfo(0).getState() == NetworkInfo.State.CONNECTED) return true;
        if (connectivityManager.getNetworkInfo(1).getState() == NetworkInfo.State.CONNECTED) return true;
        return false;
    }

    public boolean isOnline() {
        NetworkInfo networkInfo = ((ConnectivityManager)this.context.getSystemService("connectivity")).getActiveNetworkInfo();
        if (networkInfo == null) return false;
        if (!networkInfo.isConnectedOrConnecting()) return false;
        return true;
    }

    public boolean isWiFiEnabled() {
        boolean bl = false;
        if (this.wifiManager == null) return bl;
        return this.wifiManager.isWifiEnabled();
    }

    public void sendStaleLocationInfo(NDKCommProcessor nDKCommProcessor) {
        if (this.mStaleLocationInfo == null) return;
        SendToServer sendToServer = new SendToServer();
        sendToServer.m_bPacket = this.mStaleLocationInfo.getStaleLocation();
        nDKCommProcessor.sendServer(sendToServer);
    }

    public void setStaleLocationInfo(byte[] byArray, int n) {
        if (this.mStaleLocationInfo == null) {
            this.mStaleLocationInfo = new StaleLocationInfo(byArray, n);
            return;
        }
        this.mStaleLocationInfo.upDateInfo(byArray, n);
    }
}

