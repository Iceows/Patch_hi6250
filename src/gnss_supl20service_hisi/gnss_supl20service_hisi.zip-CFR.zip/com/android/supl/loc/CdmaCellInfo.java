/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc;

import com.android.bytewriter.IO;

public class CdmaCellInfo {
    private static final int CDMA_PACKET_LEN = 22;
    public int iSeconds = 0;
    public int m_iBASELAT = 0;
    public int m_iBASELONG = 0;
    public short m_sBASEID = 0;
    public short m_sNID = 0;
    public short m_sPN = 0;
    public short m_sSID = 0;
    public short m_sWeekNumber = 0;

    public byte[] getCDMAInfo() {
        byte[] byArray = new byte[22];
        IO.put4(byArray, IO.put2(byArray, IO.put2(byArray, IO.put4(byArray, IO.put4(byArray, IO.put2(byArray, IO.put2(byArray, IO.put2(byArray, 0, this.m_sNID), this.m_sSID), this.m_sBASEID), this.m_iBASELAT), this.m_iBASELONG), this.m_sPN), this.m_sWeekNumber), this.iSeconds);
        return byArray;
    }
}

