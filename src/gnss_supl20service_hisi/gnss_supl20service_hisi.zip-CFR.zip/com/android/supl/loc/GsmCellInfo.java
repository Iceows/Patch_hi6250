/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc;

import com.android.bytewriter.IO;

public class GsmCellInfo {
    private static int GSM_PACKET_LEN = 0;
    private static final int TA_DATA_LEN = 1;
    public boolean isNMRPresent = false;
    public boolean isTAPresent = false;
    public NMRElement[] mElement = null;
    public int m_iCellID = 0;
    public int m_iLAC = 0;
    public int m_iMCC = 0;
    public int m_iMNC = 0;
    public int m_iTA = 0;

    static {
        GSM_PACKET_LEN = 16;
    }

    public byte[] getGSMInfo() {
        int n;
        int n2 = 0;
        int n3 = n = GSM_PACKET_LEN;
        int n4 = n2;
        if (this.isNMRPresent) {
            n3 = n;
            n4 = n2;
            if (this.mElement != null) {
                n3 = n;
                n4 = n2;
                if (this.mElement.length > 0) {
                    n4 = this.mElement.length;
                    n3 = n + n4 * 4;
                }
            }
        }
        n = n3;
        if (this.isTAPresent) {
            n = n3 + 1;
        }
        byte[] byArray = new byte[n];
        n = IO.put2(byArray, IO.put2(byArray, IO.put2(byArray, IO.put2(byArray, 0, this.m_iMCC), this.m_iMNC), this.m_iLAC), this.m_iCellID);
        if (this.isNMRPresent) {
            n3 = n;
            if (n4 > 0) {
                n4 = IO.put1(byArray, IO.put4(byArray, n, 1), n4);
                NMRElement[] nMRElementArray = this.mElement;
                n2 = nMRElementArray.length;
                n = 0;
                while (true) {
                    n3 = n4;
                    if (n < n2) {
                        System.arraycopy((byte[])nMRElementArray[n].getNMRElementInfo(), (int)0, (byte[])byArray, (int)n4, (int)4);
                        n4 += 4;
                        ++n;
                        continue;
                    }
                    break;
                }
            }
        } else {
            n3 = IO.put4(byArray, n, 0);
        }
        if (this.isTAPresent) {
            IO.put1(byArray, IO.put4(byArray, n3, 1), this.m_iTA);
            return byArray;
        }
        IO.put4(byArray, n3, 0);
        return byArray;
    }

    public class NMRElement {
        private static final int NMR_ELEMENT_LEN = 4;
        private short m_sARFCN;
        private short m_sBSIC;
        private short m_sRxLev;

        public NMRElement(short s, short s2, short s3) {
            this.m_sARFCN = s;
            this.m_sBSIC = s2;
            this.m_sRxLev = s3;
        }

        public byte[] getNMRElementInfo() {
            byte[] byArray = new byte[4];
            IO.put1(byArray, IO.put1(byArray, IO.put2(byArray, 0, this.m_sARFCN), this.m_sBSIC), this.m_sRxLev);
            return byArray;
        }
    }
}

