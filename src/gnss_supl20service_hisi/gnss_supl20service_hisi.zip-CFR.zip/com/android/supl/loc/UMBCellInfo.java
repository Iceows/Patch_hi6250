/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc;

import com.android.bytewriter.IO;
import com.android.supl.loc.BitString;

public class UMBCellInfo {
    public BitString stRefSectorID;
    public int unRefBASELAT;
    public int unRefBASELONG;
    public int unRefSeconds;
    public short usRefMCC;
    public short usRefMNC;
    public short usRefWeekNumber;

    public byte[] getUMBCellInfo() {
        byte[] byArray = this.stRefSectorID.getBitStringInfo();
        int n = byArray.length + 18;
        byte[] byArray2 = new byte[n];
        System.arraycopy((byte[])byArray, (int)0, (byte[])byArray2, (int)0, (int)byArray.length);
        if (IO.put4(byArray2, IO.put2(byArray2, IO.put4(byArray2, IO.put4(byArray2, IO.put2(byArray2, IO.put2(byArray2, byArray.length + 0, this.usRefMCC), this.usRefMNC), this.unRefBASELAT), this.unRefBASELONG), this.usRefWeekNumber), this.unRefSeconds) == n) return byArray2;
        System.out.println("UMBCell length error");
        return byArray2;
    }

    public void setDummyData() {
        this.stRefSectorID = new BitString("umb");
        this.usRefMCC = (short)404;
        this.usRefMNC = (short)64;
        this.unRefBASELAT = 12995999;
        this.unRefBASELONG = 80252142;
        this.usRefWeekNumber = (short)454;
        this.unRefSeconds = 1145465;
    }
}

