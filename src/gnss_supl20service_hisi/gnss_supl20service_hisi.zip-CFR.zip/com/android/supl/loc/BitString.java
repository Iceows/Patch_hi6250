/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc;

import com.android.bytewriter.IO;

public class BitString {
    int nBitsUnused = 0;
    public byte[] ucBuffer = null;
    int ucLength = 0;

    public BitString(String string) {
        if (string == null) return;
        this.ucBuffer = string.getBytes();
        this.ucLength = this.ucBuffer.length;
        this.nBitsUnused = 0;
    }

    public byte[] getBitStringInfo() {
        int n = this.ucLength + 5;
        byte[] byArray = new byte[n];
        int n2 = IO.put4(byArray, IO.put1(byArray, 0, this.ucLength), this.nBitsUnused);
        System.arraycopy((byte[])this.ucBuffer, (int)0, (byte[])byArray, (int)n2, (int)this.ucLength);
        if (n2 + this.ucLength != n) {
            System.out.println("BitString length error");
        }
        System.out.println("BitString length " + this.ucLength);
        return byArray;
    }
}

