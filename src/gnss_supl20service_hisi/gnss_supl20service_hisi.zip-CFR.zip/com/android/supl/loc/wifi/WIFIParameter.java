/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.loc.wifi;

import com.android.bytewriter.IO;
import com.android.supl.loc.BitString;

public class WIFIParameter {
    private static final int WLAN802_11A = 0;
    private static final int WLAN802_11B = 1;
    private static final int WLAN802_11G = 2;
    public boolean bIsAPAGInfoPresent = false;
    public boolean bIsAPCFreqInfpPresent = false;
    public boolean bIsAPDeviceTypeInfoPresent = false;
    public boolean bIsAPRTDInfoPresent = false;
    public boolean bIsAPReportedLocationPresent = false;
    public boolean bIsAPSSInfoPresent = false;
    public boolean bIsAPStoNInfoPresent = false;
    public boolean bIsAPTPInfoPresent = false;
    public boolean bIsSetAGInfoPresent = false;
    public boolean bIsSetSigStrengthInfoPresent = false;
    public boolean bIsSetStoNInfoPresent = false;
    public boolean bIsSetTranPowerInfoPresent = false;
    public short eAPDeviceType;
    public short sAPAG;
    public short sAPSS;
    public short sAPStoN;
    public short sAPTP;
    public short sSetAG;
    public short sSetSigStrength;
    public short sSetStoN;
    public short sSetTransPower;
    public BitString stAPMACadd;
    public RTD stAPRTD;
    public ReportedLocation stReportedLocation;
    public short ucAPCFreq;

    public WIFIParameter(String string) {
        this.stAPMACadd = new BitString(string);
    }

    public byte[] getScanWIFIParameterInfo(boolean bl) {
        byte[] byArray = new byte[2005];
        byte[] byArray2 = this.stAPMACadd.getBitStringInfo();
        int n = bl ? 1 : 0;
        n = IO.put4(byArray, 0, n);
        System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray, (int)n, (int)byArray2.length);
        int n2 = n + byArray2.length;
        n = byArray2.length + 4;
        if (this.bIsAPTPInfoPresent) {
            n2 = IO.put2(byArray, IO.put4(byArray, n2, 1), this.sAPTP);
            n += 6;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsAPAGInfoPresent) {
            n2 = IO.put2(byArray, IO.put4(byArray, n2, 1), this.sAPAG);
            n += 6;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsAPStoNInfoPresent) {
            n2 = IO.put2(byArray, IO.put4(byArray, n2, 1), this.sAPStoN);
            n += 6;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsAPDeviceTypeInfoPresent) {
            n2 = IO.put4(byArray, IO.put4(byArray, n2, 1), this.eAPDeviceType);
            n += 8;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsAPSSInfoPresent) {
            n2 = IO.put2(byArray, IO.put4(byArray, n2, 1), this.sAPSS);
            n += 6;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsAPCFreqInfpPresent) {
            n2 = IO.put1(byArray, IO.put4(byArray, n2, 1), this.ucAPCFreq);
            n += 5;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsAPRTDInfoPresent && this.stAPRTD != null) {
            n2 = IO.put4(byArray, n2, 1);
            byArray2 = this.stAPRTD.getRTDInfo();
            System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray, (int)n2, (int)byArray2.length);
            n2 += byArray2.length;
            n += byArray2.length + 4;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsSetTranPowerInfoPresent) {
            n2 = IO.put2(byArray, IO.put4(byArray, n2, 1), this.sSetTransPower);
            n += 6;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsSetAGInfoPresent) {
            n2 = IO.put2(byArray, IO.put4(byArray, n2, 1), this.sSetAG);
            n += 6;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsSetStoNInfoPresent) {
            n2 = IO.put2(byArray, IO.put4(byArray, n2, 1), this.sSetStoN);
            n += 6;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsSetSigStrengthInfoPresent) {
            n2 = IO.put2(byArray, IO.put4(byArray, n2, 1), this.sSetSigStrength);
            n += 6;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsAPReportedLocationPresent && this.stReportedLocation != null) {
            n2 = IO.put4(byArray, n2, 1);
            byArray2 = this.stReportedLocation.getReportedLocationInfo();
            System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray, (int)n2, (int)byArray2.length);
            int n3 = n2 + byArray2.length;
            n2 = n + (byArray2.length + 4);
            n = n3;
        } else {
            int n4 = IO.put4(byArray, n2, 0);
            n2 = n + 4;
            n = n4;
        }
        if (n != n2) {
            System.out.println("WIFIParameter length error");
            return byArray;
        }
        byArray2 = new byte[n2];
        System.arraycopy((byte[])byArray, (int)0, (byte[])byArray2, (int)0, (int)n2);
        return byArray2;
    }

    public byte[] getWIFIParameterInfo() {
        byte[] byArray = new byte[2005];
        byte[] byArray2 = this.stAPMACadd.getBitStringInfo();
        int n = IO.put4(byArray, IO.put1(byArray, 0, 1), 0);
        System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray, (int)n, (int)byArray2.length);
        int n2 = n + byArray2.length;
        n = byArray2.length + 5;
        if (this.bIsAPTPInfoPresent) {
            n2 = IO.put2(byArray, IO.put4(byArray, n2, 1), this.sAPTP);
            n += 6;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsAPAGInfoPresent) {
            n2 = IO.put2(byArray, IO.put4(byArray, n2, 1), this.sAPAG);
            n += 6;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsAPStoNInfoPresent) {
            n2 = IO.put2(byArray, IO.put4(byArray, n2, 1), this.sAPStoN);
            n += 6;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsAPDeviceTypeInfoPresent) {
            n2 = IO.put4(byArray, IO.put4(byArray, n2, 1), this.eAPDeviceType);
            n += 8;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsAPSSInfoPresent) {
            n2 = IO.put2(byArray, IO.put4(byArray, n2, 1), this.sAPSS);
            n += 6;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsAPCFreqInfpPresent) {
            n2 = IO.put1(byArray, IO.put4(byArray, n2, 1), this.ucAPCFreq);
            n += 5;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsAPRTDInfoPresent && this.stAPRTD != null) {
            n2 = IO.put4(byArray, n2, 1);
            byArray2 = this.stAPRTD.getRTDInfo();
            System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray, (int)n2, (int)byArray2.length);
            n2 += byArray2.length;
            n += byArray2.length + 4;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsSetTranPowerInfoPresent) {
            n2 = IO.put2(byArray, IO.put4(byArray, n2, 1), this.sSetTransPower);
            n += 6;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsSetAGInfoPresent) {
            n2 = IO.put2(byArray, IO.put4(byArray, n2, 1), this.sSetAG);
            n += 6;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsSetStoNInfoPresent) {
            n2 = IO.put2(byArray, IO.put4(byArray, n2, 1), this.sSetStoN);
            n += 6;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsSetSigStrengthInfoPresent) {
            n2 = IO.put2(byArray, IO.put4(byArray, n2, 1), this.sSetSigStrength);
            n += 6;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (this.bIsAPReportedLocationPresent && this.stReportedLocation != null) {
            n2 = IO.put4(byArray, n2, 1);
            byArray2 = this.stReportedLocation.getReportedLocationInfo();
            System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray, (int)n2, (int)byArray2.length);
            n2 += byArray2.length;
            n += byArray2.length + 4;
        } else {
            n2 = IO.put4(byArray, n2, 0);
            n += 4;
        }
        if (n2 != n) {
            System.out.println("WIFIParameter length error");
            return byArray;
        }
        byArray2 = new byte[n];
        System.arraycopy((byte[])byArray, (int)0, (byte[])byArray2, (int)0, (int)n);
        return byArray2;
    }

    private class LocationData {
        public boolean bIsLocationAccuInfoPresent = false;
        public BitString stLocationValue;
        public long ulLocationAccu;

        private LocationData() {
        }

        public byte[] getLocationInfo() {
            int n = 4;
            if (this.bIsLocationAccuInfoPresent) {
                n = 12;
            }
            byte[] byArray = this.stLocationValue.getBitStringInfo();
            int n2 = n + byArray.length;
            byte[] byArray2 = new byte[n2];
            n = this.bIsLocationAccuInfoPresent ? IO.put8(byArray2, IO.put4(byArray2, 0, 1), this.ulLocationAccu) : IO.put4(byArray2, 0, 0);
            System.arraycopy((byte[])byArray, (int)0, (byte[])byArray2, (int)n, (int)byArray.length);
            if (n + byArray.length == n2) return byArray2;
            System.out.println("LocationData length error");
            return byArray2;
        }
    }

    private class RTD {
        private static final int hundrednanosec = 1;
        private static final int microsec = 0;
        private static final int nanosec = 3;
        private static final int tensnanosec = 2;
        private static final int tenthofnanosec = 4;
        public boolean bIsRTDAccuInfoPresent = false;
        public int ieRTDunits = 0;
        public short ucRTDAccuracy;
        public int uiRTDValue;

        private RTD() {
        }

        public byte[] getRTDInfo() {
            int n = 12;
            if (this.bIsRTDAccuInfoPresent) {
                n = 13;
            }
            byte[] byArray = new byte[n];
            int n2 = IO.put4(byArray, IO.put4(byArray, 0, this.uiRTDValue), this.ieRTDunits);
            n2 = this.bIsRTDAccuInfoPresent ? IO.put4(byArray, n2, 1) : IO.put4(byArray, n2, 0);
            if (IO.put1(byArray, n2, this.ucRTDAccuracy) == n) return byArray;
            System.out.println("RTD length error");
            return byArray;
        }
    }

    private class ReportedLocation {
        private static final int ASN1 = 1;
        private static final int CI = 0;
        public int ieLocationEncodingDesc = 0;
        public LocationData stLocationData;

        private ReportedLocation() {
        }

        public byte[] getReportedLocationInfo() {
            byte[] byArray = this.stLocationData.getLocationInfo();
            int n = byArray.length + 4;
            byte[] byArray2 = new byte[n];
            int n2 = IO.put4(byArray2, 0, this.ieLocationEncodingDesc);
            System.arraycopy((byte[])byArray, (int)0, (byte[])byArray2, (int)n2, (int)byArray.length);
            if (n2 + byArray.length == n) return byArray2;
            System.out.println("ReportedLocation length error");
            return byArray2;
        }
    }
}

