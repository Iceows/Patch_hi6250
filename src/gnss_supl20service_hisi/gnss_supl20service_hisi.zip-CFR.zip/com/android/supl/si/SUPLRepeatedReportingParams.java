/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;

public class SUPLRepeatedReportingParams
implements Parcelable {
    public static final Parcelable.Creator<SUPLRepeatedReportingParams> CREATOR = new Parcelable.Creator<SUPLRepeatedReportingParams>(){

        public SUPLRepeatedReportingParams createFromParcel(Parcel parcel) {
            return new SUPLRepeatedReportingParams(parcel);
        }

        public SUPLRepeatedReportingParams[] newArray(int n) {
            return new SUPLRepeatedReportingParams[n];
        }
    };
    private boolean bEnableRepeatedReporting;
    private long dwMaximumNumberOfReports = 0L;
    private long dwMinimumIntervalTime = 0L;

    public SUPLRepeatedReportingParams(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public SUPLRepeatedReportingParams(boolean bl, long l, long l2) {
        this.bEnableRepeatedReporting = bl;
        this.dwMinimumIntervalTime = l;
        this.dwMaximumNumberOfReports = l2;
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getRepeatedReportingParamsInfo() {
        byte[] byArray = new byte[12];
        int n = this.bEnableRepeatedReporting ? 1 : 0;
        IO.put4(byArray, IO.put4(byArray, IO.put4(byArray, 0, n), (int)this.dwMinimumIntervalTime), (int)this.dwMaximumNumberOfReports);
        return byArray;
    }

    public void readFromParcel(Parcel parcel) {
        byte by = parcel.readByte();
        this.bEnableRepeatedReporting = false;
        if (by == 1) {
            this.bEnableRepeatedReporting = true;
        }
        this.dwMinimumIntervalTime = parcel.readLong();
        this.dwMaximumNumberOfReports = parcel.readLong();
    }

    public String toString() {
        return this.bEnableRepeatedReporting + "," + this.dwMinimumIntervalTime + "," + this.dwMaximumNumberOfReports;
    }

    public void writeToParcel(Parcel parcel, int n) {
        byte by = this.bEnableRepeatedReporting ? (byte)1 : 0;
        parcel.writeByte(by);
        parcel.writeLong(this.dwMinimumIntervalTime);
        parcel.writeLong(this.dwMaximumNumberOfReports);
    }
}

