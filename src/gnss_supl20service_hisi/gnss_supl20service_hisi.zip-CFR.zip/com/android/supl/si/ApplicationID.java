/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;

public class ApplicationID
implements Parcelable {
    public static final Parcelable.Creator<ApplicationID> CREATOR = new Parcelable.Creator<ApplicationID>(){

        public ApplicationID createFromParcel(Parcel parcel) {
            return new ApplicationID(parcel);
        }

        public ApplicationID[] newArray(int n) {
            return new ApplicationID[n];
        }
    };
    private String m_pcAppName = null;
    private String m_pcAppProvider = null;
    public String m_pcAppVersion = null;
    private short ucAppNameLen = 0;
    private short ucAppProviderLen = 0;
    private short ucAppVersionLen = 0;

    public ApplicationID(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public ApplicationID(String string, String string2, String string3) {
        this.m_pcAppProvider = string;
        this.m_pcAppName = string2;
        this.m_pcAppVersion = string3;
        if (string == null) throw new IllegalArgumentException("No field should not be null");
        if (string2 == null) {
            throw new IllegalArgumentException("No field should not be null");
        }
        if (string3 == null) throw new IllegalArgumentException("No field should not be null");
        this.ucAppProviderLen = (short)string.getBytes().length;
        this.ucAppNameLen = (short)string2.getBytes().length;
        this.ucAppVersionLen = (short)string3.getBytes().length;
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getApplicationIDInfo() {
        if (this.m_pcAppVersion == null) {
            this.m_pcAppVersion = "";
        }
        if (this.m_pcAppProvider == null) {
            this.m_pcAppProvider = "";
        }
        if (this.m_pcAppName == null) {
            this.m_pcAppName = "";
        }
        byte[] byArray = this.m_pcAppVersion.getBytes();
        byte[] byArray2 = this.m_pcAppProvider.getBytes();
        byte[] byArray3 = this.m_pcAppName.getBytes();
        int n = byArray2.length + 3 + byArray3.length + byArray.length;
        byte[] byArray4 = new byte[n];
        int n2 = IO.put1(byArray4, IO.put1(byArray4, IO.put1(byArray4, 0, this.ucAppProviderLen), this.ucAppNameLen), this.ucAppVersionLen);
        System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray4, (int)n2, (int)byArray2.length);
        System.arraycopy((byte[])byArray3, (int)0, (byte[])byArray4, (int)(n2 += byArray2.length), (int)byArray3.length);
        System.arraycopy((byte[])byArray, (int)0, (byte[])byArray4, (int)(n2 += byArray3.length), (int)byArray.length);
        if (n2 + byArray.length == n) return byArray4;
        System.err.println("ApplicationID length invalid");
        return byArray4;
    }

    public void readFromParcel(Parcel parcel) {
        this.ucAppProviderLen = (short)parcel.readInt();
        this.ucAppNameLen = (short)parcel.readInt();
        this.ucAppVersionLen = (short)parcel.readInt();
        this.m_pcAppProvider = parcel.readString();
        this.m_pcAppName = parcel.readString();
        this.m_pcAppVersion = parcel.readString();
    }

    public String toString() {
        return this.m_pcAppProvider + ", " + this.m_pcAppName + ", " + this.m_pcAppVersion;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeInt((int)this.ucAppProviderLen);
        parcel.writeInt((int)this.ucAppNameLen);
        parcel.writeInt((int)this.ucAppVersionLen);
        parcel.writeString(this.m_pcAppProvider);
        parcel.writeString(this.m_pcAppName);
        parcel.writeString(this.m_pcAppVersion);
    }
}

