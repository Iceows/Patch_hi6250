/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;

public class SUPLThirdPartyID
implements Parcelable {
    public static final Parcelable.Creator<SUPLThirdPartyID> CREATOR = new Parcelable.Creator<SUPLThirdPartyID>(){

        public SUPLThirdPartyID createFromParcel(Parcel parcel) {
            return new SUPLThirdPartyID(parcel);
        }

        public SUPLThirdPartyID[] newArray(int n) {
            return new SUPLThirdPartyID[n];
        }
    };
    public static final int SUPL_EMAILID = 2;
    public static final int SUPL_IMS_PUB_I = 4;
    public static final int SUPL_LOGICAL_NAME = 0;
    public static final int SUPL_MDN = 6;
    public static final int SUPL_MIN = 5;
    public static final int SUPL_MSISDN = 1;
    public static final int SUPL_SIP_URI = 3;
    public static final int SUPL_URI = 7;
    private int m_enIdType;
    private short ubBitsUsed;
    public byte[] ucIDBuff = null;
    private short ucSize;

    public SUPLThirdPartyID(int n, String string, short s) {
        this.m_enIdType = n;
        if (n > 7) throw new IllegalArgumentException("ThirdPartyID type invalid");
        if (n < 0) {
            throw new IllegalArgumentException("ThirdPartyID type invalid");
        }
        if (string == null) {
            throw new IllegalArgumentException("ThirdPartyID should not be null");
        }
        this.ucIDBuff = string.getBytes();
        this.ucSize = (short)this.ucIDBuff.length;
        this.ubBitsUsed = (short)(this.ucSize * 8);
    }

    public SUPLThirdPartyID(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getThirdPartyID() {
        int n = this.ucSize + 6;
        byte[] byArray = new byte[n];
        int n2 = IO.put1(byArray, IO.put1(byArray, IO.put4(byArray, 0, this.m_enIdType), this.ucSize), this.ubBitsUsed);
        System.arraycopy((byte[])this.ucIDBuff, (int)0, (byte[])byArray, (int)n2, (int)this.ucSize);
        if (n2 + this.ucSize == n) return byArray;
        System.err.println("ThirdPartyID length invalid");
        return byArray;
    }

    public void readFromParcel(Parcel parcel) {
        this.m_enIdType = parcel.readInt();
        this.ucSize = (short)parcel.readInt();
        this.ubBitsUsed = (short)parcel.readInt();
        this.ucIDBuff = new byte[this.ucSize];
        parcel.readByteArray(this.ucIDBuff);
    }

    public String toString() {
        return this.m_enIdType + "," + new String(this.ucIDBuff);
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeInt(this.m_enIdType);
        parcel.writeInt((int)this.ucSize);
        parcel.writeInt((int)this.ubBitsUsed);
        parcel.writeByteArray(this.ucIDBuff);
    }
}

