/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import java.io.DataInputStream;
import java.io.IOException;

public class SIFailure
implements Parcelable {
    public static final Parcelable.Creator<SIFailure> CREATOR = new Parcelable.Creator<SIFailure>(){

        public SIFailure createFromParcel(Parcel parcel) {
            return new SIFailure(parcel);
        }

        public SIFailure[] newArray(int n) {
            return new SIFailure[n];
        }
    };
    public int m_enErrorCode;
    public int m_usPlatformSessionId;

    public SIFailure() {
    }

    public SIFailure(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public int describeContents() {
        return 0;
    }

    public void readFromParcel(Parcel parcel) {
        this.m_usPlatformSessionId = parcel.readInt();
        this.m_enErrorCode = parcel.readInt();
    }

    public boolean readSIFailure(DataInputStream dataInputStream) throws IOException {
        this.m_usPlatformSessionId = dataInputStream.readUnsignedShort();
        this.m_enErrorCode = dataInputStream.readInt();
        return true;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeInt(this.m_usPlatformSessionId);
        parcel.writeInt(this.m_enErrorCode);
    }
}

