/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.si;

import com.android.bytewriter.IO;

public class SetTestAreaIDParams {
    public static final int MSG_PCM_SET_TEST_AREA_ID = 284;
    public int nSetHomeAreaIDToBeSet = 0;

    public SetTestAreaIDParams(int n) {
        this.nSetHomeAreaIDToBeSet = n;
    }

    public byte[] getSetTestAreaIDInfo() {
        byte[] byArray = new byte[10];
        if (IO.put2(byArray, IO.put4(byArray, IO.put4(byArray, 0, 6), 284), this.nSetHomeAreaIDToBeSet) - 4 == 6) return byArray;
        System.err.println("invalid length in  getSetTestAreaIDInfo");
        return byArray;
    }
}

