/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;
import com.android.supl.si.SUPLPolygonDescription;

public class SUPLPolygonArea
implements Parcelable {
    public static final Parcelable.Creator<SUPLPolygonArea> CREATOR = new Parcelable.Creator<SUPLPolygonArea>(){

        public SUPLPolygonArea createFromParcel(Parcel parcel) {
            return new SUPLPolygonArea(parcel);
        }

        public SUPLPolygonArea[] newArray(int n) {
            return new SUPLPolygonArea[n];
        }
    };
    private SUPLPolygonDescription PolyDescription = null;
    private int PolygonHysteresis;

    public SUPLPolygonArea(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public SUPLPolygonArea(SUPLPolygonDescription sUPLPolygonDescription, int n) {
        if (sUPLPolygonDescription == null) {
            throw new IllegalArgumentException("PolygonDescription object should not be null");
        }
        this.PolyDescription = sUPLPolygonDescription;
        this.PolygonHysteresis = n;
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getPolygonAreaInfo() {
        byte[] byArray = this.PolyDescription.getPolygonDescription();
        int n = byArray.length + 4;
        byte[] byArray2 = new byte[n];
        System.arraycopy((byte[])byArray, (int)0, (byte[])byArray2, (int)0, (int)byArray.length);
        if (IO.put4(byArray2, byArray.length + 0, this.PolygonHysteresis) == n) return byArray2;
        System.err.println("PolygonArea length invalid");
        return byArray2;
    }

    public void readFromParcel(Parcel parcel) {
        this.PolygonHysteresis = parcel.readInt();
        this.PolyDescription = (SUPLPolygonDescription)parcel.readParcelable(SUPLPolygonDescription.class.getClassLoader());
    }

    public String toString() {
        return this.PolyDescription.toString() + "," + this.PolygonHysteresis;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeInt(this.PolygonHysteresis);
        parcel.writeParcelable((Parcelable)this.PolyDescription, n);
    }
}

