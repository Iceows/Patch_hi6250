/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;
import com.android.supl.si.ApplicationID;
import com.android.supl.si.SUPLQOPParams;
import com.android.supl.si.SUPLThirdPartyIDs;
import com.android.supl.si.SUPLTriggerParams;
import com.android.supl.si.ganss.SuplGanssAssistCapabilities;
import com.android.supl.si.ganss.SuplGanssPOSCapabilities;

public class SITriggerParams
implements Parcelable {
    public static final Parcelable.Creator<SITriggerParams> CREATOR = new Parcelable.Creator<SITriggerParams>(){

        public SITriggerParams createFromParcel(Parcel parcel) {
            System.out.println("createFromParcel ");
            return new SITriggerParams(parcel);
        }

        public SITriggerParams[] newArray(int n) {
            return new SITriggerParams[n];
        }
    };
    private static final int MSG_PCM_START_SI = 269;
    private SuplGanssAssistCapabilities mGanssAssistCapabilities = null;
    private SuplGanssPOSCapabilities mGanssPOSCapabilities = null;
    private boolean m_bIsAppIdPresent;
    private boolean m_bIsAssitancePresent = false;
    private boolean m_bIsPOSPresent = false;
    private boolean m_bIsQOPPresent = false;
    private boolean m_bIsTriggerParamsPresent;
    private SUPLThirdPartyIDs m_st3rdPartyIds = null;
    private ApplicationID m_stAppId = null;
    private SUPLQOPParams m_stQoP = null;
    private SUPLTriggerParams m_stTriggerParams = null;
    private short m_usPlatformSessionId;

    public SITriggerParams(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public SITriggerParams(boolean bl, SUPLQOPParams sUPLQOPParams, boolean bl2, SUPLTriggerParams sUPLTriggerParams, boolean bl3, ApplicationID applicationID, SUPLThirdPartyIDs sUPLThirdPartyIDs, boolean bl4, SuplGanssPOSCapabilities suplGanssPOSCapabilities, boolean bl5, SuplGanssAssistCapabilities suplGanssAssistCapabilities) {
        this.m_usPlatformSessionId = (short)-1;
        this.m_bIsQOPPresent = bl;
        if (bl && sUPLQOPParams == null) {
            throw new IllegalArgumentException("QOP paramerter should not be null");
        }
        this.m_stQoP = sUPLQOPParams;
        this.m_bIsTriggerParamsPresent = bl2;
        if (bl2 && sUPLTriggerParams == null) {
            throw new IllegalArgumentException("Trigger paramerter should not be null");
        }
        this.m_stTriggerParams = sUPLTriggerParams;
        this.m_bIsAppIdPresent = bl3;
        if (bl3 && applicationID == null) {
            throw new IllegalArgumentException("AppID should not be null");
        }
        this.m_stAppId = applicationID;
        if (sUPLThirdPartyIDs == null) {
            throw new IllegalArgumentException("3rd PartyID  should not be null");
        }
        this.m_st3rdPartyIds = sUPLThirdPartyIDs;
        this.m_bIsPOSPresent = bl4;
        if (bl4 && suplGanssPOSCapabilities == null) {
            throw new IllegalArgumentException("GanssPOSCapabilities should not be null");
        }
        this.mGanssPOSCapabilities = suplGanssPOSCapabilities;
        this.m_bIsAssitancePresent = bl5;
        if (bl5 && suplGanssAssistCapabilities == null) {
            throw new IllegalArgumentException("GanssAssistCapabilities should not be null");
        }
        this.mGanssAssistCapabilities = suplGanssAssistCapabilities;
    }

    public int describeContents() {
        return 0;
    }

    public SUPLThirdPartyIDs get3rdPartyIds() {
        return this.m_st3rdPartyIds;
    }

    public ApplicationID getAppId() {
        return this.m_stAppId;
    }

    public byte[] getStartSI() {
        byte[] byArray;
        byte[] byArray2;
        byte[] byArray3;
        int n = 26;
        byte[] byArray4 = null;
        if (this.m_bIsQOPPresent) {
            byArray4 = this.m_stQoP.getQOPParams();
            n = byArray4.length + 26;
        }
        byte[] byArray5 = null;
        int n2 = n;
        if (this.m_bIsTriggerParamsPresent) {
            byArray5 = byArray3 = this.m_stTriggerParams.getTriggerParam();
            n2 = n;
            if (byArray3 != null) {
                n2 = n + byArray3.length;
                byArray5 = byArray3;
            }
        }
        byArray3 = null;
        n = n2;
        if (this.m_bIsAppIdPresent) {
            byArray3 = this.m_stAppId.getApplicationIDInfo();
            n = n2 + byArray3.length;
        }
        byte[] byArray6 = this.m_st3rdPartyIds.getSUPLThirdPartyIDs();
        byte[] byArray7 = null;
        n2 = n += byArray6.length;
        if (this.m_bIsPOSPresent) {
            byArray7 = byArray2 = this.mGanssPOSCapabilities.getPOSCapabilities();
            n2 = n;
            if (byArray2 != null) {
                n2 = n + byArray2.length;
                byArray7 = byArray2;
            }
        }
        byArray2 = null;
        n = n2;
        if (this.m_bIsAssitancePresent) {
            byArray = this.mGanssAssistCapabilities.getAsstCapElem();
            byArray2 = byArray;
            n = n2;
            if (byArray != null) {
                n = n2 + byArray.length;
                byArray2 = byArray;
            }
        }
        byArray = new byte[n + 4];
        n2 = IO.put2(byArray, IO.put4(byArray, 4, 269), this.m_usPlatformSessionId);
        if (this.m_bIsQOPPresent) {
            n2 = IO.put4(byArray, n2, 1);
            System.arraycopy((byte[])byArray4, (int)0, (byte[])byArray, (int)n2, (int)byArray4.length);
            n2 += byArray4.length;
        } else {
            n2 = IO.put4(byArray, n2, 0);
        }
        if (this.m_bIsTriggerParamsPresent) {
            int n3;
            n2 = n3 = IO.put4(byArray, n2, 1);
            if (byArray5 != null) {
                System.arraycopy((byte[])byArray5, (int)0, (byte[])byArray, (int)n3, (int)byArray5.length);
                n2 = n3 + byArray5.length;
            }
        } else {
            n2 = IO.put4(byArray, n2, 0);
        }
        if (this.m_bIsAppIdPresent) {
            n2 = IO.put4(byArray, n2, 1);
            System.arraycopy((byte[])byArray3, (int)0, (byte[])byArray, (int)n2, (int)byArray3.length);
            n2 += byArray3.length;
        } else {
            n2 = IO.put4(byArray, n2, 0);
        }
        System.arraycopy((byte[])byArray6, (int)0, (byte[])byArray, (int)n2, (int)byArray6.length);
        n2 += byArray6.length;
        if (this.m_bIsPOSPresent) {
            n2 = IO.put4(byArray, n2, 1);
            System.arraycopy((byte[])byArray7, (int)0, (byte[])byArray, (int)n2, (int)byArray7.length);
            n2 += byArray7.length;
        } else {
            n2 = IO.put4(byArray, n2, 0);
        }
        if (this.m_bIsAssitancePresent) {
            n2 = IO.put4(byArray, n2, 1);
            System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray, (int)n2, (int)byArray2.length);
            n2 += byArray2.length;
        } else {
            n2 = IO.put4(byArray, n2, 0);
        }
        if (n2 - 4 != n) {
            System.err.println("Start SI length invalid");
        }
        IO.put4(byArray, 0, n);
        return byArray;
    }

    public SUPLTriggerParams getTriggerParams() {
        return this.m_stTriggerParams;
    }

    public void readFromParcel(Parcel parcel) {
        this.m_usPlatformSessionId = (short)parcel.readInt();
        this.m_bIsQOPPresent = false;
        if (parcel.readByte() == 1) {
            this.m_bIsQOPPresent = true;
            this.m_stQoP = (SUPLQOPParams)parcel.readParcelable(SUPLQOPParams.class.getClassLoader());
        }
        this.m_bIsTriggerParamsPresent = false;
        if (parcel.readByte() == 1) {
            this.m_bIsTriggerParamsPresent = true;
            this.m_stTriggerParams = (SUPLTriggerParams)parcel.readParcelable(SUPLTriggerParams.class.getClassLoader());
        }
        this.m_bIsAppIdPresent = false;
        if (parcel.readByte() == 1) {
            this.m_bIsAppIdPresent = true;
            this.m_stAppId = (ApplicationID)parcel.readParcelable(ApplicationID.class.getClassLoader());
        }
        this.m_st3rdPartyIds = (SUPLThirdPartyIDs)parcel.readParcelable(SUPLThirdPartyIDs.class.getClassLoader());
        byte by = parcel.readByte();
        this.m_bIsPOSPresent = false;
        if (by == 1) {
            this.m_bIsPOSPresent = true;
            this.mGanssPOSCapabilities = (SuplGanssPOSCapabilities)parcel.readParcelable(SuplGanssPOSCapabilities.class.getClassLoader());
        }
        by = parcel.readByte();
        this.m_bIsAssitancePresent = false;
        if (by != 1) return;
        this.m_bIsAssitancePresent = true;
        this.mGanssAssistCapabilities = (SuplGanssAssistCapabilities)parcel.readParcelable(SuplGanssAssistCapabilities.class.getClassLoader());
    }

    public void setPlatformSessionId(int n) {
        this.m_usPlatformSessionId = (short)n;
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("SID:");
        stringBuffer.append(this.m_usPlatformSessionId);
        if (this.m_bIsQOPPresent) {
            stringBuffer.append("QOP:");
            stringBuffer.append(this.m_stQoP.toString());
        }
        if (this.m_bIsTriggerParamsPresent) {
            stringBuffer.append("TP:");
            stringBuffer.append(this.m_stTriggerParams.toString());
        }
        if (this.m_bIsAppIdPresent) {
            stringBuffer.append("AppID:");
            stringBuffer.append(this.m_stAppId.toString());
        }
        stringBuffer.append(this.m_st3rdPartyIds.toString());
        if (this.m_bIsPOSPresent) {
            stringBuffer.append("POSCap:");
            stringBuffer.append(this.mGanssPOSCapabilities.toString());
        }
        if (!this.m_bIsAssitancePresent) return stringBuffer.toString();
        stringBuffer.append("AsCap:");
        stringBuffer.append(this.mGanssAssistCapabilities.toString());
        return stringBuffer.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        byte by = 1;
        parcel.writeInt((int)this.m_usPlatformSessionId);
        byte by2 = this.m_bIsQOPPresent ? (byte)1 : 0;
        parcel.writeByte(by2);
        if (this.m_bIsQOPPresent) {
            parcel.writeParcelable((Parcelable)this.m_stQoP, n);
        }
        by2 = this.m_bIsTriggerParamsPresent ? (byte)1 : 0;
        parcel.writeByte(by2);
        if (this.m_bIsTriggerParamsPresent) {
            parcel.writeParcelable((Parcelable)this.m_stTriggerParams, n);
        }
        by2 = this.m_bIsAppIdPresent ? (byte)1 : 0;
        parcel.writeByte(by2);
        if (this.m_bIsAppIdPresent) {
            parcel.writeParcelable((Parcelable)this.m_stAppId, n);
        }
        parcel.writeParcelable((Parcelable)this.m_st3rdPartyIds, n);
        by2 = this.m_bIsPOSPresent ? (byte)1 : 0;
        parcel.writeByte(by2);
        if (this.m_bIsPOSPresent) {
            parcel.writeParcelable((Parcelable)this.mGanssPOSCapabilities, n);
        }
        by2 = this.m_bIsAssitancePresent ? by : (byte)0;
        parcel.writeByte(by2);
        if (!this.m_bIsAssitancePresent) return;
        parcel.writeParcelable((Parcelable)this.mGanssAssistCapabilities, n);
    }
}

