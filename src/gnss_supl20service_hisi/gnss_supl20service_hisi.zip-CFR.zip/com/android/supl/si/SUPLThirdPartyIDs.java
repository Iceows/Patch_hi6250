/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;
import com.android.supl.si.SUPLThirdPartyID;

public class SUPLThirdPartyIDs
implements Parcelable {
    public static final Parcelable.Creator<SUPLThirdPartyIDs> CREATOR = new Parcelable.Creator<SUPLThirdPartyIDs>(){

        public SUPLThirdPartyIDs createFromParcel(Parcel parcel) {
            return new SUPLThirdPartyIDs(parcel);
        }

        public SUPLThirdPartyIDs[] newArray(int n) {
            return new SUPLThirdPartyIDs[n];
        }
    };
    private SUPLThirdPartyID[] mSuplThirdPartyID = null;
    private short ucValidCount;

    public SUPLThirdPartyIDs(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public SUPLThirdPartyIDs(short s, SUPLThirdPartyID[] sUPLThirdPartyIDArray) {
        this.ucValidCount = s;
        if (s > 0 && sUPLThirdPartyIDArray == null) {
            throw new IllegalArgumentException("ThirdPartyID array should not be null");
        }
        this.mSuplThirdPartyID = sUPLThirdPartyIDArray;
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getSUPLThirdPartyIDs() {
        int n;
        int n2;
        Object[] objectArray;
        int n3 = 1;
        int n4 = 1;
        if (this.ucValidCount > 0) {
            objectArray = this.mSuplThirdPartyID;
            n2 = objectArray.length;
            n = 0;
            while (true) {
                n3 = n4;
                if (n >= n2) break;
                n4 += objectArray[n].getThirdPartyID().length;
                ++n;
            }
        }
        objectArray = new byte[n3];
        n2 = n4 = IO.put1((byte[])objectArray, 0, this.ucValidCount);
        if (this.ucValidCount > 0) {
            SUPLThirdPartyID[] sUPLThirdPartyIDArray = this.mSuplThirdPartyID;
            int n5 = sUPLThirdPartyIDArray.length;
            n = 0;
            while (true) {
                n2 = n4;
                if (n >= n5) break;
                byte[] byArray = sUPLThirdPartyIDArray[n].getThirdPartyID();
                System.arraycopy((byte[])byArray, (int)0, (byte[])objectArray, (int)n4, (int)byArray.length);
                n4 += byArray.length;
                ++n;
            }
        }
        if (n2 == n3) return objectArray;
        System.err.println("ThirdPartyIDs  length invalid");
        return objectArray;
    }

    public short getValidCount() {
        return this.ucValidCount;
    }

    public void readFromParcel(Parcel parcel) {
        int n = 0;
        this.ucValidCount = (short)parcel.readInt();
        if (this.ucValidCount <= 0) return;
        Parcelable[] parcelableArray = parcel.readParcelableArray(SUPLThirdPartyID.class.getClassLoader());
        this.mSuplThirdPartyID = new SUPLThirdPartyID[parcelableArray.length];
        int n2 = parcelableArray.length;
        int n3 = 0;
        while (n < n2) {
            parcel = parcelableArray[n];
            this.mSuplThirdPartyID[n3] = (SUPLThirdPartyID)parcel;
            ++n;
            ++n3;
        }
    }

    public String toString() {
        int n = 0;
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(this.ucValidCount);
        if (this.ucValidCount <= 0) return stringBuffer.toString();
        SUPLThirdPartyID[] sUPLThirdPartyIDArray = this.mSuplThirdPartyID;
        int n2 = sUPLThirdPartyIDArray.length;
        while (n < n2) {
            SUPLThirdPartyID sUPLThirdPartyID = sUPLThirdPartyIDArray[n];
            stringBuffer.append(",");
            stringBuffer.append(sUPLThirdPartyID.toString());
            ++n;
        }
        return stringBuffer.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeInt((int)this.ucValidCount);
        if (this.ucValidCount <= 0) return;
        parcel.writeParcelableArray((Parcelable[])this.mSuplThirdPartyID, n);
    }
}

