/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.util.Log
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import com.android.bytewriter.IO;

public class SUPLSETID
implements Parcelable {
    public static final Parcelable.Creator<SUPLSETID> CREATOR = new Parcelable.Creator<SUPLSETID>(){

        public SUPLSETID createFromParcel(Parcel parcel) {
            return new SUPLSETID(parcel);
        }

        public SUPLSETID[] newArray(int n) {
            return new SUPLSETID[n];
        }
    };
    public static final int SUPL_SETID_TYPE_IMSI = 4;
    public static final int SUPL_SETID_TYPE_IPADDRESSV4 = 6;
    public static final int SUPL_SETID_TYPE_IPADDRESSV6 = 7;
    public static final int SUPL_SETID_TYPE_MDN = 2;
    public static final int SUPL_SETID_TYPE_MIN = 3;
    public static final int SUPL_SETID_TYPE_MSISDN = 1;
    public static final int SUPL_SETID_TYPE_NAI = 5;
    public static final int SUPL_SETID_TYPE_NONE = 8;
    private int iNumBytes;
    private int m_iSetIDType;
    private String stData;

    public SUPLSETID() {
    }

    public SUPLSETID(int n, String string, int n2) {
        switch (n) {
            default: {
                throw new IllegalArgumentException("invalid SETTYPE ");
            }
            case 1: {
                this.iNumBytes = 12;
                break;
            }
            case 2: {
                this.iNumBytes = 8;
                break;
            }
            case 3: {
                this.iNumBytes = 5;
                break;
            }
            case 4: {
                this.iNumBytes = 20;
                break;
            }
            case 5: {
                this.iNumBytes = 1000;
                break;
            }
            case 6: {
                this.iNumBytes = 4;
                break;
            }
            case 7: {
                this.iNumBytes = 16;
                break;
            }
            case 8: {
                this.iNumBytes = n2;
            }
        }
        this.m_iSetIDType = n;
        this.stData = string;
    }

    public SUPLSETID(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    private String addLeadingData(String string, String string2, int n) {
        if (string == null) {
            return null;
        }
        int n2 = string.length();
        if (n2 >= n) {
            return string;
        }
        StringBuffer stringBuffer = new StringBuffer();
        int n3 = 0;
        while (true) {
            if (n3 >= n - n2) {
                stringBuffer.append(string);
                return stringBuffer.toString();
            }
            stringBuffer.append(string2);
            ++n3;
        }
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getSETID() {
        int n = this.iNumBytes + 8;
        byte[] byArray = new byte[n];
        int n2 = IO.put4(byArray, IO.put4(byArray, 0, this.m_iSetIDType), this.iNumBytes);
        block0 : switch (this.m_iSetIDType) {
            case 4: {
                this.stData = this.addLeadingData(this.stData, "0", 20);
                System.arraycopy((byte[])this.stData.getBytes(), (int)0, (byte[])byArray, (int)n2, (int)this.iNumBytes);
                n2 += this.iNumBytes;
                break;
            }
            case 6: {
                String[] stringArray = this.stData.split("\\.");
                int n3 = 0;
                int n4 = stringArray.length;
                int n5 = n2;
                while (true) {
                    n2 = n5;
                    if (n3 >= n4) break block0;
                    n5 = IO.put1(byArray, n5, Integer.parseInt(stringArray[n3]));
                    ++n3;
                }
            }
            case 3: {
                n2 = IO.put5(byArray, n2, Long.parseLong(this.stData));
                break;
            }
            case 1: {
                byte[] byArray2 = this.stData.getBytes();
                this.stData = this.addLeadingData(this.stData, "0", 12);
                Log.i((String)"SUPL20_SETID", (String)("MSISDN " + this.stData));
                System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray, (int)n2, (int)byArray2.length);
                n2 += 12;
                break;
            }
            case 7: {
                String[] stringArray = this.stData.split(":");
                int n6 = 0;
                int n7 = stringArray.length;
                int n8 = n2;
                while (true) {
                    n2 = n8;
                    if (n6 >= n7) break block0;
                    String string = this.addLeadingData(stringArray[n6], "0", 4);
                    int n9 = Integer.parseInt(string.substring(0, 2), 16);
                    n2 = Integer.parseInt(string.substring(2), 16);
                    n8 = IO.put1(byArray, IO.put1(byArray, n8, n9), n2);
                    ++n6;
                }
            }
            case 2: {
                n2 = IO.put8(byArray, n2, Long.parseLong(this.stData));
                break;
            }
            case 5: {
                this.stData = this.addLeadingData(this.stData, "0", 1000);
                byte[] byArray3 = this.stData.getBytes();
                Log.i((String)"SUPL20_SETID", (String)("NAI " + this.stData));
                System.arraycopy((byte[])byArray3, (int)0, (byte[])byArray, (int)n2, (int)this.iNumBytes);
                n2 += this.iNumBytes;
                break;
            }
        }
        if (n == n2) return byArray;
        System.err.println("invalid setid packet size " + n + ": " + (n2 - 4));
        return byArray;
    }

    public void readFromParcel(Parcel parcel) {
        this.m_iSetIDType = parcel.readInt();
        this.iNumBytes = parcel.readInt();
        this.stData = parcel.readString();
    }

    public String toString() {
        return this.stData + "," + this.iNumBytes + ",SID:" + this.m_iSetIDType;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeInt(this.m_iSetIDType);
        parcel.writeInt(this.iNumBytes);
        parcel.writeString(this.stData);
    }
}

