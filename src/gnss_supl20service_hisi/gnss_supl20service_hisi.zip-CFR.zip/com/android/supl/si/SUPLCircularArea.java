/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;
import com.android.supl.si.SUPLCoordinate;

public class SUPLCircularArea
implements Parcelable {
    public static final Parcelable.Creator<SUPLCircularArea> CREATOR = new Parcelable.Creator<SUPLCircularArea>(){

        public SUPLCircularArea createFromParcel(Parcel parcel) {
            return new SUPLCircularArea(parcel);
        }

        public SUPLCircularArea[] newArray(int n) {
            return new SUPLCircularArea[n];
        }
    };
    private int nRadius;
    private int nRadiusMax;
    private int nRadiusMin;
    private SUPLCoordinate stCenter = null;

    public SUPLCircularArea(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public SUPLCircularArea(SUPLCoordinate sUPLCoordinate, int n, int n2, int n3) {
        if (sUPLCoordinate == null) {
            throw new IllegalArgumentException("Coordinate should not be null");
        }
        this.stCenter = sUPLCoordinate;
        this.nRadius = n;
        this.nRadiusMin = n2;
        this.nRadiusMax = n3;
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getCircularArea() {
        byte[] byArray = this.stCenter.getCoordinateInfo();
        int n = byArray.length + 12;
        byte[] byArray2 = new byte[n];
        System.arraycopy((byte[])byArray, (int)0, (byte[])byArray2, (int)0, (int)byArray.length);
        if (IO.put4(byArray2, IO.put4(byArray2, IO.put4(byArray2, byArray.length + 0, this.nRadius), this.nRadiusMin), this.nRadiusMax) == n) return byArray2;
        System.err.println("CircularArea length invalid");
        return byArray2;
    }

    public void readFromParcel(Parcel parcel) {
        this.stCenter = (SUPLCoordinate)parcel.readParcelable(SUPLCoordinate.class.getClassLoader());
        this.nRadius = parcel.readInt();
        this.nRadiusMin = parcel.readInt();
        this.nRadiusMax = parcel.readInt();
    }

    public String toString() {
        return "Coor:" + this.stCenter.toString() + "Rad:" + this.nRadius + "RMin" + this.nRadiusMin + "RMax" + this.nRadiusMax;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeParcelable((Parcelable)this.stCenter, n);
        parcel.writeInt(this.nRadius);
        parcel.writeInt(this.nRadiusMin);
        parcel.writeInt(this.nRadiusMax);
    }
}

