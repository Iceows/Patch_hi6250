/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;
import com.android.supl.si.ApplicationID;
import com.android.supl.si.SUPLQOPParams;
import com.android.supl.si.SUPLSETID;

public class ThirdPartyReqParams
implements Parcelable {
    public static final Parcelable.Creator<ThirdPartyReqParams> CREATOR = new Parcelable.Creator<ThirdPartyReqParams>(){

        public ThirdPartyReqParams createFromParcel(Parcel parcel) {
            return new ThirdPartyReqParams(parcel);
        }

        public ThirdPartyReqParams[] newArray(int n) {
            return new ThirdPartyReqParams[n];
        }
    };
    public static final int MSG_PCM_START_SI_OTHER_SET = 270;
    private boolean m_bIsAppIdPresent;
    private boolean m_bIsQOPPresent;
    private ApplicationID m_stAppId = null;
    private SUPLQOPParams m_stQop = null;
    private SUPLSETID m_stTargetSetId = null;
    private short m_usPlatformSessionId;

    public ThirdPartyReqParams(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public ThirdPartyReqParams(boolean bl, SUPLQOPParams sUPLQOPParams, boolean bl2, ApplicationID applicationID, SUPLSETID sUPLSETID) {
        this.m_usPlatformSessionId = (short)-1;
        this.m_bIsQOPPresent = bl;
        if (bl && sUPLQOPParams == null) {
            throw new IllegalArgumentException("QOP paramerter should not be null");
        }
        this.m_stQop = sUPLQOPParams;
        this.m_bIsAppIdPresent = bl2;
        if (bl2 && applicationID == null) {
            throw new IllegalArgumentException("ApplicationID  should not be null");
        }
        this.m_stAppId = applicationID;
        if (sUPLSETID == null) {
            throw new IllegalArgumentException("Target SETID  should not be null");
        }
        this.m_stTargetSetId = sUPLSETID;
    }

    public int describeContents() {
        return 0;
    }

    public ApplicationID getAppId() {
        return this.m_stAppId;
    }

    public byte[] getSIOnOtherSET() {
        int n = 14;
        byte[] byArray = null;
        if (this.m_bIsQOPPresent) {
            byArray = this.m_stQop.getQOPParams();
            n = byArray.length + 14;
        }
        byte[] byArray2 = null;
        int n2 = n;
        if (this.m_bIsAppIdPresent) {
            byArray2 = this.m_stAppId.getApplicationIDInfo();
            n2 = n + byArray2.length;
        }
        byte[] byArray3 = this.m_stTargetSetId.getSETID();
        byte[] byArray4 = new byte[(n2 += byArray3.length) + 4];
        n = IO.put2(byArray4, IO.put4(byArray4, 4, 270), this.m_usPlatformSessionId);
        if (this.m_bIsQOPPresent) {
            n = IO.put4(byArray4, n, 1);
            System.arraycopy((byte[])byArray, (int)0, (byte[])byArray4, (int)n, (int)byArray.length);
            n += byArray.length;
        } else {
            n = IO.put4(byArray4, n, 0);
        }
        if (this.m_bIsAppIdPresent) {
            n = IO.put4(byArray4, n, 1);
            System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray4, (int)n, (int)byArray2.length);
            n += byArray2.length;
        } else {
            n = IO.put4(byArray4, n, 0);
        }
        System.arraycopy((byte[])byArray3, (int)0, (byte[])byArray4, (int)n, (int)byArray3.length);
        int n3 = byArray3.length;
        IO.put4(byArray4, 0, n2);
        if (n + n3 - 4 == n2) return byArray4;
        System.err.println("SIOnOtherSET length invalid");
        return byArray4;
    }

    public void readFromParcel(Parcel parcel) {
        this.m_usPlatformSessionId = (short)parcel.readInt();
        this.m_bIsQOPPresent = false;
        if (parcel.readByte() == 1) {
            this.m_bIsQOPPresent = true;
            this.m_stQop = (SUPLQOPParams)parcel.readParcelable(SUPLQOPParams.class.getClassLoader());
        }
        this.m_bIsAppIdPresent = false;
        if (parcel.readByte() == 1) {
            this.m_bIsAppIdPresent = true;
            this.m_stAppId = (ApplicationID)parcel.readParcelable(ApplicationID.class.getClassLoader());
        }
        this.m_stTargetSetId = (SUPLSETID)parcel.readParcelable(SUPLSETID.class.getClassLoader());
    }

    public void setPlatformSessionId(short s) {
        this.m_usPlatformSessionId = s;
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("SID:");
        stringBuffer.append(this.m_usPlatformSessionId);
        if (this.m_bIsQOPPresent) {
            stringBuffer.append("QOP:");
            stringBuffer.append(this.m_stQop.toString());
        }
        if (this.m_bIsAppIdPresent) {
            stringBuffer.append("AppID:");
            stringBuffer.append(this.m_stAppId.toString());
        }
        stringBuffer.append("TargetSetID:" + this.m_stTargetSetId.toString());
        return stringBuffer.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        byte by = 1;
        parcel.writeInt((int)this.m_usPlatformSessionId);
        byte by2 = this.m_bIsQOPPresent ? (byte)1 : 0;
        parcel.writeByte(by2);
        if (this.m_bIsQOPPresent) {
            parcel.writeParcelable((Parcelable)this.m_stQop, n);
        }
        by2 = this.m_bIsAppIdPresent ? by : (byte)0;
        parcel.writeByte(by2);
        if (this.m_bIsAppIdPresent) {
            parcel.writeParcelable((Parcelable)this.m_stAppId, n);
        }
        parcel.writeParcelable((Parcelable)this.m_stTargetSetId, n);
    }
}

