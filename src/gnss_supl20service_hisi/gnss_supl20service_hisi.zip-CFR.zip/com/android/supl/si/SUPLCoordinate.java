/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;

public class SUPLCoordinate
implements Parcelable {
    public static final Parcelable.Creator<SUPLCoordinate> CREATOR = new Parcelable.Creator<SUPLCoordinate>(){

        public SUPLCoordinate createFromParcel(Parcel parcel) {
            return new SUPLCoordinate(parcel);
        }

        public SUPLCoordinate[] newArray(int n) {
            return new SUPLCoordinate[n];
        }
    };
    public static final double F2POW23DIV90 = 93206.755556;
    public static final double F2POW24DIV360 = 46603.377778;
    public static final int NORTH = 0;
    public static final int SIZE = 12;
    public static final int SOUTH = 1;
    private int Latitude;
    private int Longitude;
    private int iSgnType = 0;

    public SUPLCoordinate(int n, int n2, int n3) {
        if (n > 1) throw new IllegalArgumentException("invalid Sign Type");
        if (n < 0) {
            throw new IllegalArgumentException("invalid Sign Type");
        }
        this.iSgnType = n;
        this.Latitude = n2;
        this.Longitude = n3;
        if (!false) return;
        n = (int)((double)n2 * 93206.755556);
        n = (int)((double)n3 * 46603.377778);
    }

    public SUPLCoordinate(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getCoordinateInfo() {
        byte[] byArray = new byte[12];
        IO.put4(byArray, IO.put4(byArray, IO.put4(byArray, 0, this.iSgnType), this.Latitude), this.Longitude);
        return byArray;
    }

    public void readFromParcel(Parcel parcel) {
        this.iSgnType = parcel.readInt();
        this.Latitude = parcel.readInt();
        this.Longitude = parcel.readInt();
    }

    public String toString() {
        return "Sg:" + this.iSgnType + "Lat:" + this.Latitude + "Lon:" + this.Longitude;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeInt(this.iSgnType);
        parcel.writeInt(this.Latitude);
        parcel.writeInt(this.Longitude);
    }
}

