/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.si;

import java.io.DataInputStream;
import java.io.IOException;

public class SISessionComplete {
    public int m_nSessionStatus;
    public int m_usPlatformSessionId;

    public boolean readSISessionComplete(DataInputStream dataInputStream) throws IOException {
        this.m_nSessionStatus = 0;
        this.m_usPlatformSessionId = dataInputStream.readUnsignedShort();
        return true;
    }
}

