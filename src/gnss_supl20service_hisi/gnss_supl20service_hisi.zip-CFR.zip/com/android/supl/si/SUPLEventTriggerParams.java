/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;
import com.android.supl.si.SUPLAreaEventType;
import com.android.supl.si.SUPLGeoTargetArea;
import com.android.supl.si.SUPLRepeatedReportingParams;

public class SUPLEventTriggerParams
implements Parcelable {
    public static final Parcelable.Creator<SUPLEventTriggerParams> CREATOR = new Parcelable.Creator<SUPLEventTriggerParams>(){

        public SUPLEventTriggerParams createFromParcel(Parcel parcel) {
            return new SUPLEventTriggerParams(parcel);
        }

        public SUPLEventTriggerParams[] newArray(int n) {
            return new SUPLEventTriggerParams[n];
        }
    };
    private boolean bRepeatedReportingPresent;
    private long dwStartTime = 0L;
    private long dwStopTime = 8639999L;
    private long dwValidcount;
    private SUPLAreaEventType eAreaEventType = null;
    private SUPLGeoTargetArea[] stGeoTargetArea = null;
    private SUPLRepeatedReportingParams stRepeatedReportingParams = null;

    public SUPLEventTriggerParams(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public SUPLEventTriggerParams(boolean bl, SUPLAreaEventType sUPLAreaEventType, SUPLRepeatedReportingParams sUPLRepeatedReportingParams, long l, long l2, long l3, SUPLGeoTargetArea[] sUPLGeoTargetAreaArray) {
        this.bRepeatedReportingPresent = bl;
        if (bl && sUPLRepeatedReportingParams == null) {
            throw new IllegalArgumentException("Repeated Reporting Parameter shold not be null");
        }
        this.eAreaEventType = sUPLAreaEventType;
        this.stRepeatedReportingParams = sUPLRepeatedReportingParams;
        this.dwStartTime = l;
        if (l2 != 0L) {
            this.dwStopTime = l2;
        }
        if (sUPLGeoTargetAreaArray == null) {
            throw new IllegalArgumentException("GeoTargetArea shold not be null");
        }
        this.stGeoTargetArea = sUPLGeoTargetAreaArray;
        this.dwValidcount = sUPLGeoTargetAreaArray.length;
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getEventTriggerParams() {
        int n;
        byte[] byArray;
        Object[] objectArray = this.eAreaEventType.getAreaEventType();
        int n2 = objectArray.length + 16;
        byte[] byArray2 = null;
        int n3 = n2;
        if (this.bRepeatedReportingPresent) {
            byArray2 = this.stRepeatedReportingParams.getRepeatedReportingParamsInfo();
            n3 = n2 + byArray2.length;
        }
        SUPLGeoTargetArea[] sUPLGeoTargetAreaArray = this.stGeoTargetArea;
        int n4 = sUPLGeoTargetAreaArray.length;
        for (n2 = 0; n2 < n4; ++n2) {
            byArray = sUPLGeoTargetAreaArray[n2].getGeoTargetArea();
            n = n3;
            if (byArray != null) {
                n = n3 + byArray.length;
            }
            n3 = n;
        }
        byArray = new byte[n3];
        n2 = this.bRepeatedReportingPresent ? 1 : 0;
        n2 = IO.put4(byArray, 0, n2);
        System.arraycopy((byte[])objectArray, (int)0, (byte[])byArray, (int)n2, (int)objectArray.length);
        n2 = n = n2 + objectArray.length;
        if (this.bRepeatedReportingPresent) {
            System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray, (int)n, (int)byArray2.length);
            n2 = n + byArray2.length;
        }
        n = IO.put4(byArray, IO.put4(byArray, IO.put4(byArray, n2, (int)this.dwStartTime), (int)this.dwStopTime), (int)this.dwValidcount);
        objectArray = this.stGeoTargetArea;
        int n5 = objectArray.length;
        n2 = 0;
        while (true) {
            if (n2 >= n5) {
                if (n == n3) return byArray;
                System.err.println("EventTriggerParams length invalid");
                return byArray;
            }
            byArray2 = objectArray[n2].getGeoTargetArea();
            n4 = n;
            if (byArray2 != null) {
                System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray, (int)n, (int)byArray2.length);
                n4 = n + byArray2.length;
            }
            ++n2;
            n = n4;
        }
    }

    public void readFromParcel(Parcel parcelableArray) {
        int n = parcelableArray.readByte();
        this.bRepeatedReportingPresent = false;
        if (n == 1) {
            this.bRepeatedReportingPresent = true;
        }
        this.eAreaEventType = (SUPLAreaEventType)parcelableArray.readParcelable(SUPLAreaEventType.class.getClassLoader());
        if (this.bRepeatedReportingPresent) {
            this.stRepeatedReportingParams = (SUPLRepeatedReportingParams)parcelableArray.readParcelable(SUPLRepeatedReportingParams.class.getClassLoader());
        }
        this.dwStartTime = parcelableArray.readLong();
        this.dwStopTime = parcelableArray.readLong();
        this.dwValidcount = parcelableArray.readLong();
        parcelableArray = parcelableArray.readParcelableArray(SUPLGeoTargetArea.class.getClassLoader());
        this.stGeoTargetArea = new SUPLGeoTargetArea[parcelableArray.length];
        int n2 = parcelableArray.length;
        int n3 = 0;
        n = 0;
        while (n3 < n2) {
            Parcelable parcelable = parcelableArray[n3];
            this.stGeoTargetArea[n] = (SUPLGeoTargetArea)parcelable;
            ++n3;
            ++n;
        }
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("AE:");
        stringBuffer.append(this.eAreaEventType.toString());
        if (this.bRepeatedReportingPresent) {
            stringBuffer.append("Rp:");
            stringBuffer.append(this.stRepeatedReportingParams.toString());
        }
        stringBuffer.append(this.dwStartTime);
        stringBuffer.append(",");
        stringBuffer.append(this.dwStopTime);
        stringBuffer.append(",");
        stringBuffer.append(this.dwValidcount);
        stringBuffer.append(",");
        stringBuffer.append("GTA");
        stringBuffer.append(this.stGeoTargetArea.toString());
        return stringBuffer.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        byte by = this.bRepeatedReportingPresent ? (byte)1 : 0;
        parcel.writeByte(by);
        parcel.writeParcelable((Parcelable)this.eAreaEventType, n);
        if (this.bRepeatedReportingPresent) {
            parcel.writeParcelable((Parcelable)this.stRepeatedReportingParams, n);
        }
        parcel.writeLong(this.dwStartTime);
        parcel.writeLong(this.dwStopTime);
        parcel.writeLong(this.dwValidcount);
        parcel.writeParcelableArray((Parcelable[])this.stGeoTargetArea, n);
    }
}

