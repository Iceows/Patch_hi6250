/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;

public class SUPLAreaEventType
implements Parcelable {
    public static final Parcelable.Creator<SUPLAreaEventType> CREATOR = new Parcelable.Creator<SUPLAreaEventType>(){

        public SUPLAreaEventType createFromParcel(Parcel parcel) {
            return new SUPLAreaEventType(parcel);
        }

        public SUPLAreaEventType[] newArray(int n) {
            return new SUPLAreaEventType[n];
        }
    };
    public static final int ENTERINGAREA = 0;
    public static final int INSIDEAREA = 1;
    public static final int LEAVINGAREA = 3;
    public static final int OUTSIDEAREA = 2;
    private int iAreaEventType = 0;

    public SUPLAreaEventType(int n) {
        if (n > 3) throw new IllegalArgumentException("invalid AreaEvent type");
        if (n < 0) {
            throw new IllegalArgumentException("invalid AreaEvent type");
        }
        this.iAreaEventType = n;
    }

    public SUPLAreaEventType(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getAreaEventType() {
        byte[] byArray = new byte[4];
        IO.put4(byArray, 0, this.iAreaEventType);
        return byArray;
    }

    public void readFromParcel(Parcel parcel) {
        this.iAreaEventType = parcel.readInt();
    }

    public String toString() {
        return "AE:" + this.iAreaEventType;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeInt(this.iAreaEventType);
    }
}

