/*
 * Decompiled with CFR 0.151.
 */
package com.android.supl.si;

import com.android.bytewriter.IO;

public class StopSITrigSessParams {
    public static final int MSG_PCM_STOP_SI = 271;
    public int iSessionID = 0;

    public StopSITrigSessParams(int n) {
        this.iSessionID = n;
    }

    public byte[] getStopSIInfo() {
        byte[] byArray = new byte[10];
        if (IO.put2(byArray, IO.put4(byArray, IO.put4(byArray, 0, 6), 271), this.iSessionID) - 4 == 6) return byArray;
        System.err.println("invalid length in  getStopSIInfo");
        return byArray;
    }
}

