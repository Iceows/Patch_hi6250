/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;
import com.android.supl.si.SUPLCircularArea;
import com.android.supl.si.SUPLEllipticalArea;
import com.android.supl.si.SUPLPolygonArea;

public class SUPLGeoTargetArea
implements Parcelable {
    public static final Parcelable.Creator<SUPLGeoTargetArea> CREATOR = new Parcelable.Creator<SUPLGeoTargetArea>(){

        public SUPLGeoTargetArea createFromParcel(Parcel parcel) {
            return new SUPLGeoTargetArea(parcel);
        }

        public SUPLGeoTargetArea[] newArray(int n) {
            return new SUPLGeoTargetArea[n];
        }
    };
    public static final int SUPL_CIRCULAR_AREA = 0;
    public static final int SUPL_ELLIPTICAL_AREA = 1;
    public static final int SUPL_POLYGONIC_AREA = 2;
    private int eGeoAreaType;
    private Object objGeographicArea = null;

    public SUPLGeoTargetArea(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public SUPLGeoTargetArea(Object object, int n) {
        if (object == null) {
            throw new IllegalArgumentException("Geo Area object should not be null");
        }
        switch (n) {
            default: {
                throw new IllegalArgumentException("invalid Geo Area type");
            }
            case 0: {
                this.eGeoAreaType = 0;
                if (object instanceof SUPLCircularArea) break;
                throw new IllegalArgumentException("Geo Area object is not SUPLCircularArea type ");
            }
            case 1: {
                this.eGeoAreaType = 1;
                if (object instanceof SUPLEllipticalArea) break;
                throw new IllegalArgumentException("Geo Area object is not SUPLEllipticalArea type ");
            }
            case 2: {
                this.eGeoAreaType = 2;
                if (object instanceof SUPLPolygonArea) break;
                throw new IllegalArgumentException("Geo Area object is not SUPLPolygonArea type ");
            }
        }
        this.objGeographicArea = object;
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getGeoTargetArea() {
        int n = 4;
        int n2 = 0;
        byte[] byArray = null;
        switch (this.eGeoAreaType) {
            case 0: {
                byArray = ((SUPLCircularArea)this.objGeographicArea).getCircularArea();
                break;
            }
            case 1: {
                byArray = ((SUPLEllipticalArea)this.objGeographicArea).getEllipticalAreaInfo();
                break;
            }
            case 2: {
                byArray = ((SUPLPolygonArea)this.objGeographicArea).getPolygonAreaInfo();
                break;
            }
        }
        byte[] byArray2 = null;
        if (byArray != null) {
            n = byArray.length + 4;
            byArray2 = new byte[n];
            n2 = IO.put4(byArray2, 0, this.eGeoAreaType);
            System.arraycopy((byte[])byArray, (int)0, (byte[])byArray2, (int)n2, (int)byArray.length);
            n2 += byArray.length;
        }
        if (n2 == n) return byArray2;
        System.err.println("GeoTargetArea length invalid");
        return byArray2;
    }

    public void readFromParcel(Parcel parcel) {
        this.eGeoAreaType = parcel.readInt();
        switch (this.eGeoAreaType) {
            case 0: {
                this.objGeographicArea = parcel.readParcelable(SUPLCircularArea.class.getClassLoader());
                return;
            }
            case 1: {
                this.objGeographicArea = parcel.readParcelable(SUPLEllipticalArea.class.getClassLoader());
                return;
            }
            case 2: {
                this.objGeographicArea = parcel.readParcelable(SUPLPolygonArea.class.getClassLoader());
                return;
            }
        }
    }

    public String toString() {
        String string = null;
        switch (this.eGeoAreaType) {
            case 0: {
                string = "Circular:" + ((SUPLCircularArea)this.objGeographicArea).toString();
                return this.eGeoAreaType + "," + string;
            }
            case 1: {
                string = "Elli:" + ((SUPLEllipticalArea)this.objGeographicArea).toString();
                return this.eGeoAreaType + "," + string;
            }
            case 2: {
                string = "Poly:" + ((SUPLPolygonArea)this.objGeographicArea).toString();
                return this.eGeoAreaType + "," + string;
            }
        }
        return this.eGeoAreaType + "," + string;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeInt(this.eGeoAreaType);
        switch (this.eGeoAreaType) {
            case 0: {
                parcel.writeParcelable((Parcelable)((SUPLCircularArea)this.objGeographicArea), n);
                return;
            }
            case 1: {
                parcel.writeParcelable((Parcelable)((SUPLEllipticalArea)this.objGeographicArea), n);
                return;
            }
            case 2: {
                parcel.writeParcelable((Parcelable)((SUPLPolygonArea)this.objGeographicArea), n);
                return;
            }
        }
    }
}

