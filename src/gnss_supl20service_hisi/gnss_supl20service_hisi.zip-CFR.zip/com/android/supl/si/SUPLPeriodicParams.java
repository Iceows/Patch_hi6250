/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;

public class SUPLPeriodicParams
implements Parcelable {
    public static final Parcelable.Creator<SUPLPeriodicParams> CREATOR = new Parcelable.Creator<SUPLPeriodicParams>(){

        public SUPLPeriodicParams createFromParcel(Parcel parcel) {
            return new SUPLPeriodicParams(parcel);
        }

        public SUPLPeriodicParams[] newArray(int n) {
            return new SUPLPeriodicParams[n];
        }
    };
    private long dwIntervalBetweenFixes;
    private long dwNoofFixes;
    private long dwStartTime;

    public SUPLPeriodicParams(long l, long l2, long l3) {
        this.dwStartTime = l;
        this.dwNoofFixes = l2;
        this.dwIntervalBetweenFixes = l3;
    }

    public SUPLPeriodicParams(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getPeriodicParams() {
        byte[] byArray = new byte[12];
        int n = IO.put4(byArray, 0, (int)this.dwStartTime);
        System.out.println("dwStartTime = " + this.dwStartTime);
        n = IO.put4(byArray, n, (int)this.dwNoofFixes);
        System.out.println("dwNoofFixes = " + this.dwNoofFixes);
        IO.put4(byArray, n, (int)this.dwIntervalBetweenFixes);
        System.out.println("dwIntervalBetweenFixes = " + this.dwIntervalBetweenFixes);
        return byArray;
    }

    public void readFromParcel(Parcel parcel) {
        this.dwStartTime = parcel.readLong();
        this.dwNoofFixes = parcel.readLong();
        this.dwIntervalBetweenFixes = parcel.readLong();
    }

    public String toString() {
        return this.dwStartTime + "," + this.dwNoofFixes + "," + this.dwIntervalBetweenFixes;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeLong(this.dwStartTime);
        parcel.writeLong(this.dwNoofFixes);
        parcel.writeLong(this.dwIntervalBetweenFixes);
    }
}

