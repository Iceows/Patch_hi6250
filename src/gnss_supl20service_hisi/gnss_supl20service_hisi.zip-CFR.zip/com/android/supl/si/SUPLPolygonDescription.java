/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;
import com.android.supl.si.SUPLCoordinate;

public class SUPLPolygonDescription
implements Parcelable {
    public static final Parcelable.Creator<SUPLPolygonDescription> CREATOR = new Parcelable.Creator<SUPLPolygonDescription>(){

        public SUPLPolygonDescription createFromParcel(Parcel parcel) {
            return new SUPLPolygonDescription(parcel);
        }

        public SUPLPolygonDescription[] newArray(int n) {
            return new SUPLPolygonDescription[n];
        }
    };
    private int nValidCoordinates;
    private SUPLCoordinate[] stCoordinate = null;

    public SUPLPolygonDescription(int n, SUPLCoordinate[] sUPLCoordinateArray) {
        this.nValidCoordinates = n;
        if (n > 0 && sUPLCoordinateArray == null) {
            throw new IllegalArgumentException("Coordinate value should not be null");
        }
        this.stCoordinate = sUPLCoordinateArray;
    }

    public SUPLPolygonDescription(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getPolygonDescription() {
        int n;
        int n2 = this.nValidCoordinates * 12 + 4;
        byte[] byArray = new byte[n2];
        int n3 = n = IO.put4(byArray, 0, this.nValidCoordinates);
        if (this.nValidCoordinates > 0) {
            SUPLCoordinate[] sUPLCoordinateArray = this.stCoordinate;
            int n4 = sUPLCoordinateArray.length;
            int n5 = 0;
            while (true) {
                n3 = n;
                if (n5 >= n4) break;
                byte[] byArray2 = sUPLCoordinateArray[n5].getCoordinateInfo();
                System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray, (int)n, (int)byArray2.length);
                n += byArray2.length;
                ++n5;
            }
        }
        if (n3 == n2) return byArray;
        System.err.println("PolygonDescription length invalid");
        return byArray;
    }

    public void readFromParcel(Parcel parcelableArray) {
        int n = 0;
        this.nValidCoordinates = parcelableArray.readInt();
        if (this.nValidCoordinates <= 0) return;
        parcelableArray = parcelableArray.readParcelableArray(SUPLCoordinate.class.getClassLoader());
        this.stCoordinate = new SUPLCoordinate[parcelableArray.length];
        int n2 = parcelableArray.length;
        int n3 = 0;
        while (n < n2) {
            Parcelable parcelable = parcelableArray[n];
            this.stCoordinate[n3] = (SUPLCoordinate)parcelable;
            ++n;
            ++n3;
        }
    }

    public String toString() {
        int n = 0;
        StringBuffer stringBuffer = new StringBuffer();
        if (this.nValidCoordinates <= 0) return stringBuffer.toString();
        stringBuffer.append(this.nValidCoordinates);
        stringBuffer.append(",");
        SUPLCoordinate[] sUPLCoordinateArray = this.stCoordinate;
        int n2 = sUPLCoordinateArray.length;
        while (n < n2) {
            stringBuffer.append(sUPLCoordinateArray[n].toString());
            stringBuffer.append(",");
            ++n;
        }
        return stringBuffer.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeInt(this.nValidCoordinates);
        if (this.nValidCoordinates <= 0) return;
        parcel.writeParcelableArray((Parcelable[])this.stCoordinate, n);
    }
}

