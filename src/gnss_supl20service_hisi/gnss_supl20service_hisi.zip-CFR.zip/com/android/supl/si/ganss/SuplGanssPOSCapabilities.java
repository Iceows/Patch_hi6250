/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si.ganss;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;
import com.android.supl.si.ganss.SuplGanssPOSElem;

public class SuplGanssPOSCapabilities
implements Parcelable {
    public static final Parcelable.Creator<SuplGanssPOSCapabilities> CREATOR = new Parcelable.Creator<SuplGanssPOSCapabilities>(){

        public SuplGanssPOSCapabilities createFromParcel(Parcel parcel) {
            return new SuplGanssPOSCapabilities(parcel);
        }

        public SuplGanssPOSCapabilities[] newArray(int n) {
            return new SuplGanssPOSCapabilities[n];
        }
    };
    public static final int SUPL_GANSS_TYPE_MAX_CNT = 8;
    SuplGanssPOSElem[] elem = null;
    private int ucGanssCnt;

    public SuplGanssPOSCapabilities(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public SuplGanssPOSCapabilities(SuplGanssPOSElem[] suplGanssPOSElemArray) {
        if (suplGanssPOSElemArray == null) {
            throw new IllegalArgumentException("SuplGanssPOSElement should not be null");
        }
        this.ucGanssCnt = suplGanssPOSElemArray.length;
        if (this.ucGanssCnt > 8) {
            throw new IllegalArgumentException("Count should not exceed to8");
        }
        this.elem = suplGanssPOSElemArray;
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getPOSCapabilities() {
        int n = this.ucGanssCnt * SuplGanssPOSElem.getPacketSize() + 1;
        byte[] byArray = new byte[n];
        int n2 = IO.put1(byArray, 0, this.ucGanssCnt);
        SuplGanssPOSElem[] suplGanssPOSElemArray = this.elem;
        int n3 = suplGanssPOSElemArray.length;
        int n4 = 0;
        while (true) {
            if (n4 >= n3) {
                if (n == n2) return byArray;
                System.err.println("getPOSCapabilities size invalid");
                return byArray;
            }
            byte[] byArray2 = suplGanssPOSElemArray[n4].getPOSElem();
            System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray, (int)n2, (int)byArray2.length);
            n2 += byArray2.length;
            ++n4;
        }
    }

    public void readFromParcel(Parcel parcelableArray) {
        int n = 0;
        this.ucGanssCnt = parcelableArray.readInt();
        if (this.ucGanssCnt <= 0) return;
        parcelableArray = parcelableArray.readParcelableArray(SuplGanssPOSElem.class.getClassLoader());
        this.elem = new SuplGanssPOSElem[parcelableArray.length];
        int n2 = parcelableArray.length;
        int n3 = 0;
        while (n < n2) {
            Parcelable parcelable = parcelableArray[n];
            this.elem[n3] = (SuplGanssPOSElem)parcelable;
            ++n;
            ++n3;
        }
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(this.ucGanssCnt).append(",");
        SuplGanssPOSElem[] suplGanssPOSElemArray = this.elem;
        int n = 0;
        int n2 = suplGanssPOSElemArray.length;
        while (true) {
            if (n >= n2) {
                stringBuffer.deleteCharAt(stringBuffer.length() - 1);
                return stringBuffer.toString();
            }
            stringBuffer.append(suplGanssPOSElemArray[n].toString());
            stringBuffer.append(",");
            ++n;
        }
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeInt(this.ucGanssCnt);
        if (this.ucGanssCnt <= 0) return;
        parcel.writeParcelableArray((Parcelable[])this.elem, n);
    }
}

