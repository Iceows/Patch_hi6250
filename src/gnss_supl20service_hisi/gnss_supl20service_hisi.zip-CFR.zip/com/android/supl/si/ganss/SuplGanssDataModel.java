/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si.ganss;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;

public class SuplGanssDataModel
implements Parcelable {
    public static final Parcelable.Creator<SuplGanssDataModel> CREATOR = new Parcelable.Creator<SuplGanssDataModel>(){

        public SuplGanssDataModel createFromParcel(Parcel parcel) {
            return new SuplGanssDataModel(parcel);
        }

        public SuplGanssDataModel[] newArray(int n) {
            return new SuplGanssDataModel[n];
        }
    };
    public int ucAlmModel;
    public int ucClkModel;
    public int ucOrbModel;
    public int ucUtcModel;

    public SuplGanssDataModel() {
    }

    public SuplGanssDataModel(int n, int n2, int n3, int n4) {
        this.ucOrbModel = n;
        this.ucClkModel = n2;
        this.ucAlmModel = n3;
        this.ucUtcModel = n4;
    }

    public SuplGanssDataModel(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public static int getPacketSize() {
        return 4;
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getDataModel() {
        byte[] byArray = new byte[SuplGanssDataModel.getPacketSize()];
        IO.put1(byArray, IO.put1(byArray, IO.put1(byArray, IO.put1(byArray, 0, this.ucOrbModel), this.ucClkModel), this.ucAlmModel), this.ucUtcModel);
        return byArray;
    }

    public void readFromParcel(Parcel parcel) {
        this.ucOrbModel = parcel.readInt();
        this.ucClkModel = parcel.readInt();
        this.ucAlmModel = parcel.readInt();
        this.ucUtcModel = parcel.readInt();
    }

    public String toString() {
        return this.ucOrbModel + "," + this.ucClkModel + "," + this.ucAlmModel + "," + this.ucUtcModel;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeInt(this.ucOrbModel);
        parcel.writeInt(this.ucClkModel);
        parcel.writeInt(this.ucAlmModel);
        parcel.writeInt(this.ucUtcModel);
    }
}

