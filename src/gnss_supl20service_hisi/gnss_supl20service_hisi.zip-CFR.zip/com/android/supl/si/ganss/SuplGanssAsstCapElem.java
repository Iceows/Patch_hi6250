/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si.ganss;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;
import com.android.supl.si.ganss.SuplGanssDataModel;

public class SuplGanssAsstCapElem
implements Parcelable {
    public static final Parcelable.Creator<SuplGanssAsstCapElem> CREATOR = new Parcelable.Creator<SuplGanssAsstCapElem>(){

        public SuplGanssAsstCapElem createFromParcel(Parcel parcel) {
            return new SuplGanssAsstCapElem(parcel);
        }

        public SuplGanssAsstCapElem[] newArray(int n) {
            return new SuplGanssAsstCapElem[n];
        }
    };
    public int eGanssId;
    public SuplGanssDataModel ganssDataModels = null;
    public int uiAsstCapBitmap;

    public SuplGanssAsstCapElem() {
    }

    public SuplGanssAsstCapElem(int n, int n2, SuplGanssDataModel suplGanssDataModel) {
        this.eGanssId = n;
        this.uiAsstCapBitmap = n2;
        if (suplGanssDataModel == null) {
            throw new IllegalArgumentException("SuplGanssDataModel should not be null");
        }
        this.ganssDataModels = suplGanssDataModel;
    }

    public SuplGanssAsstCapElem(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public static int getPacketSize() {
        return SuplGanssDataModel.getPacketSize() + 8;
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getAsstCapElem() {
        int n = SuplGanssAsstCapElem.getPacketSize();
        byte[] byArray = new byte[n];
        int n2 = IO.put4(byArray, IO.put4(byArray, 0, this.eGanssId), this.uiAsstCapBitmap);
        byte[] byArray2 = this.ganssDataModels.getDataModel();
        System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray, (int)n2, (int)byArray2.length);
        if (n == n2 + byArray2.length) return byArray;
        System.err.println("getAsstCapElem size invalid");
        return byArray;
    }

    public void readFromParcel(Parcel parcel) {
        this.eGanssId = parcel.readInt();
        this.uiAsstCapBitmap = parcel.readInt();
        this.ganssDataModels = (SuplGanssDataModel)parcel.readParcelable(SuplGanssDataModel.class.getClassLoader());
    }

    public String toString() {
        return this.eGanssId + "," + this.uiAsstCapBitmap + "," + this.ganssDataModels;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeInt(this.eGanssId);
        parcel.writeInt(this.uiAsstCapBitmap);
        parcel.writeParcelable((Parcelable)this.ganssDataModels, n);
    }
}

