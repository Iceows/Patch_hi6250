/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si.ganss;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;
import com.android.supl.si.ganss.SuplGanssAsstCapElem;
import com.android.supl.si.ganss.SuplGanssPOSElem;

public class SuplGanssAssistCapabilities
implements Parcelable {
    public static final Parcelable.Creator<SuplGanssAssistCapabilities> CREATOR = new Parcelable.Creator<SuplGanssAssistCapabilities>(){

        public SuplGanssAssistCapabilities createFromParcel(Parcel parcel) {
            return new SuplGanssAssistCapabilities(parcel);
        }

        public SuplGanssAssistCapabilities[] newArray(int n) {
            return new SuplGanssAssistCapabilities[n];
        }
    };
    private SuplGanssAsstCapElem[] asstCapElem = null;
    private int ucGanssCnt;
    private int uiAsstCmnCapBitmap;

    public SuplGanssAssistCapabilities(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public SuplGanssAssistCapabilities(SuplGanssAsstCapElem[] suplGanssAsstCapElemArray, int n) {
        if (suplGanssAsstCapElemArray == null) {
            throw new IllegalArgumentException("SuplGanssAsstCapElement should not be null");
        }
        this.ucGanssCnt = suplGanssAsstCapElemArray.length;
        if (this.ucGanssCnt > 8) {
            throw new IllegalArgumentException("Count should not exceed to8");
        }
        this.asstCapElem = suplGanssAsstCapElemArray;
        this.uiAsstCmnCapBitmap = n;
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getAsstCapElem() {
        int n = this.ucGanssCnt * SuplGanssAsstCapElem.getPacketSize() + 5;
        byte[] byArray = new byte[n];
        int n2 = IO.put1(byArray, IO.put4(byArray, 0, this.uiAsstCmnCapBitmap), this.ucGanssCnt);
        SuplGanssAsstCapElem[] suplGanssAsstCapElemArray = this.asstCapElem;
        int n3 = suplGanssAsstCapElemArray.length;
        int n4 = 0;
        while (true) {
            if (n4 >= n3) {
                if (n == n2) return byArray;
                System.err.println("getAsstCapElem size invalid");
                return byArray;
            }
            byte[] byArray2 = suplGanssAsstCapElemArray[n4].getAsstCapElem();
            System.arraycopy((byte[])byArray2, (int)0, (byte[])byArray, (int)n2, (int)byArray2.length);
            n2 += byArray2.length;
            ++n4;
        }
    }

    public void readFromParcel(Parcel parcel) {
        int n = 0;
        this.uiAsstCmnCapBitmap = parcel.readInt();
        this.ucGanssCnt = parcel.readInt();
        if (this.ucGanssCnt <= 0) return;
        Parcelable[] parcelableArray = parcel.readParcelableArray(SuplGanssPOSElem.class.getClassLoader());
        this.asstCapElem = new SuplGanssAsstCapElem[parcelableArray.length];
        int n2 = parcelableArray.length;
        int n3 = 0;
        while (n < n2) {
            parcel = parcelableArray[n];
            this.asstCapElem[n3] = (SuplGanssAsstCapElem)parcel;
            ++n;
            ++n3;
        }
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(this.uiAsstCmnCapBitmap).append(",");
        SuplGanssAsstCapElem[] suplGanssAsstCapElemArray = this.asstCapElem;
        int n = 0;
        int n2 = suplGanssAsstCapElemArray.length;
        while (true) {
            if (n >= n2) {
                stringBuffer.deleteCharAt(stringBuffer.length() - 1);
                return stringBuffer.toString();
            }
            stringBuffer.append(suplGanssAsstCapElemArray[n].toString());
            stringBuffer.append(",");
            ++n;
        }
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeInt(this.uiAsstCmnCapBitmap);
        parcel.writeInt(this.ucGanssCnt);
        if (this.ucGanssCnt <= 0) return;
        parcel.writeParcelableArray((Parcelable[])this.asstCapElem, n);
    }
}

