/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si.ganss;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;

public class SuplGanssPOSElem
implements Parcelable {
    public static final Parcelable.Creator<SuplGanssPOSElem> CREATOR = new Parcelable.Creator<SuplGanssPOSElem>(){

        public SuplGanssPOSElem createFromParcel(Parcel parcel) {
            return new SuplGanssPOSElem(parcel);
        }

        public SuplGanssPOSElem[] newArray(int n) {
            return new SuplGanssPOSElem[n];
        }
    };
    public static final int SUPL_GANSS_ID_GALILEO = 16;
    public static final int SUPL_GANSS_ID_GLONASS = 8;
    public static final int SUPL_GANSS_ID_MODERNGPS = 2;
    public static final int SUPL_GANSS_ID_QZSS = 4;
    public static final int SUPL_GANSS_ID_RESERVED2 = 32;
    public static final int SUPL_GANSS_ID_RESERVED3 = 64;
    public static final int SUPL_GANSS_ID_RESERVED4 = 128;
    public static final int SUPL_GANSS_ID_SBAS = 1;
    public int eGanssId;
    public int ucPosCapBitmap;
    public int ucSBASBitmap;
    public int ucSignalBitmap;

    public SuplGanssPOSElem() {
    }

    public SuplGanssPOSElem(int n, int n2, int n3, int n4) {
        this.eGanssId = n;
        this.ucPosCapBitmap = n2;
        this.ucSignalBitmap = n3;
        this.ucSBASBitmap = n4;
    }

    public SuplGanssPOSElem(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public static int getPacketSize() {
        return 7;
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getPOSElem() {
        byte[] byArray = new byte[SuplGanssPOSElem.getPacketSize()];
        IO.put1(byArray, IO.put1(byArray, IO.put1(byArray, IO.put4(byArray, 0, this.eGanssId), this.ucPosCapBitmap), this.ucSignalBitmap), this.ucSBASBitmap);
        return byArray;
    }

    public void readFromParcel(Parcel parcel) {
        this.eGanssId = parcel.readInt();
        this.ucPosCapBitmap = parcel.readInt();
        this.ucSignalBitmap = parcel.readInt();
        this.ucSBASBitmap = parcel.readInt();
    }

    public String toString() {
        return this.eGanssId + "," + this.ucPosCapBitmap + "," + this.ucSignalBitmap + "," + this.ucSBASBitmap;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeInt(this.eGanssId);
        parcel.writeInt(this.ucPosCapBitmap);
        parcel.writeInt(this.ucSignalBitmap);
        parcel.writeInt(this.ucSBASBitmap);
    }
}

