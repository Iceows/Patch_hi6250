/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;
import com.android.supl.si.SUPLEventTriggerParams;
import com.android.supl.si.SUPLPeriodicParams;

public class SUPLTriggerParams
implements Parcelable {
    public static final Parcelable.Creator<SUPLTriggerParams> CREATOR = new Parcelable.Creator<SUPLTriggerParams>(){

        public SUPLTriggerParams createFromParcel(Parcel parcel) {
            return new SUPLTriggerParams(parcel);
        }

        public SUPLTriggerParams[] newArray(int n) {
            return new SUPLTriggerParams[n];
        }
    };
    public static final int SUPL_TRIGGERTYPE_EVENT = 1;
    public static final int SUPL_TRIGGERTYPE_PERIODIC = 0;
    private int eTriggerReqType;
    private Object objTriggerParam = null;

    public SUPLTriggerParams(int n, Object object) {
        if (object == null) {
            throw new IllegalArgumentException("TriggerParamater object should not be null");
        }
        switch (n) {
            default: {
                throw new IllegalArgumentException("Trigger parameter value invalid");
            }
            case 0: {
                this.eTriggerReqType = 0;
                if (object instanceof SUPLPeriodicParams) break;
                throw new IllegalArgumentException("TriggerParamater object is not a SUPLPeriodicParams type");
            }
            case 1: {
                this.eTriggerReqType = 1;
                if (object instanceof SUPLEventTriggerParams) break;
                throw new IllegalArgumentException("TriggerParamater object is not a SUPLEventTriggerParams type");
            }
        }
        this.objTriggerParam = object;
    }

    public SUPLTriggerParams(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getTriggerParam() {
        int n = 0;
        int n2 = 4;
        byte[] byArray = null;
        switch (this.eTriggerReqType) {
            case 0: {
                byArray = ((SUPLPeriodicParams)this.objTriggerParam).getPeriodicParams();
                break;
            }
            case 1: {
                byArray = ((SUPLEventTriggerParams)this.objTriggerParam).getEventTriggerParams();
                break;
            }
        }
        byte[] byArray2 = null;
        if (byArray != null) {
            n2 = byArray.length + 4;
            byArray2 = new byte[n2];
            n = IO.put4(byArray2, 0, this.eTriggerReqType);
            System.arraycopy((byte[])byArray, (int)0, (byte[])byArray2, (int)n, (int)byArray.length);
            n += byArray.length;
        }
        if (n == n2) return byArray2;
        System.err.println("TriggerParam length invalid");
        return byArray2;
    }

    public int getTriggerReqType() {
        return this.eTriggerReqType;
    }

    public void readFromParcel(Parcel parcel) {
        this.eTriggerReqType = parcel.readInt();
        switch (this.eTriggerReqType) {
            case 0: {
                this.objTriggerParam = parcel.readParcelable(SUPLPeriodicParams.class.getClassLoader());
                return;
            }
            case 1: {
                this.objTriggerParam = parcel.readParcelable(SUPLEventTriggerParams.class.getClassLoader());
                return;
            }
        }
    }

    public String toString() {
        String string = null;
        switch (this.eTriggerReqType) {
            case 0: {
                string = ((SUPLPeriodicParams)this.objTriggerParam).toString();
                return this.eTriggerReqType + "," + string;
            }
            case 1: {
                string = ((SUPLEventTriggerParams)this.objTriggerParam).toString();
                return this.eTriggerReqType + "," + string;
            }
        }
        return this.eTriggerReqType + "," + string;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeInt(this.eTriggerReqType);
        switch (this.eTriggerReqType) {
            case 0: {
                parcel.writeParcelable((Parcelable)((SUPLPeriodicParams)this.objTriggerParam), n);
                return;
            }
            case 1: {
                parcel.writeParcelable((Parcelable)((SUPLEventTriggerParams)this.objTriggerParam), n);
                return;
            }
        }
    }
}

