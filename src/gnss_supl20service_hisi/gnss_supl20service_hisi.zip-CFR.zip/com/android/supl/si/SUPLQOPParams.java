/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;

public class SUPLQOPParams
implements Parcelable {
    public static final Parcelable.Creator<SUPLQOPParams> CREATOR = new Parcelable.Creator<SUPLQOPParams>(){

        public SUPLQOPParams createFromParcel(Parcel parcel) {
            return new SUPLQOPParams(parcel);
        }

        public SUPLQOPParams[] newArray(int n) {
            return new SUPLQOPParams[n];
        }
    };
    private boolean bMaxLocAgePresent;
    private boolean bVeraccPresent;
    private boolean bdelayPresent;
    public int byDelay;
    public int byHorAcc;
    public int byVerAcc;
    public int wMaxLocAge;

    public SUPLQOPParams(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public SUPLQOPParams(boolean bl, boolean bl2, boolean bl3, int n, int n2, int n3, int n4) {
        this.bVeraccPresent = bl;
        this.bMaxLocAgePresent = bl2;
        this.bdelayPresent = bl3;
        this.byHorAcc = n;
        this.byVerAcc = n2;
        this.wMaxLocAge = n3;
        this.byDelay = n4;
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getQOPParams() {
        int n = 1;
        int n2 = 13;
        if (this.bVeraccPresent) {
            n2 = 14;
        }
        int n3 = n2;
        if (this.bMaxLocAgePresent) {
            n3 = n2 + 2;
        }
        n2 = n3;
        if (this.bdelayPresent) {
            n2 = n3 + 4;
        }
        byte[] byArray = new byte[n2];
        n3 = this.bVeraccPresent ? 1 : 0;
        n2 = IO.put4(byArray, 0, n3);
        n3 = this.bMaxLocAgePresent ? 1 : 0;
        n2 = IO.put4(byArray, n2, n3);
        n3 = this.bdelayPresent ? n : 0;
        n3 = n2 = IO.put1(byArray, IO.put4(byArray, n2, n3), this.byHorAcc);
        if (this.bVeraccPresent) {
            n3 = IO.put1(byArray, n2, this.byVerAcc);
        }
        n2 = n3;
        if (this.bMaxLocAgePresent) {
            n2 = IO.put2(byArray, n3, this.wMaxLocAge);
        }
        if (!this.bdelayPresent) return byArray;
        IO.put4(byArray, n2, this.byDelay);
        return byArray;
    }

    public void readFromParcel(Parcel parcel) {
        this.bVeraccPresent = false;
        if (parcel.readByte() == 1) {
            this.bVeraccPresent = true;
        }
        this.bMaxLocAgePresent = false;
        if (parcel.readByte() == 1) {
            this.bMaxLocAgePresent = true;
        }
        this.bdelayPresent = false;
        if (parcel.readByte() == 1) {
            this.bdelayPresent = true;
        }
        this.byHorAcc = parcel.readInt();
        if (this.bVeraccPresent) {
            this.byVerAcc = parcel.readInt();
        }
        if (this.bMaxLocAgePresent) {
            this.wMaxLocAge = parcel.readInt();
        }
        if (!this.bdelayPresent) return;
        this.byDelay = parcel.readInt();
    }

    public String toString() {
        return this.byHorAcc + "," + this.byVerAcc + "," + this.wMaxLocAge + "," + this.byDelay;
    }

    public void writeToParcel(Parcel parcel, int n) {
        byte by = 1;
        byte by2 = this.bVeraccPresent ? (byte)1 : 0;
        parcel.writeByte(by2);
        by2 = this.bMaxLocAgePresent ? (byte)1 : 0;
        parcel.writeByte(by2);
        by2 = this.bdelayPresent ? by : (byte)0;
        parcel.writeByte(by2);
        parcel.writeInt(this.byHorAcc);
        if (this.bVeraccPresent) {
            parcel.writeInt(this.byVerAcc);
        }
        if (this.bMaxLocAgePresent) {
            parcel.writeInt(this.wMaxLocAge);
        }
        if (!this.bdelayPresent) return;
        parcel.writeInt(this.byDelay);
    }
}

