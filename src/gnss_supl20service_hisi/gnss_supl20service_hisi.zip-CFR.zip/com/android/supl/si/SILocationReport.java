/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import java.io.DataInputStream;
import java.io.IOException;

public class SILocationReport
implements Parcelable {
    public static final Parcelable.Creator<SILocationReport> CREATOR = new Parcelable.Creator<SILocationReport>(){

        public SILocationReport createFromParcel(Parcel parcel) {
            return new SILocationReport(parcel);
        }

        public SILocationReport[] newArray(int n) {
            return new SILocationReport[n];
        }
    };
    public int m_iLat;
    public int m_iLon;
    public int m_usPlatformSessionId;

    public SILocationReport() {
    }

    public SILocationReport(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public int describeContents() {
        return 0;
    }

    public void readFromParcel(Parcel parcel) {
        this.m_usPlatformSessionId = parcel.readInt();
        this.m_iLat = parcel.readInt();
        this.m_iLon = parcel.readInt();
    }

    public boolean readSILocationReport(DataInputStream dataInputStream) throws IOException {
        this.m_usPlatformSessionId = dataInputStream.readUnsignedShort();
        this.m_iLat = dataInputStream.readInt();
        this.m_iLon = dataInputStream.readInt();
        return true;
    }

    public String toString() {
        return "SID:" + this.m_usPlatformSessionId + " Lat:" + this.m_iLat + " Lon:" + this.m_iLon;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeInt(this.m_usPlatformSessionId);
        parcel.writeInt(this.m_iLat);
        parcel.writeInt(this.m_iLon);
    }
}

