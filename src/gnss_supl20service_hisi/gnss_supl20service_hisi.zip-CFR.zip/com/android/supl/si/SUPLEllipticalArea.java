/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import com.android.bytewriter.IO;
import com.android.supl.si.SUPLCoordinate;

public class SUPLEllipticalArea
implements Parcelable {
    public static final Parcelable.Creator<SUPLEllipticalArea> CREATOR = new Parcelable.Creator<SUPLEllipticalArea>(){

        public SUPLEllipticalArea createFromParcel(Parcel parcel) {
            return new SUPLEllipticalArea(parcel);
        }

        public SUPLEllipticalArea[] newArray(int n) {
            return new SUPLEllipticalArea[n];
        }
    };
    public int nAngle;
    public int nSemiMajor;
    public int nSemiMajorMax;
    public int nSemiMajorMin;
    public int nSemiMinor;
    public int nSemiMinorMax;
    public int nSemiMinorMin;
    public SUPLCoordinate stCenterCoord = null;

    public SUPLEllipticalArea(int n, int n2, int n3, int n4, int n5) {
        this.nSemiMajorMin = n;
        this.nSemiMajorMax = n2;
        this.nSemiMinorMin = n3;
        this.nSemiMinorMax = n4;
        this.nAngle = n5;
    }

    public SUPLEllipticalArea(Parcel parcel) {
        this.readFromParcel(parcel);
    }

    public SUPLEllipticalArea(SUPLCoordinate sUPLCoordinate, int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        if (sUPLCoordinate == null) {
            throw new IllegalArgumentException("Coordinate should not be null");
        }
        this.stCenterCoord = sUPLCoordinate;
        this.nSemiMajor = n;
        this.nSemiMajorMin = n2;
        this.nSemiMajorMax = n3;
        this.nSemiMinor = n4;
        this.nSemiMinorMin = n5;
        this.nSemiMinorMax = n6;
        this.nAngle = n7;
    }

    public int describeContents() {
        return 0;
    }

    public byte[] getEllipticalAreaInfo() {
        byte[] byArray = this.stCenterCoord.getCoordinateInfo();
        int n = byArray.length + 28;
        byte[] byArray2 = new byte[n];
        System.arraycopy((byte[])byArray, (int)0, (byte[])byArray2, (int)0, (int)byArray.length);
        if (IO.put4(byArray2, IO.put4(byArray2, IO.put4(byArray2, IO.put4(byArray2, IO.put4(byArray2, IO.put4(byArray2, IO.put4(byArray2, byArray.length + 0, this.nSemiMajor), this.nSemiMajorMin), this.nSemiMajorMax), this.nSemiMinor), this.nSemiMinorMin), this.nSemiMinorMax), this.nAngle) == n) return byArray2;
        System.err.println("EllipticalArea length invalid");
        return byArray2;
    }

    public void readFromParcel(Parcel parcel) {
        this.stCenterCoord = (SUPLCoordinate)parcel.readParcelable(SUPLCoordinate.class.getClassLoader());
        this.nSemiMajor = parcel.readInt();
        this.nSemiMajorMin = parcel.readInt();
        this.nSemiMajorMax = parcel.readInt();
        this.nSemiMinor = parcel.readInt();
        this.nSemiMinorMin = parcel.readInt();
        this.nSemiMinorMax = parcel.readInt();
        this.nAngle = parcel.readInt();
    }

    public void setCenterCoordinate(SUPLCoordinate sUPLCoordinate) {
        this.stCenterCoord = sUPLCoordinate;
    }

    public void setSemiMajor(int n) {
        this.nSemiMajor = n;
    }

    public void setSemiMinor(int n) {
        this.nSemiMinor = n;
    }

    public String toString() {
        return this.stCenterCoord.toString() + "," + this.nSemiMajor + "," + this.nSemiMajorMin + "," + this.nSemiMajorMax + "," + this.nSemiMinor + "," + this.nSemiMinorMin + "," + this.nSemiMinorMax;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeParcelable((Parcelable)this.stCenterCoord, n);
        parcel.writeInt(this.nSemiMajor);
        parcel.writeInt(this.nSemiMajorMin);
        parcel.writeInt(this.nSemiMajorMax);
        parcel.writeInt(this.nSemiMinor);
        parcel.writeInt(this.nSemiMinorMin);
        parcel.writeInt(this.nSemiMinorMax);
        parcel.writeInt(this.nAngle);
    }
}

