/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 */
package com.android.supl.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.android.supl.Log;

public class GPSEnableReceiver
extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        Log.i("GPSEnableReceiver", "GPSEnableReceiver invoked");
        if (!intent.getAction().equals("android.location.GPS_ENABLED_CHANGE")) return;
        intent.getExtras().getBoolean("enabled");
    }
}

