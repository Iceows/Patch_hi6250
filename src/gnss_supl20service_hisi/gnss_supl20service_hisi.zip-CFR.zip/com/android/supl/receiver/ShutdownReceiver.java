/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.os.SystemProperties
 *  android.util.Log
 */
package com.android.supl.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.SystemProperties;
import android.util.Log;
import com.android.supl.commprocessor.SUPLSCMService;
import com.android.supl.loc.SUPLPlatformService;

public class ShutdownReceiver
extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        if (!"1".equals(SystemProperties.get((String)"is_hisi_connectivity_chip"))) {
            Log.d((String)"HISI_LOG", (String)"ShutdownReceiver onReceive called, but quit now");
            return;
        }
        if (intent.getAction() == null) return;
        if (!intent.getAction().equals("android.intent.action.ACTION_SHUTDOWN")) return;
        context.stopService(new Intent(context, SUPLPlatformService.class));
        context.stopService(new Intent(context, SUPLSCMService.class));
        Log.d((String)"HISI_LOG", (String)"ShutdownReceiver onReceive called");
    }
}

