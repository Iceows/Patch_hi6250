/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.os.SystemProperties
 *  android.util.Log
 */
package com.android.supl.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.SystemProperties;
import android.util.Log;
import com.android.supl.commprocessor.SUPLSCMService;
import com.android.supl.loc.SUPLPlatformService;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class BootUpReceiver
extends BroadcastReceiver {
    private static final String TAG = BootUpReceiver.class.getSimpleName();
    private static boolean is_service_start = false;
    private Context mContext = null;

    private void startSuplServices(Context context) {
        this.mContext = context;
        new Thread(){

            @Override
            public void run() {
                Intent intent = new Intent(BootUpReceiver.this.mContext, SUPLPlatformService.class);
                BootUpReceiver.this.mContext.startService(intent);
                Log.d((String)TAG, (String)"Starting platform service");
                intent = new Intent(BootUpReceiver.this.mContext, SUPLSCMService.class);
                BootUpReceiver.this.mContext.startService(intent);
                Log.d((String)TAG, (String)"Starting scm service");
            }
        }.start();
    }

    public void onReceive(Context context, Intent intent) {
        if (!"1".equals(SystemProperties.get((String)"is_hisi_connectivity_chip"))) {
            Log.d((String)TAG, (String)"BootUpReceiver onReceive called, but quit now");
            return;
        }
        if (!"hi1102".equals(SystemProperties.get((String)"ro.connectivity.sub_chiptype"))) {
            Log.d((String)TAG, (String)"supl application quit now");
            return;
        }
        Log.d((String)TAG, (String)("BootUpReceiver got " + intent.getAction()));
        if (is_service_start) return;
        if (intent.getAction() == null) return;
        if (!intent.getAction().equals("android.intent.action.BOOT_COMPLETED") && !intent.getAction().equals("android.intent.action.SCREEN_ON")) {
            if (!intent.getAction().equals("android.intent.action.SIM_STATE_CHANGED")) return;
        }
        this.startSuplServices(context);
        is_service_start = true;
    }
}

