/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.HidlSupport
 *  android.os.HwBlob
 *  android.os.HwParcel
 */
package android.hidl.base.V1_0;

import android.os.HidlSupport;
import android.os.HwBlob;
import android.os.HwParcel;
import java.util.ArrayList;
import java.util.Objects;

public final class DebugInfo {
    public int arch;
    public int pid;
    public long ptr;

    public static final ArrayList<DebugInfo> readVectorFromParcel(HwParcel hwParcel) {
        ArrayList<DebugInfo> arrayList = new ArrayList<DebugInfo>();
        Object object = hwParcel.readBuffer(16L);
        int n = object.getInt32(8L);
        HwBlob hwBlob = hwParcel.readEmbeddedBuffer((long)(n * 24), object.handle(), 0L, true);
        arrayList.clear();
        int n2 = 0;
        while (n2 < n) {
            object = new DebugInfo();
            ((DebugInfo)object).readEmbeddedFromParcel(hwParcel, hwBlob, n2 * 24);
            arrayList.add((DebugInfo)object);
            ++n2;
        }
        return arrayList;
    }

    public static final void writeVectorToParcel(HwParcel hwParcel, ArrayList<DebugInfo> arrayList) {
        HwBlob hwBlob = new HwBlob(16);
        int n = arrayList.size();
        hwBlob.putInt32(8L, n);
        hwBlob.putBool(12L, false);
        HwBlob hwBlob2 = new HwBlob(n * 24);
        int n2 = 0;
        while (true) {
            if (n2 >= n) {
                hwBlob.putBlob(0L, hwBlob2);
                hwParcel.writeBuffer(hwBlob);
                return;
            }
            arrayList.get(n2).writeEmbeddedToBlob(hwBlob2, n2 * 24);
            ++n2;
        }
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) {
            return false;
        }
        if (object.getClass() != DebugInfo.class) {
            return false;
        }
        object = (DebugInfo)object;
        if (this.pid != ((DebugInfo)object).pid) {
            return false;
        }
        if (this.ptr != ((DebugInfo)object).ptr) {
            return false;
        }
        if (this.arch == ((DebugInfo)object).arch) return true;
        return false;
    }

    public final int hashCode() {
        return Objects.hash(HidlSupport.deepHashCode((Object)this.pid), HidlSupport.deepHashCode((Object)this.ptr), HidlSupport.deepHashCode((Object)this.arch));
    }

    public final void readEmbeddedFromParcel(HwParcel hwParcel, HwBlob hwBlob, long l) {
        this.pid = hwBlob.getInt32(0L + l);
        this.ptr = hwBlob.getInt64(8L + l);
        this.arch = hwBlob.getInt32(16L + l);
    }

    public final void readFromParcel(HwParcel hwParcel) {
        this.readEmbeddedFromParcel(hwParcel, hwParcel.readBuffer(24L), 0L);
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("{");
        stringBuilder.append(".pid = ");
        stringBuilder.append(this.pid);
        stringBuilder.append(", .ptr = ");
        stringBuilder.append(this.ptr);
        stringBuilder.append(", .arch = ");
        stringBuilder.append(Architecture.toString(this.arch));
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    public final void writeEmbeddedToBlob(HwBlob hwBlob, long l) {
        hwBlob.putInt32(0L + l, this.pid);
        hwBlob.putInt64(8L + l, this.ptr);
        hwBlob.putInt32(16L + l, this.arch);
    }

    public final void writeToParcel(HwParcel hwParcel) {
        HwBlob hwBlob = new HwBlob(24);
        this.writeEmbeddedToBlob(hwBlob, 0L);
        hwParcel.writeBuffer(hwBlob);
    }

    public static final class Architecture {
        public static final int IS_32BIT = 2;
        public static final int IS_64BIT = 1;
        public static final int UNKNOWN = 0;

        public static final String dumpBitfield(int n) {
            ArrayList<String> arrayList = new ArrayList<String>();
            if ((n & 0) == 0) {
                arrayList.add("UNKNOWN");
            }
            int n2 = 0;
            if ((n & 1) == 1) {
                arrayList.add("IS_64BIT");
                n2 = 0 | 1;
            }
            int n3 = n2;
            if ((n & 2) == 2) {
                arrayList.add("IS_32BIT");
                n3 = n2 | 2;
            }
            if (n == n3) return String.join((CharSequence)" | ", arrayList);
            arrayList.add("0x" + Integer.toHexString(~n3 & n));
            return String.join((CharSequence)" | ", arrayList);
        }

        public static final String toString(int n) {
            if (n == 0) {
                return "UNKNOWN";
            }
            if (n == 1) {
                return "IS_64BIT";
            }
            if (n != 2) return "0x" + Integer.toHexString(n);
            return "IS_32BIT";
        }
    }
}

