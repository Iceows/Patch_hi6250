/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.HwBinder
 *  android.os.HwBlob
 *  android.os.HwParcel
 *  android.os.IHwBinder
 *  android.os.IHwBinder$DeathRecipient
 *  android.os.IHwInterface
 *  android.os.RemoteException
 *  android.os.SystemProperties
 */
package android.hidl.base.V1_0;

import android.hidl.base.V1_0.DebugInfo;
import android.os.HwBinder;
import android.os.HwBlob;
import android.os.HwParcel;
import android.os.IHwBinder;
import android.os.IHwInterface;
import android.os.RemoteException;
import android.os.SystemProperties;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

public interface IBase
extends IHwInterface {
    public static final String kInterfaceName = "android.hidl.base@1.0::IBase";

    public static IBase asInterface(IHwBinder object) {
        if (object == null) {
            return null;
        }
        IHwInterface iHwInterface = object.queryLocalInterface(kInterfaceName);
        if (iHwInterface != null && iHwInterface instanceof IBase) {
            return (IBase)iHwInterface;
        }
        iHwInterface = new Proxy((IHwBinder)object);
        try {
            boolean bl;
            object = iHwInterface.interfaceChain().iterator();
            do {
                if (!object.hasNext()) return null;
            } while (!(bl = ((String)object.next()).equals(kInterfaceName)));
            return iHwInterface;
        }
        catch (RemoteException remoteException) {
            // empty catch block
        }
        return null;
    }

    public static IBase castFrom(IHwInterface iHwInterface) {
        Object var1_1 = null;
        if (iHwInterface != null) return IBase.asInterface(iHwInterface.asBinder());
        return var1_1;
    }

    public static IBase getService() throws RemoteException {
        return IBase.asInterface(HwBinder.getService((String)kInterfaceName, (String)"default"));
    }

    public static IBase getService(String string) throws RemoteException {
        return IBase.asInterface(HwBinder.getService((String)kInterfaceName, (String)string));
    }

    public IHwBinder asBinder();

    public DebugInfo getDebugInfo() throws RemoteException;

    public ArrayList<byte[]> getHashChain() throws RemoteException;

    public ArrayList<String> interfaceChain() throws RemoteException;

    public String interfaceDescriptor() throws RemoteException;

    public boolean linkToDeath(IHwBinder.DeathRecipient var1, long var2) throws RemoteException;

    public void notifySyspropsChanged() throws RemoteException;

    public void ping() throws RemoteException;

    public void setHALInstrumentation() throws RemoteException;

    public boolean unlinkToDeath(IHwBinder.DeathRecipient var1) throws RemoteException;

    public static final class Proxy
    implements IBase {
        private IHwBinder mRemote;

        public Proxy(IHwBinder iHwBinder) {
            this.mRemote = Objects.requireNonNull(iHwBinder);
        }

        @Override
        public IHwBinder asBinder() {
            return this.mRemote;
        }

        @Override
        public DebugInfo getDebugInfo() throws RemoteException {
            Object object = new HwParcel();
            object.writeInterfaceToken(IBase.kInterfaceName);
            HwParcel hwParcel = new HwParcel();
            try {
                this.mRemote.transact(257049926, (HwParcel)object, hwParcel, 0);
                hwParcel.verifySuccess();
                object.releaseTemporaryStorage();
                object = new DebugInfo();
                ((DebugInfo)object).readFromParcel(hwParcel);
                return object;
            }
            finally {
                hwParcel.release();
            }
        }

        /*
         * Exception decompiling
         */
        @Override
        public ArrayList<byte[]> getHashChain() throws RemoteException {
            /*
             * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
             * 
             * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 4[FORLOOP]
             *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
             *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
             *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:845)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
             *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
             *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:910)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1022)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
             *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
             *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
             *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:73)
             *     at org.benf.cfr.reader.Main.main(Main.java:49)
             *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:303)
             *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$null$1(ResourceDecompiling.java:113)
             *     at java.base/java.lang.Thread.run(Unknown Source)
             */
            throw new IllegalStateException("Decompilation failed");
        }

        @Override
        public ArrayList<String> interfaceChain() throws RemoteException {
            Object object = new HwParcel();
            object.writeInterfaceToken(IBase.kInterfaceName);
            HwParcel hwParcel = new HwParcel();
            try {
                this.mRemote.transact(256067662, object, hwParcel, 0);
                hwParcel.verifySuccess();
                object.releaseTemporaryStorage();
                object = hwParcel.readStringVector();
                return object;
            }
            finally {
                hwParcel.release();
            }
        }

        @Override
        public String interfaceDescriptor() throws RemoteException {
            Object object = new HwParcel();
            object.writeInterfaceToken(IBase.kInterfaceName);
            HwParcel hwParcel = new HwParcel();
            try {
                this.mRemote.transact(256136003, object, hwParcel, 0);
                hwParcel.verifySuccess();
                object.releaseTemporaryStorage();
                object = hwParcel.readString();
                return object;
            }
            finally {
                hwParcel.release();
            }
        }

        @Override
        public boolean linkToDeath(IHwBinder.DeathRecipient deathRecipient, long l) throws RemoteException {
            return this.mRemote.linkToDeath(deathRecipient, l);
        }

        @Override
        public void notifySyspropsChanged() throws RemoteException {
            HwParcel hwParcel = new HwParcel();
            hwParcel.writeInterfaceToken(IBase.kInterfaceName);
            HwParcel hwParcel2 = new HwParcel();
            try {
                this.mRemote.transact(257120595, hwParcel, hwParcel2, 1);
                hwParcel.releaseTemporaryStorage();
                return;
            }
            finally {
                hwParcel2.release();
            }
        }

        @Override
        public void ping() throws RemoteException {
            HwParcel hwParcel = new HwParcel();
            hwParcel.writeInterfaceToken(IBase.kInterfaceName);
            HwParcel hwParcel2 = new HwParcel();
            try {
                this.mRemote.transact(256921159, hwParcel, hwParcel2, 0);
                hwParcel2.verifySuccess();
                hwParcel.releaseTemporaryStorage();
                return;
            }
            finally {
                hwParcel2.release();
            }
        }

        @Override
        public void setHALInstrumentation() throws RemoteException {
            HwParcel hwParcel = new HwParcel();
            hwParcel.writeInterfaceToken(IBase.kInterfaceName);
            HwParcel hwParcel2 = new HwParcel();
            try {
                this.mRemote.transact(256462420, hwParcel, hwParcel2, 1);
                hwParcel.releaseTemporaryStorage();
                return;
            }
            finally {
                hwParcel2.release();
            }
        }

        public String toString() {
            try {
                CharSequence charSequence = new StringBuilder();
                return charSequence.append(this.interfaceDescriptor()).append("@Proxy").toString();
            }
            catch (RemoteException remoteException) {
                return "[class or subclass of android.hidl.base@1.0::IBase]@Proxy";
            }
        }

        @Override
        public boolean unlinkToDeath(IHwBinder.DeathRecipient deathRecipient) throws RemoteException {
            return this.mRemote.unlinkToDeath(deathRecipient);
        }
    }

    public static abstract class Stub
    extends HwBinder
    implements IBase {
        @Override
        public IHwBinder asBinder() {
            return this;
        }

        @Override
        public final DebugInfo getDebugInfo() {
            DebugInfo debugInfo = new DebugInfo();
            debugInfo.pid = -1;
            debugInfo.ptr = 0L;
            debugInfo.arch = 0;
            return debugInfo;
        }

        @Override
        public final ArrayList<byte[]> getHashChain() {
            return new ArrayList<byte[]>(Arrays.asList(new byte[][]{{-67, -38, -74, 24, 77, 122, 52, 109, -90, -96, 125, -64, -126, -116, -15, -102, 105, 111, 76, -86, 54, 17, -59, 31, 46, 20, 86, 90, 20, -76, 15, -39}}));
        }

        @Override
        public final ArrayList<String> interfaceChain() {
            return new ArrayList<String>(Arrays.asList(IBase.kInterfaceName));
        }

        @Override
        public final String interfaceDescriptor() {
            return IBase.kInterfaceName;
        }

        @Override
        public final boolean linkToDeath(IHwBinder.DeathRecipient deathRecipient, long l) {
            return true;
        }

        @Override
        public final void notifySyspropsChanged() {
            SystemProperties.reportSyspropChanged();
        }

        public void onTransact(int n, HwParcel object, HwParcel hwParcel, int n2) throws RemoteException {
            switch (n) {
                case 256067662: {
                    object.enforceInterface(IBase.kInterfaceName);
                    object = this.interfaceChain();
                    hwParcel.writeStatus(0);
                    hwParcel.writeStringVector((ArrayList)object);
                    hwParcel.send();
                    return;
                }
                case 256131655: {
                    object.enforceInterface(IBase.kInterfaceName);
                    hwParcel.writeStatus(0);
                    hwParcel.send();
                    return;
                }
                case 256136003: {
                    object.enforceInterface(IBase.kInterfaceName);
                    object = this.interfaceDescriptor();
                    hwParcel.writeStatus(0);
                    hwParcel.writeString((String)object);
                    hwParcel.send();
                    return;
                }
                case 256398152: {
                    object.enforceInterface(IBase.kInterfaceName);
                    object = this.getHashChain();
                    hwParcel.writeStatus(0);
                    HwBlob hwBlob = new HwBlob(16);
                    int n3 = ((ArrayList)object).size();
                    hwBlob.putInt32(8L, n3);
                    hwBlob.putBool(12L, false);
                    HwBlob hwBlob2 = new HwBlob(n3 * 32);
                    n = 0;
                    while (true) {
                        if (n >= n3) {
                            hwBlob.putBlob(0L, hwBlob2);
                            hwParcel.writeBuffer(hwBlob);
                            hwParcel.send();
                            return;
                        }
                        long l = n * 32;
                        for (n2 = 0; n2 < 32; ++l, ++n2) {
                            hwBlob2.putInt8(l, ((byte[])((ArrayList)object).get(n))[n2]);
                        }
                        ++n;
                    }
                }
                case 256462420: {
                    object.enforceInterface(IBase.kInterfaceName);
                    this.setHALInstrumentation();
                    return;
                }
                case 257049926: {
                    object.enforceInterface(IBase.kInterfaceName);
                    object = this.getDebugInfo();
                    hwParcel.writeStatus(0);
                    ((DebugInfo)object).writeToParcel(hwParcel);
                    hwParcel.send();
                    return;
                }
                case 257120595: {
                    object.enforceInterface(IBase.kInterfaceName);
                    this.notifySyspropsChanged();
                    return;
                }
            }
        }

        @Override
        public final void ping() {
        }

        public IHwInterface queryLocalInterface(String string) {
            if (!IBase.kInterfaceName.equals(string)) return null;
            return this;
        }

        public void registerAsService(String string) throws RemoteException {
            this.registerService(string);
        }

        @Override
        public final void setHALInstrumentation() {
        }

        public String toString() {
            return this.interfaceDescriptor() + "@Stub";
        }

        @Override
        public final boolean unlinkToDeath(IHwBinder.DeathRecipient deathRecipient) {
            return true;
        }
    }
}

