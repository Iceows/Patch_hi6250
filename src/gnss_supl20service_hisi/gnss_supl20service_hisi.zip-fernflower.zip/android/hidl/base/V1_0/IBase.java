package android.hidl.base.V1_0;

import android.os.HwBinder;
import android.os.HwBlob;
import android.os.HwParcel;
import android.os.IHwBinder;
import android.os.IHwInterface;
import android.os.RemoteException;
import android.os.SystemProperties;
import android.os.IHwBinder.DeathRecipient;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

public interface IBase extends IHwInterface {
   String kInterfaceName = "android.hidl.base@1.0::IBase";

   static IBase asInterface(IHwBinder param0) {
      // $FF: Couldn't be decompiled
   }

   static IBase castFrom(IHwInterface var0) {
      Object var1 = null;
      IBase var2;
      if (var0 == null) {
         var2 = (IBase)var1;
      } else {
         var2 = asInterface(var0.asBinder());
      }

      return var2;
   }

   static IBase getService() throws RemoteException {
      return asInterface(HwBinder.getService("android.hidl.base@1.0::IBase", "default"));
   }

   static IBase getService(String var0) throws RemoteException {
      return asInterface(HwBinder.getService("android.hidl.base@1.0::IBase", var0));
   }

   IHwBinder asBinder();

   DebugInfo getDebugInfo() throws RemoteException;

   ArrayList getHashChain() throws RemoteException;

   ArrayList interfaceChain() throws RemoteException;

   String interfaceDescriptor() throws RemoteException;

   boolean linkToDeath(DeathRecipient var1, long var2) throws RemoteException;

   void notifySyspropsChanged() throws RemoteException;

   void ping() throws RemoteException;

   void setHALInstrumentation() throws RemoteException;

   boolean unlinkToDeath(DeathRecipient var1) throws RemoteException;

   public static final class Proxy implements IBase {
      private IHwBinder mRemote;

      public Proxy(IHwBinder var1) {
         this.mRemote = (IHwBinder)Objects.requireNonNull(var1);
      }

      public IHwBinder asBinder() {
         return this.mRemote;
      }

      public DebugInfo getDebugInfo() throws RemoteException {
         HwParcel var2 = new HwParcel();
         var2.writeInterfaceToken("android.hidl.base@1.0::IBase");
         HwParcel var1 = new HwParcel();

         DebugInfo var5;
         try {
            this.mRemote.transact(257049926, var2, var1, 0);
            var1.verifySuccess();
            var2.releaseTemporaryStorage();
            var5 = new DebugInfo();
            var5.readFromParcel(var1);
         } finally {
            var1.release();
         }

         return var5;
      }

      public ArrayList getHashChain() throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public ArrayList interfaceChain() throws RemoteException {
         HwParcel var2 = new HwParcel();
         var2.writeInterfaceToken("android.hidl.base@1.0::IBase");
         HwParcel var1 = new HwParcel();

         ArrayList var5;
         try {
            this.mRemote.transact(256067662, var2, var1, 0);
            var1.verifySuccess();
            var2.releaseTemporaryStorage();
            var5 = var1.readStringVector();
         } finally {
            var1.release();
         }

         return var5;
      }

      public String interfaceDescriptor() throws RemoteException {
         HwParcel var2 = new HwParcel();
         var2.writeInterfaceToken("android.hidl.base@1.0::IBase");
         HwParcel var1 = new HwParcel();

         String var5;
         try {
            this.mRemote.transact(256136003, var2, var1, 0);
            var1.verifySuccess();
            var2.releaseTemporaryStorage();
            var5 = var1.readString();
         } finally {
            var1.release();
         }

         return var5;
      }

      public boolean linkToDeath(DeathRecipient var1, long var2) throws RemoteException {
         return this.mRemote.linkToDeath(var1, var2);
      }

      public void notifySyspropsChanged() throws RemoteException {
         HwParcel var2 = new HwParcel();
         var2.writeInterfaceToken("android.hidl.base@1.0::IBase");
         HwParcel var1 = new HwParcel();

         try {
            this.mRemote.transact(257120595, var2, var1, 1);
            var2.releaseTemporaryStorage();
         } finally {
            var1.release();
         }

      }

      public void ping() throws RemoteException {
         HwParcel var2 = new HwParcel();
         var2.writeInterfaceToken("android.hidl.base@1.0::IBase");
         HwParcel var1 = new HwParcel();

         try {
            this.mRemote.transact(256921159, var2, var1, 0);
            var1.verifySuccess();
            var2.releaseTemporaryStorage();
         } finally {
            var1.release();
         }

      }

      public void setHALInstrumentation() throws RemoteException {
         HwParcel var2 = new HwParcel();
         var2.writeInterfaceToken("android.hidl.base@1.0::IBase");
         HwParcel var1 = new HwParcel();

         try {
            this.mRemote.transact(256462420, var2, var1, 1);
            var2.releaseTemporaryStorage();
         } finally {
            var1.release();
         }

      }

      public String toString() {
         try {
            StringBuilder var1 = new StringBuilder();
            String var3 = var1.append(this.interfaceDescriptor()).append("@Proxy").toString();
            return var3;
         } catch (RemoteException var2) {
            return "[class or subclass of android.hidl.base@1.0::IBase]@Proxy";
         }
      }

      public boolean unlinkToDeath(DeathRecipient var1) throws RemoteException {
         return this.mRemote.unlinkToDeath(var1);
      }
   }

   public abstract static class Stub extends HwBinder implements IBase {
      public IHwBinder asBinder() {
         return this;
      }

      public final DebugInfo getDebugInfo() {
         DebugInfo var1 = new DebugInfo();
         var1.pid = -1;
         var1.ptr = 0L;
         var1.arch = 0;
         return var1;
      }

      public final ArrayList getHashChain() {
         return new ArrayList(Arrays.asList(new byte[]{-67, -38, -74, 24, 77, 122, 52, 109, -90, -96, 125, -64, -126, -116, -15, -102, 105, 111, 76, -86, 54, 17, -59, 31, 46, 20, 86, 90, 20, -76, 15, -39}));
      }

      public final ArrayList interfaceChain() {
         return new ArrayList(Arrays.asList("android.hidl.base@1.0::IBase"));
      }

      public final String interfaceDescriptor() {
         return "android.hidl.base@1.0::IBase";
      }

      public final boolean linkToDeath(DeathRecipient var1, long var2) {
         return true;
      }

      public final void notifySyspropsChanged() {
         SystemProperties.reportSyspropChanged();
      }

      public void onTransact(int var1, HwParcel var2, HwParcel var3, int var4) throws RemoteException {
         ArrayList var11;
         switch(var1) {
         case 256067662:
            var2.enforceInterface("android.hidl.base@1.0::IBase");
            var11 = this.interfaceChain();
            var3.writeStatus(0);
            var3.writeStringVector(var11);
            var3.send();
            break;
         case 256131655:
            var2.enforceInterface("android.hidl.base@1.0::IBase");
            var3.writeStatus(0);
            var3.send();
            break;
         case 256136003:
            var2.enforceInterface("android.hidl.base@1.0::IBase");
            String var12 = this.interfaceDescriptor();
            var3.writeStatus(0);
            var3.writeString(var12);
            var3.send();
            break;
         case 256398152:
            var2.enforceInterface("android.hidl.base@1.0::IBase");
            var11 = this.getHashChain();
            var3.writeStatus(0);
            HwBlob var8 = new HwBlob(16);
            int var5 = var11.size();
            var8.putInt32(8L, var5);
            var8.putBool(12L, false);
            HwBlob var9 = new HwBlob(var5 * 32);

            for(var1 = 0; var1 < var5; ++var1) {
               long var6 = (long)(var1 * 32);

               for(var4 = 0; var4 < 32; ++var4) {
                  var9.putInt8(var6, ((byte[])var11.get(var1))[var4]);
                  ++var6;
               }
            }

            var8.putBlob(0L, var9);
            var3.writeBuffer(var8);
            var3.send();
            break;
         case 256462420:
            var2.enforceInterface("android.hidl.base@1.0::IBase");
            this.setHALInstrumentation();
         case 256660548:
         case 256921159:
         case 257250372:
         default:
            break;
         case 257049926:
            var2.enforceInterface("android.hidl.base@1.0::IBase");
            DebugInfo var10 = this.getDebugInfo();
            var3.writeStatus(0);
            var10.writeToParcel(var3);
            var3.send();
            break;
         case 257120595:
            var2.enforceInterface("android.hidl.base@1.0::IBase");
            this.notifySyspropsChanged();
         }

      }

      public final void ping() {
      }

      public IHwInterface queryLocalInterface(String var1) {
         return "android.hidl.base@1.0::IBase".equals(var1) ? this : null;
      }

      public void registerAsService(String var1) throws RemoteException {
         this.registerService(var1);
      }

      public final void setHALInstrumentation() {
      }

      public String toString() {
         return this.interfaceDescriptor() + "@Stub";
      }

      public final boolean unlinkToDeath(DeathRecipient var1) {
         return true;
      }
   }
}
