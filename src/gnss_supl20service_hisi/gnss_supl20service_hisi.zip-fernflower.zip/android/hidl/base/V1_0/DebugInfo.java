package android.hidl.base.V1_0;

import android.os.HidlSupport;
import android.os.HwBlob;
import android.os.HwParcel;
import java.util.ArrayList;
import java.util.Objects;

public final class DebugInfo {
   public int arch;
   public int pid;
   public long ptr;

   public static final ArrayList readVectorFromParcel(HwParcel var0) {
      ArrayList var3 = new ArrayList();
      HwBlob var4 = var0.readBuffer(16L);
      int var2 = var4.getInt32(8L);
      HwBlob var5 = var0.readEmbeddedBuffer((long)(var2 * 24), var4.handle(), 0L, true);
      var3.clear();

      for(int var1 = 0; var1 < var2; ++var1) {
         DebugInfo var6 = new DebugInfo();
         var6.readEmbeddedFromParcel(var0, var5, (long)(var1 * 24));
         var3.add(var6);
      }

      return var3;
   }

   public static final void writeVectorToParcel(HwParcel var0, ArrayList var1) {
      HwBlob var5 = new HwBlob(16);
      int var3 = var1.size();
      var5.putInt32(8L, var3);
      var5.putBool(12L, false);
      HwBlob var4 = new HwBlob(var3 * 24);

      for(int var2 = 0; var2 < var3; ++var2) {
         ((DebugInfo)var1.get(var2)).writeEmbeddedToBlob(var4, (long)(var2 * 24));
      }

      var5.putBlob(0L, var4);
      var0.writeBuffer(var5);
   }

   public final boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 == null) {
         return false;
      } else if (var1.getClass() != DebugInfo.class) {
         return false;
      } else {
         DebugInfo var2 = (DebugInfo)var1;
         if (this.pid != var2.pid) {
            return false;
         } else if (this.ptr != var2.ptr) {
            return false;
         } else {
            return this.arch == var2.arch;
         }
      }
   }

   public final int hashCode() {
      return Objects.hash(new Object[]{HidlSupport.deepHashCode(this.pid), HidlSupport.deepHashCode(this.ptr), HidlSupport.deepHashCode(this.arch)});
   }

   public final void readEmbeddedFromParcel(HwParcel var1, HwBlob var2, long var3) {
      this.pid = var2.getInt32(0L + var3);
      this.ptr = var2.getInt64(8L + var3);
      this.arch = var2.getInt32(16L + var3);
   }

   public final void readFromParcel(HwParcel var1) {
      this.readEmbeddedFromParcel(var1, var1.readBuffer(24L), 0L);
   }

   public final String toString() {
      StringBuilder var1 = new StringBuilder();
      var1.append("{");
      var1.append(".pid = ");
      var1.append(this.pid);
      var1.append(", .ptr = ");
      var1.append(this.ptr);
      var1.append(", .arch = ");
      var1.append(DebugInfo.Architecture.toString(this.arch));
      var1.append("}");
      return var1.toString();
   }

   public final void writeEmbeddedToBlob(HwBlob var1, long var2) {
      var1.putInt32(0L + var2, this.pid);
      var1.putInt64(8L + var2, this.ptr);
      var1.putInt32(16L + var2, this.arch);
   }

   public final void writeToParcel(HwParcel var1) {
      HwBlob var2 = new HwBlob(24);
      this.writeEmbeddedToBlob(var2, 0L);
      var1.writeBuffer(var2);
   }

   public static final class Architecture {
      public static final int IS_32BIT = 2;
      public static final int IS_64BIT = 1;
      public static final int UNKNOWN = 0;

      public static final String dumpBitfield(int var0) {
         ArrayList var3 = new ArrayList();
         if ((var0 & 0) == 0) {
            var3.add("UNKNOWN");
         }

         int var1 = 0;
         if ((var0 & 1) == 1) {
            var3.add("IS_64BIT");
            var1 = 0 | 1;
         }

         int var2 = var1;
         if ((var0 & 2) == 2) {
            var3.add("IS_32BIT");
            var2 = var1 | 2;
         }

         if (var0 != var2) {
            var3.add("0x" + Integer.toHexString(~var2 & var0));
         }

         return String.join(" | ", var3);
      }

      public static final String toString(int var0) {
         if (var0 == 0) {
            return "UNKNOWN";
         } else if (var0 == 1) {
            return "IS_64BIT";
         } else {
            return var0 == 2 ? "IS_32BIT" : "0x" + Integer.toHexString(var0);
         }
      }
   }
}
