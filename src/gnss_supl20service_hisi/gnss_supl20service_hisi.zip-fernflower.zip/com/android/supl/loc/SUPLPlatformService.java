package com.android.supl.loc;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import com.android.supl.GpsOnOffListener;
import com.android.supl.SUPLManager;
import com.android.supl.commprocessor.NDKCommProcessor;
import com.android.supl.config.ConfigManager;
import com.android.supl.trigger.PeriodicTriggerHandler;

public class SUPLPlatformService extends Service implements GpsOnOffListener {
   private final String LOG_TAG = "SUPL20_PCMService";
   private boolean isInit = false;
   private Context mContext = null;
   private SETLocationManager mLocationManager = null;
   private NDKCommProcessor mNDKCommProcessor = null;
   private Thread pcmThread = null;

   // $FF: synthetic method
   static NDKCommProcessor _get0/* $FF was: -get0*/(SUPLPlatformService var0) {
      return var0.mNDKCommProcessor;
   }

   public SUPLPlatformService() {
      this.mContext = this;
   }

   public SUPLPlatformService(Context var1) {
      this.mContext = var1;
      this.onCreate();
   }

   private void start() {
      this.isInit = true;
      this.mLocationManager = new SETLocationManager(this.mContext);
      ConfigManager var5 = ConfigManager.getInstance();
      int var2 = var5.getPCMPort();
      String var4 = var5.getPCMIpAdress();
      int var3 = var5.getNwTimeout();
      int var1 = var5.getNwRetries();
      this.mNDKCommProcessor = new NDKCommProcessor(false, var4, var2, this.mLocationManager, var3, var1);
      this.pcmThread = new Thread(new SUPLPlatformService.PCMConnectionThread());
      this.pcmThread.setName("PCM handsake thread");
      this.pcmThread.start();
      Log.d("SUPL20_PCMService", "SUPL20 service version :2.13.2.0");
      Log.d("SUPL20_PCMService", "Platform Service Created");
   }

   private void startPCM() {
      Log.d("SUPL20_PCMService", "Send startPCM ");
      if (this.isInit) {
         this.mNDKCommProcessor.reInit();
      } else {
         this.start();
      }

      Log.d("SUPL20_PCMService", "Send startPCM finished");
   }

   public IBinder onBind(Intent var1) {
      return null;
   }

   public void onCreate() {
      ConfigManager.getInstance();
      Log.d("SUPL20_PCMService", "SUPL20 service version :2.13.2.0");
      this.start();
   }

   public void onDestroy() {
      PeriodicTriggerHandler.getInstance().clear();
      if (this.mLocationManager != null) {
         this.mLocationManager.stopListening();
      }

      if (this.mNDKCommProcessor != null) {
         this.mNDKCommProcessor.sendByeMessage();
      }

      try {
         Thread.sleep(1000L);
      } catch (InterruptedException var2) {
         var2.printStackTrace();
      }

      if (this.mNDKCommProcessor != null) {
         this.mNDKCommProcessor.stopNetWork();
      }

      this.pcmThread.interrupt();
      SUPLManager.getInstance(this.mContext).removeGpsListener(this);
   }

   public void onGPSLocationProviderDisabled() {
      Log.d("SUPL20_PCMService", " onGPSLocationProviderDisabled");
      if (this.isInit) {
         Log.d("SUPL20_PCMService", "PCM Service running. Will pause it.");
         this.mNDKCommProcessor.pause();
      } else {
         Log.e("SUPL20_PCMService", "PCM Service not already created");
      }

   }

   public void onGPSLocationProviderEnabled() {
      this.startPCM();
   }

   public void onStart(Intent var1, int var2) {
      Log.d("SUPL20_PCMService", "onStart");
   }

   public int onStartCommand(Intent var1, int var2, int var3) {
      return 1;
   }

   public class PCMConnectionThread implements Runnable {
      public void run() {
         // $FF: Couldn't be decompiled
      }
   }
}
