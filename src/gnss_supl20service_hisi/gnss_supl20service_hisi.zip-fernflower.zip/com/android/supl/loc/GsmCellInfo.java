package com.android.supl.loc;

import com.android.bytewriter.IO;

public class GsmCellInfo {
   private static int GSM_PACKET_LEN = 16;
   private static final int TA_DATA_LEN = 1;
   public boolean isNMRPresent = false;
   public boolean isTAPresent = false;
   public GsmCellInfo.NMRElement[] mElement = null;
   public int m_iCellID = 0;
   public int m_iLAC = 0;
   public int m_iMCC = 0;
   public int m_iMNC = 0;
   public int m_iTA = 0;

   public byte[] getGSMInfo() {
      byte var4 = 0;
      int var3 = GSM_PACKET_LEN;
      int var1 = var3;
      int var2 = var4;
      if (this.isNMRPresent) {
         var1 = var3;
         var2 = var4;
         if (this.mElement != null) {
            var1 = var3;
            var2 = var4;
            if (this.mElement.length > 0) {
               var2 = this.mElement.length;
               var1 = var3 + var2 * 4;
            }
         }
      }

      var3 = var1;
      if (this.isTAPresent) {
         var3 = var1 + 1;
      }

      byte[] var6 = new byte[var3];
      var3 = IO.put2(var6, IO.put2(var6, IO.put2(var6, IO.put2(var6, 0, this.m_iMCC), this.m_iMNC), this.m_iLAC), this.m_iCellID);
      if (this.isNMRPresent) {
         var1 = var3;
         if (var2 > 0) {
            var2 = IO.put1(var6, IO.put4(var6, var3, 1), var2);
            GsmCellInfo.NMRElement[] var5 = this.mElement;
            int var7 = var5.length;
            var3 = 0;

            while(true) {
               var1 = var2;
               if (var3 >= var7) {
                  break;
               }

               System.arraycopy(var5[var3].getNMRElementInfo(), 0, var6, var2, 4);
               var2 += 4;
               ++var3;
            }
         }
      } else {
         var1 = IO.put4(var6, var3, 0);
      }

      if (this.isTAPresent) {
         IO.put1(var6, IO.put4(var6, var1, 1), this.m_iTA);
      } else {
         IO.put4(var6, var1, 0);
      }

      return var6;
   }

   public class NMRElement {
      private static final int NMR_ELEMENT_LEN = 4;
      private short m_sARFCN;
      private short m_sBSIC;
      private short m_sRxLev;

      public NMRElement(short var2, short var3, short var4) {
         this.m_sARFCN = var2;
         this.m_sBSIC = var3;
         this.m_sRxLev = var4;
      }

      public byte[] getNMRElementInfo() {
         byte[] var1 = new byte[4];
         IO.put1(var1, IO.put1(var1, IO.put2(var1, 0, this.m_sARFCN), this.m_sBSIC), this.m_sRxLev);
         return var1;
      }
   }
}
