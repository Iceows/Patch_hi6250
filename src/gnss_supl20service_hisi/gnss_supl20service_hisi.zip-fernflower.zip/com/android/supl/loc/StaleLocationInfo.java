package com.android.supl.loc;

import com.android.bytewriter.IO;

public class StaleLocationInfo {
   private byte[] bLocInfo = null;
   private int iStaleBitlocat = 0;

   public StaleLocationInfo(byte[] var1, int var2) {
      this.bLocInfo = var1;
      this.iStaleBitlocat = var2;
   }

   public byte[] getStaleLocation() {
      if (IO.get1(this.bLocInfo, this.iStaleBitlocat) == 1) {
         IO.put1(this.bLocInfo, this.iStaleBitlocat, 0);
      } else {
         System.out.println("Stale Location error");
      }

      return this.bLocInfo;
   }

   public void upDateInfo(byte[] var1, int var2) {
      this.bLocInfo = var1;
      this.iStaleBitlocat = var2;
   }
}
