package com.android.supl.loc;

import com.android.bytewriter.IO;

public class BitString {
   int nBitsUnused = 0;
   public byte[] ucBuffer = null;
   int ucLength = 0;

   public BitString(String var1) {
      if (var1 != null) {
         this.ucBuffer = var1.getBytes();
         this.ucLength = this.ucBuffer.length;
         this.nBitsUnused = 0;
      }

   }

   public byte[] getBitStringInfo() {
      int var1 = this.ucLength + 5;
      byte[] var3 = new byte[var1];
      int var2 = IO.put4(var3, IO.put1(var3, 0, this.ucLength), this.nBitsUnused);
      System.arraycopy(this.ucBuffer, 0, var3, var2, this.ucLength);
      if (var2 + this.ucLength != var1) {
         System.out.println("BitString length error");
      }

      System.out.println("BitString length " + this.ucLength);
      return var3;
   }
}
