package com.android.supl.loc;

import android.util.Log;
import com.android.bytewriter.IO;

public class SetID {
   private static final int SET_ID_DATA_LEN = 14;
   private static final int SET_ID_NODATA_LEN = 10;
   public static final int SUPL_SETID_TYPE_IMSI = 4;
   public static final int SUPL_SETID_TYPE_IPADDRESSV4 = 6;
   public static final int SUPL_SETID_TYPE_IPADDRESSV6 = 7;
   public static final int SUPL_SETID_TYPE_MDN = 2;
   public static final int SUPL_SETID_TYPE_MIN = 3;
   public static final int SUPL_SETID_TYPE_MSISDN = 1;
   public static final int SUPL_SETID_TYPE_NAI = 5;
   public static final int SUPL_SETID_TYPE_NONE = 8;
   private int iNumBytes = 0;
   private int m_iSetIDType;

   public SetID(int var1) {
      switch(var1) {
      case 1:
         this.iNumBytes = 12;
         break;
      case 2:
         this.iNumBytes = 8;
         break;
      case 3:
         this.iNumBytes = 5;
         break;
      case 4:
         this.iNumBytes = 15;
         break;
      case 5:
         this.iNumBytes = 1000;
         break;
      case 6:
         this.iNumBytes = 4;
         break;
      case 7:
         this.iNumBytes = 16;
         break;
      case 8:
         this.iNumBytes = 0;
         break;
      default:
         throw new IllegalArgumentException("invalid SETTYPE ");
      }

      this.m_iSetIDType = var1;
   }

   private String addLeadingData(String var1, String var2, int var3) {
      if (var1 == null) {
         return null;
      } else {
         StringBuffer var6 = new StringBuffer();
         int var5 = var1.length();
         if (var5 >= var3) {
            return var1;
         } else {
            for(int var4 = 0; var4 < var3 - var5; ++var4) {
               var6.append(var2);
            }

            var6.append(var1);
            return var6.toString();
         }
      }
   }

   public static boolean isValidSetIDRequest(int var0) {
      boolean var1;
      switch(var0) {
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
         var1 = true;
         break;
      case 8:
         var1 = false;
         break;
      default:
         var1 = false;
      }

      return var1;
   }

   public byte[] getSetIDBuff(int var1, String var2) {
      if (var2 == null || var2.trim().length() == 0) {
         this.m_iSetIDType = 8;
         this.iNumBytes = 0;
      }

      int var5;
      byte[] var9;
      if (this.m_iSetIDType != 8) {
         var9 = new byte[this.iNumBytes + 18];
         var5 = this.iNumBytes + 14;
      } else {
         var9 = new byte[14];
         var5 = this.iNumBytes + 10;
      }

      int var4 = IO.put4(var9, IO.put4(var9, IO.put4(var9, 0, var5), 266), this.m_iSetIDType);
      int var3 = var4;
      if (this.m_iSetIDType != 8) {
         var3 = IO.put4(var9, var4, this.iNumBytes);
         int var6;
         int var7;
         String var10;
         String[] var11;
         label39:
         switch(this.m_iSetIDType) {
         case 1:
            byte[] var13 = var2.getBytes();
            this.addLeadingData(var2, "0", 12);
            System.arraycopy(var13, 0, var9, var3, var13.length);
            var3 += 12;
            break;
         case 2:
            var3 = IO.put8(var9, var3, Long.parseLong(var2));
            break;
         case 3:
            var3 = IO.put5(var9, var3, Long.parseLong(var2));
            break;
         case 4:
            System.arraycopy(this.addLeadingData(var2, "0", 15).getBytes(), 0, var9, var3, this.iNumBytes);
            var3 += this.iNumBytes;
            break;
         case 5:
            var10 = this.addLeadingData(var2, "0", 1000);
            byte[] var12 = var10.getBytes();
            Log.i("SUPL20_SETID", "NAI " + var10);
            System.arraycopy(var12, 0, var9, var3, this.iNumBytes);
            var3 += this.iNumBytes;
            break;
         case 6:
            var11 = var2.split("\\.");
            var6 = 0;
            var7 = var11.length;
            var4 = var3;

            while(true) {
               var3 = var4;
               if (var6 >= var7) {
                  break label39;
               }

               var4 = IO.put1(var9, var4, Integer.parseInt(var11[var6]));
               ++var6;
            }
         case 7:
            var11 = var2.split(":");
            var6 = 0;
            var7 = var11.length;
            var4 = var3;

            while(true) {
               var3 = var4;
               if (var6 >= var7) {
                  break;
               }

               var10 = this.addLeadingData(var11[var6], "0", 4);
               int var8 = Integer.parseInt(var10.substring(0, 2), 16);
               var3 = Integer.parseInt(var10.substring(2), 16);
               var4 = IO.put1(var9, IO.put1(var9, var4, var8), var3);
               ++var6;
            }
         }
      }

      var3 = IO.put2(var9, var3, var1);
      if (var5 != var3 - 4) {
         System.err.println("invalid setid packet size " + var5 + ": " + (var3 - 4));
      }

      Log.i("SUPL20_SETID", " set id " + this.m_iSetIDType + " send for id:" + var1);
      return var9;
   }
}
