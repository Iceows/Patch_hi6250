package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;

public class MultiFrameCarrier {
   public short ucMultiFrameOffset;
   public int usBCCHCarrier;

   public byte[] getMultiFrameCarrier() {
      byte[] var1 = new byte[3];
      IO.put1(var1, IO.put2(var1, 0, this.usBCCHCarrier), this.ucMultiFrameOffset);
      return var1;
   }
}
