package com.android.supl.loc.measure;

import com.android.bytewriter.IO;

public class ModeFDD {
   private boolean isCpich_Ec_N0Present;
   private boolean isCpich_RSCPPresent;
   private boolean isPathLossPresent;
   private short ucCpich_Ec_N0;
   private short ucCpich_RSCP;
   private short ucPathloss;
   private short usPrimaryScramblingCode;

   public ModeFDD(short var1, short var2, short var3, short var4) {
      boolean var6 = true;
      super();
      this.usPrimaryScramblingCode = var1;
      this.ucCpich_Ec_N0 = var2;
      this.ucCpich_RSCP = var3;
      this.ucPathloss = var4;
      boolean var5;
      if (var2 != -1) {
         var5 = true;
      } else {
         var5 = false;
      }

      this.isCpich_Ec_N0Present = var5;
      if (var3 != -1) {
         var5 = true;
      } else {
         var5 = false;
      }

      this.isCpich_RSCPPresent = var5;
      if (var4 != -1) {
         var5 = var6;
      } else {
         var5 = false;
      }

      this.isPathLossPresent = var5;
   }

   public byte[] getModeFDDInfo() {
      byte var2 = 14;
      if (this.isCpich_Ec_N0Present) {
         var2 = 15;
      }

      int var1 = var2;
      if (this.isCpich_RSCPPresent) {
         var1 = var2 + 1;
      }

      int var3 = var1;
      if (this.isPathLossPresent) {
         var3 = var1 + 1;
      }

      byte[] var4 = new byte[var3];
      var1 = IO.put2(var4, 0, this.usPrimaryScramblingCode);
      int var5 = var1;
      if (this.isCpich_Ec_N0Present) {
         var5 = IO.put1(var4, var1, this.ucCpich_Ec_N0);
      }

      var1 = var5;
      if (this.isCpich_RSCPPresent) {
         var1 = IO.put1(var4, var5, this.ucCpich_RSCP);
      }

      var5 = var1;
      if (this.isPathLossPresent) {
         var5 = IO.put1(var4, var1, this.ucPathloss);
      }

      if (var3 != var5) {
         System.out.println("ModeFDD length error");
      }

      return var4;
   }
}
