package com.android.supl.loc.measure;

import com.android.bytewriter.IO;

public class ModeTDD {
   private boolean isPathLossPresent;
   private boolean isPrimaryCCPCH_RSCPPresent;
   private boolean isProposedTGSNPresent;
   private boolean isTimeslotISCP_ListPresent;
   private TimeSlotISCPList stTimeslotISCP_List;
   private short ucCellParametersID;
   private short ucPathloss;
   private short ucPrimaryCCPCH_RSCP;
   private short ucProposedTGSN;

   public ModeTDD(short var1, short var2, short var3, short var4, TimeSlotISCPList var5) {
      boolean var7 = true;
      super();
      this.isProposedTGSNPresent = false;
      this.ucProposedTGSN = -1;
      this.isPrimaryCCPCH_RSCPPresent = false;
      this.ucPrimaryCCPCH_RSCP = -1;
      this.isPathLossPresent = false;
      this.ucPathloss = -1;
      this.isTimeslotISCP_ListPresent = false;
      this.stTimeslotISCP_List = null;
      this.ucCellParametersID = var1;
      this.ucProposedTGSN = var2;
      this.ucPrimaryCCPCH_RSCP = var3;
      this.ucPathloss = var4;
      this.stTimeslotISCP_List = var5;
      boolean var6;
      if (var2 != -1) {
         var6 = true;
      } else {
         var6 = false;
      }

      this.isProposedTGSNPresent = var6;
      if (var3 != -1) {
         var6 = true;
      } else {
         var6 = false;
      }

      this.isPrimaryCCPCH_RSCPPresent = var6;
      if (var4 != -1) {
         var6 = true;
      } else {
         var6 = false;
      }

      this.isPathLossPresent = var6;
      if (var5 != null) {
         var6 = var7;
      } else {
         var6 = false;
      }

      this.isTimeslotISCP_ListPresent = var6;
   }

   public byte[] getModeTDDInfo() {
      byte var1 = 17;
      if (this.isProposedTGSNPresent) {
         var1 = 18;
      }

      int var2 = var1;
      if (this.isPrimaryCCPCH_RSCPPresent) {
         var2 = var1 + 1;
      }

      int var6 = var2;
      if (this.isPathLossPresent) {
         var6 = var2 + 1;
      }

      byte[] var4 = null;
      int var3 = var6;
      if (this.isTimeslotISCP_ListPresent) {
         var4 = this.stTimeslotISCP_List.getTimeslotISCPListInfo();
         var3 = var6 + var4.length;
      }

      byte[] var5 = new byte[var3];
      var2 = IO.put1(var5, 0, this.ucCellParametersID);
      var6 = var2;
      if (this.isProposedTGSNPresent) {
         var6 = IO.put1(var5, var2, this.ucProposedTGSN);
      }

      var2 = var6;
      if (this.isPrimaryCCPCH_RSCPPresent) {
         var2 = IO.put1(var5, var6, this.ucPrimaryCCPCH_RSCP);
      }

      var6 = var2;
      if (this.isPathLossPresent) {
         var6 = IO.put1(var5, var2, this.ucPathloss);
      }

      var2 = var6;
      if (this.isTimeslotISCP_ListPresent) {
         System.arraycopy(var4, 0, var5, var6, var4.length);
         var2 = var6 + var4.length;
      }

      if (var2 != var3) {
         System.out.println("ModeTDD length error");
      }

      return var5;
   }
}
