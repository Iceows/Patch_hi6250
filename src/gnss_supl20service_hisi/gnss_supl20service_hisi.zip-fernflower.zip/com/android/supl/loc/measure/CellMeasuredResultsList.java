package com.android.supl.loc.measure;

import com.android.bytewriter.IO;
import java.util.Iterator;
import java.util.Vector;

public class CellMeasuredResultsList {
   private CellMeasuredResults[] astCellMeasuredResults = null;
   private short ucCellMeasuredResultsCnt;

   public CellMeasuredResultsList(CellMeasuredResults[] var1) {
      if (var1 == null) {
         throw new IllegalArgumentException("CellMeasuredResults should not be n");
      } else {
         this.astCellMeasuredResults = var1;
         this.ucCellMeasuredResultsCnt = (short)var1.length;
      }
   }

   public byte[] getCellMeasuredResultList() {
      int var1 = 1;
      Vector var4 = new Vector(this.ucCellMeasuredResultsCnt);
      CellMeasuredResults[] var5 = this.astCellMeasuredResults;
      int var3 = var5.length;

      int var2;
      for(var2 = 0; var2 < var3; ++var2) {
         CellMeasuredResults var6 = var5[var2];
         if (var6 != null) {
            byte[] var9 = var6.getCellMeasuredResults();
            var1 += var9.length;
            var4.add(var9);
         }
      }

      byte[] var8 = new byte[var1];
      var2 = IO.put1(var8, 0, this.ucCellMeasuredResultsCnt);

      byte[] var7;
      for(Iterator var10 = var4.iterator(); var10.hasNext(); var2 += var7.length) {
         var7 = (byte[])var10.next();
         System.arraycopy(var7, 0, var8, var2, var7.length);
      }

      if (var2 != var1) {
         System.out.println("CellMeasuredResultList length error");
      }

      return var8;
   }
}
