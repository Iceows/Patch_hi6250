package com.android.supl.loc.measure;

import com.android.bytewriter.IO;

public class TimeSlotISCPList {
   private byte[] aucTimeslotISCP = null;
   private short ucTimeslotISCPsCnt;

   public TimeSlotISCPList(byte[] var1) {
      if (var1 == null) {
         throw new IllegalArgumentException("TimeslotISCP should not be null");
      } else {
         this.aucTimeslotISCP = var1;
         this.ucTimeslotISCPsCnt = (short)this.aucTimeslotISCP.length;
      }
   }

   public byte[] getTimeslotISCPListInfo() {
      int var1 = 1;
      if (this.aucTimeslotISCP != null) {
         var1 = this.aucTimeslotISCP.length + 1;
      }

      byte[] var2 = new byte[var1];
      var1 = IO.put1(var2, 0, this.ucTimeslotISCPsCnt);
      System.arraycopy(this.aucTimeslotISCP, 0, var2, var1, this.ucTimeslotISCPsCnt);
      short var3 = this.ucTimeslotISCPsCnt;
      return var2;
   }
}
