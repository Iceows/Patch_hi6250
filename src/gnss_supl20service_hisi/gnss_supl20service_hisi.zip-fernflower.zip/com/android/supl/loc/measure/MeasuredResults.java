package com.android.supl.loc.measure;

import com.android.bytewriter.IO;

public class MeasuredResults {
   private boolean bIsCellMeasuredResultsListPresent;
   private boolean bIsFrequencyInfoPresent;
   private boolean bIsUtra_CarrierRSSIPresent;
   private FrequencyInfo mFrequencyInfo;
   private CellMeasuredResultsList stCellMeasuredResultsList;
   private short ucUtra_CarrierRSSI;

   public MeasuredResults(FrequencyInfo var1, short var2, CellMeasuredResultsList var3) {
      boolean var5 = true;
      super();
      this.mFrequencyInfo = null;
      this.stCellMeasuredResultsList = null;
      this.mFrequencyInfo = var1;
      this.ucUtra_CarrierRSSI = var2;
      this.stCellMeasuredResultsList = var3;
      boolean var4;
      if (var1 != null) {
         var4 = true;
      } else {
         var4 = false;
      }

      this.bIsFrequencyInfoPresent = var4;
      if (var2 != -1) {
         var4 = true;
      } else {
         var4 = false;
      }

      this.bIsUtra_CarrierRSSIPresent = var4;
      if (var3 != null) {
         var4 = var5;
      } else {
         var4 = false;
      }

      this.bIsCellMeasuredResultsListPresent = var4;
   }

   public byte[] getMeasuredResultsInfo() {
      byte var1 = 12;
      byte[] var4 = null;
      int var2 = var1;
      byte[] var5;
      if (this.bIsFrequencyInfoPresent) {
         var5 = this.mFrequencyInfo.getFrequencyInfo();
         var4 = var5;
         var2 = var1;
         if (var5 != null) {
            var2 = var5.length + 12;
            var4 = var5;
         }
      }

      int var7 = var2;
      if (this.bIsUtra_CarrierRSSIPresent) {
         var7 = var2 + 1;
      }

      var5 = null;
      var2 = var7;
      if (this.bIsCellMeasuredResultsListPresent) {
         var5 = this.stCellMeasuredResultsList.getCellMeasuredResultList();
         var2 = var7 + var5.length;
      }

      byte[] var6 = new byte[var2];
      if (this.bIsFrequencyInfoPresent) {
         int var3 = IO.put4(var6, 0, 1);
         var7 = var3;
         if (var4 != null) {
            System.arraycopy(var4, 0, var6, var3, var4.length);
            var7 = var3 + var4.length;
         }
      } else {
         var7 = IO.put4(var6, 0, 0);
      }

      if (this.bIsUtra_CarrierRSSIPresent) {
         var7 = IO.put1(var6, IO.put4(var6, var7, 1), this.ucUtra_CarrierRSSI);
      } else {
         var7 = IO.put4(var6, var7, 0);
      }

      if (this.bIsCellMeasuredResultsListPresent) {
         var7 = IO.put4(var6, var7, 1);
         System.arraycopy(var5, 0, var6, var7, var5.length);
         var7 += var5.length;
      } else {
         var7 = IO.put4(var6, var7, 0);
      }

      if (var7 != var2) {
         System.out.println("MeasuredResultsInfo length error");
      }

      return var6;
   }
}
