package com.android.supl.loc.measure.odtoa;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class OTDOAConfigParser extends DefaultHandler {
   private static final String BCELLIDPARAMVALID = "bcellidparamvalid";
   private static final String BURSTTYPE = "bursttype";
   private static final String CELLPARAMID = "cellparamid";
   private static final String CELLPARAMSID = "cellparamsid";
   private static final String MEASUREINFOTYPE = "measureinfotype";
   private static final String MIDAMBLESHIFT = "midambleshift";
   private static final String MODEFDD = "modeFDD";
   private static final String MODESPECIFICMEASURE = "modespecificmeasure";
   private static final String MODETDD = "modeTDD";
   private static final String MODETYPE = "modetype";
   private static final String NEIGHBOURCOUNT = "neighbourcount";
   private static final String NEIGHBOURLIST = "neighbourlist";
   private static final String NEIGHBOURMEAS = "neighbourmeas";
   private static final String NEIGHBOURPRESENT = "neighbourpresent";
   private static final String NOOFMEASUREMENTS = "noofmeasurements";
   private static final String OTDOAMEASURE = "otdoameasure";
   private static final String PRIMSCRAMBCODE = "primscrambcode";
   private static final String PRIMSCRAMBCODEPRESENT = "primscrambcodepresent";
   private static final String RXTXTIMEDIFFTYPE = "rxtxtimedifftype";
   private static final String RXTXTIMEDIFFVALID = "rxtxtimediffvalid";
   private static final String SFN = "sfn";
   private static final String SFNSFNOBSTIMEDIFF = "sfnsfnobstimediff";
   private static final String STDDEVOTDOAMEAS = "stddevOTDOAmeas";
   private static final String STDVALUE = "stdvalue";
   private static final String TIMESLOT = "timeslot";
   private static final String VALID = "valid";
   private int iMeasIndex = -1;
   private boolean isModeSpecMeas = false;
   private boolean isNeighbourMeas = false;
   private boolean isNeighbourMeasData = false;
   private boolean isRequiredTag = false;
   private SUPL_OTDOA_Measurement otdoa_Measurement = null;
   private String stData = null;

   public OTDOAConfigParser() {
      this.init();
   }

   public void characters(char[] var1, int var2, int var3) throws SAXException {
      if (this.isRequiredTag) {
         this.stData = (new String(var1, var2, var3)).trim();
         this.isRequiredTag = false;
      } else {
         this.stData = null;
      }

   }

   public void endElement(String var1, String var2, String var3) throws SAXException {
      boolean var4 = false;
      boolean var6 = true;
      boolean var7 = true;
      boolean var8 = true;
      boolean var9 = true;
      boolean var10 = true;
      boolean var5 = true;
      SUPL_OTDOA_Measurement var11;
      if (var2.equals("valid")) {
         var11 = this.otdoa_Measurement;
         if (Integer.parseInt(this.stData) == 1) {
            var4 = var5;
         } else {
            var4 = false;
         }

         var11.bMeasurementValid = var4;
      } else if (var2.equals("sfn")) {
         this.otdoa_Measurement.lSFN = Long.parseLong(this.stData);
      } else if (var2.equals("measureinfotype")) {
         this.otdoa_Measurement.eModeSpecInfoType = Integer.parseInt(this.stData);
      } else if (var2.equals("modespecificmeasure")) {
         this.isModeSpecMeas = false;
      } else {
         SUPL_OTDOA_ModeSpecMeasFDD var12;
         if (var2.equals("primscrambcodepresent")) {
            if (this.isModeSpecMeas) {
               if (this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas != null) {
                  var12 = this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas;
                  if (Integer.parseInt(this.stData) == 1) {
                     var4 = var6;
                  } else {
                     var4 = false;
                  }

                  var12.bPrimaryScramblingCodePresent = var4;
               }
            } else if (this.isNeighbourMeas && this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas != null) {
               var12 = this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas;
               if (Integer.parseInt(this.stData) == 1) {
                  var4 = var7;
               } else {
                  var4 = false;
               }

               var12.bPrimaryScramblingCodePresent = var4;
            }
         } else if (var2.equals("primscrambcode")) {
            if (this.isModeSpecMeas) {
               if (this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas != null) {
                  this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas.lPrimaryScramblingCode = Long.parseLong(this.stData);
               }
            } else if (this.isNeighbourMeas && this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas != null) {
               this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas.lPrimaryScramblingCode = Long.parseLong(this.stData);
            }
         } else if (var2.equals("rxtxtimediffvalid")) {
            if (this.isModeSpecMeas) {
               if (this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas != null) {
                  var12 = this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas;
                  if (Integer.parseInt(this.stData) == 1) {
                     var4 = var8;
                  } else {
                     var4 = false;
                  }

                  var12.bRxTxTimeDiffValid = var4;
               }
            } else if (this.isNeighbourMeas && this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas != null) {
               var12 = this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas;
               if (Integer.parseInt(this.stData) == 1) {
                  var4 = var9;
               } else {
                  var4 = false;
               }

               var12.bRxTxTimeDiffValid = var4;
            }
         } else if (var2.equals("rxtxtimedifftype")) {
            if (this.isModeSpecMeas) {
               if (this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas != null) {
                  this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas.lRxTxTimeDiffType2 = Long.parseLong(this.stData);
               }
            } else if (this.isNeighbourMeas && this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas != null) {
               this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas.lRxTxTimeDiffType2 = Long.parseLong(this.stData);
            }
         } else if (var2.equals("stdvalue")) {
            if (this.isModeSpecMeas) {
               if (this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas != null) {
                  this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas.ucStdValue = Short.parseShort(this.stData);
               }
            } else if (this.isNeighbourMeas) {
               if (this.isNeighbourMeasData) {
                  this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].ucStdValue = Short.parseShort(this.stData);
               } else if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas != null) {
                  this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas.ucStdValue = Short.parseShort(this.stData);
               }
            }
         } else if (var2.equals("noofmeasurements")) {
            if (this.isModeSpecMeas) {
               if (this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas != null) {
                  this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas.ucNoOfMeasurements = Short.parseShort(this.stData);
               }
            } else if (this.isNeighbourMeas) {
               if (this.isNeighbourMeasData) {
                  this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].ucNoOfMeasurements = Short.parseShort(this.stData);
               } else if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas != null) {
                  this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas.ucNoOfMeasurements = Short.parseShort(this.stData);
               }
            }
         } else if (var2.equals("stddevOTDOAmeas")) {
            if (this.isModeSpecMeas) {
               if (this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas != null) {
                  this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas.ucStdDevOTDOAMeas = Short.parseShort(this.stData);
               }
            } else if (this.isNeighbourMeas) {
               if (this.isNeighbourMeasData) {
                  this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].ucStdDevOTDOAMeas = Short.parseShort(this.stData);
               } else if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas != null) {
                  this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas.ucStdDevOTDOAMeas = Short.parseShort(this.stData);
               }
            }
         } else if (var2.equals("sfnsfnobstimediff")) {
            if (this.isNeighbourMeasData) {
               this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].lSFNSFNObsTimeDiff2 = Long.parseLong(this.stData);
            }
         } else if (var2.equals("bcellidparamvalid")) {
            if (this.otdoa_Measurement.stModeSpecMeas.stModeSpecificTDDMeas != null) {
               SUPL_OTDOA_ModeSpecMeansTDD var13 = this.otdoa_Measurement.stModeSpecMeas.stModeSpecificTDDMeas;
               if (Integer.parseInt(this.stData) == 1) {
                  var4 = var10;
               } else {
                  var4 = false;
               }

               var13.bCellIDParamValid = var4;
            }
         } else if (var2.equals("cellparamsid")) {
            if (this.otdoa_Measurement.stModeSpecMeas.stModeSpecificTDDMeas != null) {
               this.otdoa_Measurement.stModeSpecMeas.stModeSpecificTDDMeas.lCellParamsID = Long.parseLong(this.stData);
            }
         } else if (var2.equals("neighbourpresent")) {
            var11 = this.otdoa_Measurement;
            if (Integer.parseInt(this.stData) == 1) {
               var4 = true;
            }

            var11.bNeighbourListPresent = var4;
            if (this.otdoa_Measurement.bNeighbourListPresent) {
               this.isNeighbourMeas = true;
            }
         } else if (var2.equals("neighbourcount")) {
            this.otdoa_Measurement.ucNoOfNeighbourList = Short.parseShort(this.stData);
            this.otdoa_Measurement.stNeighbourMeasList = new SUPL_OTDOA_NeighbourMeas[this.otdoa_Measurement.ucNoOfNeighbourList];
         } else if (var2.equals("neighbourmeas")) {
            this.isNeighbourMeasData = false;
         } else if (var2.equals("neighbourlist")) {
            this.isNeighbourMeas = false;
         } else if (var2.equals("modetype")) {
            this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].eModeType = Integer.parseInt(this.stData);
         } else if (var2.equals("bursttype")) {
            if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificTDDMeas != null) {
               this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificTDDMeas.eBurstType = Integer.parseInt(this.stData);
            }
         } else if (var2.equals("midambleshift")) {
            if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificTDDMeas != null) {
               this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificTDDMeas.lMidAmbleShift = Long.parseLong(this.stData);
            }
         } else if (var2.equals("timeslot")) {
            if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificTDDMeas != null) {
               this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificTDDMeas.lTimeSlot = Long.parseLong(this.stData);
            }
         } else if (var2.equals("cellparamid")) {
            if (this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificTDDMeas != null) {
               this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificTDDMeas.lCellParamID = Long.parseLong(this.stData);
            }
         } else if (var2.equals("modeTDD")) {
            if (this.isNeighbourMeas) {
               this.isNeighbourMeasData = true;
            } else {
               this.isNeighbourMeasData = false;
            }
         }
      }

   }

   public SUPL_OTDOA_Measurement getOtdoa_Measurement() {
      return this.otdoa_Measurement;
   }

   public void init() {
      // $FF: Couldn't be decompiled
   }

   public void startElement(String var1, String var2, String var3, Attributes var4) throws SAXException {
      if (var2.equals("otdoameasure")) {
         this.otdoa_Measurement = new SUPL_OTDOA_Measurement();
      } else if (var2.equals("valid")) {
         this.isRequiredTag = true;
      } else if (var2.equals("sfn")) {
         this.isRequiredTag = true;
      } else if (var2.equals("measureinfotype")) {
         this.isRequiredTag = true;
      } else if (var2.equals("modespecificmeasure")) {
         this.otdoa_Measurement.stModeSpecMeas = new SUPL_OTDOA_ModeSpecMeas();
         this.isModeSpecMeas = true;
      } else if (var2.equals("modeFDD")) {
         if (this.isModeSpecMeas) {
            if (this.otdoa_Measurement.eModeSpecInfoType == 1) {
               this.otdoa_Measurement.stModeSpecMeas.stModeSpecificFDDMeas = new SUPL_OTDOA_ModeSpecMeasFDD();
            }
         } else if (this.isNeighbourMeas && this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].eModeType == 1) {
            this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificFDDMeas = new SUPL_OTDOA_ModeSpecMeasFDD();
         }
      } else if (var2.equals("primscrambcodepresent")) {
         this.isRequiredTag = true;
      } else if (var2.equals("primscrambcode")) {
         this.isRequiredTag = true;
      } else if (var2.equals("rxtxtimediffvalid")) {
         this.isRequiredTag = true;
      } else if (var2.equals("rxtxtimedifftype")) {
         this.isRequiredTag = true;
      } else if (var2.equals("stdvalue")) {
         this.isRequiredTag = true;
      } else if (var2.equals("noofmeasurements")) {
         this.isRequiredTag = true;
      } else if (var2.equals("stddevOTDOAmeas")) {
         this.isRequiredTag = true;
      } else if (var2.equals("modeTDD")) {
         if (this.isModeSpecMeas) {
            if (this.otdoa_Measurement.eModeSpecInfoType == 2) {
               this.otdoa_Measurement.stModeSpecMeas.stModeSpecificTDDMeas = new SUPL_OTDOA_ModeSpecMeansTDD();
            }
         } else if (this.isNeighbourMeas && this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].eModeType == 2) {
            this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo.stModeSpecificTDDMeas = new SUPL_OTDOA_MDSpecINF_TDD();
         }
      } else if (var2.equals("bcellidparamvalid")) {
         this.isRequiredTag = true;
      } else if (var2.equals("cellparamsid")) {
         this.isRequiredTag = true;
      } else if (var2.equals("neighbourpresent")) {
         this.isRequiredTag = true;
      } else if (var2.equals("neighbourcount")) {
         this.isRequiredTag = true;
      } else if (var2.equals("neighbourmeas")) {
         ++this.iMeasIndex;
         this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex] = new SUPL_OTDOA_NeighbourMeas();
         this.otdoa_Measurement.stNeighbourMeasList[this.iMeasIndex].stNeighbourMeasInfo = new SUPL_OTDOA_NeighModeSpecMeas();
      } else if (var2.equals("modetype")) {
         this.isRequiredTag = true;
      } else if (var2.equals("bursttype")) {
         this.isRequiredTag = true;
      } else if (var2.equals("midambleshift")) {
         this.isRequiredTag = true;
      } else if (var2.equals("timeslot")) {
         this.isRequiredTag = true;
      } else if (var2.equals("cellparamid")) {
         this.isRequiredTag = true;
      } else if (var2.equals("sfnsfnobstimediff")) {
         this.isRequiredTag = true;
      }

   }
}
