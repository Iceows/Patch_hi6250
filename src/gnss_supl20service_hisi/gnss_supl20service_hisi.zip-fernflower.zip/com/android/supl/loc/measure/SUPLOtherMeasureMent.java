package com.android.supl.loc.measure;

public class SUPLOtherMeasureMent {
   public static final int NONE = 0;
   public static final int SUPL_OTHER_MEAS_AFLT = 4;
   public static final int SUPL_OTHER_MEAS_EOTD = 3;
   public static final int SUPL_OTHER_MEAS_OTDOA_GSM = 1;
   public static final int SUPL_OTHER_MEAS_OTDOA_LPP = 2;
}
