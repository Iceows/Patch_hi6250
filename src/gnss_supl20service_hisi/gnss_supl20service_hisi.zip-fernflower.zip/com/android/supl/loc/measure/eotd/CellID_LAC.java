package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;

public class CellID_LAC {
   public short usReferenceCI;
   public short usReferenceLAC;

   public byte[] getCellID_LAC() {
      byte[] var1 = new byte[4];
      IO.put2(var1, IO.put2(var1, 0, this.usReferenceLAC), this.usReferenceCI);
      return var1;
   }
}
