package com.android.supl.loc.measure.aflt;

import com.android.bytewriter.IO;

public class SUPL_AFLT_PilotPhaseRecord {
   public int PilotMeasuredPhase;
   public int PilotPhaseDoppler;
   public int PilotPhaseMeasurementError;
   public int PilotStrength;
   public int PilotphaseFalseAlarmProbability;
   public int PilotphaseFalseAlarmRange;
   public int PseudoDopplerRMSError;
   public int RMSErrorPhase;
   public int RepeaterDetectionStatus;
   public byte[] RepeaterID = new byte[8];
   public int RepeaterType;

   public byte[] getAfltPilotPhaseRecord() {
      byte[] var3 = new byte[72];
      int var2 = IO.put4(var3, IO.put4(var3, IO.put4(var3, IO.put4(var3, IO.put4(var3, IO.put4(var3, 0, this.PilotMeasuredPhase), this.PilotStrength), this.RMSErrorPhase), this.PilotPhaseMeasurementError), this.RepeaterDetectionStatus), this.RepeaterType);

      for(int var1 = 0; var1 < 8; ++var1) {
         var2 = IO.put1(var3, var2, this.RepeaterID[var1]);
      }

      IO.put4(var3, IO.put4(var3, IO.put4(var3, IO.put4(var3, var2, this.PilotPhaseDoppler), this.PseudoDopplerRMSError), this.PilotphaseFalseAlarmProbability), this.PilotphaseFalseAlarmRange);
      return var3;
   }
}
