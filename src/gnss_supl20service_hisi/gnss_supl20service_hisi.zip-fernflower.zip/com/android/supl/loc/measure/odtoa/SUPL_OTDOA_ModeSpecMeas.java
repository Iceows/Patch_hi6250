package com.android.supl.loc.measure.odtoa;

public class SUPL_OTDOA_ModeSpecMeas {
   public SUPL_OTDOA_ModeSpecMeasFDD stModeSpecificFDDMeas;
   public SUPL_OTDOA_ModeSpecMeansTDD stModeSpecificTDDMeas;

   public byte[] getModeSpecMeas() {
      byte[] var1 = null;
      if (this.stModeSpecificFDDMeas != null) {
         var1 = this.stModeSpecificFDDMeas.getModeSpecMeasFDD();
      } else if (this.stModeSpecificTDDMeas != null) {
         var1 = this.stModeSpecificTDDMeas.getModeSpecMeansTDD();
      }

      return var1;
   }
}
