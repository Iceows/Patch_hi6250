package com.android.supl.loc.measure.lpp;

import com.android.bytewriter.IO;

public class SUPL_LPP_OTDOA_SIGNAL_MMT {
   public boolean bArfcnPresent;
   public boolean bMeasureQualityPresent;
   public boolean bNeighbourMMTValid;
   public boolean bOTDOAEGCIValid = true;
   public int lArfcnEUTRAValue;
   public SUPL_LPP_NEIGHBOUR_OTDOA_MMT stLPPOTDOANeighbourLst = null;
   public SUPL_LPP_EGCI stOTDOAEGCIInfo = null;
   public SUPL_LPP_OTDOA_MMT_QUALITY stOTDOAMeasureQuality = null;
   public short usPhysCellID = 413;
   public short wSignalFrameNo = 412;

   public SUPL_LPP_OTDOA_SIGNAL_MMT() {
      this.stOTDOAEGCIInfo = new SUPL_LPP_EGCI();
      this.bArfcnPresent = true;
      this.lArfcnEUTRAValue = 415;
      this.bMeasureQualityPresent = true;
      this.stOTDOAMeasureQuality = new SUPL_LPP_OTDOA_MMT_QUALITY();
      this.bNeighbourMMTValid = true;
      this.stLPPOTDOANeighbourLst = new SUPL_LPP_NEIGHBOUR_OTDOA_MMT();
   }

   public byte[] getSIGNAL_MMT() {
      byte var3 = 1;
      byte var1 = 20;
      Object var5 = null;
      byte[] var4 = (byte[])var5;
      int var2 = var1;
      byte[] var9;
      if (this.bOTDOAEGCIValid) {
         var4 = (byte[])var5;
         var2 = var1;
         if (this.stOTDOAEGCIInfo != null) {
            var9 = this.stOTDOAEGCIInfo.getLPP_EGCI();
            var4 = var9;
            var2 = var1;
            if (var9 != null) {
               var2 = var9.length + 20;
               var4 = var9;
            }
         }
      }

      int var8 = var2;
      if (this.bArfcnPresent) {
         var8 = var2 + 4;
      }

      Object var6 = null;
      var9 = (byte[])var6;
      var2 = var8;
      byte[] var11;
      if (this.bMeasureQualityPresent) {
         var9 = (byte[])var6;
         var2 = var8;
         if (this.stOTDOAMeasureQuality != null) {
            var11 = this.stOTDOAMeasureQuality.getOTDOA_MMT_QUALITY();
            var9 = var11;
            var2 = var8;
            if (var11 != null) {
               var2 = var8 + var11.length;
               var9 = var11;
            }
         }
      }

      Object var7 = null;
      var11 = (byte[])var7;
      var8 = var2;
      byte[] var12;
      if (this.bNeighbourMMTValid) {
         var11 = (byte[])var7;
         var8 = var2;
         if (this.stLPPOTDOANeighbourLst != null) {
            var12 = this.stLPPOTDOANeighbourLst.get_NEIGHBOUR_OTDOA_MMT();
            var11 = var12;
            var8 = var2;
            if (var12 != null) {
               var8 = var2 + var12.length;
               var11 = var12;
            }
         }
      }

      var12 = new byte[var8];
      var2 = IO.put2(var12, IO.put2(var12, 0, this.wSignalFrameNo), this.usPhysCellID);
      if (this.bOTDOAEGCIValid) {
         var1 = 1;
      } else {
         var1 = 0;
      }

      var2 = IO.put4(var12, var2, var1);
      var8 = var2;
      if (this.bOTDOAEGCIValid) {
         var8 = var2;
         if (var4 != null) {
            System.arraycopy(var4, 0, var12, var2, var4.length);
            var8 = var2 + var4.length;
         }
      }

      byte var10;
      if (this.bArfcnPresent) {
         var10 = 1;
      } else {
         var10 = 0;
      }

      var2 = IO.put4(var12, var8, var10);
      var8 = var2;
      if (this.bArfcnPresent) {
         var8 = IO.put4(var12, var2, this.lArfcnEUTRAValue);
      }

      if (this.bMeasureQualityPresent) {
         var10 = 1;
      } else {
         var10 = 0;
      }

      var2 = IO.put4(var12, var8, var10);
      var8 = var2;
      if (this.bMeasureQualityPresent) {
         var8 = var2;
         if (var9 != null) {
            System.arraycopy(var9, 0, var12, var2, var9.length);
            var8 = var2 + var9.length;
         }
      }

      if (this.bNeighbourMMTValid) {
         var10 = var3;
      } else {
         var10 = 0;
      }

      var8 = IO.put4(var12, var8, var10);
      if (this.bNeighbourMMTValid && var11 != null) {
         System.arraycopy(var11, 0, var12, var8, var11.length);
         var8 = var11.length;
      }

      return var12;
   }
}
