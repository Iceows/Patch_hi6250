package com.android.supl.loc.measure;

import com.android.bytewriter.IO;

public class FrequencyInfoFdd {
   private boolean bIsUarfcn_UL_Present;
   private short usUarfcn_DL;
   private short usUarfcn_UL;

   public FrequencyInfoFdd(short var1, short var2) {
      this.usUarfcn_UL = var1;
      this.usUarfcn_DL = var2;
      boolean var3;
      if (var1 != -1) {
         var3 = true;
      } else {
         var3 = false;
      }

      this.bIsUarfcn_UL_Present = var3;
   }

   public byte[] getFrequencyInfoFdd() {
      byte var1 = 4;
      if (this.bIsUarfcn_UL_Present) {
         var1 = 8;
      }

      byte[] var3 = new byte[var1];
      int var2;
      if (this.bIsUarfcn_UL_Present) {
         var2 = IO.put2(var3, IO.put4(var3, 0, 1), this.usUarfcn_UL);
      } else {
         var2 = IO.put4(var3, 0, 0);
      }

      if (IO.put2(var3, var2, this.usUarfcn_DL) != var1) {
         System.out.println("FrequencyInfoFdd length invalid");
      }

      return var3;
   }
}
