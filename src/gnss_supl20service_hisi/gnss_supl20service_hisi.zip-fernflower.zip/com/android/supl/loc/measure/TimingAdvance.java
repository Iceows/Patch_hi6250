package com.android.supl.loc.measure;

import com.android.bytewriter.IO;

public class TimingAdvance {
   public static final int CHIP_RATE_TDD128 = 0;
   public static final int CHIP_RATE_TDD384 = 1;
   public static final int CHIP_RATE_TDD768 = 2;
   public static final int TA_RESOLUTION_RES0125CHIP = 2;
   public static final int TA_RESOLUTION_RES10CHIP = 0;
   public static final int TA_RESOLUTION_RES5CHIP = 1;
   private int enChipRate;
   private int enTAResolution;
   private boolean isChipRatePresent;
   private boolean isTAResolutionPresent;
   private short usTA;

   public TimingAdvance(short var1, int var2, int var3) {
      boolean var5 = true;
      super();
      this.isTAResolutionPresent = false;
      this.enTAResolution = -1;
      this.isChipRatePresent = false;
      this.enChipRate = -1;
      this.usTA = var1;
      this.enTAResolution = var2;
      this.enChipRate = var3;
      boolean var4;
      if (var2 != -1) {
         var4 = true;
      } else {
         var4 = false;
      }

      this.isTAResolutionPresent = var4;
      if (var3 != -1) {
         var4 = var5;
      } else {
         var4 = false;
      }

      this.isChipRatePresent = var4;
   }

   public byte[] getTimingAdvanceInfo() {
      byte var1 = 10;
      if (this.isTAResolutionPresent) {
         var1 = 14;
      }

      int var2 = var1;
      if (this.isChipRatePresent) {
         var2 = var1 + 4;
      }

      byte[] var3 = new byte[var2];
      int var4 = IO.put2(var3, 0, this.usTA);
      if (this.isTAResolutionPresent) {
         var4 = IO.put4(var3, IO.put4(var3, var4, 1), this.enTAResolution);
      } else {
         var4 = IO.put4(var3, var4, 0);
      }

      if (this.isChipRatePresent) {
         var4 = IO.put4(var3, IO.put4(var3, var4, 1), this.enChipRate);
      } else {
         var4 = IO.put4(var3, var4, 0);
      }

      if (var4 != var2) {
         System.out.println("TimingAdvance length error");
      }

      return var3;
   }
}
