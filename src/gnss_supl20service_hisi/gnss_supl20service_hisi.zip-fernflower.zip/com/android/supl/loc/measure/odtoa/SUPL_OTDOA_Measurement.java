package com.android.supl.loc.measure.odtoa;

import android.util.Log;
import com.android.bytewriter.IO;
import java.util.Iterator;
import java.util.Vector;

public class SUPL_OTDOA_Measurement {
   public static final int SUPL_OTDOA_MODE_SPEC_INFO_FDD = 1;
   public static final int SUPL_OTDOA_MODE_SPEC_INFO_NONE = 0;
   public static final int SUPL_OTDOA_MODE_SPEC_INFO_TDD = 2;
   public boolean bMeasurementValid;
   public boolean bNeighbourListPresent;
   public int eModeSpecInfoType;
   public long lSFN;
   public SUPL_OTDOA_ModeSpecMeas stModeSpecMeas;
   public SUPL_OTDOA_NeighbourMeas[] stNeighbourMeasList;
   public short ucNoOfNeighbourList;

   public byte[] getOTDOA_Measurement(int var1) {
      int var3 = 16;
      byte[] var6 = null;
      if (this.stModeSpecMeas != null) {
         var6 = this.stModeSpecMeas.getModeSpecMeas();
         var3 = var6.length + 16;
      }

      int var2 = var3;
      if (this.bNeighbourListPresent) {
         var2 = var3 + 1;
      }

      Vector var8 = null;
      int var4 = var2;
      Vector var7 = var8;
      byte[] var14;
      if (this.bNeighbourListPresent) {
         var4 = var2;
         var7 = var8;
         if (this.stNeighbourMeasList != null) {
            var8 = new Vector(this.stNeighbourMeasList.length);
            SUPL_OTDOA_NeighbourMeas[] var9 = this.stNeighbourMeasList;
            var3 = 0;
            int var5 = var9.length;

            while(true) {
               var4 = var2;
               var7 = var8;
               if (var3 >= var5) {
                  break;
               }

               SUPL_OTDOA_NeighbourMeas var13 = var9[var3];
               var4 = var2;
               if (var13 != null) {
                  var14 = var13.getNeighbourMeas();
                  var4 = var2;
                  if (var14 != null) {
                     var4 = var2 + var14.length;
                     var8.add(var14);
                  }
               }

               ++var3;
               var2 = var4;
            }
         }
      }

      var2 = var4 + 8 + 4;
      byte[] var15 = new byte[var2];
      var2 = IO.put4(var15, IO.put4(var15, IO.put4(var15, 0, var2 - 4), 276), var1);
      byte var10;
      if (this.bMeasurementValid) {
         var10 = 1;
      } else {
         var10 = 0;
      }

      var2 = IO.put4(var15, IO.put4(var15, IO.put4(var15, var2, var10), (int)this.lSFN), this.eModeSpecInfoType);
      var1 = var2;
      if (var6 != null) {
         System.arraycopy(var6, 0, var15, var2, var6.length);
         var1 = var2 + var6.length;
      }

      byte var11;
      if (this.bNeighbourListPresent) {
         var11 = 1;
      } else {
         var11 = 0;
      }

      var1 = IO.put4(var15, var1, var11);
      if (this.bNeighbourListPresent) {
         var1 = IO.put1(var15, var1, this.ucNoOfNeighbourList);
         if (var7 != null) {
            Iterator var12 = var7.iterator();

            while(var12.hasNext()) {
               var14 = (byte[])var12.next();
               if (var14 != null) {
                  System.arraycopy(var14, 0, var15, var1, var14.length);
                  var1 += var14.length;
               }
            }
         }
      }

      Log.i("SUPL20_OTDOA", "OTDOA msg has send :" + var15.length + " " + 276);
      return var15;
   }
}
