package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;

public class Neighbor_Identity {
   public int enIdType;
   public Neighbor_ID_Union stNeigh;

   public byte[] getNeighbor_Identity() {
      byte[] var2 = null;
      if (this.stNeigh != null) {
         byte[] var4 = this.stNeigh.getNeighborIDUnion(this.enIdType);
         byte[] var3 = new byte[var4.length + 4];
         int var1 = IO.put4(var3, 0, this.enIdType);
         var2 = var3;
         if (var4 != null) {
            System.arraycopy(var4, 0, var3, var1, var4.length);
            var1 = var4.length;
            var2 = var3;
         }
      }

      return var2;
   }
}
