package com.android.supl.loc.measure;

import com.android.bytewriter.IO;

public class ModeSpecificInfo {
   public static final int MODE_SPECIFIC_INFO_TYPE_FDD = 1;
   public static final int MODE_SPECIFIC_INFO_TYPE_TDD = 2;
   private int ienModeSpecificInfoType = 0;
   private ModeFDD mFdd = null;
   private ModeTDD mModeTDD = null;

   public ModeSpecificInfo(int var1, Object var2) {
      if (var1 == 1) {
         this.mFdd = (ModeFDD)var2;
      } else {
         if (var1 != 2) {
            throw new IllegalArgumentException("Invalid ModeSpecificInfo type");
         }

         this.mModeTDD = (ModeTDD)var2;
      }

   }

   public byte[] getModeSpecificInfo() {
      int var1 = 4;
      byte[] var4 = null;
      if (this.ienModeSpecificInfoType == 1) {
         var4 = this.mFdd.getModeFDDInfo();
         var1 = var4.length + 4;
      } else if (this.ienModeSpecificInfoType == 2) {
         var4 = this.mModeTDD.getModeTDDInfo();
         var1 = var4.length + 4;
      }

      byte[] var5 = new byte[var1];
      int var3 = IO.put4(var5, 0, this.ienModeSpecificInfoType);
      int var2 = var3;
      if (var4 != null) {
         System.arraycopy(var4, 0, var5, var3, var4.length);
         var2 = var3 + var4.length;
      }

      if (var2 != var1) {
         System.out.println("ModeSpecificInfo length error");
      }

      return var5;
   }
}
