package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

public class OTD_MsrEleFirst {
   public ArrayList aWithIDs = null;
   public OTD_MSREleCommon otd_MsrComm;
   public short ucSetCount;

   public byte[] getOTD_MsrEleFirst() {
      int var1 = 1;
      byte var3 = 0;
      byte[] var4 = null;
      if (this.otd_MsrComm != null) {
         var4 = this.otd_MsrComm.getOTSMSREle();
         var1 = var4.length + 1;
      }

      Vector var5 = null;
      int var2 = var1;
      byte[] var10;
      if (this.aWithIDs != null) {
         Vector var6 = new Vector(this.aWithIDs.size());
         Iterator var7 = this.aWithIDs.iterator();

         while(true) {
            var2 = var1;
            var5 = var6;
            if (!var7.hasNext()) {
               break;
            }

            OTDMeans_WithID var9 = (OTDMeans_WithID)var7.next();
            if (var9 != null) {
               var10 = var9.getOTDMeans_WithID();
               if (var10 != null) {
                  var6.add(var10);
                  var1 += var10.length;
               }
            }
         }
      }

      byte[] var11 = new byte[var2];
      var1 = var3;
      if (var4 != null) {
         System.arraycopy(var4, 0, var11, 0, var4.length);
         var1 = var4.length + 0;
      }

      var1 = IO.put1(var11, var1, this.ucSetCount);
      if (var5 != null) {
         Iterator var8 = var5.iterator();

         while(var8.hasNext()) {
            var10 = (byte[])var8.next();
            if (var10 != null) {
               System.arraycopy(var10, 0, var11, var1, var10.length);
               var1 += var10.length;
            }
         }
      }

      return var11;
   }
}
