package com.android.supl.loc.measure.lpp;

import com.android.bytewriter.IO;

public class SUPL_LPP_OTDOA_ERRINFO {
   public static final int SUPL_OTDOA_DEV_ERR_ASST_DATA_MISSING = 1;
   public static final int SUPL_OTDOA_DEV_ERR_ATTEMPT_NEIGHBOUR_CELL_MMT = 4;
   public static final int SUPL_OTDOA_DEV_ERR_NEIGHBOUR_CELL_MMT = 3;
   public static final int SUPL_OTDOA_DEV_ERR_REF_CELL_MMT = 2;
   public static final int SUPL_OTDOA_SERVER_ERR_ASST_DATA_NOTSUPP = 1;
   public static final int SUPL_OTDOA_SERVER_ERR_ASST_DATA_NOTSUPP_CURRENT = 2;
   public static final int SUPL_OTODA_DEV_ERR_UNDEFINED = 0;
   public static final int SUPL_OTODA_SERVER_ERR_UNDEFINED = 0;
   public boolean bDevErr = true;
   public boolean bServerErr = true;
   public int eLPPOTDOADevErr = 3;
   public int eLPPOTDOAServerErr = 1;

   public byte[] getOTDOA_ERRINFO() {
      byte var3 = 1;
      byte var1 = 8;
      if (this.bServerErr) {
         var1 = 12;
      }

      int var2 = var1;
      if (this.bDevErr) {
         var2 = var1 + 4;
      }

      byte[] var4 = new byte[var2];
      if (this.bServerErr) {
         var1 = 1;
      } else {
         var1 = 0;
      }

      var2 = IO.put4(var4, 0, var1);
      int var5 = var2;
      if (this.bServerErr) {
         var5 = IO.put4(var4, var2, this.eLPPOTDOAServerErr);
      }

      byte var6;
      if (this.bDevErr) {
         var6 = var3;
      } else {
         var6 = 0;
      }

      var5 = IO.put4(var4, var5, var6);
      if (this.bDevErr) {
         IO.put4(var4, var5, this.eLPPOTDOADevErr);
      }

      return var4;
   }
}
