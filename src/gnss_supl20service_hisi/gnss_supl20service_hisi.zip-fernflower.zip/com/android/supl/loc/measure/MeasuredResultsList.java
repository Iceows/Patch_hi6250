package com.android.supl.loc.measure;

import com.android.bytewriter.IO;
import java.util.Iterator;
import java.util.Vector;

public class MeasuredResultsList {
   public MeasuredResults[] astMeasuredResults = null;
   public short ucMeasuredResultsCnt;

   public MeasuredResultsList(MeasuredResults[] var1) {
      if (var1 == null) {
         throw new IllegalArgumentException("MeasuredResults should not be n");
      } else {
         this.astMeasuredResults = var1;
         this.ucMeasuredResultsCnt = (short)var1.length;
      }
   }

   public byte[] getMeasuredResultsListInfo() {
      int var1 = 1;
      Vector var4 = new Vector(this.ucMeasuredResultsCnt);
      MeasuredResults[] var5 = this.astMeasuredResults;
      int var3 = var5.length;

      int var2;
      for(var2 = 0; var2 < var3; ++var2) {
         MeasuredResults var6 = var5[var2];
         if (var6 != null) {
            byte[] var9 = var6.getMeasuredResultsInfo();
            var1 += var9.length;
            var4.add(var9);
         }
      }

      byte[] var8 = new byte[var1];
      var2 = IO.put1(var8, 0, this.ucMeasuredResultsCnt);

      byte[] var7;
      for(Iterator var10 = var4.iterator(); var10.hasNext(); var2 += var7.length) {
         var7 = (byte[])var10.next();
         System.arraycopy(var7, 0, var8, var2, var7.length);
      }

      if (var2 != var1) {
         System.out.println("MeasuredResultList length error");
      }

      return var8;
   }
}
