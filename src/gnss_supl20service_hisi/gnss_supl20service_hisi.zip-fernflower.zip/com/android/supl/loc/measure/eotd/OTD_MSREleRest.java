package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

public class OTD_MSREleRest {
   public OTD_MSREleCommon otd_MsrComm;
   public ArrayList otd_MsrsOfOtherSets;
   public short ucSetCount;

   public byte[] getOTD_MSREleRest() {
      int var1 = 1;
      byte var3 = 0;
      byte[] var4 = null;
      if (this.otd_MsrComm != null) {
         var4 = this.otd_MsrComm.getOTSMSREle();
         var1 = var4.length + 1;
      }

      Vector var5 = null;
      int var2 = var1;
      if (this.otd_MsrsOfOtherSets != null) {
         Vector var6 = new Vector(this.otd_MsrsOfOtherSets.size());
         Iterator var7 = this.otd_MsrsOfOtherSets.iterator();

         while(true) {
            var2 = var1;
            var5 = var6;
            if (!var7.hasNext()) {
               break;
            }

            OTD_MSRofOtherSets var8 = (OTD_MSRofOtherSets)var7.next();
            if (var8 != null) {
               byte[] var9 = var8.getOTD_MSRofOtherSets();
               if (var9 != null) {
                  var6.add(var9);
                  var1 += var9.length;
               }
            }
         }
      }

      byte[] var10 = new byte[var2];
      var1 = var3;
      if (var4 != null) {
         System.arraycopy(var4, 0, var10, 0, var4.length);
         var1 = var4.length + 0;
      }

      var1 = IO.put1(var10, var1, this.ucSetCount);
      if (var5 != null) {
         Iterator var11 = var5.iterator();

         while(var11.hasNext()) {
            var4 = (byte[])var11.next();
            if (var4 != null) {
               System.arraycopy(var4, 0, var10, var1, var4.length);
               var1 += var4.length;
            }
         }
      }

      return var10;
   }
}
