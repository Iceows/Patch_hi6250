package com.android.supl.loc.measure.odtoa;

import com.android.bytewriter.IO;

public class SUPL_OTDOA_MDSpecINF_TDD {
   public static final int OTDOA_BURSTTYPE1 = 0;
   public static final int OTDOA_BURSTTYPE2 = 1;
   public int eBurstType;
   public long lCellParamID;
   public long lMidAmbleShift;
   public long lTimeSlot;

   public byte[] getMDSpecINF_TDD() {
      byte[] var1 = new byte[16];
      IO.put4(var1, IO.put4(var1, IO.put4(var1, IO.put4(var1, 0, this.eBurstType), (int)this.lMidAmbleShift), (int)this.lTimeSlot), (int)this.lCellParamID);
      return var1;
   }
}
