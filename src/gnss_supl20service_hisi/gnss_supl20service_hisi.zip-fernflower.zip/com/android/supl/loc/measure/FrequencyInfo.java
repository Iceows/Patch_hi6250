package com.android.supl.loc.measure;

import com.android.bytewriter.IO;

public class FrequencyInfo {
   public static final int MODE_SPECIFIC_INFO_TYPE_FDD = 1;
   public static final int MODE_SPECIFIC_INFO_TYPE_TDD = 2;
   private int ienModeSpecificInfoType = 0;
   private FrequencyInfoFdd mFdd = null;
   private FrequencyInfoTdd mFrequencyInfoTdd = null;

   public FrequencyInfo(int var1, Object var2) {
      this.ienModeSpecificInfoType = var1;
      if (var1 == 1) {
         this.mFdd = (FrequencyInfoFdd)var2;
      } else {
         if (var1 != 2) {
            throw new IllegalArgumentException("FrequencyInfo mode value is invalid");
         }

         this.mFrequencyInfoTdd = (FrequencyInfoTdd)var2;
      }

   }

   public byte[] getFrequencyInfo() {
      int var1 = 0;
      int var2 = 4;
      byte[] var3 = null;
      if (this.ienModeSpecificInfoType == 1) {
         var3 = this.mFdd.getFrequencyInfoFdd();
      } else if (this.ienModeSpecificInfoType == 2) {
         var3 = this.mFrequencyInfoTdd.getFrequencyInfoTdd();
      }

      byte[] var4 = null;
      if (var3 != null) {
         var2 = var3.length + 4;
         var4 = new byte[var2];
         var1 = IO.put4(var4, 0, this.ienModeSpecificInfoType);
         System.arraycopy(var3, 0, var4, var1, var3.length);
         var1 += var3.length;
      }

      if (var1 != var2) {
         System.out.println("FrequencyInfo length error");
      }

      return var4;
   }
}
