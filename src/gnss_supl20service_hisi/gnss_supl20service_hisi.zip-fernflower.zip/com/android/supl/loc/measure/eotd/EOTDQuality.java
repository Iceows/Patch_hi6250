package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;

public class EOTDQuality {
   public short ucNbrOfMeasurements;
   public short ucStdOfEOTD;

   public byte[] getEOTDQulaity() {
      byte[] var1 = new byte[2];
      IO.put1(var1, IO.put1(var1, 0, this.ucNbrOfMeasurements), this.ucStdOfEOTD);
      return var1;
   }
}
