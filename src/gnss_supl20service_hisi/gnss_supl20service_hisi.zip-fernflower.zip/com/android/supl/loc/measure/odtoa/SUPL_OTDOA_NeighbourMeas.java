package com.android.supl.loc.measure.odtoa;

import com.android.bytewriter.IO;

public class SUPL_OTDOA_NeighbourMeas {
   public int eModeType;
   public long lSFNSFNObsTimeDiff2;
   public SUPL_OTDOA_NeighModeSpecMeas stNeighbourMeasInfo;
   public short ucNoOfMeasurements;
   public short ucStdDevOTDOAMeas;
   public short ucStdValue;

   public byte[] getNeighbourMeas() {
      int var1 = 11;
      byte[] var3 = null;
      if (this.stNeighbourMeasInfo != null) {
         var3 = this.stNeighbourMeasInfo.getNeighModeSpecMeas();
         var1 = var3.length + 11;
      }

      byte[] var4 = new byte[var1];
      int var2 = IO.put4(var4, 0, this.eModeType);
      var1 = var2;
      if (this.stNeighbourMeasInfo != null) {
         System.arraycopy(var3, 0, var4, var2, var3.length);
         var1 = var2 + var3.length;
      }

      IO.put4(var4, IO.put1(var4, IO.put1(var4, IO.put1(var4, var1, this.ucStdValue), this.ucNoOfMeasurements), this.ucStdDevOTDOAMeas), (int)this.lSFNSFNObsTimeDiff2);
      return var4;
   }
}
