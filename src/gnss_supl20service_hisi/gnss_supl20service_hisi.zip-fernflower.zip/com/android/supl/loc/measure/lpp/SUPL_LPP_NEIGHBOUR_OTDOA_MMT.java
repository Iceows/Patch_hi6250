package com.android.supl.loc.measure.lpp;

import com.android.bytewriter.IO;
import java.util.Iterator;
import java.util.Vector;

public class SUPL_LPP_NEIGHBOUR_OTDOA_MMT {
   public byte byNumberofNeighbourMmts = 1;
   SUPL_LPP_NEIGHBOUR_ELEM[] stLPPOTDOANeighbourElem = null;

   public SUPL_LPP_NEIGHBOUR_OTDOA_MMT() {
      this.stLPPOTDOANeighbourElem = new SUPL_LPP_NEIGHBOUR_ELEM[]{new SUPL_LPP_NEIGHBOUR_ELEM()};
   }

   public byte[] get_NEIGHBOUR_OTDOA_MMT() {
      int var3 = 1;
      int var1 = 1;
      Vector var5 = null;
      if (this.stLPPOTDOANeighbourElem != null) {
         Vector var6 = new Vector(this.byNumberofNeighbourMmts);
         SUPL_LPP_NEIGHBOUR_ELEM[] var7 = this.stLPPOTDOANeighbourElem;
         int var4 = var7.length;
         int var2 = 0;

         while(true) {
            var3 = var1;
            var5 = var6;
            if (var2 >= var4) {
               break;
            }

            SUPL_LPP_NEIGHBOUR_ELEM var8 = var7[var2];
            var3 = var1;
            if (var8 != null) {
               byte[] var9 = var8.getLPP_NEIGHBOUR_ELEM();
               var3 = var1;
               if (var9 != null) {
                  var6.add(var9);
                  var3 = var1 + var9.length;
               }
            }

            ++var2;
            var1 = var3;
         }
      }

      byte[] var10 = new byte[var3];
      var1 = IO.put1(var10, 0, this.byNumberofNeighbourMmts);
      if (this.byNumberofNeighbourMmts > 0 && var5 != null) {
         Iterator var11 = var5.iterator();

         while(var11.hasNext()) {
            byte[] var12 = (byte[])var11.next();
            if (var12 != null) {
               System.arraycopy(var12, 0, var10, var1, var12.length);
               var1 += var12.length;
            }
         }
      }

      return var10;
   }
}
