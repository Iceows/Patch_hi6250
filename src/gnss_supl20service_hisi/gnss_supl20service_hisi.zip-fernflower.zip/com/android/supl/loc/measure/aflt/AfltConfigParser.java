package com.android.supl.loc.measure.aflt;

import android.util.Log;
import java.util.ArrayList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class AfltConfigParser extends DefaultHandler {
   private static final String AFLTMEASUREMENT = "afltmeasurement";
   private static final String BANDCLASS = "bandclass";
   private static final String BASESTATIONID = "basestationid";
   private static final String BMEASUREMENTVALID = "bmeasurementvalid";
   private static final String CDMAFREQUENCY = "cdmafrequency";
   private static final String ISOFFSETINCLUDED = "isOffsetincluded";
   private static final String MSTIMEOFFSET = "mstimeOffset";
   private static final String NETWORKIDENTIFICATION = "networkidentification";
   private static final String PILOTMEASUREDPHASE = "pilotmeasuredphase";
   private static final String PILOTPHASEDOPPLER = "pilotphasedoppler";
   private static final String PILOTPHASEFALSEALARMPROBABILITY = "pilotphasefalsealarmprobability";
   private static final String PILOTPHASEFALSEALARMRANGE = "pilotphasefalsealarmrange";
   private static final String PILOTPHASEMEASUREMENTERROR = "pilotphasemeasurementerror";
   private static final String PILOTPHASERECORD = "pilotphaserecord";
   private static final String PILOTSTRENGTH = "pilotstrength";
   private static final String PSEUDODOPPLERRMSERROR = "pseudodopplerrmserror";
   private static final String REFERENCEPILOTSTRENGTH = "referencepilotstrength";
   private static final String REFERENCEPN = "referencepn";
   private static final String REPEATERDETECTIONSTATUS = "repeaterdetectionstatus";
   private static final String REPEATERID = "repeaterid";
   private static final String REPEATERTYPE = "repeatertype";
   private static final String RMSERRORPHASE = "rmserrorphase";
   private static final String SYSTEMIDENTIFICATION = "systemidentification";
   private static final String TIMEREFERENCE = "timereference";
   private static final String TOTALNUMBEROFPILOTS = "totalnumberofpilots";
   private static final String TOTALRECEIVEDPOWER = "totalreceivedpower";
   public AfltMeasure afltmeasure = null;
   private int iIndex = -1;
   private boolean isMeasurementValid = false;
   private boolean isOffsetIncluded = false;
   private boolean isRequiredTag = false;
   private String repeaterId = null;
   private String stData = null;

   public AfltConfigParser() {
      this.init();
   }

   public void characters(char[] var1, int var2, int var3) throws SAXException {
      if (this.isRequiredTag) {
         this.stData = (new String(var1, var2, var3)).trim();
         this.isRequiredTag = false;
      } else {
         this.stData = null;
      }

   }

   public void endElement(String var1, String var2, String var3) throws SAXException {
      boolean var5 = true;
      boolean var4 = true;
      AfltMeasure var6;
      if (var2.equals("bmeasurementvalid")) {
         var6 = this.afltmeasure;
         if (Integer.parseInt(this.stData) != 1) {
            var4 = false;
         }

         var6.bMeasurementValid = var4;
         Log.i("AFLT_CONFIG", "afltmeasure.bMeasurementValid : " + this.afltmeasure.bMeasurementValid);
      } else if (var2.equals("timereference")) {
         this.afltmeasure.TimeReference = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.TimeReference : " + this.afltmeasure.TimeReference);
      } else if (var2.equals("isOffsetincluded")) {
         var6 = this.afltmeasure;
         if (Integer.parseInt(this.stData) == 1) {
            var4 = var5;
         } else {
            var4 = false;
         }

         var6.IsOffsetIncluded = var4;
         Log.i("AFLT_CONFIG", "afltmeasure.IsOffsetIncluded : " + this.afltmeasure.IsOffsetIncluded);
      } else if (var2.equals("mstimeOffset")) {
         this.afltmeasure.MSTimeOffset = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.MSTimeOffset : " + this.afltmeasure.MSTimeOffset);
      } else if (var2.equals("referencepn")) {
         this.afltmeasure.ReferencePN = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.ReferencePN : " + this.afltmeasure.ReferencePN);
      } else if (var2.equals("referencepilotstrength")) {
         this.afltmeasure.ReferencePilotStrength = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.ReferencePilotStrength : " + this.afltmeasure.ReferencePilotStrength);
      } else if (var2.equals("bandclass")) {
         this.afltmeasure.BandClass = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.BandClass : " + this.afltmeasure.BandClass);
      } else if (var2.equals("cdmafrequency")) {
         this.afltmeasure.CDMAFrequency = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.CDMAFrequency : " + this.afltmeasure.CDMAFrequency);
      } else if (var2.equals("basestationid")) {
         this.afltmeasure.BaseStationID = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.BaseStationID : " + this.afltmeasure.BaseStationID);
      } else if (var2.equals("systemidentification")) {
         this.afltmeasure.SystemIdentification = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.SystemIdentification : " + this.afltmeasure.SystemIdentification);
      } else if (var2.equals("networkidentification")) {
         this.afltmeasure.NetworkIdentification = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.NetworkIdentification : " + this.afltmeasure.NetworkIdentification);
      } else if (var2.equals("totalreceivedpower")) {
         this.afltmeasure.TotalReceivedPower = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.TotalReceivedPower : " + this.afltmeasure.TotalReceivedPower);
      } else if (var2.equals("totalnumberofpilots")) {
         this.afltmeasure.TotalNumberOfPilots = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.TotalNumberOfPilots : " + this.afltmeasure.TotalNumberOfPilots);
      } else if (var2.equals("pilotphaserecord")) {
         ++this.iIndex;
         this.afltmeasure.phaseRecord.add(this.iIndex, new SUPL_AFLT_PilotPhaseRecord());
      } else if (var2.equals("pilotmeasuredphase")) {
         ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).PilotMeasuredPhase = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.phaseRecord.get(iIndex).PilotMeasuredPhase : " + ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).PilotMeasuredPhase);
      } else if (var2.equals("pilotstrength")) {
         ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).PilotStrength = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.phaseRecord.get(iIndex).PilotStrength : " + ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).PilotStrength);
      } else if (var2.equals("rmserrorphase")) {
         ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).RMSErrorPhase = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.phaseRecord.get(iIndex).RMSErrorPhase : " + ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).RMSErrorPhase);
      } else if (var2.equals("pilotphasemeasurementerror")) {
         ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).PilotPhaseMeasurementError = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.phaseRecord.get(iIndex).PilotPhaseMeasurementError : " + ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).PilotPhaseMeasurementError);
      } else if (var2.equals("repeaterdetectionstatus")) {
         ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).RepeaterDetectionStatus = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.phaseRecord.get(iIndex).RepeaterDetectionStatus : " + ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).RepeaterDetectionStatus);
      } else if (var2.equals("repeatertype")) {
         ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).RepeaterType = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.phaseRecord.get(iIndex).RepeaterType : " + ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).RepeaterType);
      } else if (var2.equals("repeaterid")) {
         ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).RepeaterID = this.stData.getBytes();
         Log.i("AFLT_CONFIG", "afltmeasure.phaseRecord.get(iIndex).RepeaterID : " + ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).RepeaterID);
      } else if (var2.equals("pilotphasedoppler")) {
         ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).PilotPhaseDoppler = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.phaseRecord.get(iIndex).PilotPhaseDoppler : " + ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).PilotPhaseDoppler);
      } else if (var2.equals("pseudodopplerrmserror")) {
         ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).PseudoDopplerRMSError = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.phaseRecord.get(iIndex).PseudoDopplerRMSError : " + ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).PseudoDopplerRMSError);
      } else if (var2.equals("pilotphasefalsealarmprobability")) {
         ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).PilotphaseFalseAlarmProbability = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.phaseRecord.get(iIndex).PilotphaseFalseAlarmRange : " + ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).PilotphaseFalseAlarmProbability);
      } else if (var2.equals("pilotphasefalsealarmrange")) {
         ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).PilotphaseFalseAlarmRange = Integer.parseInt(this.stData);
         Log.i("AFLT_CONFIG", "afltmeasure.phaseRecord.get(iIndex).PilotphaseFalseAlarmRange : " + ((SUPL_AFLT_PilotPhaseRecord)this.afltmeasure.phaseRecord.get(this.iIndex)).PilotphaseFalseAlarmRange);
      }

   }

   public AfltMeasure getAFLTMeasInfo() {
      return this.afltmeasure;
   }

   public void init() {
      // $FF: Couldn't be decompiled
   }

   public void startElement(String var1, String var2, String var3, Attributes var4) throws SAXException {
      if (var2.equals("afltmeasurement")) {
         this.afltmeasure = new AfltMeasure();
      } else if (var2.equals("bmeasurementvalid")) {
         this.isRequiredTag = true;
      } else if (var2.equals("timereference")) {
         this.isRequiredTag = true;
      } else if (var2.equals("isOffsetincluded")) {
         this.isRequiredTag = true;
      } else if (var2.equals("mstimeOffset")) {
         this.isRequiredTag = true;
      } else if (var2.equals("referencepn")) {
         this.isRequiredTag = true;
      } else if (var2.equals("referencepilotstrength")) {
         this.isRequiredTag = true;
      } else if (var2.equals("bandclass")) {
         this.isRequiredTag = true;
      } else if (var2.equals("cdmafrequency")) {
         this.isRequiredTag = true;
      } else if (var2.equals("basestationid")) {
         this.isRequiredTag = true;
      } else if (var2.equals("systemidentification")) {
         this.isRequiredTag = true;
      } else if (var2.equals("networkidentification")) {
         this.isRequiredTag = true;
      } else if (var2.equals("totalreceivedpower")) {
         this.isRequiredTag = true;
      } else if (var2.equals("totalnumberofpilots")) {
         this.isRequiredTag = true;
      } else if (var2.equals("pilotphaserecord")) {
         ++this.iIndex;
         if (this.afltmeasure.phaseRecord == null) {
            this.afltmeasure.phaseRecord = new ArrayList();
         }

         this.afltmeasure.phaseRecord.add(this.iIndex, new SUPL_AFLT_PilotPhaseRecord());
      } else if (var2.equals("pilotmeasuredphase")) {
         this.isRequiredTag = true;
      } else if (var2.equals("pilotstrength")) {
         this.isRequiredTag = true;
      } else if (var2.equals("rmserrorphase")) {
         this.isRequiredTag = true;
      } else if (var2.equals("pilotphasemeasurementerror")) {
         this.isRequiredTag = true;
      } else if (var2.equals("repeaterdetectionstatus")) {
         this.isRequiredTag = true;
      } else if (var2.equals("repeatertype")) {
         this.isRequiredTag = true;
      } else if (var2.equals("repeaterid")) {
         this.isRequiredTag = true;
      } else if (var2.equals("pilotphasedoppler")) {
         this.isRequiredTag = true;
      } else if (var2.equals("pseudodopplerrmserror")) {
         this.isRequiredTag = true;
      } else if (var2.equals("pilotphasefalsealarmprobability")) {
         this.isRequiredTag = true;
      } else if (var2.equals("pilotphasefalsealarmrange")) {
         this.isRequiredTag = true;
      }

   }
}
