package com.android.supl.loc.measure;

import com.android.bytewriter.IO;

public class FrequencyInfoTdd {
   private short usUarfcn_Nt;

   public FrequencyInfoTdd(short var1) {
      this.usUarfcn_Nt = var1;
   }

   public byte[] getFrequencyInfoTdd() {
      byte[] var1 = new byte[2];
      IO.put2(var1, 0, this.usUarfcn_Nt);
      return var1;
   }
}
