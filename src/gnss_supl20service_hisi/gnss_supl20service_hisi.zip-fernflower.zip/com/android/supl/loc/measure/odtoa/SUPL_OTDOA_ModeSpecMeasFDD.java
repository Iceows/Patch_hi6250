package com.android.supl.loc.measure.odtoa;

import com.android.bytewriter.IO;

public class SUPL_OTDOA_ModeSpecMeasFDD {
   public boolean bPrimaryScramblingCodePresent;
   public boolean bRxTxTimeDiffValid;
   public long lPrimaryScramblingCode;
   public long lRxTxTimeDiffType2;
   public short ucNoOfMeasurements;
   public short ucStdDevOTDOAMeas;
   public short ucStdValue;

   public byte[] getModeSpecMeasFDD() {
      byte var2 = 1;
      byte var1;
      if (this.bPrimaryScramblingCodePresent) {
         var1 = 4;
      } else {
         var1 = 0;
      }

      byte[] var4 = new byte[var1 + 12 + 3];
      if (this.bPrimaryScramblingCodePresent) {
         var1 = 1;
      } else {
         var1 = 0;
      }

      int var3 = IO.put4(var4, 0, var1);
      int var5 = var3;
      if (this.bPrimaryScramblingCodePresent) {
         var5 = IO.put4(var4, var3, (int)this.lPrimaryScramblingCode);
      }

      if (!this.bRxTxTimeDiffValid) {
         var2 = 0;
      }

      IO.put1(var4, IO.put1(var4, IO.put1(var4, IO.put4(var4, IO.put4(var4, var5, var2), (int)this.lRxTxTimeDiffType2), this.ucStdValue), this.ucNoOfMeasurements), this.ucStdDevOTDOAMeas);
      return var4;
   }
}
