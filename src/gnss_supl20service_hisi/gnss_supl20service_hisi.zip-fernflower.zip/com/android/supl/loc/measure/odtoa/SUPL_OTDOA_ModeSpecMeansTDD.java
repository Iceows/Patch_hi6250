package com.android.supl.loc.measure.odtoa;

import com.android.bytewriter.IO;

public class SUPL_OTDOA_ModeSpecMeansTDD {
   public boolean bCellIDParamValid;
   public long lCellParamsID;

   public byte[] getModeSpecMeansTDD() {
      byte[] var2 = new byte[8];
      byte var1;
      if (this.bCellIDParamValid) {
         var1 = 1;
      } else {
         var1 = 0;
      }

      IO.put4(var2, IO.put4(var2, 0, var1), (int)this.lCellParamsID);
      return var2;
   }
}
