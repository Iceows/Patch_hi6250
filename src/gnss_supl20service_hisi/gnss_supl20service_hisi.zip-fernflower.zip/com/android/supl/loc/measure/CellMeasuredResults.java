package com.android.supl.loc.measure;

import com.android.bytewriter.IO;

public class CellMeasuredResults {
   private boolean bIsCellIdentityPresent;
   private ModeSpecificInfo mModeSpecificInfo = null;
   private int unCellIdentity;

   public CellMeasuredResults(int var1, ModeSpecificInfo var2) {
      if (var2 == null) {
         throw new IllegalArgumentException("ModeSpecificInfo should not be null");
      } else {
         this.unCellIdentity = var1;
         this.mModeSpecificInfo = var2;
         boolean var3;
         if (var1 != -1) {
            var3 = true;
         } else {
            var3 = false;
         }

         this.bIsCellIdentityPresent = var3;
      }
   }

   public byte[] getCellMeasuredResults() {
      byte var1 = 4;
      if (this.bIsCellIdentityPresent) {
         var1 = 8;
      }

      byte[] var3 = this.mModeSpecificInfo.getModeSpecificInfo();
      int var2 = var1 + var3.length;
      byte[] var4 = new byte[var2];
      int var5;
      if (this.bIsCellIdentityPresent) {
         var5 = IO.put4(var4, IO.put4(var4, 0, 1), this.unCellIdentity);
      } else {
         var5 = IO.put4(var4, 0, 0);
      }

      System.arraycopy(var3, 0, var4, var5, var3.length);
      if (var5 + var3.length != var2) {
         System.out.println("CellMeasuredResults length error");
      }

      return var4;
   }
}
