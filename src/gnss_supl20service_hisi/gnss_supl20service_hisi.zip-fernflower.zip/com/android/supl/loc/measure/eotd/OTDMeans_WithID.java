package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;

public class OTDMeans_WithID {
   public EOTDQuality eotdQuality;
   public Neighbor_Identity neighborIdentity;
   public short ucNborTimeSlot;
   public int usOTDValue;

   public byte[] getOTDMeans_WithID() {
      byte var3 = 0;
      int var1 = 3;
      byte[] var4 = null;
      byte[] var5 = null;
      if (this.neighborIdentity != null) {
         var4 = this.neighborIdentity.getNeighbor_Identity();
         var1 = var4.length + 3;
      }

      int var2 = var1;
      if (this.eotdQuality != null) {
         var5 = this.eotdQuality.getEOTDQulaity();
         var2 = var1 + var5.length;
      }

      byte[] var6 = new byte[var2];
      var1 = var3;
      if (var4 != null) {
         System.arraycopy(var4, 0, var6, 0, var4.length);
         var1 = var4.length + 0;
      }

      var2 = IO.put1(var6, var1, this.ucNborTimeSlot);
      var1 = var2;
      if (var5 != null) {
         System.arraycopy(var5, 0, var6, var2, var5.length);
         var1 = var2 + var5.length;
      }

      IO.put2(var6, var1, this.usOTDValue);
      return var6;
   }
}
