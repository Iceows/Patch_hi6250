package com.android.supl.loc.measure.odtoa;

public class SUPL_OTDOA_NeighModeSpecMeas {
   public SUPL_OTDOA_ModeSpecMeasFDD stModeSpecificFDDMeas;
   public SUPL_OTDOA_MDSpecINF_TDD stModeSpecificTDDMeas;

   public byte[] getNeighModeSpecMeas() {
      byte[] var1 = null;
      if (this.stModeSpecificFDDMeas != null) {
         var1 = this.stModeSpecificFDDMeas.getModeSpecMeasFDD();
      } else if (this.stModeSpecificTDDMeas != null) {
         var1 = this.stModeSpecificTDDMeas.getMDSpecINF_TDD();
      }

      return var1;
   }
}
