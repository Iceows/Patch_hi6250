package com.android.supl.loc.measure.lpp;

import com.android.bytewriter.IO;

public class SUPL_LPP_OTDOA_MEASUREMENT {
   public boolean bErrorInfoPresent;
   public boolean bValidMmtPresent = true;
   public SUPL_LPP_OTDOA_ERRINFO stLPPOTDOAError = null;
   public SUPL_LPP_OTDOA_SIGNAL_MMT stLPPOTDOASignalMmt = null;

   public SUPL_LPP_OTDOA_MEASUREMENT() {
      this.stLPPOTDOASignalMmt = new SUPL_LPP_OTDOA_SIGNAL_MMT();
      this.bErrorInfoPresent = true;
      this.stLPPOTDOAError = new SUPL_LPP_OTDOA_ERRINFO();
   }

   public byte[] getOTDOA_MEASUREMENT(int var1) {
      byte var4 = 1;
      int var2 = 12 + 4;
      byte[] var7 = null;
      Object var9 = null;
      Object var8 = null;
      byte[] var6 = (byte[])var8;
      int var3 = var2;
      byte[] var5;
      if (this.bValidMmtPresent) {
         var3 = var2 + 4;
         var5 = (byte[])var9;
         var2 = var3;
         if (this.bValidMmtPresent) {
            var5 = (byte[])var9;
            var2 = var3;
            if (this.stLPPOTDOASignalMmt != null) {
               var6 = this.stLPPOTDOASignalMmt.getSIGNAL_MMT();
               var5 = var6;
               var2 = var3;
               if (var6 != null) {
                  var2 = var6.length + 20;
                  var5 = var6;
               }
            }
         }

         var6 = (byte[])var8;
         var7 = var5;
         var3 = var2;
         if (this.bErrorInfoPresent) {
            var6 = (byte[])var8;
            var7 = var5;
            var3 = var2;
            if (this.stLPPOTDOAError != null) {
               byte[] var12 = this.stLPPOTDOAError.getOTDOA_ERRINFO();
               var6 = var12;
               var7 = var5;
               var3 = var2;
               if (var12 != null) {
                  var3 = var2 + var12.length;
                  var7 = var5;
                  var6 = var12;
               }
            }
         }
      }

      var5 = new byte[var3];
      var2 = IO.put4(var5, IO.put4(var5, IO.put4(var5, 0, var3 - 4), 276), var1);
      byte var10;
      if (this.bValidMmtPresent) {
         var10 = 1;
      } else {
         var10 = 0;
      }

      var2 = IO.put4(var5, var2, var10);
      if (this.bValidMmtPresent) {
         var1 = var2;
         if (var7 != null) {
            System.arraycopy(var7, 0, var5, var2, var7.length);
            var1 = var2 + var7.length;
         }

         byte var11;
         if (this.bErrorInfoPresent) {
            var11 = var4;
         } else {
            var11 = 0;
         }

         var1 = IO.put4(var5, var1, var11);
         if (this.bErrorInfoPresent && var6 != null) {
            System.arraycopy(var6, 0, var5, var1, var6.length);
            var1 = var6.length;
         }
      }

      return var5;
   }
}
