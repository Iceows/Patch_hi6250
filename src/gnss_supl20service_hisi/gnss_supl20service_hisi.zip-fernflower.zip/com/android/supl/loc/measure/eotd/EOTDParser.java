package com.android.supl.loc.measure.eotd;

import java.util.ArrayList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class EOTDParser extends DefaultHandler {
   private static final String BCCHCARRIER = "bcchcarrier";
   private static final String BSIC = "bsic";
   private static final String BSICANDCARRIER = "bsicandcarrier";
   private static final String CARRIER = "carrier";
   private static final String CELLIDANDLAC = "cellidandlac";
   private static final String COUNT = "count";
   private static final String EOTDMEAS = "eotdmeas";
   private static final String EOTDQUALITY = "eotdquality";
   private static final String ISIDENTITYPRESENT = "isidentitypresent";
   private static final String MEASR98EXT = "measr98ext";
   private static final String MEASREL5EXT = "measrel5ext";
   private static final String MEASWITHID = "measwithid";
   private static final String MSRELECOMMON = "msrelecommon";
   private static final String MSRELEFIRST = "msrelefirst";
   private static final String MSRELEREST = "msrelerest";
   private static final String MSROFOTHERSETS = "msrofothersets";
   private static final String MSROTHERSETSUNION = "msrothersetsunion";
   private static final String MULTIFRAMECARRIER = "multiframecarrier";
   private static final String MULTIFRAMEOFFSET = "multiframeoffset";
   private static final String NBORTIMESLOT = "nbortimeslot";
   private static final String NBROFMEASUREMENTS = "nbrofmeasurements";
   private static final String NEIGHBORIDENTITY = "neighboridentity";
   private static final String NEIGHBORIDTYPE = "neighboridtype";
   private static final String NEIGHBORIDUNION = "neighboridunion";
   private static final String NOOFVALIDSETS = "noofvalidsets";
   private static final String NUMOFMEASUREMENTS = "numofmeasurements";
   private static final String OTDMEAS = "otdmeas";
   private static final String OTDREL5PRESENT = "otdrel5present";
   private static final String OTDREL98PRESENT = "otdrel98present";
   private static final String OTDVALUE = "otdvalue";
   private static final String REFERENCECI = "referenceci";
   private static final String REFERENCELAC = "referencelac";
   private static final String REFERENCETIMESLOT = "referencetimeslot";
   private static final String REFFRAMENUMBER = "refframenumber";
   private static final String REFQUALITY = "refquality";
   private static final String REQUESTINDEX = "requestindex";
   private static final String SETCOUNT = "setcount";
   private static final String STDOFEOTD = "stdofeotd";
   private static final String STDRESOLUTION = "stdresolution";
   private static final String SYSTEMINFOINDEX = "systeminfoindex";
   private static final String TACORRECTION = "tacorrection";
   private static final String VALIDEOTDMEASUREMENT = "valideotdmeasurement";
   private OTD_MSREleCommon eleCommon = null;
   private OTD_MSREleRest eleRest = null;
   private SUPL_EOTDMeasInfo eotdMeasInfo = null;
   private int iSetCount = 0;
   private boolean isEleRest = false;
   private boolean isMesare98 = false;
   private boolean isMesarel5 = false;
   private boolean isMsrelefirst = false;
   private boolean isNotValideotdMeasurement = false;
   private boolean isOTDMeas = false;
   private boolean isRequiredTag;
   private OTDMeans_WithID means_WithID = null;
   private OTD_MSRofOtherSets otd_MSRofOtherSets = null;
   private EOTDQuality quality = null;
   private String stData;

   public EOTDParser() {
      this.init();
   }

   private void init() {
      // $FF: Couldn't be decompiled
   }

   public void characters(char[] var1, int var2, int var3) throws SAXException {
      if (this.isRequiredTag) {
         this.stData = (new String(var1, var2, var3)).trim();
         this.isRequiredTag = false;
      } else {
         this.stData = null;
      }

   }

   public void endElement(String var1, String var2, String var3) throws SAXException {
      boolean var4 = true;
      boolean var7 = true;
      boolean var6 = true;
      boolean var5 = true;
      SUPL_EOTDMeasInfo var8;
      if (var2.equals("valideotdmeasurement")) {
         var8 = this.eotdMeasInfo;
         if (Integer.parseInt(this.stData) == 0) {
            var4 = false;
         } else {
            var4 = true;
         }

         var8.bIsValidEOTDMeasurement = var4;
         if (Integer.parseInt(this.stData) == 0) {
            var4 = var5;
         } else {
            var4 = false;
         }

         this.isNotValideotdMeasurement = var4;
      } else {
         if (this.isNotValideotdMeasurement) {
            return;
         }

         if (var2.equals("msrelefirst")) {
            this.isMsrelefirst = false;
         } else if (var2.equals("msrelecommon")) {
            if (this.isMsrelefirst) {
               this.eotdMeasInfo.otdMsrFirstSet.otd_MsrComm = this.eleCommon;
            } else if (this.isEleRest) {
               this.eleRest.otd_MsrComm = this.eleCommon;
            }

            this.eleCommon = null;
         } else if (var2.equals("refframenumber")) {
            this.eleCommon.usRefFrameNumber = Integer.parseInt(this.stData);
         } else if (var2.equals("referencetimeslot")) {
            this.eleCommon.ucReferenceTimeSlot = Short.parseShort(this.stData);
         } else if (var2.equals("refquality")) {
            this.eleCommon.ucRefQuality = Short.parseShort(this.stData);
         } else if (var2.equals("numofmeasurements")) {
            this.eleCommon.ucNumOfMeasurements = Short.parseShort(this.stData);
         } else if (var2.equals("stdresolution")) {
            this.eleCommon.ucStdResolution = Short.parseShort(this.stData);
         } else if (var2.equals("tacorrection")) {
            this.eleCommon.usTACorrection = Integer.parseInt(this.stData);
         } else if (var2.equals("msrelecommon")) {
            if (this.isMsrelefirst) {
               this.eotdMeasInfo.otdMsrFirstSet.otd_MsrComm = this.eleCommon;
            } else if (this.isEleRest || this.eotdMeasInfo.bOTDRel5Present) {
               this.eleRest.otd_MsrComm = this.eleCommon;
            }

            this.eleCommon = null;
         } else if (var2.equals("setcount")) {
            if (this.isMsrelefirst) {
               this.eotdMeasInfo.otdMsrFirstSet.ucSetCount = Short.parseShort(this.stData);
            } else if (this.isEleRest) {
               this.eleRest.ucSetCount = Short.parseShort(this.stData);
            }
         } else if (var2.equals("measwithid")) {
            if (this.isMsrelefirst) {
               if (this.eotdMeasInfo.otdMsrFirstSet.aWithIDs == null) {
                  this.eotdMeasInfo.otdMsrFirstSet.aWithIDs = new ArrayList(this.eotdMeasInfo.otdMsrFirstSet.ucSetCount);
               }

               this.eotdMeasInfo.otdMsrFirstSet.aWithIDs.add(this.means_WithID);
            } else if (this.isMesare98) {
               if (this.eotdMeasInfo.otd_MeasureInfo_R98_Ext.otd_FirstSetMsrs == null) {
                  this.eotdMeasInfo.otd_MeasureInfo_R98_Ext.otd_FirstSetMsrs = new ArrayList(this.eotdMeasInfo.otd_MeasureInfo_R98_Ext.ucCount);
               }

               this.eotdMeasInfo.otd_MeasureInfo_R98_Ext.otd_FirstSetMsrs.add(this.means_WithID);
            } else if (this.isMesarel5 && this.otd_MSRofOtherSets.bIsIdentityPresent) {
               this.otd_MSRofOtherSets.stOTDMsr.identityPresent = this.means_WithID;
            }

            this.means_WithID = null;
         } else if (var2.equals("neighboridtype")) {
            this.means_WithID.neighborIdentity.enIdType = Integer.parseInt(this.stData);
         } else if (var2.equals("carrier")) {
            this.means_WithID.neighborIdentity.stNeigh.bsicAndCarrier.usCarrier = Integer.parseInt(this.stData);
         } else if (var2.equals("bsic")) {
            this.means_WithID.neighborIdentity.stNeigh.bsicAndCarrier.cBsic = Short.parseShort(this.stData);
         } else if (var2.equals("referencelac")) {
            this.means_WithID.neighborIdentity.stNeigh.ciandlac.usReferenceLAC = Short.parseShort(this.stData);
         } else if (var2.equals("referenceci")) {
            this.means_WithID.neighborIdentity.stNeigh.ciandlac.usReferenceCI = Short.parseShort(this.stData);
         } else if (var2.equals("bcchcarrier")) {
            this.means_WithID.neighborIdentity.stNeigh.multiFrameCarrier.usBCCHCarrier = Integer.parseInt(this.stData);
         } else if (var2.equals("multiframeoffset")) {
            this.means_WithID.neighborIdentity.stNeigh.multiFrameCarrier.ucMultiFrameOffset = Short.parseShort(this.stData);
         } else if (var2.equals("nbortimeslot")) {
            if (this.isOTDMeas) {
               this.otd_MSRofOtherSets.stOTDMsr.identityNotPresent.ucNborTimeSlot = Short.parseShort(this.stData);
            } else {
               this.means_WithID.ucNborTimeSlot = Short.parseShort(this.stData);
            }
         } else if (var2.equals("nbrofmeasurements")) {
            this.quality.ucNbrOfMeasurements = Short.parseShort(this.stData);
         } else if (var2.equals("stdofeotd")) {
            this.quality.ucStdOfEOTD = Short.parseShort(this.stData);
         } else if (var2.equals("eotdquality")) {
            if (this.isOTDMeas) {
               this.otd_MSRofOtherSets.stOTDMsr.identityNotPresent.eotdQuality = this.quality;
            } else {
               this.means_WithID.eotdQuality = this.quality;
            }
         } else if (var2.equals("otdvalue")) {
            if (this.isOTDMeas) {
               this.otd_MSRofOtherSets.stOTDMsr.identityNotPresent.usOTDValue = Integer.parseInt(this.stData);
            } else {
               this.means_WithID.usOTDValue = Integer.parseInt(this.stData);
            }
         } else if (var2.equals("msrelefirst")) {
            this.eotdMeasInfo.otdMsrFirstSet.ucSetCount = (short)this.iSetCount;
         } else if (var2.equals("noofvalidsets")) {
            this.eotdMeasInfo.nNoOfValidSets = Integer.parseInt(this.stData);
            if (this.eotdMeasInfo.nNoOfValidSets > 0) {
               this.eotdMeasInfo.otdMsrRestSets = new ArrayList(this.eotdMeasInfo.nNoOfValidSets);
            }
         } else if (var2.equals("msrelerest")) {
            if (!this.isMesarel5 && this.isEleRest) {
               this.eotdMeasInfo.otdMsrRestSets.add(this.eleRest);
            } else if (this.isMesarel5) {
               this.eotdMeasInfo.otd_MeasureInfo_Rel_5_Ext.otdMsrRestSets.add(this.eleRest);
            }

            this.eleRest = null;
         } else if (var2.equals("msrofothersets")) {
            if (this.isEleRest) {
               if (this.eleRest.otd_MsrsOfOtherSets == null) {
                  this.eleRest.otd_MsrsOfOtherSets = new ArrayList(this.eleRest.ucSetCount);
               }

               this.eleRest.otd_MsrsOfOtherSets.add(this.otd_MSRofOtherSets);
            } else if (this.eotdMeasInfo.bOTDRel5Present) {
               if (this.eleRest.otd_MsrsOfOtherSets == null) {
                  this.eleRest.otd_MsrsOfOtherSets = new ArrayList(this.eleRest.ucSetCount);
               }

               this.eleRest.otd_MsrsOfOtherSets.add(this.otd_MSRofOtherSets);
            }

            this.otd_MSRofOtherSets = null;
         } else if (var2.equals("isidentitypresent")) {
            OTD_MSRofOtherSets var9 = this.otd_MSRofOtherSets;
            if (Integer.parseInt(this.stData) != 1) {
               var4 = false;
            }

            var9.bIsIdentityPresent = var4;
         } else if (var2.equals("nbortimeslot")) {
            this.otd_MSRofOtherSets.stOTDMsr.identityNotPresent.ucNborTimeSlot = Short.parseShort(this.stData);
         } else if (var2.equals("otdvalue")) {
            this.otd_MSRofOtherSets.stOTDMsr.identityNotPresent.usOTDValue = Short.parseShort(this.stData);
         } else if (var2.equals("otdmeas")) {
            this.otd_MSRofOtherSets.stOTDMsr.identityNotPresent.eotdQuality = this.quality;
            this.isOTDMeas = false;
         } else if (var2.equals("otdrel98present")) {
            var8 = this.eotdMeasInfo;
            if (Integer.parseInt(this.stData) == 1) {
               var4 = var7;
            } else {
               var4 = false;
            }

            var8.bOTDRel98Present = var4;
            this.isMesare98 = this.eotdMeasInfo.bOTDRel98Present;
            if (this.eotdMeasInfo.bOTDRel98Present) {
               this.eotdMeasInfo.otd_MeasureInfo_R98_Ext = new OTD_MeasR98Ext();
            }
         } else if (var2.equals("measr98ext")) {
            this.isMesare98 = false;
         } else if (var2.equals("count")) {
            if (this.isMesare98) {
               this.eotdMeasInfo.otd_MeasureInfo_R98_Ext.ucCount = Short.parseShort(this.stData);
               this.eotdMeasInfo.otd_MeasureInfo_R98_Ext.otd_FirstSetMsrs = new ArrayList(this.eotdMeasInfo.otd_MeasureInfo_R98_Ext.ucCount);
            } else if (this.isMesarel5) {
               this.eotdMeasInfo.otd_MeasureInfo_Rel_5_Ext.ucCount = Short.parseShort(this.stData);
               this.eotdMeasInfo.otd_MeasureInfo_Rel_5_Ext.otdMsrRestSets = new ArrayList(this.eotdMeasInfo.otd_MeasureInfo_Rel_5_Ext.ucCount);
            }
         } else if (var2.equals("otdrel5present")) {
            var8 = this.eotdMeasInfo;
            if (Integer.parseInt(this.stData) == 1) {
               var4 = true;
            } else {
               var4 = false;
            }

            var8.bOTDRel5Present = var4;
            if (this.eotdMeasInfo.bOTDRel5Present) {
               this.eotdMeasInfo.otd_MeasureInfo_Rel_5_Ext = new OTD_MeasREL5Ext();
            }

            if (Integer.parseInt(this.stData) == 1) {
               var4 = var6;
            } else {
               var4 = false;
            }

            this.isMesarel5 = var4;
         } else if (var2.equals("measrel5ext")) {
            this.isMesarel5 = false;
         } else if (var2.equals("requestindex")) {
            this.means_WithID.neighborIdentity.stNeigh.ucRequestIndex = Short.parseShort(this.stData);
         } else if (var2.equals("systeminfoindex")) {
            this.means_WithID.neighborIdentity.stNeigh.ucSystemInfoIndex = Short.parseShort(this.stData);
         }
      }

   }

   public SUPL_EOTDMeasInfo getEotdMeasInfo() {
      return this.eotdMeasInfo;
   }

   public void startElement(String var1, String var2, String var3, Attributes var4) throws SAXException {
      if (var2.equals("valideotdmeasurement")) {
         this.isRequiredTag = true;
      } else if (var2.equals("eotdmeas")) {
         this.eotdMeasInfo = new SUPL_EOTDMeasInfo();
      } else {
         if (this.isNotValideotdMeasurement) {
            return;
         }

         if (var2.equals("msrelefirst")) {
            this.eotdMeasInfo.otdMsrFirstSet = new OTD_MsrEleFirst();
            this.isMsrelefirst = true;
         } else if (var2.equals("msrelecommon")) {
            this.eleCommon = new OTD_MSREleCommon();
         } else if (var2.equals("refframenumber")) {
            this.isRequiredTag = true;
         } else if (var2.equals("referencetimeslot")) {
            this.isRequiredTag = true;
         } else if (var2.equals("refquality")) {
            this.isRequiredTag = true;
         } else if (var2.equals("numofmeasurements")) {
            this.isRequiredTag = true;
         } else if (var2.equals("stdresolution")) {
            this.isRequiredTag = true;
         } else if (var2.equals("tacorrection")) {
            this.isRequiredTag = true;
         } else if (var2.equals("setcount")) {
            this.isRequiredTag = true;
         } else if (var2.equals("measwithid")) {
            this.means_WithID = new OTDMeans_WithID();
         } else if (var2.equals("neighboridentity")) {
            this.means_WithID.neighborIdentity = new Neighbor_Identity();
         } else if (var2.equals("neighboridtype")) {
            this.isRequiredTag = true;
         } else if (var2.equals("neighboridunion")) {
            this.means_WithID.neighborIdentity.stNeigh = new Neighbor_ID_Union();
         } else if (var2.equals("bsicandcarrier")) {
            this.means_WithID.neighborIdentity.stNeigh.bsicAndCarrier = new BSIC_Carrier();
         } else if (var2.equals("cellidandlac")) {
            this.means_WithID.neighborIdentity.stNeigh.ciandlac = new CellID_LAC();
         } else if (var2.equals("multiframecarrier")) {
            this.means_WithID.neighborIdentity.stNeigh.multiFrameCarrier = new MultiFrameCarrier();
         } else if (var2.equals("requestindex")) {
            this.isRequiredTag = true;
         } else if (var2.equals("referencelac")) {
            this.isRequiredTag = true;
         } else if (var2.equals("referenceci")) {
            this.isRequiredTag = true;
         } else if (var2.equals("bcchcarrier")) {
            this.isRequiredTag = true;
         } else if (var2.equals("multiframeoffset")) {
            this.isRequiredTag = true;
         } else if (var2.equals("carrier")) {
            this.isRequiredTag = true;
         } else if (var2.equals("bsic")) {
            this.isRequiredTag = true;
         } else if (var2.equals("nbortimeslot")) {
            this.isRequiredTag = true;
         } else if (var2.equals("eotdquality")) {
            this.quality = new EOTDQuality();
         } else if (var2.equals("nbrofmeasurements")) {
            this.isRequiredTag = true;
         } else if (var2.equals("stdofeotd")) {
            this.isRequiredTag = true;
         } else if (var2.equals("otdvalue")) {
            this.isRequiredTag = true;
         } else if (var2.equals("noofvalidsets")) {
            this.isRequiredTag = true;
         } else if (var2.equals("msrelerest")) {
            this.eleRest = new OTD_MSREleRest();
            this.isEleRest = true;
         } else if (var2.equals("msrofothersets")) {
            this.otd_MSRofOtherSets = new OTD_MSRofOtherSets();
         } else if (var2.equals("isidentitypresent")) {
            this.isRequiredTag = true;
         } else if (var2.equals("msrothersetsunion")) {
            this.otd_MSRofOtherSets.stOTDMsr = new OTD_MSR_OtherSets_Union();
         } else if (var2.equals("otdmeas")) {
            if (!this.otd_MSRofOtherSets.bIsIdentityPresent) {
               this.otd_MSRofOtherSets.stOTDMsr.identityNotPresent = new OTDMeas();
               if (!this.otd_MSRofOtherSets.bIsIdentityPresent) {
                  this.isOTDMeas = true;
               }
            }
         } else if (var2.equals("nbortimeslot")) {
            this.isRequiredTag = true;
         } else if (var2.equals("otdvalue")) {
            this.isRequiredTag = true;
         } else if (var2.equals("otdrel98present")) {
            this.isRequiredTag = true;
         } else if (var2.equals("count")) {
            this.isRequiredTag = true;
         } else if (var2.equals("otdrel5present")) {
            this.isRequiredTag = true;
         } else if (var2.equals("systeminfoindex")) {
            this.isRequiredTag = true;
         }
      }

   }
}
