package com.android.supl.loc.measure.lpp;

import com.android.bytewriter.IO;

public class SUPL_LPP_NEIGHBOUR_ELEM {
   public boolean bArfcnPresent;
   public boolean bEGCIPresent = true;
   public int lArfcnEUTRAValue;
   public SUPL_LPP_EGCI stLPPOTDOAEGCI = null;
   SUPL_LPP_OTDOA_MMT_QUALITY stOTDOAMeasureQuality = null;
   public int ulLPPrstd;
   public short usPhysCellIDNeighbour = 412;

   public SUPL_LPP_NEIGHBOUR_ELEM() {
      this.stLPPOTDOAEGCI = new SUPL_LPP_EGCI();
      this.bArfcnPresent = true;
      this.lArfcnEUTRAValue = 512;
      this.ulLPPrstd = 478;
      this.stOTDOAMeasureQuality = new SUPL_LPP_OTDOA_MMT_QUALITY();
   }

   public byte[] getLPP_NEIGHBOUR_ELEM() {
      byte var3 = 1;
      byte var2 = 14;
      if (this.bArfcnPresent) {
         var2 = 18;
      }

      Object var5 = null;
      byte[] var4 = (byte[])var5;
      int var1 = var2;
      byte[] var9;
      if (this.bEGCIPresent) {
         var4 = (byte[])var5;
         var1 = var2;
         if (this.stLPPOTDOAEGCI != null) {
            var9 = this.stLPPOTDOAEGCI.getLPP_EGCI();
            var4 = var9;
            var1 = var2;
            if (var9 != null) {
               var1 = var2 + var9.length;
               var4 = var9;
            }
         }
      }

      var9 = null;
      int var8 = var1;
      byte[] var6;
      if (this.stOTDOAMeasureQuality != null) {
         var6 = this.stOTDOAMeasureQuality.getOTDOA_MMT_QUALITY();
         var9 = var6;
         var8 = var1;
         if (var6 != null) {
            var8 = var1 + var6.length;
            var9 = var6;
         }
      }

      var6 = new byte[var8];
      var8 = IO.put2(var6, 0, this.usPhysCellIDNeighbour);
      byte var7;
      if (this.bEGCIPresent) {
         var7 = 1;
      } else {
         var7 = 0;
      }

      var8 = IO.put4(var6, var8, var7);
      var1 = var8;
      if (this.bEGCIPresent) {
         var1 = var8;
         if (var4 != null) {
            System.arraycopy(var4, 0, var6, var8, var4.length);
            var1 = var8 + var4.length;
         }
      }

      if (this.bArfcnPresent) {
         var2 = var3;
      } else {
         var2 = 0;
      }

      var8 = IO.put4(var6, var1, var2);
      var1 = var8;
      if (this.bArfcnPresent) {
         var1 = IO.put4(var6, var8, this.lArfcnEUTRAValue);
      }

      var1 = IO.put4(var6, var1, this.ulLPPrstd);
      if (var9 != null) {
         System.arraycopy(var9, 0, var6, var1, var9.length);
         var1 = var9.length;
      }

      return var6;
   }
}
