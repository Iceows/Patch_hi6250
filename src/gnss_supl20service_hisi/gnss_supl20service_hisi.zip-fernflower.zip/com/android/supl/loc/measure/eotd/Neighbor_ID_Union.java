package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;

public class Neighbor_ID_Union {
   public static final int NEIGHBORIDENTITY_BSICANDCARRIER = 1;
   public static final int NEIGHBORIDENTITY_CI = 2;
   public static final int NEIGHBORIDENTITY_CIANDLAC = 6;
   public static final int NEIGHBORIDENTITY_MULTIFRAMECARRIER = 3;
   public static final int NEIGHBORIDENTITY_REQUESTINDEX = 4;
   public static final int NEIGHBORIDENTITY_SYSTEMINFOINDEX = 5;
   public static final int NeighborIdentity_NOTHING = 0;
   public BSIC_Carrier bsicAndCarrier;
   public CellID_LAC ciandlac;
   public MultiFrameCarrier multiFrameCarrier;
   public short ucRequestIndex;
   public short ucSystemInfoIndex;
   public short usCellID;

   public byte[] getNeighborIDUnion(int var1) {
      Object var3 = null;
      byte[] var2 = (byte[])var3;
      switch(var1) {
      case 0:
         break;
      case 1:
         var2 = (byte[])var3;
         if (this.bsicAndCarrier != null) {
            var2 = this.bsicAndCarrier.getBSIC_Carrier();
         }
         break;
      case 2:
         var2 = new byte[2];
         IO.put2(var2, 0, this.usCellID);
         break;
      case 3:
         var2 = (byte[])var3;
         if (this.multiFrameCarrier != null) {
            var2 = this.multiFrameCarrier.getMultiFrameCarrier();
         }
         break;
      case 4:
         var2 = new byte[1];
         IO.put1(var2, 0, this.ucRequestIndex);
         break;
      case 5:
         var2 = new byte[1];
         IO.put1(var2, 0, this.ucSystemInfoIndex);
         break;
      case 6:
         var2 = (byte[])var3;
         if (this.ciandlac != null) {
            var2 = this.ciandlac.getCellID_LAC();
         }
         break;
      default:
         var2 = (byte[])var3;
      }

      return var2;
   }
}
