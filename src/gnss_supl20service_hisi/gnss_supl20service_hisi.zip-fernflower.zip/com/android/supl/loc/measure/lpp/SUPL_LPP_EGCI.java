package com.android.supl.loc.measure.lpp;

import com.android.bytewriter.IO;

public class SUPL_LPP_EGCI {
   public byte byValidMCCValues = 3;
   public byte byValidMNCValues;
   public byte[] nMCC = null;
   public byte[] nMNC = null;
   public int ulCellID;

   public SUPL_LPP_EGCI() {
      this.nMCC = new byte[this.byValidMCCValues];
      this.byValidMNCValues = 2;
      this.nMNC = new byte[this.byValidMNCValues];
   }

   public byte[] getLPP_EGCI() {
      byte[] var3 = new byte[this.byValidMCCValues * 1 + 6 + this.byValidMNCValues * 1];
      int var2 = IO.put1(var3, 0, this.byValidMCCValues);
      int var1 = var2;
      if (this.byValidMCCValues > 0) {
         var1 = var2;
         if (this.nMCC != null) {
            System.arraycopy(this.nMCC, 0, var3, var2, this.byValidMCCValues);
            var1 = var2 + this.byValidMCCValues;
         }
      }

      var2 = IO.put1(var3, var1, this.byValidMNCValues);
      var1 = var2;
      if (this.byValidMNCValues > 0) {
         var1 = var2;
         if (this.nMNC != null) {
            System.arraycopy(this.nMNC, 0, var3, var2, this.byValidMNCValues);
            var1 = var2 + this.byValidMNCValues;
         }
      }

      IO.put4(var3, var1, this.ulCellID);
      return var3;
   }
}
