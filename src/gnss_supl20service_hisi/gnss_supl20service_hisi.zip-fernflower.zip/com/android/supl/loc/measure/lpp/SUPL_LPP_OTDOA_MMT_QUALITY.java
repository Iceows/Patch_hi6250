package com.android.supl.loc.measure.lpp;

import com.android.bytewriter.IO;

public class SUPL_LPP_OTDOA_MMT_QUALITY {
   public boolean bNumberofSamplesPresent = true;
   public byte byErrorResolution = 2;
   public byte byErrorValue = 2;
   public byte byNumberofSamples = 4;

   public byte[] getOTDOA_MMT_QUALITY() {
      byte var1 = 6;
      if (this.bNumberofSamplesPresent) {
         var1 = 7;
      }

      byte[] var3 = new byte[var1];
      int var2 = IO.put1(var3, IO.put1(var3, 0, this.byErrorResolution), this.byErrorValue);
      if (this.bNumberofSamplesPresent) {
         var1 = 1;
      } else {
         var1 = 0;
      }

      int var4 = IO.put4(var3, var2, var1);
      if (this.bNumberofSamplesPresent) {
         IO.put1(var3, var4, this.byNumberofSamples);
      }

      return var3;
   }
}
