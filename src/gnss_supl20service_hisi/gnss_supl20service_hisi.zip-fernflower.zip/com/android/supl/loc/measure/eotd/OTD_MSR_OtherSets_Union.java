package com.android.supl.loc.measure.eotd;

public class OTD_MSR_OtherSets_Union {
   OTDMeas identityNotPresent;
   OTDMeans_WithID identityPresent;

   public byte[] getOTDOtherSets() {
      byte[] var1 = null;
      if (this.identityNotPresent != null) {
         var1 = this.identityNotPresent.getOTDMeas();
      } else if (this.identityPresent != null) {
         var1 = this.identityPresent.getOTDMeans_WithID();
      }

      return var1;
   }
}
