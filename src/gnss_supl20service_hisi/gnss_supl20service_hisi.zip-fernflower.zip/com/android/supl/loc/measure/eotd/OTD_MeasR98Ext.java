package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

public class OTD_MeasR98Ext {
   public ArrayList otd_FirstSetMsrs;
   public short ucCount;

   public byte[] getOTD_MeasR98Ext() {
      int var2 = 1;
      int var1 = 1;
      Vector var3 = null;
      Iterator var5;
      byte[] var7;
      if (this.otd_FirstSetMsrs != null) {
         Vector var4 = new Vector(this.otd_FirstSetMsrs.size());
         var5 = this.otd_FirstSetMsrs.iterator();

         while(true) {
            var2 = var1;
            var3 = var4;
            if (!var5.hasNext()) {
               break;
            }

            OTDMeans_WithID var6 = (OTDMeans_WithID)var5.next();
            if (var6 != null) {
               var7 = var6.getOTDMeans_WithID();
               if (var7 != null) {
                  var4.add(var7);
                  var1 += var7.length;
               }
            }
         }
      }

      byte[] var8 = new byte[var2];
      var1 = IO.put1(var8, 0, this.ucCount);
      if (var3 != null) {
         var5 = var3.iterator();

         while(var5.hasNext()) {
            var7 = (byte[])var5.next();
            if (var7 != null) {
               System.arraycopy(var7, 0, var8, var1, var7.length);
               var1 += var7.length;
            }
         }
      }

      return var8;
   }
}
