package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;

public class OTD_MSRofOtherSets {
   public boolean bIsIdentityPresent;
   public OTD_MSR_OtherSets_Union stOTDMsr;

   public byte[] getOTD_MSRofOtherSets() {
      int var1 = 4;
      byte[] var2 = null;
      if (this.stOTDMsr != null) {
         var2 = this.stOTDMsr.getOTDOtherSets();
         var1 = var2.length + 4;
      }

      byte[] var3 = new byte[var1];
      byte var4;
      if (this.bIsIdentityPresent) {
         var4 = 1;
      } else {
         var4 = 0;
      }

      var1 = IO.put4(var3, 0, var4);
      if (var2 != null) {
         System.arraycopy(var2, 0, var3, var1, var2.length);
         var1 = var2.length;
      }

      return var3;
   }
}
