package com.android.supl.loc.measure.aflt;

import com.android.bytewriter.IO;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

public class AfltMeasure {
   public int BandClass;
   public int BaseStationID;
   public int CDMAFrequency;
   public boolean IsOffsetIncluded;
   public int MSTimeOffset;
   public int NetworkIdentification;
   public int ReferencePN;
   public int ReferencePilotStrength;
   public int SystemIdentification;
   public int TimeReference;
   public int TotalNumberOfPilots;
   public int TotalReceivedPower;
   public boolean bMeasurementValid;
   ArrayList phaseRecord = null;

   public byte[] getAFLTMeasInfo(int var1) {
      byte var4 = 1;
      int var2 = 12 + 4;
      Vector var6 = null;
      int var3 = var2;
      Vector var5 = var6;
      Iterator var7;
      byte[] var11;
      if (this.bMeasurementValid) {
         var3 = var2 + 44;
         var2 = var3;
         if (this.IsOffsetIncluded) {
            var2 = var3 + 4;
         }

         var3 = var2;
         var5 = var6;
         if (this.TotalNumberOfPilots > 0) {
            var3 = var2;
            var5 = var6;
            if (this.phaseRecord != null) {
               var6 = new Vector(this.phaseRecord.size());
               var7 = this.phaseRecord.iterator();

               while(true) {
                  var3 = var2;
                  var5 = var6;
                  if (!var7.hasNext()) {
                     break;
                  }

                  SUPL_AFLT_PilotPhaseRecord var9 = (SUPL_AFLT_PilotPhaseRecord)var7.next();
                  if (var9 != null) {
                     var11 = var9.getAfltPilotPhaseRecord();
                     if (var11 != null) {
                        var6.add(var11);
                        var2 += var11.length;
                     }
                  }
               }
            }
         }
      }

      byte[] var10 = new byte[var3];
      var2 = IO.put4(var10, IO.put4(var10, IO.put4(var10, 0, var3 - 4), 276), var1);
      byte var8;
      if (this.bMeasurementValid) {
         var8 = 1;
      } else {
         var8 = 0;
      }

      var1 = IO.put4(var10, var2, var8);
      if (this.bMeasurementValid) {
         var2 = IO.put4(var10, var1, this.TimeReference);
         if (this.IsOffsetIncluded) {
            var8 = var4;
         } else {
            var8 = 0;
         }

         var2 = IO.put4(var10, var2, var8);
         var1 = var2;
         if (this.IsOffsetIncluded) {
            var1 = IO.put4(var10, var2, this.MSTimeOffset);
         }

         var1 = IO.put4(var10, IO.put4(var10, IO.put4(var10, IO.put4(var10, IO.put4(var10, IO.put4(var10, IO.put4(var10, IO.put4(var10, IO.put4(var10, var1, this.ReferencePN), this.ReferencePilotStrength), this.BandClass), this.CDMAFrequency), this.BaseStationID), this.SystemIdentification), this.NetworkIdentification), this.TotalReceivedPower), this.TotalNumberOfPilots);
         if (this.TotalNumberOfPilots > 0 && var5 != null) {
            var7 = var5.iterator();

            while(var7.hasNext()) {
               var11 = (byte[])var7.next();
               if (var11 != null) {
                  System.arraycopy(var11, 0, var10, var1, var11.length);
                  var1 += var11.length;
               }
            }
         }
      }

      return var10;
   }
}
