package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;

public class OTDMeas {
   public EOTDQuality eotdQuality;
   public short ucNborTimeSlot;
   public int usOTDValue;

   public byte[] getOTDMeas() {
      int var1 = 3;
      byte[] var3 = null;
      if (this.eotdQuality != null) {
         var3 = this.eotdQuality.getEOTDQulaity();
         var1 = var3.length + 3;
      }

      byte[] var4 = new byte[var1];
      int var2 = IO.put1(var4, 0, this.ucNborTimeSlot);
      var1 = var2;
      if (var3 != null) {
         System.arraycopy(var3, 0, var4, var2, var3.length);
         var1 = var2 + var3.length;
      }

      IO.put2(var4, var1, this.usOTDValue);
      return var4;
   }
}
