package com.android.supl.loc.measure.eotd;

import android.util.Log;
import com.android.bytewriter.IO;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

public class SUPL_EOTDMeasInfo {
   public boolean bIsValidEOTDMeasurement;
   public boolean bOTDRel5Present;
   public boolean bOTDRel98Present;
   public int nNoOfValidSets;
   public OTD_MsrEleFirst otdMsrFirstSet;
   public ArrayList otdMsrRestSets;
   public OTD_MeasR98Ext otd_MeasureInfo_R98_Ext;
   public OTD_MeasREL5Ext otd_MeasureInfo_Rel_5_Ext;

   public byte[] getEOTDMeasInfo(int var1) {
      int var3 = 4;
      byte[] var9 = null;
      byte[] var4 = null;
      Vector var10 = null;
      Vector var6 = null;
      byte[] var8 = null;
      Object var12 = null;
      Object var11 = null;
      Log.i("SUPL20_EOTD", "EOTD bValid value is " + this.bIsValidEOTDMeasurement);
      byte[] var7 = (byte[])var11;
      int var2;
      byte[] var17;
      if (this.bIsValidEOTDMeasurement) {
         byte var14 = 16;
         var2 = var14;
         byte[] var5;
         if (this.otdMsrFirstSet != null) {
            var5 = this.otdMsrFirstSet.getOTD_MsrEleFirst();
            var4 = var5;
            var2 = var14;
            if (var5 != null) {
               var2 = var5.length + 16;
               var4 = var5;
            }
         }

         var3 = var2;
         Vector var15 = var6;
         if (this.nNoOfValidSets > 0) {
            var3 = var2;
            var15 = var6;
            if (this.otdMsrRestSets != null) {
               var6 = new Vector(this.nNoOfValidSets);
               Iterator var18 = this.otdMsrRestSets.iterator();

               while(true) {
                  var3 = var2;
                  var15 = var6;
                  if (!var18.hasNext()) {
                     break;
                  }

                  OTD_MSREleRest var16 = (OTD_MSREleRest)var18.next();
                  if (var16 != null) {
                     var5 = var16.getOTD_MSREleRest();
                     if (var5 != null) {
                        var2 += var5.length;
                        var6.add(var5);
                     }
                  }
               }
            }
         }

         var17 = (byte[])var12;
         var2 = var3;
         if (this.bOTDRel98Present) {
            var17 = (byte[])var12;
            var2 = var3;
            if (this.otd_MeasureInfo_R98_Ext != null) {
               var7 = this.otd_MeasureInfo_R98_Ext.getOTD_MeasR98Ext();
               var17 = var7;
               var2 = var3;
               if (var7 != null) {
                  var2 = var3 + var7.length;
                  var17 = var7;
               }
            }
         }

         var9 = var4;
         var7 = (byte[])var11;
         var8 = var17;
         var3 = var2;
         var10 = var15;
         if (this.bOTDRel5Present) {
            var9 = var4;
            var7 = (byte[])var11;
            var8 = var17;
            var3 = var2;
            var10 = var15;
            if (this.otd_MeasureInfo_Rel_5_Ext != null) {
               byte[] var21 = this.otd_MeasureInfo_Rel_5_Ext.getOTD_MeasRel5Ext();
               var9 = var4;
               var7 = var21;
               var8 = var17;
               var3 = var2;
               var10 = var15;
               if (var21 != null) {
                  var3 = var2 + var21.length;
                  var10 = var15;
                  var8 = var17;
                  var7 = var21;
                  var9 = var4;
               }
            }
         }
      }

      var2 = var3 + 8 + 4;
      var4 = new byte[var2];
      var2 = IO.put4(var4, IO.put4(var4, IO.put4(var4, 0, var2 - 4), 276), var1);
      byte var13;
      if (this.bIsValidEOTDMeasurement) {
         var13 = 1;
      } else {
         var13 = 0;
      }

      var2 = IO.put4(var4, var2, var13);
      if (this.bIsValidEOTDMeasurement) {
         var1 = var2;
         if (var9 != null) {
            System.arraycopy(var9, 0, var4, var2, var9.length);
            var1 = var2 + var9.length;
         }

         var1 = IO.put4(var4, var1, this.nNoOfValidSets);
         var2 = var1;
         if (this.nNoOfValidSets > 0) {
            var2 = var1;
            if (var10 != null) {
               Iterator var19 = var10.iterator();

               while(true) {
                  var2 = var1;
                  if (!var19.hasNext()) {
                     break;
                  }

                  var17 = (byte[])var19.next();
                  System.arraycopy(var17, 0, var4, var1, var17.length);
                  var1 += var17.length;
               }
            }
         }

         if (this.bOTDRel98Present) {
            var13 = 1;
         } else {
            var13 = 0;
         }

         var2 = IO.put4(var4, var2, var13);
         var1 = var2;
         if (var8 != null) {
            System.arraycopy(var8, 0, var4, var2, var8.length);
            var1 = var2 + var8.length;
         }

         byte var20;
         if (this.bOTDRel5Present) {
            var20 = 1;
         } else {
            var20 = 0;
         }

         var1 = IO.put4(var4, var1, var20);
         if (var7 != null) {
            System.arraycopy(var7, 0, var4, var1, var7.length);
            var1 = var7.length;
         }
      }

      Log.i("SUPL20_EOTD", "EOTD msg has send :" + var4.length + " " + 276);
      return var4;
   }
}
