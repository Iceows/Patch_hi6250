package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;

public class BSIC_Carrier {
   public short cBsic;
   public int usCarrier;

   public byte[] getBSIC_Carrier() {
      byte[] var1 = new byte[3];
      IO.put1(var1, IO.put2(var1, 0, this.usCarrier), this.cBsic);
      return var1;
   }
}
