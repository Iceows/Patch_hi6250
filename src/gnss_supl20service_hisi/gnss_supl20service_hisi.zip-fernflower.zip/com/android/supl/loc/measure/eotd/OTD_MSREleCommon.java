package com.android.supl.loc.measure.eotd;

import com.android.bytewriter.IO;

public class OTD_MSREleCommon {
   public short ucNumOfMeasurements;
   public short ucRefQuality;
   public short ucReferenceTimeSlot;
   public short ucStdResolution;
   public int usRefFrameNumber;
   public int usTACorrection;

   public byte[] getOTSMSREle() {
      byte[] var1 = new byte[8];
      IO.put2(var1, IO.put1(var1, IO.put1(var1, IO.put1(var1, IO.put1(var1, IO.put2(var1, 0, this.usRefFrameNumber), this.ucReferenceTimeSlot), this.ucRefQuality), this.ucNumOfMeasurements), this.ucStdResolution), this.usTACorrection);
      return var1;
   }
}
