package com.android.supl.loc;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import com.android.supl.commprocessor.NDKCommProcessor;
import com.android.supl.nc.SendToServer;

public class NetInfo {
   private ConnectivityManager connManager = null;
   private Context context = null;
   private StaleLocationInfo mStaleLocationInfo = null;
   private WifiInfo wifiInfo = null;
   private WifiManager wifiManager = null;

   public NetInfo(Context var1) {
      this.connManager = (ConnectivityManager)var1.getSystemService("connectivity");
      this.context = var1;
      this.initWIFIManager();
   }

   public int getCurrentNetworkType() {
      int var1 = 0;
      if (this.connManager == null) {
         return 0;
      } else {
         NetworkInfo var2 = this.connManager.getActiveNetworkInfo();
         if (var2 != null) {
            var1 = var2.getType();
         }

         return var1;
      }
   }

   public String getIPAddress() {
      // $FF: Couldn't be decompiled
   }

   public String getLinkSpeed() {
      return this.wifiManager != null && this.wifiInfo != null ? this.wifiInfo.getLinkSpeed() + "Mbs" : "0Mbs";
   }

   public String getSupplicantDeatils() {
      return WifiInfo.getDetailedStateOf(this.wifiInfo.getSupplicantState()).name();
   }

   public String getWiFiBSSID() {
      return this.wifiManager != null && this.wifiInfo != null ? this.wifiInfo.getBSSID() : "";
   }

   public String getWiFiMACAddress() {
      return this.wifiManager != null && this.wifiInfo != null ? this.wifiInfo.getMacAddress() : "";
   }

   public int getWiFiRssi() {
      return this.wifiManager != null && this.wifiInfo != null ? this.wifiInfo.getRssi() : 0;
   }

   public String getWiFiSSID() {
      return this.wifiManager != null && this.wifiInfo != null ? this.wifiInfo.getSSID() : "";
   }

   public String getWifiIpAddress() {
      if (this.wifiManager != null && this.wifiInfo != null) {
         int var1 = this.wifiInfo.getIpAddress();
         return String.format("%d.%d.%d.%d", var1 & 255, var1 >> 8 & 255, var1 >> 16 & 255, var1 >> 24 & 255);
      } else {
         return "";
      }
   }

   public void initWIFIManager() {
      this.wifiManager = (WifiManager)this.context.getSystemService("wifi");
      this.wifiInfo = this.wifiManager.getConnectionInfo();
   }

   public boolean isNetworkOn() {
      ConnectivityManager var2 = (ConnectivityManager)this.context.getSystemService("connectivity");
      boolean var1;
      if (var2.getNetworkInfo(0).getState() != State.CONNECTED && var2.getNetworkInfo(1).getState() != State.CONNECTED) {
         var1 = false;
      } else {
         var1 = true;
      }

      return var1;
   }

   public boolean isOnline() {
      NetworkInfo var1 = ((ConnectivityManager)this.context.getSystemService("connectivity")).getActiveNetworkInfo();
      return var1 != null && var1.isConnectedOrConnecting();
   }

   public boolean isWiFiEnabled() {
      boolean var1 = false;
      if (this.wifiManager != null) {
         var1 = this.wifiManager.isWifiEnabled();
      }

      return var1;
   }

   public void sendStaleLocationInfo(NDKCommProcessor var1) {
      if (this.mStaleLocationInfo != null) {
         SendToServer var2 = new SendToServer();
         var2.m_bPacket = this.mStaleLocationInfo.getStaleLocation();
         var1.sendServer(var2);
      }

   }

   public void setStaleLocationInfo(byte[] var1, int var2) {
      if (this.mStaleLocationInfo == null) {
         this.mStaleLocationInfo = new StaleLocationInfo(var1, var2);
      } else {
         this.mStaleLocationInfo.upDateInfo(var1, var2);
      }

   }
}
