package com.android.supl.loc.wifi;

import com.android.bytewriter.IO;
import com.android.supl.loc.BitString;

public class WIFIParameter {
   private static final int WLAN802_11A = 0;
   private static final int WLAN802_11B = 1;
   private static final int WLAN802_11G = 2;
   public boolean bIsAPAGInfoPresent = false;
   public boolean bIsAPCFreqInfpPresent = false;
   public boolean bIsAPDeviceTypeInfoPresent = false;
   public boolean bIsAPRTDInfoPresent = false;
   public boolean bIsAPReportedLocationPresent = false;
   public boolean bIsAPSSInfoPresent = false;
   public boolean bIsAPStoNInfoPresent = false;
   public boolean bIsAPTPInfoPresent = false;
   public boolean bIsSetAGInfoPresent = false;
   public boolean bIsSetSigStrengthInfoPresent = false;
   public boolean bIsSetStoNInfoPresent = false;
   public boolean bIsSetTranPowerInfoPresent = false;
   public short eAPDeviceType;
   public short sAPAG;
   public short sAPSS;
   public short sAPStoN;
   public short sAPTP;
   public short sSetAG;
   public short sSetSigStrength;
   public short sSetStoN;
   public short sSetTransPower;
   public BitString stAPMACadd;
   public WIFIParameter.RTD stAPRTD;
   public WIFIParameter.ReportedLocation stReportedLocation;
   public short ucAPCFreq;

   public WIFIParameter(String var1) {
      this.stAPMACadd = new BitString(var1);
   }

   public byte[] getScanWIFIParameterInfo(boolean var1) {
      byte[] var5 = new byte[2005];
      byte[] var6 = this.stAPMACadd.getBitStringInfo();
      byte var2;
      if (var1) {
         var2 = 1;
      } else {
         var2 = 0;
      }

      int var7 = IO.put4(var5, 0, var2);
      System.arraycopy(var6, 0, var5, var7, var6.length);
      int var3 = var7 + var6.length;
      var7 = var6.length + 4;
      if (this.bIsAPTPInfoPresent) {
         var3 = IO.put2(var5, IO.put4(var5, var3, 1), this.sAPTP);
         var7 += 6;
      } else {
         var3 = IO.put4(var5, var3, 0);
         var7 += 4;
      }

      if (this.bIsAPAGInfoPresent) {
         var3 = IO.put2(var5, IO.put4(var5, var3, 1), this.sAPAG);
         var7 += 6;
      } else {
         var3 = IO.put4(var5, var3, 0);
         var7 += 4;
      }

      if (this.bIsAPStoNInfoPresent) {
         var3 = IO.put2(var5, IO.put4(var5, var3, 1), this.sAPStoN);
         var7 += 6;
      } else {
         var3 = IO.put4(var5, var3, 0);
         var7 += 4;
      }

      if (this.bIsAPDeviceTypeInfoPresent) {
         var3 = IO.put4(var5, IO.put4(var5, var3, 1), this.eAPDeviceType);
         var7 += 8;
      } else {
         var3 = IO.put4(var5, var3, 0);
         var7 += 4;
      }

      if (this.bIsAPSSInfoPresent) {
         var3 = IO.put2(var5, IO.put4(var5, var3, 1), this.sAPSS);
         var7 += 6;
      } else {
         var3 = IO.put4(var5, var3, 0);
         var7 += 4;
      }

      if (this.bIsAPCFreqInfpPresent) {
         var3 = IO.put1(var5, IO.put4(var5, var3, 1), this.ucAPCFreq);
         var7 += 5;
      } else {
         var3 = IO.put4(var5, var3, 0);
         var7 += 4;
      }

      if (this.bIsAPRTDInfoPresent && this.stAPRTD != null) {
         var3 = IO.put4(var5, var3, 1);
         var6 = this.stAPRTD.getRTDInfo();
         System.arraycopy(var6, 0, var5, var3, var6.length);
         var3 += var6.length;
         var7 += var6.length + 4;
      } else {
         var3 = IO.put4(var5, var3, 0);
         var7 += 4;
      }

      if (this.bIsSetTranPowerInfoPresent) {
         var3 = IO.put2(var5, IO.put4(var5, var3, 1), this.sSetTransPower);
         var7 += 6;
      } else {
         var3 = IO.put4(var5, var3, 0);
         var7 += 4;
      }

      if (this.bIsSetAGInfoPresent) {
         var3 = IO.put2(var5, IO.put4(var5, var3, 1), this.sSetAG);
         var7 += 6;
      } else {
         var3 = IO.put4(var5, var3, 0);
         var7 += 4;
      }

      if (this.bIsSetStoNInfoPresent) {
         var3 = IO.put2(var5, IO.put4(var5, var3, 1), this.sSetStoN);
         var7 += 6;
      } else {
         var3 = IO.put4(var5, var3, 0);
         var7 += 4;
      }

      if (this.bIsSetSigStrengthInfoPresent) {
         var3 = IO.put2(var5, IO.put4(var5, var3, 1), this.sSetSigStrength);
         var7 += 6;
      } else {
         var3 = IO.put4(var5, var3, 0);
         var7 += 4;
      }

      int var4;
      if (this.bIsAPReportedLocationPresent && this.stReportedLocation != null) {
         var3 = IO.put4(var5, var3, 1);
         var6 = this.stReportedLocation.getReportedLocationInfo();
         System.arraycopy(var6, 0, var5, var3, var6.length);
         var4 = var3 + var6.length;
         var3 = var7 + var6.length + 4;
         var7 = var4;
      } else {
         var4 = IO.put4(var5, var3, 0);
         var3 = var7 + 4;
         var7 = var4;
      }

      if (var7 != var3) {
         System.out.println("WIFIParameter length error");
      } else {
         var6 = new byte[var3];
         System.arraycopy(var5, 0, var6, 0, var3);
         var5 = var6;
      }

      return var5;
   }

   public byte[] getWIFIParameterInfo() {
      byte[] var3 = new byte[2005];
      byte[] var4 = this.stAPMACadd.getBitStringInfo();
      int var1 = IO.put4(var3, IO.put1(var3, 0, 1), 0);
      System.arraycopy(var4, 0, var3, var1, var4.length);
      int var2 = var1 + var4.length;
      var1 = var4.length + 5;
      if (this.bIsAPTPInfoPresent) {
         var2 = IO.put2(var3, IO.put4(var3, var2, 1), this.sAPTP);
         var1 += 6;
      } else {
         var2 = IO.put4(var3, var2, 0);
         var1 += 4;
      }

      if (this.bIsAPAGInfoPresent) {
         var2 = IO.put2(var3, IO.put4(var3, var2, 1), this.sAPAG);
         var1 += 6;
      } else {
         var2 = IO.put4(var3, var2, 0);
         var1 += 4;
      }

      if (this.bIsAPStoNInfoPresent) {
         var2 = IO.put2(var3, IO.put4(var3, var2, 1), this.sAPStoN);
         var1 += 6;
      } else {
         var2 = IO.put4(var3, var2, 0);
         var1 += 4;
      }

      if (this.bIsAPDeviceTypeInfoPresent) {
         var2 = IO.put4(var3, IO.put4(var3, var2, 1), this.eAPDeviceType);
         var1 += 8;
      } else {
         var2 = IO.put4(var3, var2, 0);
         var1 += 4;
      }

      if (this.bIsAPSSInfoPresent) {
         var2 = IO.put2(var3, IO.put4(var3, var2, 1), this.sAPSS);
         var1 += 6;
      } else {
         var2 = IO.put4(var3, var2, 0);
         var1 += 4;
      }

      if (this.bIsAPCFreqInfpPresent) {
         var2 = IO.put1(var3, IO.put4(var3, var2, 1), this.ucAPCFreq);
         var1 += 5;
      } else {
         var2 = IO.put4(var3, var2, 0);
         var1 += 4;
      }

      if (this.bIsAPRTDInfoPresent && this.stAPRTD != null) {
         var2 = IO.put4(var3, var2, 1);
         var4 = this.stAPRTD.getRTDInfo();
         System.arraycopy(var4, 0, var3, var2, var4.length);
         var2 += var4.length;
         var1 += var4.length + 4;
      } else {
         var2 = IO.put4(var3, var2, 0);
         var1 += 4;
      }

      if (this.bIsSetTranPowerInfoPresent) {
         var2 = IO.put2(var3, IO.put4(var3, var2, 1), this.sSetTransPower);
         var1 += 6;
      } else {
         var2 = IO.put4(var3, var2, 0);
         var1 += 4;
      }

      if (this.bIsSetAGInfoPresent) {
         var2 = IO.put2(var3, IO.put4(var3, var2, 1), this.sSetAG);
         var1 += 6;
      } else {
         var2 = IO.put4(var3, var2, 0);
         var1 += 4;
      }

      if (this.bIsSetStoNInfoPresent) {
         var2 = IO.put2(var3, IO.put4(var3, var2, 1), this.sSetStoN);
         var1 += 6;
      } else {
         var2 = IO.put4(var3, var2, 0);
         var1 += 4;
      }

      if (this.bIsSetSigStrengthInfoPresent) {
         var2 = IO.put2(var3, IO.put4(var3, var2, 1), this.sSetSigStrength);
         var1 += 6;
      } else {
         var2 = IO.put4(var3, var2, 0);
         var1 += 4;
      }

      if (this.bIsAPReportedLocationPresent && this.stReportedLocation != null) {
         var2 = IO.put4(var3, var2, 1);
         var4 = this.stReportedLocation.getReportedLocationInfo();
         System.arraycopy(var4, 0, var3, var2, var4.length);
         var2 += var4.length;
         var1 += var4.length + 4;
      } else {
         var2 = IO.put4(var3, var2, 0);
         var1 += 4;
      }

      if (var2 != var1) {
         System.out.println("WIFIParameter length error");
      } else {
         var4 = new byte[var1];
         System.arraycopy(var3, 0, var4, 0, var1);
         var3 = var4;
      }

      return var3;
   }

   private class LocationData {
      public boolean bIsLocationAccuInfoPresent = false;
      public BitString stLocationValue;
      public long ulLocationAccu;

      public byte[] getLocationInfo() {
         byte var1 = 4;
         if (this.bIsLocationAccuInfoPresent) {
            var1 = 12;
         }

         byte[] var3 = this.stLocationValue.getBitStringInfo();
         int var2 = var1 + var3.length;
         byte[] var4 = new byte[var2];
         int var5;
         if (this.bIsLocationAccuInfoPresent) {
            var5 = IO.put8(var4, IO.put4(var4, 0, 1), this.ulLocationAccu);
         } else {
            var5 = IO.put4(var4, 0, 0);
         }

         System.arraycopy(var3, 0, var4, var5, var3.length);
         if (var5 + var3.length != var2) {
            System.out.println("LocationData length error");
         }

         return var4;
      }
   }

   private class RTD {
      private static final int hundrednanosec = 1;
      private static final int microsec = 0;
      private static final int nanosec = 3;
      private static final int tensnanosec = 2;
      private static final int tenthofnanosec = 4;
      public boolean bIsRTDAccuInfoPresent = false;
      public int ieRTDunits = 0;
      public short ucRTDAccuracy;
      public int uiRTDValue;

      public byte[] getRTDInfo() {
         byte var1 = 12;
         if (this.bIsRTDAccuInfoPresent) {
            var1 = 13;
         }

         byte[] var3 = new byte[var1];
         int var2 = IO.put4(var3, IO.put4(var3, 0, this.uiRTDValue), this.ieRTDunits);
         if (this.bIsRTDAccuInfoPresent) {
            var2 = IO.put4(var3, var2, 1);
         } else {
            var2 = IO.put4(var3, var2, 0);
         }

         if (IO.put1(var3, var2, this.ucRTDAccuracy) != var1) {
            System.out.println("RTD length error");
         }

         return var3;
      }
   }

   private class ReportedLocation {
      private static final int ASN1 = 1;
      private static final int CI = 0;
      public int ieLocationEncodingDesc = 0;
      public WIFIParameter.LocationData stLocationData;

      public byte[] getReportedLocationInfo() {
         byte[] var3 = this.stLocationData.getLocationInfo();
         int var2 = var3.length + 4;
         byte[] var4 = new byte[var2];
         int var1 = IO.put4(var4, 0, this.ieLocationEncodingDesc);
         System.arraycopy(var3, 0, var4, var1, var3.length);
         if (var1 + var3.length != var2) {
            System.out.println("ReportedLocation length error");
         }

         return var4;
      }
   }
}
