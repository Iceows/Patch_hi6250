package com.android.supl.loc;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.LocationManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.SystemProperties;
import android.telephony.CellLocation;
import android.telephony.PhoneNumberUtils;
import android.telephony.PhoneStateListener;
import android.telephony.ServiceState;
import android.telephony.TelephonyManager;
import android.telephony.cdma.CdmaCellLocation;
import android.telephony.gsm.GsmCellLocation;
import android.util.Log;
import com.android.bytewriter.IO;
import com.android.supl.commprocessor.NDKCommProcessor;
import com.android.supl.config.ConfigManager;
import com.android.supl.loc.wifi.WIFIParameter;
import com.android.supl.nc.SendToServer;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

public class SETLocationManager {
   public static final int JELLY_BEAN_MR1 = 17;
   public static final int LOCATION_ID_STATUS_CURRENT = 1;
   public static final int LOCATION_ID_STATUS_STALE = 0;
   public static final int LOCATION_ID_STATUS_UNKNOWN = 2;
   private static final String LOG_TAG = "SUPL20_LocMan";
   public static final int MAX_WLAN_INFO = 20;
   private static final int TD_SCDMA = 17;
   private static final int UMB_CELLINFO = 20;
   private static final int WIFI_CELLINFO = 21;
   public static final String outgoing = "android.intent.action.NEW_OUTGOING_CALL";
   private IntentFilter intentFilter = new IntentFilter("android.intent.action.NEW_OUTGOING_CALL");
   private boolean isEmergencyCall = false;
   private boolean isEmergencyCallListen = false;
   private boolean isLocationSwithEnable = false;
   private boolean isStartListen = false;
   private boolean isWifiRegister = false;
   private SETLocationManager.EmergencyCallListener mCallListener = null;
   private NDKCommProcessor mCommProcessor = null;
   private Context mContext = null;
   private SETLocationManager.MyPhoneStateListener mMyPhoneStateListener = null;
   private NetInfo mNetInfo = null;
   private StaleLocationInfo mStaleLocationInfo = null;
   private SETLocationManager.NetworkStateBroadcastReceiver mWIFIReceiver = null;
   private int m_iMcc = 0;
   private int m_iMnc = 0;
   private String m_stBearerNetworkType = null;
   private String m_stIMSI = null;
   private String m_stMSISDN = null;
   private String m_stPhoneType = null;
   private BroadcastReceiver outGoingCallReceiver = new BroadcastReceiver() {
      public void onReceive(Context var1, Intent var2) {
         byte var3 = 1;
         String var8 = var2.getStringExtra("android.intent.extra.PHONE_NUMBER");
         SETLocationManager var6 = SETLocationManager.this;
         boolean var5;
         if (!EmergencyUtils.isEmergencyNumber(var8)) {
            var5 = PhoneNumberUtils.isEmergencyNumber(var8);
         } else {
            var5 = true;
         }

         var6.isEmergencyCall = var5;
         if (SETLocationManager.this.isEmergencyCall) {
            Log.i("SUPL20_LocMan", var8 + " on Emergency call is going..");
            SendToServer var9 = new SendToServer();
            var9.m_bPacket = new byte[12];
            int var4 = IO.put4(var9.m_bPacket, 0, 8);
            var4 = IO.put4(var9.m_bPacket, var4, 278);
            byte[] var7 = var9.m_bPacket;
            if (!SETLocationManager.this.isEmergencyCall) {
               var3 = 0;
            }

            IO.put4(var7, var4, var3);
            SETLocationManager.this.mCommProcessor.sendServer(var9);
         }

      }
   };
   private TelephonyManager tm = null;

   public SETLocationManager(Context var1) {
      this.mContext = var1;
      this.mNetInfo = new NetInfo(var1);
      this.tm = (TelephonyManager)this.mContext.getSystemService("phone");
      this.mMyPhoneStateListener = new SETLocationManager.MyPhoneStateListener((SETLocationManager.MyPhoneStateListener)null);
      this.isLocationSwithEnable = this.getLocationEnableState(var1);
   }

   private boolean checkCdmaCellLocationVaild(CdmaCellLocation var1) {
      if (var1 == null) {
         Log.e("SUPL20_LocMan", "cdmaCell is null.");
         return false;
      } else if (var1.getLac() >= 0 && var1.getLac() <= 32767) {
         if (var1.getCid() >= 0 && var1.getCid() <= 65535) {
            if (var1.getBaseStationId() >= 0 && var1.getBaseStationId() <= 65535) {
               if (var1.getBaseStationLatitude() >= -1296000 && var1.getBaseStationLatitude() <= 1296000) {
                  if (var1.getBaseStationLongitude() >= -2592000 && var1.getBaseStationLongitude() <= 2592000) {
                     return true;
                  } else {
                     Log.e("SUPL20_LocMan", "cdmaCell lon is error! " + var1.getBaseStationLongitude());
                     return false;
                  }
               } else {
                  Log.e("SUPL20_LocMan", "cdmaCell lat is error! " + var1.getBaseStationLatitude());
                  return false;
               }
            } else {
               Log.e("SUPL20_LocMan", "cdmaCell base id is error! " + var1.getBaseStationId());
               return false;
            }
         } else {
            Log.e("SUPL20_LocMan", "cdmaCell nid is error! " + var1.getCid());
            return false;
         }
      } else {
         Log.e("SUPL20_LocMan", "cdmaCell sid is error! " + var1.getLac());
         return false;
      }
   }

   private boolean checkGsmCellLocationValid(GsmCellLocation var1) {
      if (var1 == null) {
         Log.e("SUPL20_LocMan", "gsmCell is null.");
         return false;
      } else if (var1.getCid() >= 0 && var1.getCid() <= 65535) {
         if (var1.getLac() >= 0 && var1.getLac() <= 65535) {
            return true;
         } else {
            Log.e("SUPL20_LocMan", "gsmCell lac is error! " + var1.getLac());
            return false;
         }
      } else {
         Log.e("SUPL20_LocMan", "gsmCell cid is error! " + var1.getCid());
         return false;
      }
   }

   private boolean checkLteCellLocationValid(GsmCellLocation var1) {
      if (var1 == null) {
         Log.e("SUPL20_LocMan", "lteCell is null.");
         return false;
      } else if (var1.getCid() >= 0 && var1.getCid() <= 268435455) {
         if (var1.getLac() >= 0 && var1.getLac() <= 65535) {
            if (var1.getPsc() < 0 || var1.getPsc() > 503) {
               Log.w("SUPL20_LocMan", "lteCell psc is error! " + var1.getPsc());
            }

            return true;
         } else {
            Log.e("SUPL20_LocMan", "lteCell lac is error! " + var1.getLac());
            return false;
         }
      } else {
         Log.e("SUPL20_LocMan", "lteCell cid is error! " + var1.getCid());
         return false;
      }
   }

   private boolean checkUmtsCellLocationValid(GsmCellLocation var1) {
      if (var1 == null) {
         Log.e("SUPL20_LocMan", "umtsCell is null.");
         return false;
      } else if (var1.getCid() >= 0 && var1.getCid() <= 268435455) {
         if (var1.getLac() >= 0 && var1.getLac() <= 65535) {
            return true;
         } else {
            Log.e("SUPL20_LocMan", "umtsCell lac is error! " + var1.getLac());
            return false;
         }
      } else {
         Log.e("SUPL20_LocMan", "umtsCell cid is error! " + var1.getCid());
         return false;
      }
   }

   private void fakeGSMData() {
      GsmCellLocation var1 = new GsmCellLocation();
      var1.setLacAndCid(3203, 13310261);
      this.m_iMcc = 404;
      this.m_iMnc = 64;
      Log.i("SUPL20_LocMan", "fakeGSMData called");
      this.fillCellInfo(var1, true, 2, (byte[])null, (List)null);
   }

   private void fakeLTEData() {
      Log.i("SUPL20_LocMan", "fakeLTEData called");
      this.fillCellInfo((CellLocation)null, true, 13, (byte[])null, (List)null);
   }

   private CdmaCellInfo fillCDMACellinfo(CellLocation var1) {
      CdmaCellLocation var3 = (CdmaCellLocation)var1;
      CdmaCellInfo var2 = new CdmaCellInfo();
      var2.m_iBASELAT = var3.getBaseStationLatitude();
      var2.m_iBASELONG = var3.getBaseStationLongitude();
      var2.m_sBASEID = (short)var3.getBaseStationId();
      var2.m_sSID = (short)var3.getLac();
      var2.m_sNID = (short)var3.getCid();
      return var2;
   }

   private void fillCellInfo(CellLocation param1, boolean param2, int param3, byte[] param4, List param5) {
      // $FF: Couldn't be decompiled
   }

   private GsmCellInfo fillGSMCellinfo(CellLocation var1) {
      GsmCellLocation var2 = (GsmCellLocation)var1;
      GsmCellInfo var3 = new GsmCellInfo();
      var3.m_iMNC = this.m_iMnc;
      var3.m_iMCC = this.m_iMcc;
      var3.m_iLAC = var2.getLac();
      var3.m_iCellID = var2.getCid();
      return var3;
   }

   private boolean getLocationEnableState(Context var1) {
      if (this.isGlobalVersion()) {
         return true;
      } else {
         LocationManager var4 = (LocationManager)var1.getApplicationContext().getSystemService("location");
         boolean var3 = var4.isProviderEnabled("gps");
         boolean var2 = var4.isProviderEnabled("network");
         Log.d("SUPL20_LocMan", "gps switch " + var3 + " network switch " + var2);
         return var3 || var2;
      }
   }

   private String getNetworkTypeString(int var1) {
      String var2;
      switch(var1) {
      case 0:
         var2 = "UNKNOWN";
         break;
      case 1:
         var2 = "GPRS";
         break;
      case 2:
         var2 = "EDGE";
         break;
      case 3:
         var2 = "UMTS";
         break;
      case 4:
         var2 = "CDMA";
         break;
      case 5:
         var2 = "EVDO_0";
         break;
      case 6:
         var2 = "EVDO_A";
         break;
      case 7:
         var2 = "1xRTT";
         break;
      case 8:
         var2 = "HSDPA";
         break;
      case 9:
         var2 = "HSUPA";
         break;
      case 10:
         var2 = "HSPA";
         break;
      case 11:
         var2 = "IDEN";
         break;
      case 12:
         var2 = "EVDO_B";
         break;
      case 13:
         var2 = "LTE";
         break;
      case 14:
         var2 = "EHRPD";
         break;
      case 15:
         var2 = "HSPAP";
         break;
      case 16:
         var2 = "GSM";
         break;
      case 17:
         var2 = "TDS";
         break;
      case 18:
      default:
         var2 = "NOT RETERIVE";
         break;
      case 19:
         var2 = "TDS-DPA";
      }

      return var2;
   }

   private String getPhoneTypeString(int var1) {
      String var2;
      switch(var1) {
      case 0:
         var2 = "UNKNOWN";
         break;
      case 1:
         var2 = "GSM";
         break;
      case 2:
         var2 = "CDMA";
         break;
      default:
         var2 = "NOT RETERIVE";
      }

      return var2;
   }

   private boolean isGlobalVersion() {
      boolean var1;
      if ("zh".equals(SystemProperties.get("ro.product.locale.language"))) {
         var1 = "CN".equals(SystemProperties.get("ro.product.locale.region")) ^ true;
      } else {
         var1 = true;
      }

      return var1;
   }

   private boolean isSIMEnabled() {
      int var1 = this.tm.getSimState();
      boolean var2 = false;
      switch(var1) {
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
         var2 = false;
         break;
      case 5:
         var2 = true;
      }

      Log.i("SUPL20_LocMan", "SIM state :" + var1);
      return var2;
   }

   private void sendWIFIScanResult(List var1) {
      if (var1 != null && var1.size() > 0) {
         int var3 = 0;
         int var4 = var1.size();
         int var2 = var4;
         if (var4 > 20) {
            var2 = 20;
         }

         Vector var8 = new Vector(var2);

         for(int var5 = 0; var5 < var2; var3 = var4) {
            ScanResult var11 = (ScanResult)var1.get(var5);
            var4 = var3;
            if (var11 != null) {
               var4 = var3;
               if (var11.BSSID != null) {
                  WIFIParameter var9 = new WIFIParameter(var11.BSSID);
                  var4 = var3;
                  if (var9 != null) {
                     boolean var7 = false;
                     boolean var6 = var7;
                     if (this.mNetInfo != null) {
                        String var10 = this.mNetInfo.getWiFiMACAddress();
                        var6 = var7;
                        if (var10 != null) {
                           var6 = var11.BSSID.equals(var10);
                        }
                     }

                     byte[] var14 = var9.getScanWIFIParameterInfo(var6);
                     var4 = var3;
                     if (var14 != null) {
                        var4 = var3 + var14.length;
                        var8.add(var14);
                     }
                  }
               }
            }

            ++var5;
         }

         if (var8.size() > 0) {
            ++var3;
            byte[] var12 = new byte[var3];
            var2 = IO.put1(var12, 0, var8.size());
            Iterator var15 = var8.iterator();

            while(var15.hasNext()) {
               byte[] var13 = (byte[])var15.next();
               if (var13 != null) {
                  System.arraycopy(var13, 0, var12, var2, var13.length);
                  var2 += var13.length;
               }
            }

            if (var2 != var3) {
               Log.e("SUPL20_LocMan", "Wifi sacn result length invalid=" + var2 + ":" + var3);
            } else {
               Log.d("SUPL20_LocMan", "Wifi sacn result send");
               this.fillCellInfo((CellLocation)null, false, 21, var12, (List)null);
            }
         }
      }

   }

   private void startListener() {
      if (!this.isStartListen) {
         this.isStartListen = true;
         this.tm.listen(this.mMyPhoneStateListener, 209);
         Log.i("SUPL20_LocMan", "Registered MyPhoneStateListener");
         if (this.isLocationSwithEnable) {
            CellLocation.requestLocationUpdate();
            this.forceCellLocationUpdate();
         } else {
            Log.i("SUPL20_LocMan", "Location switch is OFF");
         }
      }

   }

   private void upDatePhoneInfo() {
      this.m_stIMSI = this.tm.getSubscriberId();
      this.m_stPhoneType = this.getPhoneTypeString(this.tm.getPhoneType());
      Log.i("SUPL20_LocMan", "Phone type:" + this.m_stPhoneType);
      this.m_stBearerNetworkType = this.getNetworkTypeString(this.tm.getNetworkType());
      if ("msisdn".equals(ConfigManager.getInstance().getPrefSetId())) {
         this.m_stMSISDN = this.tm.getLine1Number();
      }

      String var1 = this.tm.getNetworkOperator();
      if (var1 != null && var1.length() > 0) {
         try {
            this.m_iMcc = Integer.parseInt(var1.substring(0, 3));
            this.m_iMnc = Integer.parseInt(var1.substring(3));
            StringBuilder var3 = new StringBuilder();
            Log.i("SUPL20_LocMan", var3.append("Network Op Mnc= ").append(this.m_iMnc).append(" MCC = ").append(this.m_iMcc).toString());
         } catch (NumberFormatException var2) {
            ;
         }
      } else {
         Log.i("SUPL20_LocMan", "NULL Value received for network operator");
      }

   }

   private void updateNoSIM_MNC_MCC(SendToServer var1, int var2) {
      var1.m_bPacket = new byte[14];
      int var3 = IO.put4(var1.m_bPacket, 0, var1.m_bPacket.length - 4);
      var3 = IO.put4(var1.m_bPacket, var3, 281);
      var2 = IO.put2(var1.m_bPacket, var3, var2);
      IO.put4(var1.m_bPacket, var2, 0);
   }

   public void forceCellLocationUpdate() {
      (new Thread() {
         public void run() {
            if (SETLocationManager.this.isLocationSwithEnable) {
               int var1 = SETLocationManager.this.tm.getNetworkType();
               CellLocation var2 = SETLocationManager.this.tm.getCellLocation();
               if (var2 == null) {
                  Log.e("SUPL20_LocMan", "tm.getCellLocation() returned null");
               } else {
                  Log.i("SUPL20_LocMan", "tm.getCellLocation() returned non-null ");
                  SETLocationManager.this.fillCellInfo(var2, false, var1, (byte[])null, (List)null);
               }
            } else {
               Log.i("SUPL20_LocMan", "Location switch is OFF");
            }

         }
      }).start();
   }

   public SendToServer getSIM_Mnc_MCC(int var1) {
      SendToServer var3 = new SendToServer();
      if (this.tm != null) {
         String var4 = this.tm.getSimOperator();
         if (var4 != null && var4.length() > 0) {
            try {
               var3.m_bPacket = new byte[18];
               this.m_iMcc = Integer.parseInt(var4.substring(0, 3));
               this.m_iMnc = Integer.parseInt(var4.substring(3));
               int var2 = IO.put4(var3.m_bPacket, 0, var3.m_bPacket.length - 4);
               var2 = IO.put4(var3.m_bPacket, var2, 281);
               var1 = IO.put2(var3.m_bPacket, var2, var1);
               var1 = IO.put4(var3.m_bPacket, var1, 1);
               var1 = IO.put2(var3.m_bPacket, var1, this.m_iMcc);
               IO.put2(var3.m_bPacket, var1, this.m_iMnc);
               StringBuilder var6 = new StringBuilder();
               Log.i("SUPL20_LocMan", var6.append("Sim Operator Mnc= ").append(this.m_iMnc).append(" MCC = ").append(this.m_iMcc).toString());
            } catch (NumberFormatException var5) {
               ;
            }
         } else {
            this.updateNoSIM_MNC_MCC(var3, var1);
            Log.i("SUPL20_LocMan", "NULL Value received for Sim Operator ");
         }
      } else {
         this.updateNoSIM_MNC_MCC(var3, var1);
         Log.i("SUPL20_LocMan", "NULL Value received for TelephonyManager ");
      }

      Log.i("SUPL20_LocMan", " Msg  MSG_PCM_UPDATE_SIM_MCC_MNC");
      return var3;
   }

   public void registerEmergencyReceiver() {
      if (!this.isEmergencyCallListen) {
         Log.i("SUPL20_LocMan", "register the Emergency Receiver ");
         this.mContext.registerReceiver(this.outGoingCallReceiver, this.intentFilter, "supl20servicePermission", (Handler)null);
         this.isEmergencyCallListen = true;
         if (this.mCallListener == null) {
            this.mCallListener = new SETLocationManager.EmergencyCallListener((SETLocationManager.EmergencyCallListener)null);
         }

         this.tm.listen(this.mCallListener, 32);
      }

   }

   public void sendCellStaleLocation() {
      if (this.mStaleLocationInfo != null) {
         SendToServer var1 = new SendToServer();
         var1.m_bPacket = this.mStaleLocationInfo.getStaleLocation();
         this.mCommProcessor.sendServer(var1);
      }

   }

   public void sendSETIDInfo(int var1, int var2) {
      if (this.isLocationSwithEnable) {
         this.upDatePhoneInfo();
      }

      SetID var4 = new SetID(var1);
      SendToServer var3 = new SendToServer();
      switch(var1) {
      case 1:
         var3.m_bPacket = var4.getSetIDBuff(var2, this.m_stMSISDN);
         break;
      case 2:
         var3.m_bPacket = var4.getSetIDBuff(var2, "");
         break;
      case 3:
         var3.m_bPacket = var4.getSetIDBuff(var2, "");
         break;
      case 4:
         var3.m_bPacket = var4.getSetIDBuff(var2, this.m_stIMSI);
         break;
      case 5:
         var3.m_bPacket = var4.getSetIDBuff(var2, "");
         break;
      case 6:
         var3.m_bPacket = var4.getSetIDBuff(var2, this.mNetInfo.getIPAddress());
         break;
      case 7:
         var3.m_bPacket = var4.getSetIDBuff(var2, "");
         break;
      case 8:
         var3.m_bPacket = var4.getSetIDBuff(var2, "");
         break;
      default:
         var3.m_bPacket = var4.getSetIDBuff(var2, "");
      }

      this.mCommProcessor.sendServer(var3);
   }

   public void setCommProcessor(NDKCommProcessor var1) {
      this.mCommProcessor = var1;
   }

   public void startLocationIdListener() {
      IntentFilter var1 = new IntentFilter();
      var1.addAction("android.net.wifi.SCAN_RESULTS");
      var1.addAction("android.net.wifi.WIFI_STATE_CHANGED");
      var1.addAction("android.net.conn.CONNECTIVITY_CHANGE");
      var1.addAction("android.net.wifi.STATE_CHANGE");
      var1.addAction("android.net.wifi.supplicant.CONNECTION_CHANGE");
      var1.addAction("android.net.wifi.supplicant.STATE_CHANGE");
      var1.addAction("android.location.PROVIDERS_CHANGED");
      if (this.mWIFIReceiver == null) {
         this.mWIFIReceiver = new SETLocationManager.NetworkStateBroadcastReceiver();
      }

      if (!this.isWifiRegister) {
         this.mContext.registerReceiver(this.mWIFIReceiver, var1, "supl20servicePermission", (Handler)null);
         this.isWifiRegister = true;
      }

      if (this.isSIMEnabled()) {
         Log.i("SUPL20_LocMan", " sim is enable on the SET");
         this.startListener();
      } else {
         this.startListener();
         Log.i("SUPL20_LocMan", " sim is not enabled on the SET");
      }

   }

   public void stopListening() {
      if (this.mWIFIReceiver != null && this.isWifiRegister) {
         this.mContext.unregisterReceiver(this.mWIFIReceiver);
         this.isWifiRegister = false;
      }

      if (this.tm != null && this.mMyPhoneStateListener != null && this.isStartListen) {
         this.isStartListen = false;
         this.tm.listen(this.mMyPhoneStateListener, 0);
         Log.i("SUPL20_LocMan", "De-Registered MyPhoneStateListener");
      }

   }

   public void unregisterEmergencyReceiver() {
      if (this.isEmergencyCallListen) {
         this.mContext.unregisterReceiver(this.outGoingCallReceiver);
         this.tm.listen(this.mCallListener, 0);
         this.isEmergencyCallListen = false;
         Log.i("SUPL20_LocMan", "unregister the Emergency Receiver ");
      }

   }

   private class EmergencyCallListener extends PhoneStateListener {
      private EmergencyCallListener() {
      }

      // $FF: synthetic method
      EmergencyCallListener(SETLocationManager.EmergencyCallListener var2) {
         this();
      }

      public void onCallStateChanged(int var1, String var2) {
         byte var3 = 0;
         switch(var1) {
         case 0:
            if (SETLocationManager.this.isEmergencyCall) {
               SETLocationManager.this.isEmergencyCall = false;
               SendToServer var5 = new SendToServer();
               var5.m_bPacket = new byte[12];
               int var4 = IO.put4(var5.m_bPacket, 0, 8);
               var4 = IO.put4(var5.m_bPacket, var4, 278);
               byte[] var6 = var5.m_bPacket;
               if (SETLocationManager.this.isEmergencyCall) {
                  var3 = 1;
               }

               IO.put4(var6, var4, var3);
               SETLocationManager.this.mCommProcessor.sendServer(var5);
               Log.i("SUPL20_LocMan", "onCallStateChanged " + "IDLE" + " on Emergency call End");
            }
            break;
         case 1:
            (new StringBuilder()).append("Ringing (").append(var2).append(")").toString();
         case 2:
         }

         super.onCallStateChanged(var1, var2);
      }
   }

   private class MyPhoneStateListener extends PhoneStateListener {
      private MyPhoneStateListener() {
      }

      // $FF: synthetic method
      MyPhoneStateListener(SETLocationManager.MyPhoneStateListener var2) {
         this();
      }

      public void onCellInfoChanged(List var1) {
         int var2 = SETLocationManager.this.tm.getNetworkType();
         Log.i("SUPL20_LocMan", "onCellInfoChanged network type:" + var2);
         if (var2 == 13) {
            SETLocationManager.this.fillCellInfo((CellLocation)null, false, var2, (byte[])null, var1);
         }

         super.onCellInfoChanged(var1);
      }

      public void onCellLocationChanged(CellLocation var1) {
         int var2 = SETLocationManager.this.tm.getNetworkType();
         Log.i("SUPL20_LocMan", "onCellLocationChanged network type:" + var2);
         SETLocationManager.this.fillCellInfo(var1, false, var2, (byte[])null, (List)null);
         super.onCellLocationChanged(var1);
      }

      public void onDataConnectionStateChanged(int var1) {
         String var2;
         switch(var1) {
         case 0:
            var2 = "Disconnected";
            break;
         case 1:
            var2 = "Connecting";
            break;
         case 2:
            var2 = "Connected";
            break;
         case 3:
            var2 = "Suspended";
            break;
         default:
            var2 = "Unknown: " + var1;
         }

         Log.i("SUPL20_LocMan", "onDataConnectionStateChanged " + var2);
         SETLocationManager.this.forceCellLocationUpdate();
         super.onDataConnectionStateChanged(var1);
      }

      public void onDataConnectionStateChanged(int var1, int var2) {
         Log.i("SUPL20_LocMan", "onDataConnectionStateChanged networkType = " + var2);
         switch(var1) {
         case 0:
            Log.i("SUPL20_LocMan", "onDataConnectionStateChanged TelephonyManager.DATA_DISCONNECTED");
            break;
         case 1:
            Log.i("SUPL20_LocMan", "onDataConnectionStateChanged TelephonyManager.DATA_CONNECTING");
            break;
         case 2:
            Log.i("SUPL20_LocMan", "onDataConnectionStateChanged TelephonyManager.DATA_CONNECTED");
            break;
         case 3:
            Log.i("SUPL20_LocMan", "onDataConnectionStateChanged TelephonyManager.DATA_SUSPENDED");
            break;
         default:
            (new StringBuilder()).append("Unknown: ").append(var1).toString();
            Log.i("SUPL20_LocMan", "onDataConnectionStateChanged state = " + var1);
         }

         SETLocationManager.this.forceCellLocationUpdate();
         super.onDataConnectionStateChanged(var1);
      }

      public void onServiceStateChanged(ServiceState var1) {
         boolean var2 = false;
         switch(var1.getState()) {
         case 0:
            Log.i("SUPL20_LocMan", "onServiceStateChanged ServiceState.STATE_IN_SERVICE");
            break;
         case 1:
            var2 = true;
            Log.i("SUPL20_LocMan", "onServiceStateChanged ServiceState.STATE_OUT_OF_SERVICE");
            break;
         case 2:
            var2 = true;
            Log.i("SUPL20_LocMan", "onServiceStateChanged ServiceState.STATE_EMERGENCY_ONLY");
            break;
         case 3:
            var2 = true;
            Log.i("SUPL20_LocMan", "onServiceStateChanged ServiceState.STATE_POWER_OFF");
            break;
         default:
            var2 = true;
            Log.i("SUPL20_LocMan", "onServiceStateChanged " + var1.getState());
         }

         if (var2) {
            SETLocationManager.this.sendCellStaleLocation();
            SETLocationManager.this.mNetInfo.sendStaleLocationInfo(SETLocationManager.this.mCommProcessor);
         } else {
            SETLocationManager.this.forceCellLocationUpdate();
         }

         super.onServiceStateChanged(var1);
      }
   }

   public class NetworkStateBroadcastReceiver extends BroadcastReceiver {
      public void onReceive(Context var1, Intent var2) {
         String var4 = var2.getAction();
         String var7;
         if (var4.equals("android.net.wifi.SCAN_RESULTS")) {
            if (SETLocationManager.this.isLocationSwithEnable) {
               List var6 = ((WifiManager)var1.getSystemService("wifi")).getScanResults();
               StringBuilder var9 = (new StringBuilder()).append(" num scan results=");
               Object var5;
               if (var6 == null) {
                  var5 = "0";
               } else {
                  var5 = var6.size();
               }

               var7 = var9.append(var5).toString();
               Log.d("SUPL20_LocMan", "WIFI_STATE result" + var7);
               SETLocationManager.this.sendWIFIScanResult(var6);
            }
         } else if (var4.equals("android.net.conn.CONNECTIVITY_CHANGE")) {
            if (var2.getBooleanExtra("noConnectivity", false)) {
               var7 = "no connectivity";
            } else {
               var7 = "connection available";
            }

            Log.d("SUPL20_LocMan", "Connectivity result: " + var7);
         } else if (var4.equals("android.net.wifi.WIFI_STATE_CHANGED")) {
            int var3 = var2.getIntExtra("wifi_state", 4);
            var7 = "unknown";
            switch(var3) {
            case 0:
               var7 = "disabling";
               break;
            case 1:
               var7 = "disabled";
               SETLocationManager.this.mNetInfo.sendStaleLocationInfo(SETLocationManager.this.mCommProcessor);
               break;
            case 2:
               var7 = "enabling";
               break;
            case 3:
               String var8 = "enabled";
               var7 = var8;
               if (SETLocationManager.this.isLocationSwithEnable) {
                  var7 = SETLocationManager.this.mNetInfo.getWiFiMACAddress();
                  if (var7 != null && var7.trim().length() > 0) {
                     SETLocationManager.this.fillCellInfo((CellLocation)null, false, 21, (byte[])null, (List)null);
                     var7 = var8;
                  } else {
                     Log.e("SUPL20_LocMan", "WIFI_STATE not have mac address");
                     var7 = var8;
                  }
               }
            }

            Log.d("SUPL20_LocMan", "WIFI_STATE " + var7);
         } else if (var4.equals("android.location.PROVIDERS_CHANGED")) {
            SETLocationManager.this.isLocationSwithEnable = SETLocationManager.this.getLocationEnableState(var1);
            if (SETLocationManager.this.isLocationSwithEnable && SETLocationManager.this.isGlobalVersion() ^ true) {
               SETLocationManager.this.forceCellLocationUpdate();
            }

            Log.d("SUPL20_LocMan", "Location switch " + SETLocationManager.this.isLocationSwithEnable);
         }

      }
   }
}
