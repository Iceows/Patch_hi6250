package com.android.supl.loc;

import com.android.bytewriter.IO;

public class UMBCellInfo {
   public BitString stRefSectorID;
   public int unRefBASELAT;
   public int unRefBASELONG;
   public int unRefSeconds;
   public short usRefMCC;
   public short usRefMNC;
   public short usRefWeekNumber;

   public byte[] getUMBCellInfo() {
      byte[] var3 = this.stRefSectorID.getBitStringInfo();
      int var1 = var3.length + 18;
      byte[] var2 = new byte[var1];
      System.arraycopy(var3, 0, var2, 0, var3.length);
      if (IO.put4(var2, IO.put2(var2, IO.put4(var2, IO.put4(var2, IO.put2(var2, IO.put2(var2, var3.length + 0, this.usRefMCC), this.usRefMNC), this.unRefBASELAT), this.unRefBASELONG), this.usRefWeekNumber), this.unRefSeconds) != var1) {
         System.out.println("UMBCell length error");
      }

      return var2;
   }

   public void setDummyData() {
      this.stRefSectorID = new BitString("umb");
      this.usRefMCC = 404;
      this.usRefMNC = 64;
      this.unRefBASELAT = 12995999;
      this.unRefBASELONG = 80252142;
      this.usRefWeekNumber = 454;
      this.unRefSeconds = 1145465;
   }
}
