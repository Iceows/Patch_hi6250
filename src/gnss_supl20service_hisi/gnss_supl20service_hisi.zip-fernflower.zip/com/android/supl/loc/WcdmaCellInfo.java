package com.android.supl.loc;

import android.telephony.CellLocation;
import android.telephony.gsm.GsmCellLocation;
import com.android.bytewriter.IO;
import com.android.supl.loc.measure.FrequencyInfo;
import com.android.supl.loc.measure.MeasuredResultsList;
import com.android.supl.loc.measure.TimingAdvance;

public class WcdmaCellInfo {
   public boolean IsMeasuredResultsListPresent = false;
   public boolean bIsCellParametersIdPresent;
   public boolean isFrequencyInfoPresent = false;
   public boolean isPrimaryScramblingCodePresent = false;
   public boolean isTimingAdvancePresent;
   public FrequencyInfo mFrequencyInfo = null;
   public short m_sLAC = 0;
   public short m_sMCC = 0;
   public short m_sMNC = 0;
   public MeasuredResultsList stMeasuredResultsList;
   public TimingAdvance stTimingAdvance;
   public short ucCellParametersId;
   public int uiRefUC = 0;
   public short usPrimaryScramblingCode;

   public WcdmaCellInfo(CellLocation var1, int var2, int var3) {
      GsmCellLocation var4 = (GsmCellLocation)var1;
      this.m_sMNC = (short)var2;
      this.m_sMCC = (short)var3;
      this.m_sLAC = (short)var4.getLac();
      this.uiRefUC = var4.getCid();
   }

   public byte[] getWCDMAInfo() {
      byte var2 = 30;
      Object var5 = null;
      byte[] var4 = (byte[])var5;
      int var1 = var2;
      byte[] var9;
      if (this.isFrequencyInfoPresent) {
         var4 = (byte[])var5;
         var1 = var2;
         if (this.mFrequencyInfo != null) {
            var9 = this.mFrequencyInfo.getFrequencyInfo();
            var4 = var9;
            var1 = var2;
            if (var9 != null) {
               var1 = var9.length + 30;
               var4 = var9;
            }
         }
      }

      int var3 = var1;
      if (this.isPrimaryScramblingCodePresent) {
         var3 = var1 + 2;
      }

      Object var6 = null;
      var9 = (byte[])var6;
      int var8 = var3;
      if (this.IsMeasuredResultsListPresent) {
         var9 = (byte[])var6;
         var8 = var3;
         if (this.stMeasuredResultsList != null) {
            var9 = this.stMeasuredResultsList.getMeasuredResultsListInfo();
            var8 = var3 + var9.length;
         }
      }

      var1 = var8;
      if (this.bIsCellParametersIdPresent) {
         var1 = var8 + 1;
      }

      Object var7 = null;
      byte[] var10 = (byte[])var7;
      var8 = var1;
      if (this.isTimingAdvancePresent) {
         var10 = (byte[])var7;
         var8 = var1;
         if (this.stTimingAdvance != null) {
            var10 = this.stTimingAdvance.getTimingAdvanceInfo();
            var8 = var1 + var10.length;
         }
      }

      byte[] var11 = new byte[var8];
      var1 = IO.put4(var11, IO.put2(var11, IO.put2(var11, IO.put2(var11, 0, this.m_sMCC), this.m_sMNC), this.m_sLAC), this.uiRefUC);
      if (this.isFrequencyInfoPresent && var4 != null) {
         var1 = IO.put4(var11, var1, 1);
         System.arraycopy(var4, 0, var11, var1, var4.length);
         var1 += var4.length;
      } else {
         var1 = IO.put4(var11, var1, 0);
      }

      if (this.isPrimaryScramblingCodePresent) {
         var1 = IO.put2(var11, IO.put4(var11, var1, 1), this.usPrimaryScramblingCode) + 2;
      } else {
         var1 = IO.put4(var11, var1, 0);
      }

      if (this.IsMeasuredResultsListPresent && var9 != null) {
         var1 = IO.put4(var11, var1, 1);
         System.arraycopy(var9, 0, var11, var1, var9.length);
         var1 += var9.length;
      } else {
         var1 = IO.put4(var11, var1, 0);
      }

      if (this.bIsCellParametersIdPresent) {
         var1 = IO.put1(var11, IO.put4(var11, var1, 1), this.ucCellParametersId) + 1;
      } else {
         var1 = IO.put4(var11, var1, 0);
      }

      if (this.isTimingAdvancePresent && var10 != null) {
         var1 = IO.put4(var11, var1, 1);
         System.arraycopy(var10, 0, var11, var1, var10.length);
         var1 += var10.length;
      } else {
         var1 = IO.put4(var11, var1, 0);
      }

      if (var1 != var8) {
         System.out.println("getWCDMAInfo invalid length");
      }

      return var11;
   }
}
