package com.android.supl.loc;

import android.content.Context;
import android.telephony.CellIdentityLte;
import android.telephony.CellInfo;
import android.telephony.CellInfoLte;
import android.telephony.CellLocation;
import android.telephony.CellSignalStrengthLte;
import android.telephony.NeighboringCellInfo;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.util.Log;
import com.android.bytewriter.IO;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class LTECellInfo {
   private static final String LOG = "SUPL20_LTECellInfo";
   public static boolean bIsMeasResultListEUTRA = false;
   public static boolean bIsRSRPInfoPresent = false;
   public static boolean bIsRSRQInfoPresent = false;
   public static boolean bIsTAInfoPresent = false;
   public static List listMRLEUTRA = new ArrayList();
   public static short ucRSRPResult;
   public static short ucRSRQResult;
   public static final short usMaxCellReport = 8;
   public static short usTA;
   public LTECellInfo.Cell_Globalid_Eutra stCELLGlobalID = null;
   public short usPhysCellID;
   public char usTrackAreaCode;

   public LTECellInfo(LTECellInfo.Cell_Globalid_Eutra var1, char var2, short var3) {
      if (var1 == null) {
         throw new NullPointerException("Cell_Globalid_Eutra should not null");
      } else {
         if (var2 == 0) {
            Log.w("SUPL20_LTECellInfo", "TrackAreaCode should not be zero");
         }

         this.stCELLGlobalID = var1;
         this.usTrackAreaCode = var2;
         this.usPhysCellID = var3;
      }
   }

   public static LTECellInfo getAPILTECellInfo(Context var0) {
      TelephonyManager var4 = (TelephonyManager)var0.getSystemService("phone");
      Log.i("SUPL20_LTECellInfo", "TelephonyManager class:" + var4.getClass().getCanonicalName());
      List var7 = var4.getAllCellInfo();
      if (var7 == null) {
         Log.e("SUPL20_LTECellInfo", "getAllCellInfo function returns list is null");
         return null;
      } else {
         List var5 = var4.getNeighboringCellInfo();
         if (var5 != null) {
            Log.i("SUPL20_LTECellInfo", "neighborCellInfoList size: " + var5.size());
            Iterator var8 = var5.iterator();

            while(var8.hasNext()) {
               NeighboringCellInfo var6 = (NeighboringCellInfo)var8.next();
               if (var6 != null) {
                  var6.getLac();
                  var6.getCid();
                  int var2 = var6.getPsc();
                  int var3 = var6.getRssi();
                  int var1 = var6.getNetworkType();
                  Log.i("SUPL20_LTECellInfo", "neighborCellInfo psc:" + var2 + "rssi:" + var3 + "nwtype:" + var1);
               }
            }
         }

         return getCellInfo_To_LTECellInfo(var7, var5);
      }
   }

   public static LTECellInfo getCellInfo_To_LTECellInfo(List var0, List var1) {
      Log.i("SUPL20_LTECellInfo", "start to get lte cell info");
      bIsMeasResultListEUTRA = false;
      listMRLEUTRA.clear();
      if (var0 == null) {
         Log.e("SUPL20_LTECellInfo", "cellInfoList is null");
         return null;
      } else {
         var1 = null;
         Log.i("SUPL20_LTECellInfo", "cellinfo list size: " + var0.size());
         Iterator var13 = var0.iterator();
         LTECellInfo var15 = var1;

         while(var13.hasNext()) {
            CellInfo var18 = (CellInfo)var13.next();
            if (var18 instanceof CellInfoLte) {
               CellInfoLte var19 = (CellInfoLte)var18;
               int var8;
               CellSignalStrengthLte var21;
               if (var19.isRegistered()) {
                  CellIdentityLte var16 = var19.getCellIdentity();
                  if (var16 == null) {
                     Log.e("SUPL20_LTECellInfo", "getCellIdentity function returns null");
                     return null;
                  }

                  int var12 = var16.getMnc();
                  var8 = var16.getMcc();
                  int var10 = var16.getTac();
                  int var9 = var16.getCi();
                  int var11 = var16.getPci();
                  char var4 = (char)(var8 / 100);
                  char var2 = (char)(var8 % 100 / 10);
                  char var3 = (char)(var8 % 10);
                  char[] var17;
                  if (var12 > 99) {
                     var17 = new char[]{(char)(var12 / 100), (char)(var12 % 100 / 10), (char)(var12 % 10)};
                  } else {
                     var17 = new char[]{(char)(var12 / 10), (char)(var12 % 10)};
                  }

                  LTECellInfo.MNCList var20 = new LTECellInfo.MNCList(var17);
                  var15 = new LTECellInfo(new LTECellInfo.Cell_Globalid_Eutra(new LTECellInfo.PlmnIdentity(true, new LTECellInfo.MCC_LIST(new char[]{var4, var2, var3}), var20), var9), (char)var10, (short)var11);
                  var21 = var19.getCellSignalStrength();
                  if (var21 != null) {
                     ucRSRPResult = (short)var21.getDbm();
                     ucRSRPResult = (short)(ucRSRPResult + 141);
                     if (ucRSRPResult < 0) {
                        ucRSRPResult = 0;
                     } else if (ucRSRPResult > 97) {
                        ucRSRPResult = 97;
                     }

                     bIsRSRPInfoPresent = true;
                     ucRSRQResult = (short)(var21.getRsrq() * 2 + 40);
                     if (ucRSRQResult < 0) {
                        ucRSRQResult = 0;
                     } else if (ucRSRQResult > 34) {
                        ucRSRQResult = 34;
                     }

                     bIsRSRQInfoPresent = true;
                     Log.i("SUPL20_LTECellInfo", String.format("ucRSRPResult:%d, ucRSRQResult:%d", Integer.valueOf(ucRSRPResult), Integer.valueOf(ucRSRQResult)));
                  } else {
                     bIsRSRPInfoPresent = false;
                     bIsRSRQInfoPresent = false;
                  }
               } else {
                  CellIdentityLte var14 = var19.getCellIdentity();
                  if (var14 == null) {
                     Log.w("SUPL20_LTECellInfo", "get neighbor cell returns null");
                  } else {
                     var14.getMnc();
                     var14.getMcc();
                     var14.getTac();
                     var14.getCi();
                     var8 = var14.getPci();
                     short var5 = 0;
                     short var6 = 0;
                     var21 = var19.getCellSignalStrength();
                     if (var21 != null) {
                        var6 = (short)((short)var21.getDbm() + 141);
                        if (var6 < 0) {
                           var5 = 0;
                        } else {
                           var5 = var6;
                           if (var6 > 97) {
                              var5 = 97;
                           }
                        }

                        short var7 = (short)(var21.getRsrq() * 2 + 40);
                        if (var7 < 0) {
                           var6 = 0;
                        } else {
                           var6 = var7;
                           if (var7 > 34) {
                              var6 = 34;
                           }
                        }

                        Log.i("SUPL20_LTECellInfo", String.format("usMeasResultRSRP:%d, usMeasResultRSRQ:%d", Integer.valueOf(var5), Integer.valueOf(var6)));
                     }

                     if (listMRLEUTRA.size() < 8) {
                        LTECellInfo.measResultEUTRA var22 = new LTECellInfo.measResultEUTRA((short)var8, var5, var6);
                        listMRLEUTRA.add(var22);
                        bIsMeasResultListEUTRA = true;
                     } else {
                        Log.w("SUPL20_LTECellInfo", "listMRLEUTRA size > 8, discard!");
                     }
                  }
               }
            }
         }

         Log.i("SUPL20_LTECellInfo", "listMRLEUTRA size: " + listMRLEUTRA.size());
         return var15;
      }
   }

   public static LTECellInfo getCellLocation_To_LTECellInfo(CellLocation var0, int var1, int var2) {
      if (var0 instanceof GsmCellLocation) {
         char var7 = (char)(var1 / 100);
         char var5 = (char)(var1 % 100 / 10);
         char var6 = (char)(var1 % 10);
         char[] var8;
         if (var2 > 99) {
            var8 = new char[]{(char)(var2 / 100), (char)(var2 % 100 / 10), (char)(var2 % 10)};
         } else {
            var8 = new char[]{(char)(var2 / 10), (char)(var2 % 10)};
         }

         LTECellInfo.MNCList var9 = new LTECellInfo.MNCList(var8);
         LTECellInfo.Cell_Globalid_Eutra var10 = new LTECellInfo.Cell_Globalid_Eutra(new LTECellInfo.PlmnIdentity(true, new LTECellInfo.MCC_LIST(new char[]{var7, var5, var6}), var9), var0.getCid());
         byte var4 = 0;
         short var3 = var4;
         if (var0.getPsc() >= 0) {
            var3 = var4;
            if (503 >= var0.getPsc()) {
               var3 = (short)var0.getPsc();
            }
         }

         return new LTECellInfo(var10, (char)var0.getLac(), var3);
      } else {
         return null;
      }
   }

   private static Object getFunctionReturnValue(Object param0, String param1, String param2, Class[] param3, Object[] param4) {
      // $FF: Couldn't be decompiled
   }

   public static LTECellInfo getNONAPILTECellInfo(Context param0) {
      // $FF: Couldn't be decompiled
   }

   public byte[] getLTECellInfo() {
      byte[] var5 = this.stCELLGlobalID.getCellGlobalidInfo();
      int var2 = var5.length + 0 + 2 + 2 + 16;
      int var1 = var2;
      if (bIsRSRPInfoPresent) {
         var1 = var2 + 1;
      }

      var2 = var1;
      if (bIsRSRQInfoPresent) {
         var2 = var1 + 1;
      }

      var1 = var2;
      if (bIsTAInfoPresent) {
         var1 = var2 + 2;
      }

      Iterator var4 = null;
      byte[] var3 = (byte[])var4;
      var2 = var1;
      if (bIsMeasResultListEUTRA) {
         var3 = (byte[])var4;
         var2 = var1;
         if (listMRLEUTRA != null) {
            var2 = 0;
            var3 = new byte[listMRLEUTRA.size() * 6];

            for(var4 = listMRLEUTRA.iterator(); var4.hasNext(); var2 += 6) {
               System.arraycopy(((LTECellInfo.measResultEUTRA)var4.next()).getMeasResultEUTRA(), 0, var3, var2, 6);
            }

            var2 = var1 + 1 + var3.length;
         }
      }

      byte[] var6 = new byte[var2];
      System.arraycopy(var5, 0, var6, 0, var5.length);
      var1 = IO.put2(var6, IO.put2(var6, var5.length + 0, this.usPhysCellID), this.usTrackAreaCode);
      if (bIsRSRPInfoPresent) {
         var1 = IO.put1(var6, IO.put4(var6, var1, 1), ucRSRPResult);
      } else {
         var1 = IO.put4(var6, var1, 0);
      }

      if (bIsRSRQInfoPresent) {
         var1 = IO.put1(var6, IO.put4(var6, var1, 1), ucRSRQResult);
      } else {
         var1 = IO.put4(var6, var1, 0);
      }

      if (bIsTAInfoPresent) {
         var1 = IO.put2(var6, IO.put4(var6, var1, 1), usTA);
      } else {
         var1 = IO.put4(var6, var1, 0);
      }

      if (bIsMeasResultListEUTRA && listMRLEUTRA != null) {
         var1 = IO.put1(var6, IO.put4(var6, var1, 1), listMRLEUTRA.size());
         System.arraycopy(var3, 0, var6, var1, var3.length);
         var1 += var3.length;
      } else {
         var1 = IO.put4(var6, var1, 0);
      }

      if (var1 != var2) {
         System.out.println("LTECellInfo length error");
      }

      return var6;
   }

   public static class Cell_Globalid_Eutra {
      private int iCellIdentity;
      private LTECellInfo.PlmnIdentity stPLMNIdentity;

      public Cell_Globalid_Eutra(LTECellInfo.PlmnIdentity var1, int var2) {
         if (var1 == null) {
            throw new NullPointerException("PlmnIdentity should not null");
         } else {
            if (var2 == 0) {
               Log.w("SUPL20_LTECellInfo", "CellIdentity should not be zero");
            }

            this.stPLMNIdentity = var1;
            this.iCellIdentity = var2;
         }
      }

      public byte[] getCellGlobalidInfo() {
         byte[] var2 = this.stPLMNIdentity.getPLMNIdentityInfo();
         byte[] var1 = new byte[var2.length + 4];
         System.arraycopy(var2, 0, var1, 0, var2.length);
         IO.put4(var1, var2.length + 0, this.iCellIdentity);
         return var1;
      }
   }

   public static class MCC_LIST {
      private char[] usRefMCC;

      public MCC_LIST(char[] var1) {
         if (var1 == null) {
            throw new NullPointerException("MCC_LIST should not null");
         } else {
            if (var1.length < 3) {
               Log.w("SUPL20_LTECellInfo", "MCC_LIST should not be less than 3");
            }

            this.usRefMCC = var1;
         }
      }

      public char[] getMccListInfo() {
         return this.usRefMCC;
      }
   }

   public static class MNCList {
      private char[] ucRefMNC;
      private short ucRefMNCcnt;

      public MNCList(char[] var1) {
         this.ucRefMNC = var1;
         if (this.ucRefMNC != null) {
            this.ucRefMNCcnt = (short)this.ucRefMNC.length;
         } else {
            this.ucRefMNCcnt = 0;
         }

      }

      public byte[] getMncListInfo() {
         byte[] var3;
         if (this.ucRefMNCcnt > 0) {
            byte[] var4 = new byte[this.ucRefMNCcnt * 2 + 1];
            int var2 = IO.put1(var4, 0, this.ucRefMNCcnt);
            int var1 = 0;

            while(true) {
               var3 = var4;
               if (var1 >= this.ucRefMNCcnt) {
                  break;
               }

               var2 = IO.put2(var4, var2, this.ucRefMNC[var1]);
               ++var1;
            }
         } else {
            var3 = new byte[1];
            IO.put1(var3, 0, 0);
         }

         return var3;
      }
   }

   public static class PlmnIdentity {
      private boolean bIsMCCPresent;
      private LTECellInfo.MCC_LIST stMCC;
      private LTECellInfo.MNCList stMNC;

      public PlmnIdentity(boolean var1, LTECellInfo.MCC_LIST var2, LTECellInfo.MNCList var3) {
         if (var3 == null) {
            throw new NullPointerException("MNCList should not null");
         } else if (var1 && var2 == null) {
            throw new NullPointerException("MCC_LIST should not null");
         } else {
            this.bIsMCCPresent = var1;
            this.stMCC = var2;
            this.stMNC = var3;
         }
      }

      public byte[] getPLMNIdentityInfo() {
         int var1 = 4;
         char[] var5 = null;
         if (this.bIsMCCPresent) {
            var5 = this.stMCC.getMccListInfo();
            var1 = var5.length * 2 + 4;
         }

         byte[] var7 = this.stMNC.getMncListInfo();
         int var4 = var1 + var7.length;
         byte[] var6 = new byte[var4];
         int var3;
         if (this.bIsMCCPresent) {
            var1 = IO.put4(var6, 0, 1);
            int var2 = 0;

            while(true) {
               var3 = var1;
               if (var2 >= var5.length) {
                  break;
               }

               var1 = IO.put2(var6, var1, var5[var2]);
               ++var2;
            }
         } else {
            var3 = IO.put4(var6, 0, 0);
         }

         System.arraycopy(var7, 0, var6, var3, var7.length);
         if (var4 != var3 + var7.length) {
            Log.e("SUPL20_LTECellInfo", "PLMNIdentity length error");
         }

         return var6;
      }
   }

   public static class measResultEUTRA {
      public short sPhysCellID;
      public short sRSRPResult;
      public short sRSRQResult;

      public measResultEUTRA(short var1, short var2, short var3) {
         this.sPhysCellID = var1;
         this.sRSRPResult = var2;
         this.sRSRQResult = var3;
      }

      public byte[] getMeasResultEUTRA() {
         byte[] var1 = new byte[6];
         IO.put2(var1, IO.put2(var1, IO.put2(var1, 0, this.sPhysCellID), this.sRSRPResult), this.sRSRQResult);
         return var1;
      }
   }
}
