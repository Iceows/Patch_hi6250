package com.android.supl;

import android.content.Context;
import android.os.RemoteException;
import android.os.IHwBinder.DeathRecipient;
import com.android.supl.commprocessor.FromServer;
import com.android.supl.nc.SendToServer;
import com.android.supl.nc.SuplServiceMgr;
import vendor.huawei.hardware.hisupl.V1_0.ISuplclienttoserverCallbacks;
import vendor.huawei.hardware.hisupl.V1_0.ISuplclienttoserverInterface;
import vendor.huawei.hardware.hisupl.V1_0.server2client;

public class SUPLHIDLInterface {
   private static final String LOG_TAG = "SUPLHIDL";
   private static SUPLHIDLInterface.HiSuplCallback mHiSuplCb = null;
   private static SUPLHIDLInterface mSUPLHIDLInterface;
   private static final Object sWatcherLock = new Object();
   private Context mContext;
   private SUPLHIDLInterface.HidlServiceDeathHandler mHidlDeathHandler;
   private ISuplclienttoserverInterface mISupl = null;
   private final Object mObject = new Object();
   private SuplServiceMgr mSuplServiceMgr = null;

   public SUPLHIDLInterface(Context var1) {
      this.mContext = var1;
      mHiSuplCb = new SUPLHIDLInterface.HiSuplCallback();
      Log.d("SUPLHIDL", "getISuplService");
      this.getISuplService();
   }

   public static SUPLHIDLInterface createSUPLHIDLInterface(Context var0) {
      Object var1 = sWatcherLock;
      synchronized(var1){}

      try {
         if (mSUPLHIDLInterface == null) {
            Log.i("SUPLHIDL", "new one");
            SUPLHIDLInterface var2 = new SUPLHIDLInterface(var0);
            mSUPLHIDLInterface = var2;
         }
      } finally {
         ;
      }

      return mSUPLHIDLInterface;
   }

   private void getISuplService() {
      synchronized(this){}

      try {
         if (this.mISupl == null) {
            try {
               this.mISupl = ISuplclienttoserverInterface.getService();
               if (this.mISupl != null) {
                  Log.d("SUPLHIDL", "Get mISupl service success.");
                  this.mISupl.setCallback(mHiSuplCb);
                  SUPLHIDLInterface.HidlServiceDeathHandler var9 = new SUPLHIDLInterface.HidlServiceDeathHandler((SUPLHIDLInterface.HidlServiceDeathHandler)null);
                  this.mHidlDeathHandler = var9;
                  this.mISupl.linkToDeath(this.mHidlDeathHandler, 0L);
               } else {
                  Log.d("SUPLHIDL", "mISupl return null");
               }

               return;
            } catch (RemoteException var6) {
               StringBuilder var2 = new StringBuilder();
               Log.e("SUPLHIDL", var2.append("Exception getting ISupl: ").append(var6.getMessage()).toString());
            } catch (Exception var7) {
               StringBuilder var1 = new StringBuilder();
               Log.e("SUPLHIDL", var1.append("Exception: ").append(var7.getMessage()).toString());
            }

            return;
         }

         Log.d("SUPLHIDL", "Get getISuplService service not null.");
      } finally {
         ;
      }

   }

   public void SendMsg2PCM(SendToServer param1) {
      // $FF: Couldn't be decompiled
   }

   public void SendMsg2SCM(SendToServer param1) {
      // $FF: Couldn't be decompiled
   }

   public void setSuplServiceMgr(SuplServiceMgr var1) {
      this.mSuplServiceMgr = var1;
   }

   class HiSuplCallback extends ISuplclienttoserverCallbacks.Stub {
      public void suplPcmCb(server2client var1) throws RemoteException {
         Object var2 = SUPLHIDLInterface.this.mObject;
         synchronized(var2){}

         try {
            Log.d("SUPLHIDL", "suplPcmCb enter");
            FromServer var3 = new FromServer();
            var3.m_bPacket = new byte[var1.packetSize];
            System.arraycopy(var1.s2c_packet, 0, var3.m_bPacket, 0, var1.packetSize);
            if (SUPLHIDLInterface.this.mSuplServiceMgr != null) {
               SUPLHIDLInterface.this.mSuplServiceMgr.addPcmPacket(var3);
            } else {
               Log.e("SUPLHIDL", "mSuplServiceMgr is null");
            }
         } finally {
            ;
         }

      }

      public void suplScmCb(server2client var1) throws RemoteException {
         Object var2 = SUPLHIDLInterface.this.mObject;
         synchronized(var2){}

         try {
            Log.d("SUPLHIDL", "suplScmCb enter.");
            FromServer var3 = new FromServer();
            var3.m_bPacket = new byte[var1.packetSize];
            System.arraycopy(var1.s2c_packet, 0, var3.m_bPacket, 0, var1.packetSize);
            if (SUPLHIDLInterface.this.mSuplServiceMgr != null) {
               SUPLHIDLInterface.this.mSuplServiceMgr.addScmPacket(var3);
            } else {
               Log.e("SUPLHIDL", "mSuplServiceMgr is null");
            }
         } finally {
            ;
         }

      }
   }

   private class HidlServiceDeathHandler implements DeathRecipient {
      private HidlServiceDeathHandler() {
      }

      // $FF: synthetic method
      HidlServiceDeathHandler(SUPLHIDLInterface.HidlServiceDeathHandler var2) {
         this();
      }

      public void serviceDied(long var1) {
         try {
            Log.d("SUPLHIDL", "HISUPL server died.");
            if (SUPLHIDLInterface.this.mISupl != null) {
               Log.d("SUPLHIDL", "HISUPL server died 00.");
               SUPLHIDLInterface.this.mISupl.unlinkToDeath(SUPLHIDLInterface.this.mHidlDeathHandler);
               Log.d("SUPLHIDL", "HISUPL server died 01.");
               SUPLHIDLInterface.this.mISupl = null;
            }
         } catch (RemoteException var4) {
            Log.e("SUPLHIDL", "Exception unlinkToDeath: " + var4.getMessage());
         }

      }
   }
}
