package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.Log;
import com.android.bytewriter.IO;

public class SUPLSETID implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SUPLSETID createFromParcel(Parcel var1) {
         return new SUPLSETID(var1);
      }

      public SUPLSETID[] newArray(int var1) {
         return new SUPLSETID[var1];
      }
   };
   public static final int SUPL_SETID_TYPE_IMSI = 4;
   public static final int SUPL_SETID_TYPE_IPADDRESSV4 = 6;
   public static final int SUPL_SETID_TYPE_IPADDRESSV6 = 7;
   public static final int SUPL_SETID_TYPE_MDN = 2;
   public static final int SUPL_SETID_TYPE_MIN = 3;
   public static final int SUPL_SETID_TYPE_MSISDN = 1;
   public static final int SUPL_SETID_TYPE_NAI = 5;
   public static final int SUPL_SETID_TYPE_NONE = 8;
   private int iNumBytes;
   private int m_iSetIDType;
   private String stData;

   public SUPLSETID() {
   }

   public SUPLSETID(int var1, String var2, int var3) {
      switch(var1) {
      case 1:
         this.iNumBytes = 12;
         break;
      case 2:
         this.iNumBytes = 8;
         break;
      case 3:
         this.iNumBytes = 5;
         break;
      case 4:
         this.iNumBytes = 20;
         break;
      case 5:
         this.iNumBytes = 1000;
         break;
      case 6:
         this.iNumBytes = 4;
         break;
      case 7:
         this.iNumBytes = 16;
         break;
      case 8:
         this.iNumBytes = var3;
         break;
      default:
         throw new IllegalArgumentException("invalid SETTYPE ");
      }

      this.m_iSetIDType = var1;
      this.stData = var2;
   }

   public SUPLSETID(Parcel var1) {
      this.readFromParcel(var1);
   }

   private String addLeadingData(String var1, String var2, int var3) {
      if (var1 == null) {
         return null;
      } else {
         int var5 = var1.length();
         if (var5 >= var3) {
            return var1;
         } else {
            StringBuffer var6 = new StringBuffer();

            for(int var4 = 0; var4 < var3 - var5; ++var4) {
               var6.append(var2);
            }

            var6.append(var1);
            return var6.toString();
         }
      }
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getSETID() {
      int var1;
      int var4;
      byte[] var7;
      var4 = this.iNumBytes + 8;
      var7 = new byte[var4];
      var1 = IO.put4(var7, IO.put4(var7, 0, this.m_iSetIDType), this.iNumBytes);
      int var2;
      int var3;
      int var5;
      byte[] var11;
      label31:
      switch(this.m_iSetIDType) {
      case 1:
         var11 = this.stData.getBytes();
         this.stData = this.addLeadingData(this.stData, "0", 12);
         Log.i("SUPL20_SETID", "MSISDN " + this.stData);
         System.arraycopy(var11, 0, var7, var1, var11.length);
         var1 += 12;
         break;
      case 2:
         var1 = IO.put8(var7, var1, Long.parseLong(this.stData));
         break;
      case 3:
         var1 = IO.put5(var7, var1, Long.parseLong(this.stData));
         break;
      case 4:
         this.stData = this.addLeadingData(this.stData, "0", 20);
         System.arraycopy(this.stData.getBytes(), 0, var7, var1, this.iNumBytes);
         var1 += this.iNumBytes;
         break;
      case 5:
         this.stData = this.addLeadingData(this.stData, "0", 1000);
         var11 = this.stData.getBytes();
         Log.i("SUPL20_SETID", "NAI " + this.stData);
         System.arraycopy(var11, 0, var7, var1, this.iNumBytes);
         var1 += this.iNumBytes;
         break;
      case 6:
         String[] var10 = this.stData.split("\\.");
         var3 = 0;
         var5 = var10.length;
         var2 = var1;

         while(true) {
            var1 = var2;
            if (var3 >= var5) {
               break label31;
            }

            var2 = IO.put1(var7, var2, Integer.parseInt(var10[var3]));
            ++var3;
         }
      case 7:
         String[] var9 = this.stData.split(":");
         var3 = 0;
         var5 = var9.length;
         var2 = var1;

         while(true) {
            var1 = var2;
            if (var3 >= var5) {
               break;
            }

            String var8 = this.addLeadingData(var9[var3], "0", 4);
            int var6 = Integer.parseInt(var8.substring(0, 2), 16);
            var1 = Integer.parseInt(var8.substring(2), 16);
            var2 = IO.put1(var7, IO.put1(var7, var2, var6), var1);
            ++var3;
         }
      }

      if (var4 != var1) {
         System.err.println("invalid setid packet size " + var4 + ": " + (var1 - 4));
      }

      return var7;
   }

   public void readFromParcel(Parcel var1) {
      this.m_iSetIDType = var1.readInt();
      this.iNumBytes = var1.readInt();
      this.stData = var1.readString();
   }

   public String toString() {
      return this.stData + "," + this.iNumBytes + ",SID:" + this.m_iSetIDType;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeInt(this.m_iSetIDType);
      var1.writeInt(this.iNumBytes);
      var1.writeString(this.stData);
   }
}
