package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.io.DataInputStream;
import java.io.IOException;

public class SILocationReport implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SILocationReport createFromParcel(Parcel var1) {
         return new SILocationReport(var1);
      }

      public SILocationReport[] newArray(int var1) {
         return new SILocationReport[var1];
      }
   };
   public int m_iLat;
   public int m_iLon;
   public int m_usPlatformSessionId;

   public SILocationReport() {
   }

   public SILocationReport(Parcel var1) {
      this.readFromParcel(var1);
   }

   public int describeContents() {
      return 0;
   }

   public void readFromParcel(Parcel var1) {
      this.m_usPlatformSessionId = var1.readInt();
      this.m_iLat = var1.readInt();
      this.m_iLon = var1.readInt();
   }

   public boolean readSILocationReport(DataInputStream var1) throws IOException {
      this.m_usPlatformSessionId = var1.readUnsignedShort();
      this.m_iLat = var1.readInt();
      this.m_iLon = var1.readInt();
      return true;
   }

   public String toString() {
      return "SID:" + this.m_usPlatformSessionId + " Lat:" + this.m_iLat + " Lon:" + this.m_iLon;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeInt(this.m_usPlatformSessionId);
      var1.writeInt(this.m_iLat);
      var1.writeInt(this.m_iLon);
   }
}
