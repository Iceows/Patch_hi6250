package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class SUPLAreaEventType implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SUPLAreaEventType createFromParcel(Parcel var1) {
         return new SUPLAreaEventType(var1);
      }

      public SUPLAreaEventType[] newArray(int var1) {
         return new SUPLAreaEventType[var1];
      }
   };
   public static final int ENTERINGAREA = 0;
   public static final int INSIDEAREA = 1;
   public static final int LEAVINGAREA = 3;
   public static final int OUTSIDEAREA = 2;
   private int iAreaEventType = 0;

   public SUPLAreaEventType(int var1) {
      if (var1 <= 3 && var1 >= 0) {
         this.iAreaEventType = var1;
      } else {
         throw new IllegalArgumentException("invalid AreaEvent type");
      }
   }

   public SUPLAreaEventType(Parcel var1) {
      this.readFromParcel(var1);
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getAreaEventType() {
      byte[] var1 = new byte[4];
      IO.put4(var1, 0, this.iAreaEventType);
      return var1;
   }

   public void readFromParcel(Parcel var1) {
      this.iAreaEventType = var1.readInt();
   }

   public String toString() {
      return "AE:" + this.iAreaEventType;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeInt(this.iAreaEventType);
   }
}
