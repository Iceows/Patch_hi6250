package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class SUPLPolygonArea implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SUPLPolygonArea createFromParcel(Parcel var1) {
         return new SUPLPolygonArea(var1);
      }

      public SUPLPolygonArea[] newArray(int var1) {
         return new SUPLPolygonArea[var1];
      }
   };
   private SUPLPolygonDescription PolyDescription = null;
   private int PolygonHysteresis;

   public SUPLPolygonArea(Parcel var1) {
      this.readFromParcel(var1);
   }

   public SUPLPolygonArea(SUPLPolygonDescription var1, int var2) {
      if (var1 == null) {
         throw new IllegalArgumentException("PolygonDescription object should not be null");
      } else {
         this.PolyDescription = var1;
         this.PolygonHysteresis = var2;
      }
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getPolygonAreaInfo() {
      byte[] var3 = this.PolyDescription.getPolygonDescription();
      int var1 = var3.length + 4;
      byte[] var2 = new byte[var1];
      System.arraycopy(var3, 0, var2, 0, var3.length);
      if (IO.put4(var2, var3.length + 0, this.PolygonHysteresis) != var1) {
         System.err.println("PolygonArea length invalid");
      }

      return var2;
   }

   public void readFromParcel(Parcel var1) {
      this.PolygonHysteresis = var1.readInt();
      this.PolyDescription = (SUPLPolygonDescription)var1.readParcelable(SUPLPolygonDescription.class.getClassLoader());
   }

   public String toString() {
      return this.PolyDescription.toString() + "," + this.PolygonHysteresis;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeInt(this.PolygonHysteresis);
      var1.writeParcelable(this.PolyDescription, var2);
   }
}
