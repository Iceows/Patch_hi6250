package com.android.supl.si;

import com.android.bytewriter.IO;

public class StopSITrigSessParams {
   public static final int MSG_PCM_STOP_SI = 271;
   public int iSessionID = 0;

   public StopSITrigSessParams(int var1) {
      this.iSessionID = var1;
   }

   public byte[] getStopSIInfo() {
      byte[] var1 = new byte[10];
      if (IO.put2(var1, IO.put4(var1, IO.put4(var1, 0, 6), 271), this.iSessionID) - 4 != 6) {
         System.err.println("invalid length in  getStopSIInfo");
      }

      return var1;
   }
}
