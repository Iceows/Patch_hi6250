package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class SUPLCoordinate implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SUPLCoordinate createFromParcel(Parcel var1) {
         return new SUPLCoordinate(var1);
      }

      public SUPLCoordinate[] newArray(int var1) {
         return new SUPLCoordinate[var1];
      }
   };
   public static final double F2POW23DIV90 = 93206.755556D;
   public static final double F2POW24DIV360 = 46603.377778D;
   public static final int NORTH = 0;
   public static final int SIZE = 12;
   public static final int SOUTH = 1;
   private int Latitude;
   private int Longitude;
   private int iSgnType = 0;

   public SUPLCoordinate(int var1, int var2, int var3) {
      if (var1 <= 1 && var1 >= 0) {
         this.iSgnType = var1;
         this.Latitude = var2;
         this.Longitude = var3;
         if (false) {
            var1 = (int)((long)((double)var2 * 93206.755556D));
            var1 = (int)((long)((double)var3 * 46603.377778D));
         }

      } else {
         throw new IllegalArgumentException("invalid Sign Type");
      }
   }

   public SUPLCoordinate(Parcel var1) {
      this.readFromParcel(var1);
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getCoordinateInfo() {
      byte[] var1 = new byte[12];
      IO.put4(var1, IO.put4(var1, IO.put4(var1, 0, this.iSgnType), this.Latitude), this.Longitude);
      return var1;
   }

   public void readFromParcel(Parcel var1) {
      this.iSgnType = var1.readInt();
      this.Latitude = var1.readInt();
      this.Longitude = var1.readInt();
   }

   public String toString() {
      return "Sg:" + this.iSgnType + "Lat:" + this.Latitude + "Lon:" + this.Longitude;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeInt(this.iSgnType);
      var1.writeInt(this.Latitude);
      var1.writeInt(this.Longitude);
   }
}
