package com.android.supl.si.ganss;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class SuplGanssPOSElem implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SuplGanssPOSElem createFromParcel(Parcel var1) {
         return new SuplGanssPOSElem(var1);
      }

      public SuplGanssPOSElem[] newArray(int var1) {
         return new SuplGanssPOSElem[var1];
      }
   };
   public static final int SUPL_GANSS_ID_GALILEO = 16;
   public static final int SUPL_GANSS_ID_GLONASS = 8;
   public static final int SUPL_GANSS_ID_MODERNGPS = 2;
   public static final int SUPL_GANSS_ID_QZSS = 4;
   public static final int SUPL_GANSS_ID_RESERVED2 = 32;
   public static final int SUPL_GANSS_ID_RESERVED3 = 64;
   public static final int SUPL_GANSS_ID_RESERVED4 = 128;
   public static final int SUPL_GANSS_ID_SBAS = 1;
   public int eGanssId;
   public int ucPosCapBitmap;
   public int ucSBASBitmap;
   public int ucSignalBitmap;

   public SuplGanssPOSElem() {
   }

   public SuplGanssPOSElem(int var1, int var2, int var3, int var4) {
      this.eGanssId = var1;
      this.ucPosCapBitmap = var2;
      this.ucSignalBitmap = var3;
      this.ucSBASBitmap = var4;
   }

   public SuplGanssPOSElem(Parcel var1) {
      this.readFromParcel(var1);
   }

   public static int getPacketSize() {
      return 7;
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getPOSElem() {
      byte[] var1 = new byte[getPacketSize()];
      IO.put1(var1, IO.put1(var1, IO.put1(var1, IO.put4(var1, 0, this.eGanssId), this.ucPosCapBitmap), this.ucSignalBitmap), this.ucSBASBitmap);
      return var1;
   }

   public void readFromParcel(Parcel var1) {
      this.eGanssId = var1.readInt();
      this.ucPosCapBitmap = var1.readInt();
      this.ucSignalBitmap = var1.readInt();
      this.ucSBASBitmap = var1.readInt();
   }

   public String toString() {
      return this.eGanssId + "," + this.ucPosCapBitmap + "," + this.ucSignalBitmap + "," + this.ucSBASBitmap;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeInt(this.eGanssId);
      var1.writeInt(this.ucPosCapBitmap);
      var1.writeInt(this.ucSignalBitmap);
      var1.writeInt(this.ucSBASBitmap);
   }
}
