package com.android.supl.si.ganss;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class SuplGanssDataModel implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SuplGanssDataModel createFromParcel(Parcel var1) {
         return new SuplGanssDataModel(var1);
      }

      public SuplGanssDataModel[] newArray(int var1) {
         return new SuplGanssDataModel[var1];
      }
   };
   public int ucAlmModel;
   public int ucClkModel;
   public int ucOrbModel;
   public int ucUtcModel;

   public SuplGanssDataModel() {
   }

   public SuplGanssDataModel(int var1, int var2, int var3, int var4) {
      this.ucOrbModel = var1;
      this.ucClkModel = var2;
      this.ucAlmModel = var3;
      this.ucUtcModel = var4;
   }

   public SuplGanssDataModel(Parcel var1) {
      this.readFromParcel(var1);
   }

   public static int getPacketSize() {
      return 4;
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getDataModel() {
      byte[] var1 = new byte[getPacketSize()];
      IO.put1(var1, IO.put1(var1, IO.put1(var1, IO.put1(var1, 0, this.ucOrbModel), this.ucClkModel), this.ucAlmModel), this.ucUtcModel);
      return var1;
   }

   public void readFromParcel(Parcel var1) {
      this.ucOrbModel = var1.readInt();
      this.ucClkModel = var1.readInt();
      this.ucAlmModel = var1.readInt();
      this.ucUtcModel = var1.readInt();
   }

   public String toString() {
      return this.ucOrbModel + "," + this.ucClkModel + "," + this.ucAlmModel + "," + this.ucUtcModel;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeInt(this.ucOrbModel);
      var1.writeInt(this.ucClkModel);
      var1.writeInt(this.ucAlmModel);
      var1.writeInt(this.ucUtcModel);
   }
}
