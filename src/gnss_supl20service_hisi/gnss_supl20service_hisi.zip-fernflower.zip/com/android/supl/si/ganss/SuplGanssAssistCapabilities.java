package com.android.supl.si.ganss;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class SuplGanssAssistCapabilities implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SuplGanssAssistCapabilities createFromParcel(Parcel var1) {
         return new SuplGanssAssistCapabilities(var1);
      }

      public SuplGanssAssistCapabilities[] newArray(int var1) {
         return new SuplGanssAssistCapabilities[var1];
      }
   };
   private SuplGanssAsstCapElem[] asstCapElem = null;
   private int ucGanssCnt;
   private int uiAsstCmnCapBitmap;

   public SuplGanssAssistCapabilities(Parcel var1) {
      this.readFromParcel(var1);
   }

   public SuplGanssAssistCapabilities(SuplGanssAsstCapElem[] var1, int var2) {
      if (var1 == null) {
         throw new IllegalArgumentException("SuplGanssAsstCapElement should not be null");
      } else {
         this.ucGanssCnt = var1.length;
         if (this.ucGanssCnt > 8) {
            throw new IllegalArgumentException("Count should not exceed to8");
         } else {
            this.asstCapElem = var1;
            this.uiAsstCmnCapBitmap = var2;
         }
      }
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getAsstCapElem() {
      int var4 = this.ucGanssCnt * SuplGanssAsstCapElem.getPacketSize() + 5;
      byte[] var6 = new byte[var4];
      int var2 = IO.put1(var6, IO.put4(var6, 0, this.uiAsstCmnCapBitmap), this.ucGanssCnt);
      SuplGanssAsstCapElem[] var7 = this.asstCapElem;
      int var3 = var7.length;

      for(int var1 = 0; var1 < var3; ++var1) {
         byte[] var5 = var7[var1].getAsstCapElem();
         System.arraycopy(var5, 0, var6, var2, var5.length);
         var2 += var5.length;
      }

      if (var4 != var2) {
         System.err.println("getAsstCapElem size invalid");
      }

      return var6;
   }

   public void readFromParcel(Parcel var1) {
      int var3 = 0;
      this.uiAsstCmnCapBitmap = var1.readInt();
      this.ucGanssCnt = var1.readInt();
      if (this.ucGanssCnt > 0) {
         Parcelable[] var5 = var1.readParcelableArray(SuplGanssPOSElem.class.getClassLoader());
         this.asstCapElem = new SuplGanssAsstCapElem[var5.length];
         int var4 = var5.length;

         for(int var2 = 0; var3 < var4; ++var2) {
            Parcelable var6 = var5[var3];
            this.asstCapElem[var2] = (SuplGanssAsstCapElem)var6;
            ++var3;
         }
      }

   }

   public String toString() {
      StringBuffer var3 = new StringBuffer();
      var3.append(this.uiAsstCmnCapBitmap).append(",");
      SuplGanssAsstCapElem[] var4 = this.asstCapElem;
      int var1 = 0;

      for(int var2 = var4.length; var1 < var2; ++var1) {
         var3.append(var4[var1].toString());
         var3.append(",");
      }

      var3.deleteCharAt(var3.length() - 1);
      return var3.toString();
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeInt(this.uiAsstCmnCapBitmap);
      var1.writeInt(this.ucGanssCnt);
      if (this.ucGanssCnt > 0) {
         var1.writeParcelableArray(this.asstCapElem, var2);
      }

   }
}
