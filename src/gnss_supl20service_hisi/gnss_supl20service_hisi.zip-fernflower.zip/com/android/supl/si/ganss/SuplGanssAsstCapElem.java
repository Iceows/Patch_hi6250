package com.android.supl.si.ganss;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class SuplGanssAsstCapElem implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SuplGanssAsstCapElem createFromParcel(Parcel var1) {
         return new SuplGanssAsstCapElem(var1);
      }

      public SuplGanssAsstCapElem[] newArray(int var1) {
         return new SuplGanssAsstCapElem[var1];
      }
   };
   public int eGanssId;
   public SuplGanssDataModel ganssDataModels = null;
   public int uiAsstCapBitmap;

   public SuplGanssAsstCapElem() {
   }

   public SuplGanssAsstCapElem(int var1, int var2, SuplGanssDataModel var3) {
      this.eGanssId = var1;
      this.uiAsstCapBitmap = var2;
      if (var3 == null) {
         throw new IllegalArgumentException("SuplGanssDataModel should not be null");
      } else {
         this.ganssDataModels = var3;
      }
   }

   public SuplGanssAsstCapElem(Parcel var1) {
      this.readFromParcel(var1);
   }

   public static int getPacketSize() {
      return SuplGanssDataModel.getPacketSize() + 8;
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getAsstCapElem() {
      int var1 = getPacketSize();
      byte[] var3 = new byte[var1];
      int var2 = IO.put4(var3, IO.put4(var3, 0, this.eGanssId), this.uiAsstCapBitmap);
      byte[] var4 = this.ganssDataModels.getDataModel();
      System.arraycopy(var4, 0, var3, var2, var4.length);
      if (var1 != var2 + var4.length) {
         System.err.println("getAsstCapElem size invalid");
      }

      return var3;
   }

   public void readFromParcel(Parcel var1) {
      this.eGanssId = var1.readInt();
      this.uiAsstCapBitmap = var1.readInt();
      this.ganssDataModels = (SuplGanssDataModel)var1.readParcelable(SuplGanssDataModel.class.getClassLoader());
   }

   public String toString() {
      return this.eGanssId + "," + this.uiAsstCapBitmap + "," + this.ganssDataModels;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeInt(this.eGanssId);
      var1.writeInt(this.uiAsstCapBitmap);
      var1.writeParcelable(this.ganssDataModels, var2);
   }
}
