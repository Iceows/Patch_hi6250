package com.android.supl.si.ganss;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class SuplGanssPOSCapabilities implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SuplGanssPOSCapabilities createFromParcel(Parcel var1) {
         return new SuplGanssPOSCapabilities(var1);
      }

      public SuplGanssPOSCapabilities[] newArray(int var1) {
         return new SuplGanssPOSCapabilities[var1];
      }
   };
   public static final int SUPL_GANSS_TYPE_MAX_CNT = 8;
   SuplGanssPOSElem[] elem = null;
   private int ucGanssCnt;

   public SuplGanssPOSCapabilities(Parcel var1) {
      this.readFromParcel(var1);
   }

   public SuplGanssPOSCapabilities(SuplGanssPOSElem[] var1) {
      if (var1 == null) {
         throw new IllegalArgumentException("SuplGanssPOSElement should not be null");
      } else {
         this.ucGanssCnt = var1.length;
         if (this.ucGanssCnt > 8) {
            throw new IllegalArgumentException("Count should not exceed to8");
         } else {
            this.elem = var1;
         }
      }
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getPOSCapabilities() {
      int var3 = this.ucGanssCnt * SuplGanssPOSElem.getPacketSize() + 1;
      byte[] var7 = new byte[var3];
      int var2 = IO.put1(var7, 0, this.ucGanssCnt);
      SuplGanssPOSElem[] var6 = this.elem;
      int var4 = var6.length;

      for(int var1 = 0; var1 < var4; ++var1) {
         byte[] var5 = var6[var1].getPOSElem();
         System.arraycopy(var5, 0, var7, var2, var5.length);
         var2 += var5.length;
      }

      if (var3 != var2) {
         System.err.println("getPOSCapabilities size invalid");
      }

      return var7;
   }

   public void readFromParcel(Parcel var1) {
      int var2 = 0;
      this.ucGanssCnt = var1.readInt();
      if (this.ucGanssCnt > 0) {
         Parcelable[] var6 = var1.readParcelableArray(SuplGanssPOSElem.class.getClassLoader());
         this.elem = new SuplGanssPOSElem[var6.length];
         int var4 = var6.length;

         for(int var3 = 0; var2 < var4; ++var3) {
            Parcelable var5 = var6[var2];
            this.elem[var3] = (SuplGanssPOSElem)var5;
            ++var2;
         }
      }

   }

   public String toString() {
      StringBuffer var3 = new StringBuffer();
      var3.append(this.ucGanssCnt).append(",");
      SuplGanssPOSElem[] var4 = this.elem;
      int var1 = 0;

      for(int var2 = var4.length; var1 < var2; ++var1) {
         var3.append(var4[var1].toString());
         var3.append(",");
      }

      var3.deleteCharAt(var3.length() - 1);
      return var3.toString();
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeInt(this.ucGanssCnt);
      if (this.ucGanssCnt > 0) {
         var1.writeParcelableArray(this.elem, var2);
      }

   }
}
