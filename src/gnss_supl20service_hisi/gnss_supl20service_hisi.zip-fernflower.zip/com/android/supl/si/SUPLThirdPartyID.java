package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class SUPLThirdPartyID implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SUPLThirdPartyID createFromParcel(Parcel var1) {
         return new SUPLThirdPartyID(var1);
      }

      public SUPLThirdPartyID[] newArray(int var1) {
         return new SUPLThirdPartyID[var1];
      }
   };
   public static final int SUPL_EMAILID = 2;
   public static final int SUPL_IMS_PUB_I = 4;
   public static final int SUPL_LOGICAL_NAME = 0;
   public static final int SUPL_MDN = 6;
   public static final int SUPL_MIN = 5;
   public static final int SUPL_MSISDN = 1;
   public static final int SUPL_SIP_URI = 3;
   public static final int SUPL_URI = 7;
   private int m_enIdType;
   private short ubBitsUsed;
   public byte[] ucIDBuff = null;
   private short ucSize;

   public SUPLThirdPartyID(int var1, String var2, short var3) {
      this.m_enIdType = var1;
      if (var1 <= 7 && var1 >= 0) {
         if (var2 == null) {
            throw new IllegalArgumentException("ThirdPartyID should not be null");
         } else {
            this.ucIDBuff = var2.getBytes();
            this.ucSize = (short)this.ucIDBuff.length;
            this.ubBitsUsed = (short)(this.ucSize * 8);
         }
      } else {
         throw new IllegalArgumentException("ThirdPartyID type invalid");
      }
   }

   public SUPLThirdPartyID(Parcel var1) {
      this.readFromParcel(var1);
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getThirdPartyID() {
      int var1 = this.ucSize + 6;
      byte[] var3 = new byte[var1];
      int var2 = IO.put1(var3, IO.put1(var3, IO.put4(var3, 0, this.m_enIdType), this.ucSize), this.ubBitsUsed);
      System.arraycopy(this.ucIDBuff, 0, var3, var2, this.ucSize);
      if (var2 + this.ucSize != var1) {
         System.err.println("ThirdPartyID length invalid");
      }

      return var3;
   }

   public void readFromParcel(Parcel var1) {
      this.m_enIdType = var1.readInt();
      this.ucSize = (short)var1.readInt();
      this.ubBitsUsed = (short)var1.readInt();
      this.ucIDBuff = new byte[this.ucSize];
      var1.readByteArray(this.ucIDBuff);
   }

   public String toString() {
      return this.m_enIdType + "," + new String(this.ucIDBuff);
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeInt(this.m_enIdType);
      var1.writeInt(this.ucSize);
      var1.writeInt(this.ubBitsUsed);
      var1.writeByteArray(this.ucIDBuff);
   }
}
