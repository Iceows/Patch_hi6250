package com.android.supl.si;

import com.android.bytewriter.IO;

public class SetTestAreaIDParams {
   public static final int MSG_PCM_SET_TEST_AREA_ID = 284;
   public int nSetHomeAreaIDToBeSet = 0;

   public SetTestAreaIDParams(int var1) {
      this.nSetHomeAreaIDToBeSet = var1;
   }

   public byte[] getSetTestAreaIDInfo() {
      byte[] var1 = new byte[10];
      if (IO.put2(var1, IO.put4(var1, IO.put4(var1, 0, 6), 284), this.nSetHomeAreaIDToBeSet) - 4 != 6) {
         System.err.println("invalid length in  getSetTestAreaIDInfo");
      }

      return var1;
   }
}
