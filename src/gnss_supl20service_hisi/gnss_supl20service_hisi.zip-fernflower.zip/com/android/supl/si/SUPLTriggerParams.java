package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class SUPLTriggerParams implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SUPLTriggerParams createFromParcel(Parcel var1) {
         return new SUPLTriggerParams(var1);
      }

      public SUPLTriggerParams[] newArray(int var1) {
         return new SUPLTriggerParams[var1];
      }
   };
   public static final int SUPL_TRIGGERTYPE_EVENT = 1;
   public static final int SUPL_TRIGGERTYPE_PERIODIC = 0;
   private int eTriggerReqType;
   private Object objTriggerParam = null;

   public SUPLTriggerParams(int var1, Object var2) {
      if (var2 == null) {
         throw new IllegalArgumentException("TriggerParamater object should not be null");
      } else {
         switch(var1) {
         case 0:
            this.eTriggerReqType = 0;
            if (!(var2 instanceof SUPLPeriodicParams)) {
               throw new IllegalArgumentException("TriggerParamater object is not a SUPLPeriodicParams type");
            }
            break;
         case 1:
            this.eTriggerReqType = 1;
            if (!(var2 instanceof SUPLEventTriggerParams)) {
               throw new IllegalArgumentException("TriggerParamater object is not a SUPLEventTriggerParams type");
            }
            break;
         default:
            throw new IllegalArgumentException("Trigger parameter value invalid");
         }

         this.objTriggerParam = var2;
      }
   }

   public SUPLTriggerParams(Parcel var1) {
      this.readFromParcel(var1);
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getTriggerParam() {
      int var2 = 0;
      int var1 = 4;
      byte[] var3 = null;
      switch(this.eTriggerReqType) {
      case 0:
         var3 = ((SUPLPeriodicParams)this.objTriggerParam).getPeriodicParams();
         break;
      case 1:
         var3 = ((SUPLEventTriggerParams)this.objTriggerParam).getEventTriggerParams();
      }

      byte[] var4 = null;
      if (var3 != null) {
         var1 = var3.length + 4;
         var4 = new byte[var1];
         var2 = IO.put4(var4, 0, this.eTriggerReqType);
         System.arraycopy(var3, 0, var4, var2, var3.length);
         var2 += var3.length;
      }

      if (var2 != var1) {
         System.err.println("TriggerParam length invalid");
      }

      return var4;
   }

   public int getTriggerReqType() {
      return this.eTriggerReqType;
   }

   public void readFromParcel(Parcel var1) {
      this.eTriggerReqType = var1.readInt();
      switch(this.eTriggerReqType) {
      case 0:
         this.objTriggerParam = var1.readParcelable(SUPLPeriodicParams.class.getClassLoader());
         break;
      case 1:
         this.objTriggerParam = var1.readParcelable(SUPLEventTriggerParams.class.getClassLoader());
      }

   }

   public String toString() {
      String var1 = null;
      switch(this.eTriggerReqType) {
      case 0:
         var1 = ((SUPLPeriodicParams)this.objTriggerParam).toString();
         break;
      case 1:
         var1 = ((SUPLEventTriggerParams)this.objTriggerParam).toString();
      }

      return this.eTriggerReqType + "," + var1;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeInt(this.eTriggerReqType);
      switch(this.eTriggerReqType) {
      case 0:
         var1.writeParcelable((SUPLPeriodicParams)this.objTriggerParam, var2);
         break;
      case 1:
         var1.writeParcelable((SUPLEventTriggerParams)this.objTriggerParam, var2);
      }

   }
}
