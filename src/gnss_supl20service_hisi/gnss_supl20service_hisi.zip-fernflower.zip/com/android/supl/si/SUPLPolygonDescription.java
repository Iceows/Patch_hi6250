package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class SUPLPolygonDescription implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SUPLPolygonDescription createFromParcel(Parcel var1) {
         return new SUPLPolygonDescription(var1);
      }

      public SUPLPolygonDescription[] newArray(int var1) {
         return new SUPLPolygonDescription[var1];
      }
   };
   private int nValidCoordinates;
   private SUPLCoordinate[] stCoordinate = null;

   public SUPLPolygonDescription(int var1, SUPLCoordinate[] var2) {
      this.nValidCoordinates = var1;
      if (var1 > 0 && var2 == null) {
         throw new IllegalArgumentException("Coordinate value should not be null");
      } else {
         this.stCoordinate = var2;
      }
   }

   public SUPLPolygonDescription(Parcel var1) {
      this.readFromParcel(var1);
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getPolygonDescription() {
      int var5 = this.nValidCoordinates * 12 + 4;
      byte[] var8 = new byte[var5];
      int var1 = IO.put4(var8, 0, this.nValidCoordinates);
      int var3 = var1;
      if (this.nValidCoordinates > 0) {
         SUPLCoordinate[] var6 = this.stCoordinate;
         int var4 = var6.length;
         int var2 = 0;

         while(true) {
            var3 = var1;
            if (var2 >= var4) {
               break;
            }

            byte[] var7 = var6[var2].getCoordinateInfo();
            System.arraycopy(var7, 0, var8, var1, var7.length);
            var1 += var7.length;
            ++var2;
         }
      }

      if (var3 != var5) {
         System.err.println("PolygonDescription length invalid");
      }

      return var8;
   }

   public void readFromParcel(Parcel var1) {
      int var3 = 0;
      this.nValidCoordinates = var1.readInt();
      if (this.nValidCoordinates > 0) {
         Parcelable[] var6 = var1.readParcelableArray(SUPLCoordinate.class.getClassLoader());
         this.stCoordinate = new SUPLCoordinate[var6.length];
         int var4 = var6.length;

         for(int var2 = 0; var3 < var4; ++var2) {
            Parcelable var5 = var6[var3];
            this.stCoordinate[var2] = (SUPLCoordinate)var5;
            ++var3;
         }
      }

   }

   public String toString() {
      int var1 = 0;
      StringBuffer var3 = new StringBuffer();
      if (this.nValidCoordinates > 0) {
         var3.append(this.nValidCoordinates);
         var3.append(",");
         SUPLCoordinate[] var4 = this.stCoordinate;

         for(int var2 = var4.length; var1 < var2; ++var1) {
            var3.append(var4[var1].toString());
            var3.append(",");
         }
      }

      return var3.toString();
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeInt(this.nValidCoordinates);
      if (this.nValidCoordinates > 0) {
         var1.writeParcelableArray(this.stCoordinate, var2);
      }

   }
}
