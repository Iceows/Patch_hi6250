package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class SUPLEllipticalArea implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SUPLEllipticalArea createFromParcel(Parcel var1) {
         return new SUPLEllipticalArea(var1);
      }

      public SUPLEllipticalArea[] newArray(int var1) {
         return new SUPLEllipticalArea[var1];
      }
   };
   public int nAngle;
   public int nSemiMajor;
   public int nSemiMajorMax;
   public int nSemiMajorMin;
   public int nSemiMinor;
   public int nSemiMinorMax;
   public int nSemiMinorMin;
   public SUPLCoordinate stCenterCoord = null;

   public SUPLEllipticalArea(int var1, int var2, int var3, int var4, int var5) {
      this.nSemiMajorMin = var1;
      this.nSemiMajorMax = var2;
      this.nSemiMinorMin = var3;
      this.nSemiMinorMax = var4;
      this.nAngle = var5;
   }

   public SUPLEllipticalArea(Parcel var1) {
      this.readFromParcel(var1);
   }

   public SUPLEllipticalArea(SUPLCoordinate var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      if (var1 == null) {
         throw new IllegalArgumentException("Coordinate should not be null");
      } else {
         this.stCenterCoord = var1;
         this.nSemiMajor = var2;
         this.nSemiMajorMin = var3;
         this.nSemiMajorMax = var4;
         this.nSemiMinor = var5;
         this.nSemiMinorMin = var6;
         this.nSemiMinorMax = var7;
         this.nAngle = var8;
      }
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getEllipticalAreaInfo() {
      byte[] var2 = this.stCenterCoord.getCoordinateInfo();
      int var1 = var2.length + 28;
      byte[] var3 = new byte[var1];
      System.arraycopy(var2, 0, var3, 0, var2.length);
      if (IO.put4(var3, IO.put4(var3, IO.put4(var3, IO.put4(var3, IO.put4(var3, IO.put4(var3, IO.put4(var3, var2.length + 0, this.nSemiMajor), this.nSemiMajorMin), this.nSemiMajorMax), this.nSemiMinor), this.nSemiMinorMin), this.nSemiMinorMax), this.nAngle) != var1) {
         System.err.println("EllipticalArea length invalid");
      }

      return var3;
   }

   public void readFromParcel(Parcel var1) {
      this.stCenterCoord = (SUPLCoordinate)var1.readParcelable(SUPLCoordinate.class.getClassLoader());
      this.nSemiMajor = var1.readInt();
      this.nSemiMajorMin = var1.readInt();
      this.nSemiMajorMax = var1.readInt();
      this.nSemiMinor = var1.readInt();
      this.nSemiMinorMin = var1.readInt();
      this.nSemiMinorMax = var1.readInt();
      this.nAngle = var1.readInt();
   }

   public void setCenterCoordinate(SUPLCoordinate var1) {
      this.stCenterCoord = var1;
   }

   public void setSemiMajor(int var1) {
      this.nSemiMajor = var1;
   }

   public void setSemiMinor(int var1) {
      this.nSemiMinor = var1;
   }

   public String toString() {
      return this.stCenterCoord.toString() + "," + this.nSemiMajor + "," + this.nSemiMajorMin + "," + this.nSemiMajorMax + "," + this.nSemiMinor + "," + this.nSemiMinorMin + "," + this.nSemiMinorMax;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeParcelable(this.stCenterCoord, var2);
      var1.writeInt(this.nSemiMajor);
      var1.writeInt(this.nSemiMajorMin);
      var1.writeInt(this.nSemiMajorMax);
      var1.writeInt(this.nSemiMinor);
      var1.writeInt(this.nSemiMinorMin);
      var1.writeInt(this.nSemiMinorMax);
      var1.writeInt(this.nAngle);
   }
}
