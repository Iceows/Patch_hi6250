package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class SUPLEventTriggerParams implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SUPLEventTriggerParams createFromParcel(Parcel var1) {
         return new SUPLEventTriggerParams(var1);
      }

      public SUPLEventTriggerParams[] newArray(int var1) {
         return new SUPLEventTriggerParams[var1];
      }
   };
   private boolean bRepeatedReportingPresent;
   private long dwStartTime = 0L;
   private long dwStopTime = 8639999L;
   private long dwValidcount;
   private SUPLAreaEventType eAreaEventType = null;
   private SUPLGeoTargetArea[] stGeoTargetArea = null;
   private SUPLRepeatedReportingParams stRepeatedReportingParams = null;

   public SUPLEventTriggerParams(Parcel var1) {
      this.readFromParcel(var1);
   }

   public SUPLEventTriggerParams(boolean var1, SUPLAreaEventType var2, SUPLRepeatedReportingParams var3, long var4, long var6, long var8, SUPLGeoTargetArea[] var10) {
      this.bRepeatedReportingPresent = var1;
      if (var1 && var3 == null) {
         throw new IllegalArgumentException("Repeated Reporting Parameter shold not be null");
      } else {
         this.eAreaEventType = var2;
         this.stRepeatedReportingParams = var3;
         this.dwStartTime = var4;
         if (var6 != 0L) {
            this.dwStopTime = var6;
         }

         if (var10 == null) {
            throw new IllegalArgumentException("GeoTargetArea shold not be null");
         } else {
            this.stGeoTargetArea = var10;
            this.dwValidcount = (long)var10.length;
         }
      }
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getEventTriggerParams() {
      byte[] var7 = this.eAreaEventType.getAreaEventType();
      int var2 = var7.length + 16;
      byte[] var6 = null;
      int var1 = var2;
      if (this.bRepeatedReportingPresent) {
         var6 = this.stRepeatedReportingParams.getRepeatedReportingParamsInfo();
         var1 = var2 + var6.length;
      }

      SUPLGeoTargetArea[] var9 = this.stGeoTargetArea;
      int var4 = var9.length;

      int var3;
      byte[] var8;
      for(var2 = 0; var2 < var4; var1 = var3) {
         var8 = var9[var2].getGeoTargetArea();
         var3 = var1;
         if (var8 != null) {
            var3 = var1 + var8.length;
         }

         ++var2;
      }

      var8 = new byte[var1];
      byte var10;
      if (this.bRepeatedReportingPresent) {
         var10 = 1;
      } else {
         var10 = 0;
      }

      var2 = IO.put4(var8, 0, var10);
      System.arraycopy(var7, 0, var8, var2, var7.length);
      var3 = var2 + var7.length;
      var2 = var3;
      if (this.bRepeatedReportingPresent) {
         System.arraycopy(var6, 0, var8, var3, var6.length);
         var2 = var3 + var6.length;
      }

      var3 = IO.put4(var8, IO.put4(var8, IO.put4(var8, var2, (int)this.dwStartTime), (int)this.dwStopTime), (int)this.dwValidcount);
      SUPLGeoTargetArea[] var11 = this.stGeoTargetArea;
      int var5 = var11.length;

      for(var2 = 0; var2 < var5; var3 = var4) {
         var6 = var11[var2].getGeoTargetArea();
         var4 = var3;
         if (var6 != null) {
            System.arraycopy(var6, 0, var8, var3, var6.length);
            var4 = var3 + var6.length;
         }

         ++var2;
      }

      if (var3 != var1) {
         System.err.println("EventTriggerParams length invalid");
      }

      return var8;
   }

   public void readFromParcel(Parcel var1) {
      byte var2 = var1.readByte();
      this.bRepeatedReportingPresent = false;
      if (var2 == 1) {
         this.bRepeatedReportingPresent = true;
      }

      this.eAreaEventType = (SUPLAreaEventType)var1.readParcelable(SUPLAreaEventType.class.getClassLoader());
      if (this.bRepeatedReportingPresent) {
         this.stRepeatedReportingParams = (SUPLRepeatedReportingParams)var1.readParcelable(SUPLRepeatedReportingParams.class.getClassLoader());
      }

      this.dwStartTime = var1.readLong();
      this.dwStopTime = var1.readLong();
      this.dwValidcount = var1.readLong();
      Parcelable[] var6 = var1.readParcelableArray(SUPLGeoTargetArea.class.getClassLoader());
      this.stGeoTargetArea = new SUPLGeoTargetArea[var6.length];
      int var4 = var6.length;
      int var3 = 0;

      for(int var7 = 0; var3 < var4; ++var7) {
         Parcelable var5 = var6[var3];
         this.stGeoTargetArea[var7] = (SUPLGeoTargetArea)var5;
         ++var3;
      }

   }

   public String toString() {
      StringBuffer var1 = new StringBuffer();
      var1.append("AE:");
      var1.append(this.eAreaEventType.toString());
      if (this.bRepeatedReportingPresent) {
         var1.append("Rp:");
         var1.append(this.stRepeatedReportingParams.toString());
      }

      var1.append(this.dwStartTime);
      var1.append(",");
      var1.append(this.dwStopTime);
      var1.append(",");
      var1.append(this.dwValidcount);
      var1.append(",");
      var1.append("GTA");
      var1.append(this.stGeoTargetArea.toString());
      return var1.toString();
   }

   public void writeToParcel(Parcel var1, int var2) {
      byte var3;
      if (this.bRepeatedReportingPresent) {
         var3 = 1;
      } else {
         var3 = 0;
      }

      var1.writeByte(var3);
      var1.writeParcelable(this.eAreaEventType, var2);
      if (this.bRepeatedReportingPresent) {
         var1.writeParcelable(this.stRepeatedReportingParams, var2);
      }

      var1.writeLong(this.dwStartTime);
      var1.writeLong(this.dwStopTime);
      var1.writeLong(this.dwValidcount);
      var1.writeParcelableArray(this.stGeoTargetArea, var2);
   }
}
