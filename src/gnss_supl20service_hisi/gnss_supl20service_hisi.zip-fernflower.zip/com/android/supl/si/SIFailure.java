package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.io.DataInputStream;
import java.io.IOException;

public class SIFailure implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SIFailure createFromParcel(Parcel var1) {
         return new SIFailure(var1);
      }

      public SIFailure[] newArray(int var1) {
         return new SIFailure[var1];
      }
   };
   public int m_enErrorCode;
   public int m_usPlatformSessionId;

   public SIFailure() {
   }

   public SIFailure(Parcel var1) {
      this.readFromParcel(var1);
   }

   public int describeContents() {
      return 0;
   }

   public void readFromParcel(Parcel var1) {
      this.m_usPlatformSessionId = var1.readInt();
      this.m_enErrorCode = var1.readInt();
   }

   public boolean readSIFailure(DataInputStream var1) throws IOException {
      this.m_usPlatformSessionId = var1.readUnsignedShort();
      this.m_enErrorCode = var1.readInt();
      return true;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeInt(this.m_usPlatformSessionId);
      var1.writeInt(this.m_enErrorCode);
   }
}
