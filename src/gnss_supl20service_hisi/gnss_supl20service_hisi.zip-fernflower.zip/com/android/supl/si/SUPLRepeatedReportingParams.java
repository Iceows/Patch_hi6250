package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class SUPLRepeatedReportingParams implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SUPLRepeatedReportingParams createFromParcel(Parcel var1) {
         return new SUPLRepeatedReportingParams(var1);
      }

      public SUPLRepeatedReportingParams[] newArray(int var1) {
         return new SUPLRepeatedReportingParams[var1];
      }
   };
   private boolean bEnableRepeatedReporting;
   private long dwMaximumNumberOfReports = 0L;
   private long dwMinimumIntervalTime = 0L;

   public SUPLRepeatedReportingParams(Parcel var1) {
      this.readFromParcel(var1);
   }

   public SUPLRepeatedReportingParams(boolean var1, long var2, long var4) {
      this.bEnableRepeatedReporting = var1;
      this.dwMinimumIntervalTime = var2;
      this.dwMaximumNumberOfReports = var4;
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getRepeatedReportingParamsInfo() {
      byte[] var2 = new byte[12];
      byte var1;
      if (this.bEnableRepeatedReporting) {
         var1 = 1;
      } else {
         var1 = 0;
      }

      IO.put4(var2, IO.put4(var2, IO.put4(var2, 0, var1), (int)this.dwMinimumIntervalTime), (int)this.dwMaximumNumberOfReports);
      return var2;
   }

   public void readFromParcel(Parcel var1) {
      byte var2 = var1.readByte();
      this.bEnableRepeatedReporting = false;
      if (var2 == 1) {
         this.bEnableRepeatedReporting = true;
      }

      this.dwMinimumIntervalTime = var1.readLong();
      this.dwMaximumNumberOfReports = var1.readLong();
   }

   public String toString() {
      return this.bEnableRepeatedReporting + "," + this.dwMinimumIntervalTime + "," + this.dwMaximumNumberOfReports;
   }

   public void writeToParcel(Parcel var1, int var2) {
      byte var3;
      if (this.bEnableRepeatedReporting) {
         var3 = 1;
      } else {
         var3 = 0;
      }

      var1.writeByte(var3);
      var1.writeLong(this.dwMinimumIntervalTime);
      var1.writeLong(this.dwMaximumNumberOfReports);
   }
}
