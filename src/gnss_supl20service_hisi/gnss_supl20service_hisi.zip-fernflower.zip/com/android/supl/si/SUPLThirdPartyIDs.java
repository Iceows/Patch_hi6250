package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class SUPLThirdPartyIDs implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SUPLThirdPartyIDs createFromParcel(Parcel var1) {
         return new SUPLThirdPartyIDs(var1);
      }

      public SUPLThirdPartyIDs[] newArray(int var1) {
         return new SUPLThirdPartyIDs[var1];
      }
   };
   private SUPLThirdPartyID[] mSuplThirdPartyID = null;
   private short ucValidCount;

   public SUPLThirdPartyIDs(Parcel var1) {
      this.readFromParcel(var1);
   }

   public SUPLThirdPartyIDs(short var1, SUPLThirdPartyID[] var2) {
      this.ucValidCount = var1;
      if (var1 > 0 && var2 == null) {
         throw new IllegalArgumentException("ThirdPartyID array should not be null");
      } else {
         this.mSuplThirdPartyID = var2;
      }
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getSUPLThirdPartyIDs() {
      int var2 = 1;
      int var1 = 1;
      int var3;
      int var4;
      if (this.ucValidCount > 0) {
         SUPLThirdPartyID[] var6 = this.mSuplThirdPartyID;
         var4 = var6.length;
         var3 = 0;

         while(true) {
            var2 = var1;
            if (var3 >= var4) {
               break;
            }

            var1 += var6[var3].getThirdPartyID().length;
            ++var3;
         }
      }

      byte[] var9 = new byte[var2];
      var1 = IO.put1(var9, 0, this.ucValidCount);
      var4 = var1;
      if (this.ucValidCount > 0) {
         SUPLThirdPartyID[] var8 = this.mSuplThirdPartyID;
         int var5 = var8.length;
         var3 = 0;

         while(true) {
            var4 = var1;
            if (var3 >= var5) {
               break;
            }

            byte[] var7 = var8[var3].getThirdPartyID();
            System.arraycopy(var7, 0, var9, var1, var7.length);
            var1 += var7.length;
            ++var3;
         }
      }

      if (var4 != var2) {
         System.err.println("ThirdPartyIDs  length invalid");
      }

      return var9;
   }

   public short getValidCount() {
      return this.ucValidCount;
   }

   public void readFromParcel(Parcel var1) {
      int var3 = 0;
      this.ucValidCount = (short)var1.readInt();
      if (this.ucValidCount > 0) {
         Parcelable[] var5 = var1.readParcelableArray(SUPLThirdPartyID.class.getClassLoader());
         this.mSuplThirdPartyID = new SUPLThirdPartyID[var5.length];
         int var4 = var5.length;

         for(int var2 = 0; var3 < var4; ++var2) {
            Parcelable var6 = var5[var3];
            this.mSuplThirdPartyID[var2] = (SUPLThirdPartyID)var6;
            ++var3;
         }
      }

   }

   public String toString() {
      int var1 = 0;
      StringBuffer var3 = new StringBuffer();
      var3.append(this.ucValidCount);
      if (this.ucValidCount > 0) {
         SUPLThirdPartyID[] var4 = this.mSuplThirdPartyID;

         for(int var2 = var4.length; var1 < var2; ++var1) {
            SUPLThirdPartyID var5 = var4[var1];
            var3.append(",");
            var3.append(var5.toString());
         }
      }

      return var3.toString();
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeInt(this.ucValidCount);
      if (this.ucValidCount > 0) {
         var1.writeParcelableArray(this.mSuplThirdPartyID, var2);
      }

   }
}
