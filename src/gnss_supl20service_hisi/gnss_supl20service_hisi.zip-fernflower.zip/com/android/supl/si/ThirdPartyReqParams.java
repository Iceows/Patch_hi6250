package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class ThirdPartyReqParams implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public ThirdPartyReqParams createFromParcel(Parcel var1) {
         return new ThirdPartyReqParams(var1);
      }

      public ThirdPartyReqParams[] newArray(int var1) {
         return new ThirdPartyReqParams[var1];
      }
   };
   public static final int MSG_PCM_START_SI_OTHER_SET = 270;
   private boolean m_bIsAppIdPresent;
   private boolean m_bIsQOPPresent;
   private ApplicationID m_stAppId = null;
   private SUPLQOPParams m_stQop = null;
   private SUPLSETID m_stTargetSetId = null;
   private short m_usPlatformSessionId;

   public ThirdPartyReqParams(Parcel var1) {
      this.readFromParcel(var1);
   }

   public ThirdPartyReqParams(boolean var1, SUPLQOPParams var2, boolean var3, ApplicationID var4, SUPLSETID var5) {
      this.m_usPlatformSessionId = -1;
      this.m_bIsQOPPresent = var1;
      if (var1 && var2 == null) {
         throw new IllegalArgumentException("QOP paramerter should not be null");
      } else {
         this.m_stQop = var2;
         this.m_bIsAppIdPresent = var3;
         if (var3 && var4 == null) {
            throw new IllegalArgumentException("ApplicationID  should not be null");
         } else {
            this.m_stAppId = var4;
            if (var5 == null) {
               throw new IllegalArgumentException("Target SETID  should not be null");
            } else {
               this.m_stTargetSetId = var5;
            }
         }
      }
   }

   public int describeContents() {
      return 0;
   }

   public ApplicationID getAppId() {
      return this.m_stAppId;
   }

   public byte[] getSIOnOtherSET() {
      int var1 = 14;
      byte[] var4 = null;
      if (this.m_bIsQOPPresent) {
         var4 = this.m_stQop.getQOPParams();
         var1 = var4.length + 14;
      }

      byte[] var5 = null;
      int var2 = var1;
      if (this.m_bIsAppIdPresent) {
         var5 = this.m_stAppId.getApplicationIDInfo();
         var2 = var1 + var5.length;
      }

      byte[] var7 = this.m_stTargetSetId.getSETID();
      var2 += var7.length;
      byte[] var6 = new byte[var2 + 4];
      var1 = IO.put2(var6, IO.put4(var6, 4, 270), this.m_usPlatformSessionId);
      if (this.m_bIsQOPPresent) {
         var1 = IO.put4(var6, var1, 1);
         System.arraycopy(var4, 0, var6, var1, var4.length);
         var1 += var4.length;
      } else {
         var1 = IO.put4(var6, var1, 0);
      }

      if (this.m_bIsAppIdPresent) {
         var1 = IO.put4(var6, var1, 1);
         System.arraycopy(var5, 0, var6, var1, var5.length);
         var1 += var5.length;
      } else {
         var1 = IO.put4(var6, var1, 0);
      }

      System.arraycopy(var7, 0, var6, var1, var7.length);
      int var3 = var7.length;
      IO.put4(var6, 0, var2);
      if (var1 + var3 - 4 != var2) {
         System.err.println("SIOnOtherSET length invalid");
      }

      return var6;
   }

   public void readFromParcel(Parcel var1) {
      this.m_usPlatformSessionId = (short)var1.readInt();
      this.m_bIsQOPPresent = false;
      if (var1.readByte() == 1) {
         this.m_bIsQOPPresent = true;
         this.m_stQop = (SUPLQOPParams)var1.readParcelable(SUPLQOPParams.class.getClassLoader());
      }

      this.m_bIsAppIdPresent = false;
      if (var1.readByte() == 1) {
         this.m_bIsAppIdPresent = true;
         this.m_stAppId = (ApplicationID)var1.readParcelable(ApplicationID.class.getClassLoader());
      }

      this.m_stTargetSetId = (SUPLSETID)var1.readParcelable(SUPLSETID.class.getClassLoader());
   }

   public void setPlatformSessionId(short var1) {
      this.m_usPlatformSessionId = var1;
   }

   public String toString() {
      StringBuffer var1 = new StringBuffer();
      var1.append("SID:");
      var1.append(this.m_usPlatformSessionId);
      if (this.m_bIsQOPPresent) {
         var1.append("QOP:");
         var1.append(this.m_stQop.toString());
      }

      if (this.m_bIsAppIdPresent) {
         var1.append("AppID:");
         var1.append(this.m_stAppId.toString());
      }

      var1.append("TargetSetID:" + this.m_stTargetSetId.toString());
      return var1.toString();
   }

   public void writeToParcel(Parcel var1, int var2) {
      byte var4 = 1;
      var1.writeInt(this.m_usPlatformSessionId);
      byte var3;
      if (this.m_bIsQOPPresent) {
         var3 = 1;
      } else {
         var3 = 0;
      }

      var1.writeByte(var3);
      if (this.m_bIsQOPPresent) {
         var1.writeParcelable(this.m_stQop, var2);
      }

      if (this.m_bIsAppIdPresent) {
         var3 = var4;
      } else {
         var3 = 0;
      }

      var1.writeByte(var3);
      if (this.m_bIsAppIdPresent) {
         var1.writeParcelable(this.m_stAppId, var2);
      }

      var1.writeParcelable(this.m_stTargetSetId, var2);
   }
}
