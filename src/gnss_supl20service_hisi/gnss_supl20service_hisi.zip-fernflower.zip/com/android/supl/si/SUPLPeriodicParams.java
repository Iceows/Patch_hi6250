package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class SUPLPeriodicParams implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SUPLPeriodicParams createFromParcel(Parcel var1) {
         return new SUPLPeriodicParams(var1);
      }

      public SUPLPeriodicParams[] newArray(int var1) {
         return new SUPLPeriodicParams[var1];
      }
   };
   private long dwIntervalBetweenFixes;
   private long dwNoofFixes;
   private long dwStartTime;

   public SUPLPeriodicParams(long var1, long var3, long var5) {
      this.dwStartTime = var1;
      this.dwNoofFixes = var3;
      this.dwIntervalBetweenFixes = var5;
   }

   public SUPLPeriodicParams(Parcel var1) {
      this.readFromParcel(var1);
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getPeriodicParams() {
      byte[] var2 = new byte[12];
      int var1 = IO.put4(var2, 0, (int)this.dwStartTime);
      System.out.println("dwStartTime = " + this.dwStartTime);
      var1 = IO.put4(var2, var1, (int)this.dwNoofFixes);
      System.out.println("dwNoofFixes = " + this.dwNoofFixes);
      IO.put4(var2, var1, (int)this.dwIntervalBetweenFixes);
      System.out.println("dwIntervalBetweenFixes = " + this.dwIntervalBetweenFixes);
      return var2;
   }

   public void readFromParcel(Parcel var1) {
      this.dwStartTime = var1.readLong();
      this.dwNoofFixes = var1.readLong();
      this.dwIntervalBetweenFixes = var1.readLong();
   }

   public String toString() {
      return this.dwStartTime + "," + this.dwNoofFixes + "," + this.dwIntervalBetweenFixes;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeLong(this.dwStartTime);
      var1.writeLong(this.dwNoofFixes);
      var1.writeLong(this.dwIntervalBetweenFixes);
   }
}
