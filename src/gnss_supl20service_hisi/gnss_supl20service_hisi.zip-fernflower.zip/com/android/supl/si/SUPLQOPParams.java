package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class SUPLQOPParams implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SUPLQOPParams createFromParcel(Parcel var1) {
         return new SUPLQOPParams(var1);
      }

      public SUPLQOPParams[] newArray(int var1) {
         return new SUPLQOPParams[var1];
      }
   };
   private boolean bMaxLocAgePresent;
   private boolean bVeraccPresent;
   private boolean bdelayPresent;
   public int byDelay;
   public int byHorAcc;
   public int byVerAcc;
   public int wMaxLocAge;

   public SUPLQOPParams(Parcel var1) {
      this.readFromParcel(var1);
   }

   public SUPLQOPParams(boolean var1, boolean var2, boolean var3, int var4, int var5, int var6, int var7) {
      this.bVeraccPresent = var1;
      this.bMaxLocAgePresent = var2;
      this.bdelayPresent = var3;
      this.byHorAcc = var4;
      this.byVerAcc = var5;
      this.wMaxLocAge = var6;
      this.byDelay = var7;
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getQOPParams() {
      byte var3 = 1;
      byte var2 = 13;
      if (this.bVeraccPresent) {
         var2 = 14;
      }

      int var1 = var2;
      if (this.bMaxLocAgePresent) {
         var1 = var2 + 2;
      }

      int var6 = var1;
      if (this.bdelayPresent) {
         var6 = var1 + 4;
      }

      byte[] var4 = new byte[var6];
      byte var5;
      if (this.bVeraccPresent) {
         var5 = 1;
      } else {
         var5 = 0;
      }

      var6 = IO.put4(var4, 0, var5);
      if (this.bMaxLocAgePresent) {
         var5 = 1;
      } else {
         var5 = 0;
      }

      var6 = IO.put4(var4, var6, var5);
      if (this.bdelayPresent) {
         var5 = var3;
      } else {
         var5 = 0;
      }

      var6 = IO.put1(var4, IO.put4(var4, var6, var5), this.byHorAcc);
      var1 = var6;
      if (this.bVeraccPresent) {
         var1 = IO.put1(var4, var6, this.byVerAcc);
      }

      var6 = var1;
      if (this.bMaxLocAgePresent) {
         var6 = IO.put2(var4, var1, this.wMaxLocAge);
      }

      if (this.bdelayPresent) {
         IO.put4(var4, var6, this.byDelay);
      }

      return var4;
   }

   public void readFromParcel(Parcel var1) {
      this.bVeraccPresent = false;
      if (var1.readByte() == 1) {
         this.bVeraccPresent = true;
      }

      this.bMaxLocAgePresent = false;
      if (var1.readByte() == 1) {
         this.bMaxLocAgePresent = true;
      }

      this.bdelayPresent = false;
      if (var1.readByte() == 1) {
         this.bdelayPresent = true;
      }

      this.byHorAcc = var1.readInt();
      if (this.bVeraccPresent) {
         this.byVerAcc = var1.readInt();
      }

      if (this.bMaxLocAgePresent) {
         this.wMaxLocAge = var1.readInt();
      }

      if (this.bdelayPresent) {
         this.byDelay = var1.readInt();
      }

   }

   public String toString() {
      return this.byHorAcc + "," + this.byVerAcc + "," + this.wMaxLocAge + "," + this.byDelay;
   }

   public void writeToParcel(Parcel var1, int var2) {
      byte var4 = 1;
      byte var3;
      if (this.bVeraccPresent) {
         var3 = 1;
      } else {
         var3 = 0;
      }

      var1.writeByte(var3);
      if (this.bMaxLocAgePresent) {
         var3 = 1;
      } else {
         var3 = 0;
      }

      var1.writeByte(var3);
      if (this.bdelayPresent) {
         var3 = var4;
      } else {
         var3 = 0;
      }

      var1.writeByte(var3);
      var1.writeInt(this.byHorAcc);
      if (this.bVeraccPresent) {
         var1.writeInt(this.byVerAcc);
      }

      if (this.bMaxLocAgePresent) {
         var1.writeInt(this.wMaxLocAge);
      }

      if (this.bdelayPresent) {
         var1.writeInt(this.byDelay);
      }

   }
}
