package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;
import com.android.supl.si.ganss.SuplGanssAssistCapabilities;
import com.android.supl.si.ganss.SuplGanssPOSCapabilities;

public class SITriggerParams implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SITriggerParams createFromParcel(Parcel var1) {
         System.out.println("createFromParcel ");
         return new SITriggerParams(var1);
      }

      public SITriggerParams[] newArray(int var1) {
         return new SITriggerParams[var1];
      }
   };
   private static final int MSG_PCM_START_SI = 269;
   private SuplGanssAssistCapabilities mGanssAssistCapabilities = null;
   private SuplGanssPOSCapabilities mGanssPOSCapabilities = null;
   private boolean m_bIsAppIdPresent;
   private boolean m_bIsAssitancePresent = false;
   private boolean m_bIsPOSPresent = false;
   private boolean m_bIsQOPPresent = false;
   private boolean m_bIsTriggerParamsPresent;
   private SUPLThirdPartyIDs m_st3rdPartyIds = null;
   private ApplicationID m_stAppId = null;
   private SUPLQOPParams m_stQoP = null;
   private SUPLTriggerParams m_stTriggerParams = null;
   private short m_usPlatformSessionId;

   public SITriggerParams(Parcel var1) {
      this.readFromParcel(var1);
   }

   public SITriggerParams(boolean var1, SUPLQOPParams var2, boolean var3, SUPLTriggerParams var4, boolean var5, ApplicationID var6, SUPLThirdPartyIDs var7, boolean var8, SuplGanssPOSCapabilities var9, boolean var10, SuplGanssAssistCapabilities var11) {
      this.m_usPlatformSessionId = -1;
      this.m_bIsQOPPresent = var1;
      if (var1 && var2 == null) {
         throw new IllegalArgumentException("QOP paramerter should not be null");
      } else {
         this.m_stQoP = var2;
         this.m_bIsTriggerParamsPresent = var3;
         if (var3 && var4 == null) {
            throw new IllegalArgumentException("Trigger paramerter should not be null");
         } else {
            this.m_stTriggerParams = var4;
            this.m_bIsAppIdPresent = var5;
            if (var5 && var6 == null) {
               throw new IllegalArgumentException("AppID should not be null");
            } else {
               this.m_stAppId = var6;
               if (var7 == null) {
                  throw new IllegalArgumentException("3rd PartyID  should not be null");
               } else {
                  this.m_st3rdPartyIds = var7;
                  this.m_bIsPOSPresent = var8;
                  if (var8 && var9 == null) {
                     throw new IllegalArgumentException("GanssPOSCapabilities should not be null");
                  } else {
                     this.mGanssPOSCapabilities = var9;
                     this.m_bIsAssitancePresent = var10;
                     if (var10 && var11 == null) {
                        throw new IllegalArgumentException("GanssAssistCapabilities should not be null");
                     } else {
                        this.mGanssAssistCapabilities = var11;
                     }
                  }
               }
            }
         }
      }
   }

   public int describeContents() {
      return 0;
   }

   public SUPLThirdPartyIDs get3rdPartyIds() {
      return this.m_st3rdPartyIds;
   }

   public ApplicationID getAppId() {
      return this.m_stAppId;
   }

   public byte[] getStartSI() {
      int var2 = 26;
      byte[] var4 = null;
      if (this.m_bIsQOPPresent) {
         var4 = this.m_stQoP.getQOPParams();
         var2 = var4.length + 26;
      }

      byte[] var5 = null;
      int var1 = var2;
      byte[] var6;
      if (this.m_bIsTriggerParamsPresent) {
         var6 = this.m_stTriggerParams.getTriggerParam();
         var5 = var6;
         var1 = var2;
         if (var6 != null) {
            var1 = var2 + var6.length;
            var5 = var6;
         }
      }

      var6 = null;
      var2 = var1;
      if (this.m_bIsAppIdPresent) {
         var6 = this.m_stAppId.getApplicationIDInfo();
         var2 = var1 + var6.length;
      }

      byte[] var10 = this.m_st3rdPartyIds.getSUPLThirdPartyIDs();
      var2 += var10.length;
      byte[] var7 = null;
      var1 = var2;
      byte[] var8;
      if (this.m_bIsPOSPresent) {
         var8 = this.mGanssPOSCapabilities.getPOSCapabilities();
         var7 = var8;
         var1 = var2;
         if (var8 != null) {
            var1 = var2 + var8.length;
            var7 = var8;
         }
      }

      var8 = null;
      var2 = var1;
      byte[] var9;
      if (this.m_bIsAssitancePresent) {
         var9 = this.mGanssAssistCapabilities.getAsstCapElem();
         var8 = var9;
         var2 = var1;
         if (var9 != null) {
            var2 = var1 + var9.length;
            var8 = var9;
         }
      }

      var9 = new byte[var2 + 4];
      var1 = IO.put2(var9, IO.put4(var9, 4, 269), this.m_usPlatformSessionId);
      if (this.m_bIsQOPPresent) {
         var1 = IO.put4(var9, var1, 1);
         System.arraycopy(var4, 0, var9, var1, var4.length);
         var1 += var4.length;
      } else {
         var1 = IO.put4(var9, var1, 0);
      }

      if (this.m_bIsTriggerParamsPresent) {
         int var3 = IO.put4(var9, var1, 1);
         var1 = var3;
         if (var5 != null) {
            System.arraycopy(var5, 0, var9, var3, var5.length);
            var1 = var3 + var5.length;
         }
      } else {
         var1 = IO.put4(var9, var1, 0);
      }

      if (this.m_bIsAppIdPresent) {
         var1 = IO.put4(var9, var1, 1);
         System.arraycopy(var6, 0, var9, var1, var6.length);
         var1 += var6.length;
      } else {
         var1 = IO.put4(var9, var1, 0);
      }

      System.arraycopy(var10, 0, var9, var1, var10.length);
      var1 += var10.length;
      if (this.m_bIsPOSPresent) {
         var1 = IO.put4(var9, var1, 1);
         System.arraycopy(var7, 0, var9, var1, var7.length);
         var1 += var7.length;
      } else {
         var1 = IO.put4(var9, var1, 0);
      }

      if (this.m_bIsAssitancePresent) {
         var1 = IO.put4(var9, var1, 1);
         System.arraycopy(var8, 0, var9, var1, var8.length);
         var1 += var8.length;
      } else {
         var1 = IO.put4(var9, var1, 0);
      }

      if (var1 - 4 != var2) {
         System.err.println("Start SI length invalid");
      }

      IO.put4(var9, 0, var2);
      return var9;
   }

   public SUPLTriggerParams getTriggerParams() {
      return this.m_stTriggerParams;
   }

   public void readFromParcel(Parcel var1) {
      this.m_usPlatformSessionId = (short)var1.readInt();
      this.m_bIsQOPPresent = false;
      if (var1.readByte() == 1) {
         this.m_bIsQOPPresent = true;
         this.m_stQoP = (SUPLQOPParams)var1.readParcelable(SUPLQOPParams.class.getClassLoader());
      }

      this.m_bIsTriggerParamsPresent = false;
      if (var1.readByte() == 1) {
         this.m_bIsTriggerParamsPresent = true;
         this.m_stTriggerParams = (SUPLTriggerParams)var1.readParcelable(SUPLTriggerParams.class.getClassLoader());
      }

      this.m_bIsAppIdPresent = false;
      if (var1.readByte() == 1) {
         this.m_bIsAppIdPresent = true;
         this.m_stAppId = (ApplicationID)var1.readParcelable(ApplicationID.class.getClassLoader());
      }

      this.m_st3rdPartyIds = (SUPLThirdPartyIDs)var1.readParcelable(SUPLThirdPartyIDs.class.getClassLoader());
      byte var2 = var1.readByte();
      this.m_bIsPOSPresent = false;
      if (var2 == 1) {
         this.m_bIsPOSPresent = true;
         this.mGanssPOSCapabilities = (SuplGanssPOSCapabilities)var1.readParcelable(SuplGanssPOSCapabilities.class.getClassLoader());
      }

      var2 = var1.readByte();
      this.m_bIsAssitancePresent = false;
      if (var2 == 1) {
         this.m_bIsAssitancePresent = true;
         this.mGanssAssistCapabilities = (SuplGanssAssistCapabilities)var1.readParcelable(SuplGanssAssistCapabilities.class.getClassLoader());
      }

   }

   public void setPlatformSessionId(int var1) {
      this.m_usPlatformSessionId = (short)var1;
   }

   public String toString() {
      StringBuffer var1 = new StringBuffer();
      var1.append("SID:");
      var1.append(this.m_usPlatformSessionId);
      if (this.m_bIsQOPPresent) {
         var1.append("QOP:");
         var1.append(this.m_stQoP.toString());
      }

      if (this.m_bIsTriggerParamsPresent) {
         var1.append("TP:");
         var1.append(this.m_stTriggerParams.toString());
      }

      if (this.m_bIsAppIdPresent) {
         var1.append("AppID:");
         var1.append(this.m_stAppId.toString());
      }

      var1.append(this.m_st3rdPartyIds.toString());
      if (this.m_bIsPOSPresent) {
         var1.append("POSCap:");
         var1.append(this.mGanssPOSCapabilities.toString());
      }

      if (this.m_bIsAssitancePresent) {
         var1.append("AsCap:");
         var1.append(this.mGanssAssistCapabilities.toString());
      }

      return var1.toString();
   }

   public void writeToParcel(Parcel var1, int var2) {
      byte var4 = 1;
      var1.writeInt(this.m_usPlatformSessionId);
      byte var3;
      if (this.m_bIsQOPPresent) {
         var3 = 1;
      } else {
         var3 = 0;
      }

      var1.writeByte(var3);
      if (this.m_bIsQOPPresent) {
         var1.writeParcelable(this.m_stQoP, var2);
      }

      if (this.m_bIsTriggerParamsPresent) {
         var3 = 1;
      } else {
         var3 = 0;
      }

      var1.writeByte(var3);
      if (this.m_bIsTriggerParamsPresent) {
         var1.writeParcelable(this.m_stTriggerParams, var2);
      }

      if (this.m_bIsAppIdPresent) {
         var3 = 1;
      } else {
         var3 = 0;
      }

      var1.writeByte(var3);
      if (this.m_bIsAppIdPresent) {
         var1.writeParcelable(this.m_stAppId, var2);
      }

      var1.writeParcelable(this.m_st3rdPartyIds, var2);
      if (this.m_bIsPOSPresent) {
         var3 = 1;
      } else {
         var3 = 0;
      }

      var1.writeByte(var3);
      if (this.m_bIsPOSPresent) {
         var1.writeParcelable(this.mGanssPOSCapabilities, var2);
      }

      if (this.m_bIsAssitancePresent) {
         var3 = var4;
      } else {
         var3 = 0;
      }

      var1.writeByte(var3);
      if (this.m_bIsAssitancePresent) {
         var1.writeParcelable(this.mGanssAssistCapabilities, var2);
      }

   }
}
