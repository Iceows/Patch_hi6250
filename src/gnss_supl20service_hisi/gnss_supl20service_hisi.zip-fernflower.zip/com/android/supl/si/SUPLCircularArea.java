package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class SUPLCircularArea implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SUPLCircularArea createFromParcel(Parcel var1) {
         return new SUPLCircularArea(var1);
      }

      public SUPLCircularArea[] newArray(int var1) {
         return new SUPLCircularArea[var1];
      }
   };
   private int nRadius;
   private int nRadiusMax;
   private int nRadiusMin;
   private SUPLCoordinate stCenter = null;

   public SUPLCircularArea(Parcel var1) {
      this.readFromParcel(var1);
   }

   public SUPLCircularArea(SUPLCoordinate var1, int var2, int var3, int var4) {
      if (var1 == null) {
         throw new IllegalArgumentException("Coordinate should not be null");
      } else {
         this.stCenter = var1;
         this.nRadius = var2;
         this.nRadiusMin = var3;
         this.nRadiusMax = var4;
      }
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getCircularArea() {
      byte[] var2 = this.stCenter.getCoordinateInfo();
      int var1 = var2.length + 12;
      byte[] var3 = new byte[var1];
      System.arraycopy(var2, 0, var3, 0, var2.length);
      if (IO.put4(var3, IO.put4(var3, IO.put4(var3, var2.length + 0, this.nRadius), this.nRadiusMin), this.nRadiusMax) != var1) {
         System.err.println("CircularArea length invalid");
      }

      return var3;
   }

   public void readFromParcel(Parcel var1) {
      this.stCenter = (SUPLCoordinate)var1.readParcelable(SUPLCoordinate.class.getClassLoader());
      this.nRadius = var1.readInt();
      this.nRadiusMin = var1.readInt();
      this.nRadiusMax = var1.readInt();
   }

   public String toString() {
      return "Coor:" + this.stCenter.toString() + "Rad:" + this.nRadius + "RMin" + this.nRadiusMin + "RMax" + this.nRadiusMax;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeParcelable(this.stCenter, var2);
      var1.writeInt(this.nRadius);
      var1.writeInt(this.nRadiusMin);
      var1.writeInt(this.nRadiusMax);
   }
}
