package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class ApplicationID implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public ApplicationID createFromParcel(Parcel var1) {
         return new ApplicationID(var1);
      }

      public ApplicationID[] newArray(int var1) {
         return new ApplicationID[var1];
      }
   };
   private String m_pcAppName = null;
   private String m_pcAppProvider = null;
   public String m_pcAppVersion = null;
   private short ucAppNameLen = 0;
   private short ucAppProviderLen = 0;
   private short ucAppVersionLen = 0;

   public ApplicationID(Parcel var1) {
      this.readFromParcel(var1);
   }

   public ApplicationID(String var1, String var2, String var3) {
      this.m_pcAppProvider = var1;
      this.m_pcAppName = var2;
      this.m_pcAppVersion = var3;
      if (var1 != null && var2 != null && var3 != null) {
         this.ucAppProviderLen = (short)var1.getBytes().length;
         this.ucAppNameLen = (short)var2.getBytes().length;
         this.ucAppVersionLen = (short)var3.getBytes().length;
      } else {
         throw new IllegalArgumentException("No field should not be null");
      }
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getApplicationIDInfo() {
      if (this.m_pcAppVersion == null) {
         this.m_pcAppVersion = "";
      }

      if (this.m_pcAppProvider == null) {
         this.m_pcAppProvider = "";
      }

      if (this.m_pcAppName == null) {
         this.m_pcAppName = "";
      }

      byte[] var3 = this.m_pcAppVersion.getBytes();
      byte[] var6 = this.m_pcAppProvider.getBytes();
      byte[] var5 = this.m_pcAppName.getBytes();
      int var1 = var6.length + 3 + var5.length + var3.length;
      byte[] var4 = new byte[var1];
      int var2 = IO.put1(var4, IO.put1(var4, IO.put1(var4, 0, this.ucAppProviderLen), this.ucAppNameLen), this.ucAppVersionLen);
      System.arraycopy(var6, 0, var4, var2, var6.length);
      var2 += var6.length;
      System.arraycopy(var5, 0, var4, var2, var5.length);
      var2 += var5.length;
      System.arraycopy(var3, 0, var4, var2, var3.length);
      if (var2 + var3.length != var1) {
         System.err.println("ApplicationID length invalid");
      }

      return var4;
   }

   public void readFromParcel(Parcel var1) {
      this.ucAppProviderLen = (short)var1.readInt();
      this.ucAppNameLen = (short)var1.readInt();
      this.ucAppVersionLen = (short)var1.readInt();
      this.m_pcAppProvider = var1.readString();
      this.m_pcAppName = var1.readString();
      this.m_pcAppVersion = var1.readString();
   }

   public String toString() {
      return this.m_pcAppProvider + ", " + this.m_pcAppName + ", " + this.m_pcAppVersion;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeInt(this.ucAppProviderLen);
      var1.writeInt(this.ucAppNameLen);
      var1.writeInt(this.ucAppVersionLen);
      var1.writeString(this.m_pcAppProvider);
      var1.writeString(this.m_pcAppName);
      var1.writeString(this.m_pcAppVersion);
   }
}
