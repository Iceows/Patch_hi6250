package com.android.supl.si;

import java.io.DataInputStream;
import java.io.IOException;

public class SISessionComplete {
   public int m_nSessionStatus;
   public int m_usPlatformSessionId;

   public boolean readSISessionComplete(DataInputStream var1) throws IOException {
      this.m_nSessionStatus = 0;
      this.m_usPlatformSessionId = var1.readUnsignedShort();
      return true;
   }
}
