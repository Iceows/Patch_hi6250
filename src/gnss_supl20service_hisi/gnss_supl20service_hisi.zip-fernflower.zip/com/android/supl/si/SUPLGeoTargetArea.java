package com.android.supl.si;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.android.bytewriter.IO;

public class SUPLGeoTargetArea implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public SUPLGeoTargetArea createFromParcel(Parcel var1) {
         return new SUPLGeoTargetArea(var1);
      }

      public SUPLGeoTargetArea[] newArray(int var1) {
         return new SUPLGeoTargetArea[var1];
      }
   };
   public static final int SUPL_CIRCULAR_AREA = 0;
   public static final int SUPL_ELLIPTICAL_AREA = 1;
   public static final int SUPL_POLYGONIC_AREA = 2;
   private int eGeoAreaType;
   private Object objGeographicArea = null;

   public SUPLGeoTargetArea(Parcel var1) {
      this.readFromParcel(var1);
   }

   public SUPLGeoTargetArea(Object var1, int var2) {
      if (var1 == null) {
         throw new IllegalArgumentException("Geo Area object should not be null");
      } else {
         switch(var2) {
         case 0:
            this.eGeoAreaType = 0;
            if (!(var1 instanceof SUPLCircularArea)) {
               throw new IllegalArgumentException("Geo Area object is not SUPLCircularArea type ");
            }
            break;
         case 1:
            this.eGeoAreaType = 1;
            if (!(var1 instanceof SUPLEllipticalArea)) {
               throw new IllegalArgumentException("Geo Area object is not SUPLEllipticalArea type ");
            }
            break;
         case 2:
            this.eGeoAreaType = 2;
            if (!(var1 instanceof SUPLPolygonArea)) {
               throw new IllegalArgumentException("Geo Area object is not SUPLPolygonArea type ");
            }
            break;
         default:
            throw new IllegalArgumentException("invalid Geo Area type");
         }

         this.objGeographicArea = var1;
      }
   }

   public int describeContents() {
      return 0;
   }

   public byte[] getGeoTargetArea() {
      int var2 = 4;
      int var1 = 0;
      byte[] var3 = null;
      switch(this.eGeoAreaType) {
      case 0:
         var3 = ((SUPLCircularArea)this.objGeographicArea).getCircularArea();
         break;
      case 1:
         var3 = ((SUPLEllipticalArea)this.objGeographicArea).getEllipticalAreaInfo();
         break;
      case 2:
         var3 = ((SUPLPolygonArea)this.objGeographicArea).getPolygonAreaInfo();
      }

      byte[] var4 = null;
      if (var3 != null) {
         var2 = var3.length + 4;
         var4 = new byte[var2];
         var1 = IO.put4(var4, 0, this.eGeoAreaType);
         System.arraycopy(var3, 0, var4, var1, var3.length);
         var1 += var3.length;
      }

      if (var1 != var2) {
         System.err.println("GeoTargetArea length invalid");
      }

      return var4;
   }

   public void readFromParcel(Parcel var1) {
      this.eGeoAreaType = var1.readInt();
      switch(this.eGeoAreaType) {
      case 0:
         this.objGeographicArea = var1.readParcelable(SUPLCircularArea.class.getClassLoader());
         break;
      case 1:
         this.objGeographicArea = var1.readParcelable(SUPLEllipticalArea.class.getClassLoader());
         break;
      case 2:
         this.objGeographicArea = var1.readParcelable(SUPLPolygonArea.class.getClassLoader());
      }

   }

   public String toString() {
      String var1 = null;
      switch(this.eGeoAreaType) {
      case 0:
         var1 = "Circular:" + ((SUPLCircularArea)this.objGeographicArea).toString();
         break;
      case 1:
         var1 = "Elli:" + ((SUPLEllipticalArea)this.objGeographicArea).toString();
         break;
      case 2:
         var1 = "Poly:" + ((SUPLPolygonArea)this.objGeographicArea).toString();
      }

      return this.eGeoAreaType + "," + var1;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeInt(this.eGeoAreaType);
      switch(this.eGeoAreaType) {
      case 0:
         var1.writeParcelable((SUPLCircularArea)this.objGeographicArea, var2);
         break;
      case 1:
         var1.writeParcelable((SUPLEllipticalArea)this.objGeographicArea, var2);
         break;
      case 2:
         var1.writeParcelable((SUPLPolygonArea)this.objGeographicArea, var2);
      }

   }
}
