package com.android.supl;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.SystemProperties;
import com.android.supl.commprocessor.SUPLSCMService;
import com.android.supl.loc.SUPLPlatformService;

public class SuplApplication extends Application {
   private static final String TAG = "SUPL20_Main";
   private static Context context;

   public static Context getContext() {
      return context;
   }

   private void startSuplServices() {
      if (!"1".equals(SystemProperties.get("is_hisi_connectivity_chip"))) {
         Log.d("SUPL20_Main", "Not hisi chip, quit now!");
      } else {
         (new Thread() {
            public void run() {
               Intent var1 = new Intent(SuplApplication.context, SUPLPlatformService.class);
               SuplApplication.context.startService(var1);
               Log.d("SUPL20_Main", "Starting platform service");
               var1 = new Intent(SuplApplication.context, SUPLSCMService.class);
               SuplApplication.context.startService(var1);
               Log.d("SUPL20_Main", "Starting scm service");
            }
         }).start();
      }
   }

   public void onCreate() {
      super.onCreate();
      Log.d("SUPL20_Main", "Starting supl application");
      context = this.getApplicationContext();
      this.startSuplServices();
   }
}
