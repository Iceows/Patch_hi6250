package com.android.supl;

import java.text.SimpleDateFormat;

public class Log {
   private static final String SPACE = " ";
   private static SimpleDateFormat sdf = null;

   static {
      init();
   }

   public static int d(String var0, String var1) {
      return android.util.Log.d(var0, var1);
   }

   public static int d(String var0, String var1, Throwable var2) {
      return android.util.Log.d(var0, var1, var2);
   }

   public static int e(String var0, String var1) {
      return android.util.Log.e(var0, var1);
   }

   public static int e(String var0, String var1, Throwable var2) {
      return android.util.Log.e(var0, var1, var2);
   }

   public static int i(String var0, String var1) {
      return android.util.Log.i(var0, var1);
   }

   public static int i(String var0, String var1, Throwable var2) {
      return android.util.Log.i(var0, var1, var2);
   }

   public static void init() {
      sdf = new SimpleDateFormat("dd-MM hh:mm:ss zzz");
   }

   public static int println(int var0, String var1, String var2) {
      return android.util.Log.println(var0, var1, var2);
   }

   public static int v(String var0, String var1) {
      return android.util.Log.i(var0, var1);
   }

   public static int v(String var0, String var1, Throwable var2) {
      return android.util.Log.i(var0, var1, var2);
   }

   public static int w(String var0, String var1) {
      return android.util.Log.w(var0, var1);
   }

   public static int w(String var0, String var1, Throwable var2) {
      return android.util.Log.w(var0, var1, var2);
   }

   public static int w(String var0, Throwable var1) {
      return android.util.Log.w(var0, var1);
   }
}
