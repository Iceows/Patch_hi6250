package com.android.supl.bearer;

public class BearerNetwork {
   private int iPriority = 0;
   private String stBearerNetWorkName = null;

   public BearerNetwork(String var1, int var2) {
      this.stBearerNetWorkName = var1;
      this.iPriority = var2;
   }

   public String getBearerNetWorkName() {
      return this.stBearerNetWorkName;
   }

   public int getPriority() {
      return this.iPriority;
   }

   public String toString() {
      return this.stBearerNetWorkName + ":" + this.iPriority;
   }
}
