package com.android.supl.bearer;

import java.util.Comparator;

public class BearerNetworkComparater implements Comparator {
   public int compare(BearerNetwork var1, BearerNetwork var2) {
      if (var1.getPriority() > var2.getPriority()) {
         return -1;
      } else {
         return var1.getPriority() < var2.getPriority() ? 1 : 0;
      }
   }
}
