package com.android.supl;

public interface GpsOnOffListener {
   void onGPSLocationProviderDisabled();

   void onGPSLocationProviderEnabled();
}
