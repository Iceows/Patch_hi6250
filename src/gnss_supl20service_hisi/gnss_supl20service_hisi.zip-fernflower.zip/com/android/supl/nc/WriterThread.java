package com.android.supl.nc;

import android.util.Log;
import com.android.bytewriter.IO;
import com.android.supl.commprocessor.FromServer;
import com.android.supl.commprocessor.NetworkCommandProcessor;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.util.Date;
import java.util.concurrent.BlockingQueue;
import javax.net.ssl.SSLProtocolException;

public class WriterThread implements Runnable {
   private static final String LOG_TAG = "SUPL20_SPIMESLP-SENDING";
   private static final int m_iBufferSize = 10;
   private BlockingQueue deque = null;
   private int iNetWorkID = -1;
   private int iNumberOfMessageOnQueue = 0;
   private transient boolean isBrokenPipe = false;
   private boolean isReadyForColse = false;
   private boolean isStopWrite = false;
   private Socket m_CilentSocket = null;
   private NetworkController nc = null;
   private Object objMyWriteLock = null;
   private OutputStream out = null;
   private Thread workerThread = null;

   public WriterThread(BlockingQueue var1, NetworkController var2, int var3) throws IllegalArgumentException {
      if (var1 == null) {
         throw new IllegalArgumentException("deque object  must not be null");
      } else {
         this.deque = var1;
         this.iNetWorkID = var3;
         this.nc = var2;
      }
   }

   private void notifyToCloseConnection() {
      Object var2 = this.objMyWriteLock;
      synchronized(var2){}

      try {
         this.isReadyForColse = true;
         this.objMyWriteLock.notify();
      } finally {
         ;
      }

   }

   private void sendError() {
      if (this.nc != null) {
         NetworkCommandProcessor var1 = this.nc.getNetworkCommandProcessor();
         if (this.iNetWorkID != -1 && var1 != null && var1 instanceof NetworkCommandProcessor) {
            byte[] var2 = new byte[13];
            IO.put4(var2, IO.put1(var2, IO.put4(var2, IO.put4(var2, 0, 9), 521), this.iNetWorkID), 1);
            FromServer var3 = new FromServer();
            var3.m_bPacket = var2;
            Log.i("SUPL20_SPIMESLP-SENDING", this.workerThread.getName() + " send connection error msg");
            var1.writePacket(var3);
         }
      }

   }

   private void write(SendToServer var1) {
      try {
         StringBuilder var3;
         try {
            if (this.iNetWorkID == -1) {
               if (this.nc.IsSCM()) {
                  SuplServiceMgr.getInstance().writeToScm(var1);
               } else {
                  SuplServiceMgr.getInstance().writeToPcm(var1);
               }
            } else {
               var3 = new StringBuilder();
               var3 = var3.append(this.workerThread.getName()).append(" ");
               Date var4 = new Date();
               Log.i("SUPL20_SPIMESLP-SENDING", var3.append(var4.toString()).append(" onSendData").toString());
               this.out.write(var1.m_bPacket);
               this.out.flush();
               var3 = new StringBuilder();
               Log.i("SUPL20_SPIMESLP-SENDING", var3.append("m_bPacket.length ").append(var1.m_bPacket.length).toString());
            }
         } catch (SSLProtocolException var9) {
            Log.e("SUPL20_SPIMESLP-SENDING", var9.getMessage(), var9);
            this.sendError();
            if (this.nc != null && !this.isBrokenPipe) {
               var3 = new StringBuilder();
               Log.d("SUPL20_SPIMESLP-SENDING", var3.append("Removing SLP Session for nc=").append(this.nc).toString());
               this.nc.removeSLPSession();
            }
         } catch (SocketException var10) {
            this.sendError();
            Log.e("SUPL20_SPIMESLP-SENDING", var10.getMessage(), var10);
            boolean var2 = this.isBrokenPipe;
         } catch (IOException var11) {
            Log.i("SUPL20_SPIMESLP-SENDING", "Inside the IOException block of write--brokenpipe");
            this.sendError();
            Log.e("SUPL20_SPIMESLP-SENDING", var11.getMessage(), var11);
            this.isBrokenPipe = true;
            Log.i("SUPL20_SPIMESLP-SENDING", "calling nc.stop with reconnect as true");
            this.nc.stop(true, (Object)null, true);
            Log.i("SUPL20_SPIMESLP-SENDING", "addPacket after broken pipe");
         }
      } finally {
         Log.i("SUPL20_SPIMESLP-SENDING", "bBrokenPipe = " + this.isBrokenPipe);
         if (this.isBrokenPipe) {
            Log.i("SUPL20_SPIMESLP-SENDING", "Adding packet to queue since pipe is broken");
            this.addPacket(var1);
         }

      }

   }

   public void addPacket(SendToServer param1) throws NullPointerException {
      // $FF: Couldn't be decompiled
   }

   public void closeWrite() {
      try {
         if (this.out != null && this.iNetWorkID != -1) {
            this.out.close();
            StringBuilder var1 = new StringBuilder();
            Log.i("SUPL20_SPIMESLP-SENDING", var1.append(this.workerThread.getName()).append(" close the write ").toString());
         }
      } catch (IOException var2) {
         Log.e("SUPL20_SPIMESLP-SENDING", var2.getMessage(), var2);
      }

   }

   public void decrementMessageCount() {
      synchronized(this){}

      try {
         --this.iNumberOfMessageOnQueue;
      } finally {
         ;
      }

   }

   public int getMessageCount() {
      synchronized(this){}

      int var1;
      try {
         var1 = this.iNumberOfMessageOnQueue;
      } finally {
         ;
      }

      return var1;
   }

   public void incrementMessageCount() {
      synchronized(this){}

      try {
         ++this.iNumberOfMessageOnQueue;
      } finally {
         ;
      }

   }

   public boolean isReadyForColse() {
      return this.isReadyForColse;
   }

   public boolean isSessionRunning() {
      boolean var2 = true;
      boolean var3 = this.deque.isEmpty();
      Log.i("SUPL20_SPIMESLP-SENDING", "isSessionRunning deque size:" + this.deque.size() + ", getMessageCount:" + this.getMessageCount() + ", isBrokenPipe : " + this.isBrokenPipe);
      boolean var1 = var2;
      if (!(var3 ^ true)) {
         if (this.getMessageCount() > 0) {
            var1 = var2;
         } else {
            var1 = false;
         }
      }

      return var1;
   }

   public void run() {
      // $FF: Couldn't be decompiled
   }

   public void setClientSocket(Socket var1, String var2) throws IllegalStateException, IllegalArgumentException {
      if (var1 == null) {
         throw new IllegalArgumentException("socket object must not be null");
      } else if (!var1.isConnected()) {
         throw new IllegalStateException("socket is not connected");
      } else if (!var1.isClosed() && !var1.isOutputShutdown()) {
         String var3 = var2;
         if (var2 == null) {
            var3 = "WriterThread";
         }

         var2 = var3;
         if (this.iNetWorkID != -1) {
            var2 = var3 + " NW:" + this.iNetWorkID;
            Log.i("SUPL20_SPIMESLP-SENDING", "setClientSocket :" + this.iNetWorkID);
         }

         this.m_CilentSocket = var1;

         try {
            this.out = var1.getOutputStream();
         } catch (IOException var4) {
            var4.printStackTrace();
         }

         this.isBrokenPipe = false;
         this.workerThread = new Thread(this, var2);
         this.workerThread.start();
         this.m_CilentSocket = var1;
      } else {
         throw new IllegalStateException("socket is closed");
      }
   }

   public void setStopLock(Object var1) {
      this.objMyWriteLock = var1;
   }

   public void startThread() {
      Log.i("SUPL20_SPIMESLP-SENDING", "startThread");
      if (this.iNetWorkID == -1) {
         this.isBrokenPipe = false;
         this.workerThread = new Thread(this, "WriterThread");
         this.workerThread.start();
         SuplServiceMgr.getInstance().getSUPLHILDInterface();
      } else {
         Log.e("SUPL20_SPIMESLP-SENDING", "socket don't start write thread here.");
      }

   }

   public void stopWrite() {
      if (this.isBrokenPipe || this.isSessionRunning() ^ true) {
         if (this.workerThread != null) {
            this.workerThread.interrupt();
         }

         this.notifyToCloseConnection();
      }

      this.isStopWrite = true;
   }
}
