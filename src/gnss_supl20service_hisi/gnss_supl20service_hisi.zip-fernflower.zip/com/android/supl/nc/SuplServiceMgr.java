package com.android.supl.nc;

import android.util.Log;
import com.android.supl.SUPLHIDLInterface;
import com.android.supl.SuplApplication;
import com.android.supl.commprocessor.CommandProcessor;
import com.android.supl.commprocessor.FromServer;

public class SuplServiceMgr {
   private static final String LOG_TAG = "SuplServiceMgr";
   private static SuplServiceMgr mInstance = null;
   private CommandProcessor mPcmCommandProcessor = null;
   private CommandProcessor mScmCommandProcessor = null;
   private SUPLHIDLInterface mSuplHidl = null;

   public static SuplServiceMgr getInstance() {
      synchronized(SuplServiceMgr.class){}

      SuplServiceMgr var0;
      try {
         if (mInstance == null) {
            Log.i("SuplServiceMgr", "new one");
            var0 = new SuplServiceMgr();
            mInstance = var0;
         }

         var0 = mInstance;
      } finally {
         ;
      }

      return var0;
   }

   public void addPcmPacket(FromServer var1) {
      if (this.mPcmCommandProcessor != null) {
         this.mPcmCommandProcessor.writePacket(var1);
      } else {
         Log.e("SuplServiceMgr", "mPcmCommandProcessor is null");
      }

   }

   public void addScmPacket(FromServer var1) {
      if (this.mScmCommandProcessor != null) {
         this.mScmCommandProcessor.writePacket(var1);
      } else {
         Log.e("SuplServiceMgr", "mScmCommandProcessor is null");
      }

   }

   public void getSUPLHILDInterface() {
      if (this.mSuplHidl == null) {
         Log.i("SuplServiceMgr", "getSUPLHILDInterface");
         this.mSuplHidl = SUPLHIDLInterface.createSUPLHIDLInterface(SuplApplication.getContext());
         this.mSuplHidl.setSuplServiceMgr(this);
      } else {
         Log.i("SuplServiceMgr", "SUPLHIDL interface already exist");
      }

   }

   public void setPcmCommandProcessor(CommandProcessor var1) {
      this.mPcmCommandProcessor = var1;
   }

   public void setScmCommandProcessor(CommandProcessor var1) {
      this.mScmCommandProcessor = var1;
   }

   public void writeToPcm(SendToServer var1) {
      if (this.mSuplHidl != null) {
         this.mSuplHidl.SendMsg2PCM(var1);
      } else {
         Log.e("SuplServiceMgr", "mSuplHidl is null");
      }

   }

   public void writeToScm(SendToServer var1) {
      if (this.mSuplHidl != null) {
         this.mSuplHidl.SendMsg2SCM(var1);
      } else {
         Log.e("SuplServiceMgr", "mSuplHidl is null");
      }

   }
}
