package com.android.supl.nc;

import android.util.Log;
import com.android.bytewriter.IO;
import com.android.supl.commprocessor.CommandProcessor;
import com.android.supl.commprocessor.FromServer;
import com.android.supl.commprocessor.NetworkCommandProcessor;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;
import java.util.Date;

public class ReaderThread implements Runnable {
   private static final String LOG_TAG = "SUPL20_SLP-RECEIVING";
   private CommandProcessor cp = null;
   private int iNetworkID = -1;
   private BufferedInputStream in = null;
   private boolean isRead = false;
   private boolean isReadyForClose = false;
   private Socket m_CilentSocket = null;
   private NetworkController nc = null;
   public Object objMyReadLock = null;
   private Thread workerThread = null;

   public ReaderThread(CommandProcessor var1, int var2) {
      this.cp = var1;
      this.iNetworkID = var2;
   }

   private void closeInputStream() {
      if (this.in != null) {
         try {
            if (this.iNetworkID != -1) {
               this.in.close();
               StringBuilder var1 = new StringBuilder();
               Log.i("SUPL20_SLP-RECEIVING", var1.append(this.workerThread.getName()).append(" InputStream closed").toString());
            }
         } catch (IOException var2) {
            Log.e("SUPL20_SLP-RECEIVING", this.workerThread.getName() + " close exception", var2);
         }

         Log.i("SUPL20_SLP-RECEIVING", this.workerThread.getName() + " close");
      }

   }

   private void sendError() {
      if (this.iNetworkID != -1 && this.cp != null && this.cp instanceof NetworkCommandProcessor) {
         byte[] var1 = new byte[13];
         IO.put4(var1, IO.put1(var1, IO.put4(var1, IO.put4(var1, 0, 9), 521), this.iNetworkID), 1);
         FromServer var2 = new FromServer();
         var2.m_bPacket = var1;
         Log.i("SUPL20_SLP-RECEIVING", this.workerThread.getName() + " send connection error msg ");
         this.cp.writePacket(var2);
      }

   }

   private void sendOnReceiveData(int var1, byte[] var2, FromServer var3) {
      int var4 = var1 + 8 + 1;
      var3.m_bPacket = new byte[var4 + 4];
      var4 = IO.put4(var3.m_bPacket, 0, var4);
      var4 = IO.put4(var3.m_bPacket, var4, 520);
      var4 = IO.put4(var3.m_bPacket, var4, var1);
      System.arraycopy(var2, 0, var3.m_bPacket, var4, var1);
      IO.put1(var3.m_bPacket, var4 + var1, this.iNetworkID);
      Log.i("SUPL20_SLP-RECEIVING", this.workerThread.getName() + " " + (new Date()).toString() + " OnReceiveData from the " + this.cp.toString());
   }

   public void closeConnection() {
      if (this.objMyReadLock != null) {
         Object var1 = this.objMyReadLock;
         synchronized(var1){}

         try {
            this.isReadyForClose = true;
            StringBuilder var2 = new StringBuilder();
            Log.i("SUPL20_SLP-RECEIVING", var2.append(this.workerThread.getName()).append(" notify ").toString());
            this.objMyReadLock.notify();
         } finally {
            ;
         }
      }

      if (this.workerThread != null) {
         this.workerThread.interrupt();
      }

      this.closeInputStream();
   }

   public boolean isReadyForColse() {
      return this.isReadyForClose;
   }

   public void run() {
      // $FF: Couldn't be decompiled
   }

   public void setClientSocket(Socket var1, String var2) throws IllegalArgumentException, IllegalStateException {
      if (var1 == null) {
         throw new IllegalArgumentException("socket object must not be null");
      } else if (!var1.isConnected()) {
         throw new IllegalStateException("socket is not connected");
      } else if (!var1.isClosed() && !var1.isInputShutdown()) {
         String var3 = var2;
         if (var2 == null) {
            var3 = "ReadThread";
         }

         if (this.iNetworkID != -1) {
            Log.i("SUPL20_SLP-RECEIVING", "readerThread initialized");
            var3 = var3 + " NW:" + this.iNetworkID;
         } else {
            try {
               var1.setSoTimeout(200);
            } catch (SocketException var4) {
               var4.printStackTrace();
            }
         }

         this.m_CilentSocket = var1;
         this.isRead = true;
         this.workerThread = new Thread(this, var3);
         this.workerThread.start();
      } else {
         throw new IllegalStateException("socket is closed");
      }
   }

   public void setNetworkController(NetworkController var1) {
      this.nc = var1;
   }

   public void setStopLock(Object var1) {
      this.objMyReadLock = var1;
   }

   public void stopRead() {
      try {
         StringBuilder var1 = new StringBuilder();
         Log.i("SUPL20_SLP-RECEIVING", var1.append(this.workerThread.getName()).append(" stopRead invoked").toString());
         this.isRead = false;
         Log.i("SUPL20_SLP-RECEIVING", " stopRead by invoke closeInputStream()");
         this.closeInputStream();
         this.isReadyForClose = true;
         if (this.m_CilentSocket != null) {
            this.m_CilentSocket.close();
         }

         this.workerThread.interrupt();
         Log.i("SUPL20_SLP-RECEIVING", " stopRead by isReadyForClose is true");
      } catch (Exception var2) {
         Log.e("SUPL20_SLP-RECEIVING", var2.getMessage(), var2);
      }

   }
}
