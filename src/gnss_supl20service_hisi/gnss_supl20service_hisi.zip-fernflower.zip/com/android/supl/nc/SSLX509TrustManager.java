package com.android.supl.nc;

import android.util.Log;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import javax.net.ssl.SSLException;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import org.apache.http.conn.ssl.StrictHostnameVerifier;

public class SSLX509TrustManager implements X509TrustManager {
   private static final String LOG = "SUPL20_TrustManager";
   private Vector allx509TrustManager = null;
   private Vector factories = null;
   private String fqdn = null;

   public SSLX509TrustManager(List var1, String var2) throws NoSuchAlgorithmException, KeyStoreException {
      if (var2 == null) {
         Log.e("SUPL20_TrustManager", "fqdn == null");
         throw new KeyStoreException("fqdn == null");
      } else {
         this.fqdn = var2;
         this.allx509TrustManager = new Vector(3);
         if (var1 != null && var1.isEmpty() ^ true) {
            Iterator var3 = var1.iterator();

            while(var3.hasNext()) {
               this.addKeyStore((KeyStore)var3.next(), false);
            }
         }

         this.addKeyStore((KeyStore)null, false);
         if (this.allx509TrustManager.isEmpty()) {
            Log.e("SUPL20_TrustManager", "No Trust Manager Found");
            throw new NoSuchAlgorithmException("No Trust Manager Found");
         } else {
            Log.i("SUPL20_TrustManager", "Added " + this.allx509TrustManager.size() + " Trust Managers");
         }
      }
   }

   private Vector splitByIssuers(X509Certificate[] var1) {
      Vector var6 = new Vector(1);
      boolean var3 = false;
      int var4 = 0;

      for(int var2 = 0; var2 < var1.length; ++var2) {
         if (!var3) {
            var4 = var2;
         }

         X509Certificate var7 = var1[var2];
         X509Certificate var5 = null;
         if (var2 != var1.length - 1) {
            var5 = var1[var2 + 1];
         }

         if (var5 != null && var7.getIssuerDN().equals(var5.getSubjectDN())) {
            var3 = true;
         } else {
            var3 = false;
         }

         if (!var3) {
            X509Certificate[] var8 = new X509Certificate[var2 - var4 + 1];
            System.arraycopy(var1, var4, var8, 0, var8.length);
            var6.add(var8);
         }
      }

      return var6;
   }

   public void addKeyStore(KeyStore var1, boolean var2) throws KeyStoreException, NoSuchAlgorithmException {
      TrustManagerFactory var7 = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
      var7.init(var1);
      TrustManager[] var10 = var7.getTrustManagers();
      int var5 = var10.length;

      for(int var3 = 0; var3 < var5; ++var3) {
         TrustManager var11 = var10[var3];
         if (var11 instanceof X509TrustManager) {
            X509TrustManager var9 = (X509TrustManager)var11;
            this.allx509TrustManager.add(var9);
            if (var2) {
               Log.i("SUPL20_TrustManager", "Added new Trust Manager. It contains the following Accepted Issuer Certificates:");
               X509Certificate[] var12 = var9.getAcceptedIssuers();
               int var4 = 0;

               for(int var6 = var12.length; var4 < var6; ++var4) {
                  X509Certificate var8 = var12[var4];
                  Log.i("SUPL20_TrustManager", "Certificate: " + var8);
               }
            }

            Log.i("SUPL20_TrustManager", "Number of accepted issuers: " + var9.getAcceptedIssuers().length);
         }
      }

   }

   public void checkClientTrusted(X509Certificate[] var1, String var2) throws CertificateException {
      throw new CertificateException(new UnsupportedOperationException());
   }

   public void checkServerTrusted(X509Certificate[] var1, String var2) throws CertificateException {
      if (var1 != null && var1.length != 0) {
         try {
            StrictHostnameVerifier var5 = new StrictHostnameVerifier();
            var5.verify(this.fqdn, var1[0]);
         } catch (SSLException var11) {
            Log.e("SUPL20_TrustManager", "Certificate SubjectDN : " + var1[0].getSubjectDN().toString());
            Log.e("SUPL20_TrustManager", "But trying to connect to FQDN: " + this.fqdn);
            throw new CertificateException(var11);
         }

         CertificateException var6 = null;
         Vector var15;
         if (var1.length > 1) {
            var15 = this.splitByIssuers(var1);
         } else {
            var15 = new Vector(1);
            var15.add(var1);
         }

         boolean var3 = false;
         Iterator var7 = var15.iterator();
         CertificateException var17 = var6;

         boolean var4;
         do {
            var4 = var3;
            var6 = var17;
            if (!var7.hasNext()) {
               break;
            }

            X509Certificate[] var8 = (X509Certificate[])var7.next();
            Iterator var9 = this.allx509TrustManager.iterator();
            var6 = var17;

            while(true) {
               var4 = var3;
               if (!var9.hasNext()) {
                  break;
               }

               X509TrustManager var18 = (X509TrustManager)var9.next();

               try {
                  var18.checkServerTrusted(var8, var2);
               } catch (CertificateException var12) {
                  var6 = var12;
                  continue;
               }

               var4 = true;
               break;
            }

            var3 = var4;
            var17 = var6;
         } while(!var4);

         if (!var4) {
            Log.e("SUPL20_TrustManager", "Couldn't find trusted anchor for certificate chain");
            throw var6;
         } else {
            int var14 = 0;

            for(int var16 = var1.length; var14 < var16; ++var14) {
               X509Certificate var13 = var1[var14];

               try {
                  var13.checkValidity();
               } catch (CertificateException var10) {
                  Log.e("SUPL20_TrustManager", "The following certificate in the chain is invalid: " + var13);
                  throw var10;
               }
            }

         }
      } else {
         Log.e("SUPL20_TrustManager", "Server didn't provide any certificate");
         throw new CertificateException("Server didn't provide any certificate");
      }
   }

   public X509Certificate[] getAcceptedIssuers() {
      ArrayList var2 = new ArrayList();
      Iterator var1 = this.allx509TrustManager.iterator();

      while(var1.hasNext()) {
         var2.addAll(Arrays.asList(((X509TrustManager)var1.next()).getAcceptedIssuers()));
      }

      return (X509Certificate[])var2.toArray(new X509Certificate[var2.size()]);
   }
}
