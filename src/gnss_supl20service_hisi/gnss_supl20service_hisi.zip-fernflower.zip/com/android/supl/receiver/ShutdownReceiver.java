package com.android.supl.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.SystemProperties;
import android.util.Log;
import com.android.supl.commprocessor.SUPLSCMService;
import com.android.supl.loc.SUPLPlatformService;

public class ShutdownReceiver extends BroadcastReceiver {
   public void onReceive(Context var1, Intent var2) {
      if (!"1".equals(SystemProperties.get("is_hisi_connectivity_chip"))) {
         Log.d("HISI_LOG", "ShutdownReceiver onReceive called, but quit now");
      } else {
         if (var2.getAction() != null && var2.getAction().equals("android.intent.action.ACTION_SHUTDOWN")) {
            var1.stopService(new Intent(var1, SUPLPlatformService.class));
            var1.stopService(new Intent(var1, SUPLSCMService.class));
            Log.d("HISI_LOG", "ShutdownReceiver onReceive called");
         }

      }
   }
}
