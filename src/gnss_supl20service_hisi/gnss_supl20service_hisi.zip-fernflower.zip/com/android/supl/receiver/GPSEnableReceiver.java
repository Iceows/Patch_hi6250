package com.android.supl.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.android.supl.Log;

public class GPSEnableReceiver extends BroadcastReceiver {
   public void onReceive(Context var1, Intent var2) {
      Log.i("GPSEnableReceiver", "GPSEnableReceiver invoked");
      if (var2.getAction().equals("android.location.GPS_ENABLED_CHANGE")) {
         var2.getExtras().getBoolean("enabled");
      }

   }
}
