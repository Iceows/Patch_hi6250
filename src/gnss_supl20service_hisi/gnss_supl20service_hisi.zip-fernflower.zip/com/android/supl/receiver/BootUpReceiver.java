package com.android.supl.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.SystemProperties;
import android.util.Log;
import com.android.supl.commprocessor.SUPLSCMService;
import com.android.supl.loc.SUPLPlatformService;

public class BootUpReceiver extends BroadcastReceiver {
   private static final String TAG = BootUpReceiver.class.getSimpleName();
   private static boolean is_service_start = false;
   private Context mContext = null;

   private void startSuplServices(Context var1) {
      this.mContext = var1;
      (new Thread() {
         public void run() {
            Intent var1 = new Intent(BootUpReceiver.this.mContext, SUPLPlatformService.class);
            BootUpReceiver.this.mContext.startService(var1);
            Log.d(BootUpReceiver.TAG, "Starting platform service");
            var1 = new Intent(BootUpReceiver.this.mContext, SUPLSCMService.class);
            BootUpReceiver.this.mContext.startService(var1);
            Log.d(BootUpReceiver.TAG, "Starting scm service");
         }
      }).start();
   }

   public void onReceive(Context var1, Intent var2) {
      if (!"1".equals(SystemProperties.get("is_hisi_connectivity_chip"))) {
         Log.d(TAG, "BootUpReceiver onReceive called, but quit now");
      } else if (!"hi1102".equals(SystemProperties.get("ro.connectivity.sub_chiptype"))) {
         Log.d(TAG, "supl application quit now");
      } else {
         Log.d(TAG, "BootUpReceiver got " + var2.getAction());
         if (!is_service_start && var2.getAction() != null && (var2.getAction().equals("android.intent.action.BOOT_COMPLETED") || var2.getAction().equals("android.intent.action.SCREEN_ON") || var2.getAction().equals("android.intent.action.SIM_STATE_CHANGED"))) {
            this.startSuplServices(var1);
            is_service_start = true;
         }

      }
   }
}
