package com.android.supl.config;

public class NetworkConnectionParam {
   public int m_iConnectionRetries = 5;
   public int m_iConnectionTimeOut = 5000;
   public int m_iPCMPort = 9001;
   public int m_iSCMPort = 9002;
   public String m_sPCMUnixSocPath = "/data/gnss/pcm_soc";
   public String m_sSCMUnixSocPath = "/data/gnss/scm_soc";
   public String m_stPCMFQDN = "127.0.0.1";
   public String m_stSCMFQDN = "127.0.0.1";

   public String toString() {
      return "ConnectionTimeOut :" + this.m_iConnectionTimeOut + "\n" + "ConnectionRetries:" + this.m_iConnectionRetries + "\n" + "PCMPort:" + this.m_iPCMPort + "\n" + "PCMFQDN:" + this.m_stPCMFQDN + "\n" + "SCMPort:" + this.m_iSCMPort + "\n" + "SCMFQDN:" + this.m_stSCMFQDN + "\n" + "PCMUnixSocPath:" + this.m_sPCMUnixSocPath + "\n" + "SCMUnixSocPath:" + this.m_sSCMUnixSocPath + "\n";
   }
}
