package com.android.supl.config;

import android.util.Log;
import com.android.bytewriter.IO;
import com.android.supl.bearer.BearerNetworkComparater;
import java.util.HashMap;
import java.util.PriorityQueue;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class ConfigManager extends DefaultHandler {
   private static final String BEARER_NETWORK_ENABLE = "bearer_network_enable";
   private static final String BEARER_NETWORK_PRIORITY = "bearer_network_priority";
   private static final String BEARER_NETWORK_SUPPORT = "bearer_network_support";
   public static final String CDMA = "cdma";
   private static final String CERT = "cert";
   private static final String CHECK_GPS = "checkgps";
   private static final String CI = "ci";
   private static final String CONFIG_START = "config_start";
   private static final String CUST_SUPL_CONFIG_PATH = "/data/cust/xml/gnss_suplconfig_hisi.xml";
   private static final String DEFAULT_SUPL_CONFIG_PATH = "/vendor/etc/gnss/config/gnss_suplconfig_hisi.xml";
   private static final String FILLTAANDNMR = "filltaandnmr";
   private static final String FORCETESTVALUE = "forcetestvalue";
   public static final String GSM = "gsm";
   public static final String HRPD = "hrpd";
   private static final String IPADDRESS = "ipaddress";
   private static final String LAC = "lac";
   public static final String LTE = "lte";
   private static final String MCC = "mcc";
   private static final String MNC = "mnc";
   private static final String MSISDN = "msisdn";
   private static final String NETCONT_PARAMS = "netcont_params";
   private static final String NI_UDP_ENABLED = "ni_udp_enabled";
   private static final String NMR = "nmr";
   private static final String NW_RETRIES = "nw_retries";
   private static final String NW_TIMEOUT = "nw_timeout";
   private static final String PATH = "path";
   private static final String PCM = "pcm";
   private static final String PORT = "port";
   private static final String PREF_SETID = "pref_setid";
   private static final String PWD = "pwd";
   private static final String SCM = "scm";
   private static String ST_LOG = "SUPL20_Config";
   public static final String SUPL_Services_Version = "2.13.2.0";
   private static final String SUPL_VERSION = "suplver";
   private static final String SWITCH_APN_ENABLE = "switch_apn_enable";
   private static final String TA = "ta";
   public static final String UMB = "umb";
   private static final String UNIXSOCPATH = "unixsocketpath";
   private static final String VALID = "valid";
   public static final String WCDMA = "wcdma";
   public static final String WIMAX = "wimax";
   public static final String WLAN = "wlan";
   private static ConfigManager sConfigManager = null;
   private int iConfigStartVersion = 0;
   private int iSUPLVersion = 1;
   private boolean isBearNetworkFound = false;
   private boolean isCertFound = false;
   private boolean isCertVaild = false;
   private boolean isCheckGPSEnabled = false;
   private boolean isForceTest = false;
   private boolean isMultipleBearNetworkSupport = false;
   private boolean isMultipleBearNetworkSupportRoaming = false;
   private boolean isNiUdpEnabled = false;
   private boolean isPCMFound = false;
   private boolean isRequiredTag = false;
   private boolean isSCMFound = false;
   private boolean isSwitchApnEnabled = false;
   private BearerNetworkComparater mComparater = new BearerNetworkComparater();
   private NetworkConnectionParam m_connectionParam = null;
   private PriorityQueue queue = null;
   private HashMap roamingBearerNetwork = null;
   private String stCurrentBearerNetWork = null;
   private String stData = null;
   private String stKeyStoreConv = "format-convert";
   private String stKeyStorePath = null;
   private String stPerfSetId = null;
   private String stPrivateKeyStore = null;
   private String stPrivateKeyStoreConv = null;
   private ConfigManager.ForceTestValue testValue = null;

   private ConfigManager() {
      this.init();
      if (this.m_connectionParam != null) {
         Log.i(ST_LOG, this.m_connectionParam.toString());
      }

      this.setKeyStore_ConvFromConfig();
   }

   public static ConfigManager getInstance() {
      synchronized(ConfigManager.class){}

      ConfigManager var0;
      try {
         if (sConfigManager == null) {
            var0 = new ConfigManager();
            sConfigManager = var0;
         }

         var0 = sConfigManager;
      } finally {
         ;
      }

      return var0;
   }

   private void setKeyStore_ConvFromConfig() {
      this.stPrivateKeyStore = this.getKeyStorePath();
      this.stPrivateKeyStoreConv = this.getKeyStoreConv();
   }

   public void characters(char[] var1, int var2, int var3) throws SAXException {
      if (this.isRequiredTag) {
         this.stData = (new String(var1, var2, var3)).trim();
         this.isRequiredTag = false;
      }

   }

   public boolean checkGPSEnabled() {
      return this.isCheckGPSEnabled;
   }

   public void endElement(String param1, String param2, String param3) throws SAXException {
      // $FF: Couldn't be decompiled
   }

   public byte[] getForceTestvalue() {
      byte[] var1 = null;
      if (this.testValue != null) {
         var1 = this.testValue.getForceTest();
      }

      return var1;
   }

   public String getKeyStoreConv() {
      return this.stKeyStoreConv;
   }

   public String getKeyStorePath() {
      return this.stKeyStorePath;
   }

   public int getNwRetries() {
      int var1 = 5;
      if (this.m_connectionParam != null) {
         var1 = this.m_connectionParam.m_iConnectionRetries;
      }

      return var1;
   }

   public int getNwTimeout() {
      int var1 = 5000;
      if (this.m_connectionParam != null) {
         var1 = this.m_connectionParam.m_iConnectionTimeOut;
      }

      return var1;
   }

   public String getPCMIpAdress() {
      String var1 = "127.0.0.1";
      if (this.m_connectionParam != null) {
         var1 = this.m_connectionParam.m_stPCMFQDN;
      }

      return var1;
   }

   public int getPCMPort() {
      int var1 = 9001;
      if (this.m_connectionParam != null) {
         var1 = this.m_connectionParam.m_iPCMPort;
      }

      return var1;
   }

   public String getPCMUnixSocketPath() {
      String var1 = "/data/gnss/pcm_soc";
      if (this.m_connectionParam != null) {
         var1 = this.m_connectionParam.m_sPCMUnixSocPath;
      }

      return var1;
   }

   public String getPrefSetId() {
      return this.stPerfSetId;
   }

   public String getPrivateKeyStore() {
      return this.stPrivateKeyStore;
   }

   public String getPrivateKeyStoreConv() {
      return this.stPrivateKeyStoreConv;
   }

   public HashMap getRoamingBearerNetwork() {
      return this.roamingBearerNetwork;
   }

   public String getSCMIpAdress() {
      String var1 = "127.0.0.1";
      if (this.m_connectionParam != null) {
         var1 = this.m_connectionParam.m_stSCMFQDN;
      }

      return var1;
   }

   public int getSCMPort() {
      int var1 = 9002;
      if (this.m_connectionParam != null) {
         var1 = this.m_connectionParam.m_iSCMPort;
      }

      return var1;
   }

   public String getSCMUnixSocketPath() {
      String var1 = "/data/gnss/scm_soc";
      if (this.m_connectionParam != null) {
         var1 = this.m_connectionParam.m_sSCMUnixSocPath;
      }

      return var1;
   }

   public int getSUPLVersion() {
      return this.iSUPLVersion;
   }

   public void init() {
      // $FF: Couldn't be decompiled
   }

   public boolean isCertVaild() {
      return this.isCertVaild;
   }

   public boolean isForceTest() {
      return this.isForceTest;
   }

   public boolean isMultipleBearNetworkSupport() {
      return this.isMultipleBearNetworkSupport;
   }

   public boolean isNiUdpEnabled() {
      return this.isNiUdpEnabled;
   }

   public void startElement(String var1, String var2, String var3, Attributes var4) throws SAXException {
      boolean var5 = true;
      if (var2.equals("suplver")) {
         this.isRequiredTag = true;
      } else if (var2.equals("config_start")) {
         try {
            this.iConfigStartVersion = Math.round(Float.parseFloat(var4.getValue("", "version")));
         } catch (NumberFormatException var6) {
            ;
         } catch (NullPointerException var7) {
            ;
         }
      } else if (this.iConfigStartVersion == this.iSUPLVersion) {
         if (var2.equals("switch_apn_enable")) {
            this.isRequiredTag = true;
         } else if (var2.equals("pref_setid")) {
            this.isRequiredTag = true;
         } else if (var2.equals("netcont_params")) {
            this.m_connectionParam = new NetworkConnectionParam();
         } else if (var2.equals("nw_timeout")) {
            this.isRequiredTag = true;
         } else if (var2.equals("nw_retries")) {
            this.isRequiredTag = true;
         } else if (var2.equals("pcm")) {
            this.isPCMFound = true;
         } else if (var2.equals("scm")) {
            this.isSCMFound = true;
         } else if (var2.equals("port")) {
            this.isRequiredTag = true;
         } else if (var2.equals("ipaddress")) {
            this.isRequiredTag = true;
         } else if (var2.equals("unixsocketpath")) {
            this.isRequiredTag = true;
         } else if (var2.equals("ni_udp_enabled")) {
            this.isRequiredTag = true;
         } else if (var2.equals("cert")) {
            this.isCertFound = true;
         } else if (var2.equals("valid")) {
            if (this.isCertFound) {
               this.isRequiredTag = true;
            }
         } else if (var2.equals("path")) {
            if (this.isCertFound && this.isCertVaild) {
               this.isRequiredTag = true;
            }
         } else if (var2.equals("pwd")) {
            if (this.isCertFound && this.isCertVaild) {
               this.isRequiredTag = true;
            }
         } else if (var2.equals("forcetestvalue")) {
            this.isRequiredTag = true;
         } else if (this.testValue != null && var2.equals("mcc")) {
            this.isRequiredTag = true;
         } else if (this.testValue != null && var2.equals("mnc")) {
            this.isRequiredTag = true;
         } else if (this.testValue != null && var2.equals("lac")) {
            this.isRequiredTag = true;
         } else if (this.testValue != null && var2.equals("ci")) {
            this.isRequiredTag = true;
         } else if (this.testValue != null && var2.equals("msisdn")) {
            this.isRequiredTag = true;
         } else if (this.testValue != null && var2.equals("filltaandnmr")) {
            this.isRequiredTag = true;
         } else if (this.testValue != null && var2.equals("ta")) {
            this.isRequiredTag = true;
         } else if (this.testValue != null && var2.equals("nmr")) {
            this.isRequiredTag = true;
         } else if (var2.equals("checkgps")) {
            this.isRequiredTag = true;
         } else if (var2.equals("bearer_network_enable")) {
            this.isRequiredTag = true;
         } else if (var2.equals("bearer_network_support")) {
            this.isBearNetworkFound = true;
            if (Integer.parseInt(var4.getValue("", "roaming")) != 1) {
               var5 = false;
            }

            this.isMultipleBearNetworkSupportRoaming = var5;
            if (this.isMultipleBearNetworkSupport) {
               this.queue = new PriorityQueue(10, this.mComparater);
               this.roamingBearerNetwork.put(this.isMultipleBearNetworkSupportRoaming, this.queue);
            }
         } else if (this.isBearNetworkFound) {
            if (var2.equals("wlan")) {
               this.isRequiredTag = true;
            } else if (var2.equals("lte")) {
               this.isRequiredTag = true;
            } else if (var2.equals("gsm")) {
               this.isRequiredTag = true;
            } else if (var2.equals("cdma")) {
               this.isRequiredTag = true;
            } else if (var2.equals("wcdma")) {
               this.isRequiredTag = true;
            } else if (var2.equals("umb")) {
               this.isRequiredTag = true;
            } else if (var2.equals("wimax")) {
               this.isRequiredTag = true;
            } else if (var2.equals("hrpd")) {
               this.isRequiredTag = true;
            }
         }
      }

   }

   public boolean switchApnEnabled() {
      return this.isSwitchApnEnabled;
   }

   public class ForceTestValue {
      public int[] aNMR = null;
      public int iCI = 0;
      public int iLac = 0;
      public long iMSISDN = 0L;
      public int iMcc = 0;
      public int iMnc = 0;
      public int iTA = 0;
      public boolean isFillTAandNMR = false;

      public byte[] getForceTest() {
         byte var3 = 0;
         byte var1 = 32;
         if (this.isFillTAandNMR) {
            var1 = 36;
         }

         int var2 = var1;
         if (this.aNMR != null) {
            var2 = var1 + 4 + this.aNMR.length * 4;
         }

         byte[] var5 = new byte[var2];
         var2 = IO.put8(var5, IO.put4(var5, IO.put4(var5, IO.put4(var5, IO.put4(var5, IO.put4(var5, IO.put4(var5, 0, 111), var2 - 4), this.iMcc), this.iMnc), this.iLac), this.iCI), this.iMSISDN);
         if (this.isFillTAandNMR) {
            var1 = 1;
         } else {
            var1 = 0;
         }

         var2 = IO.put4(var5, var2, var1);
         int var7 = var2;
         if (this.isFillTAandNMR) {
            var7 = IO.put4(var5, var2, this.iTA);
         }

         if (this.aNMR != null) {
            var2 = IO.put4(var5, var7, this.aNMR.length);
            int[] var6 = this.aNMR;
            int var4 = var6.length;

            for(var7 = var3; var7 < var4; ++var7) {
               var2 = IO.put4(var5, var2, var6[var7]);
            }
         } else {
            IO.put4(var5, var7, 0);
         }

         return var5;
      }
   }
}
