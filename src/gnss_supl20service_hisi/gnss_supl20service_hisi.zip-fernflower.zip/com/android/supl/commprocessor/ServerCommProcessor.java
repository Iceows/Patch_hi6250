package com.android.supl.commprocessor;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.util.Log;
import com.android.bytewriter.IO;
import com.android.supl.nc.NetworkController;
import com.android.supl.nc.SendToServer;
import com.android.supl.nc.SuplServiceMgr;
import java.util.Arrays;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class ServerCommProcessor implements CommandProcessor {
   public static final int COMM_MSG_HELLO_TO_COMM_SRVC_MAGIC_CODE = -1724873644;
   public static final int COMM_MSG_HELLO_TO_SUPL_CLIENT_MAGIC_CODE = -2125961885;
   private static final String LOG_TAG = "SUPL20_SCM";
   public static final int MASTER_BUFF_LEN = 5000;
   public static final int MSG_SCM_BYE = 512;
   public static final int MSG_SCM_CONNECT = 514;
   public static final int MSG_SCM_DISCONNECT = 515;
   public static final int MSG_SCM_HELLO_TO_COMM_SRVC = 513;
   public static final int MSG_SCM_HELLO_TO_SUPL_CLIENT = 517;
   public static final int MSG_SCM_NW_CONNECTION_OFF = 523;
   public static final int MSG_SCM_NW_CONNECTION_ON = 522;
   public static final int MSG_SCM_ON_CONNECTED = 518;
   public static final int MSG_SCM_ON_NOT_CONNECTED = 519;
   public static final int MSG_SCM_ON_NW_SESSION_CLOSED = 521;
   public static final int MSG_SCM_ON_RECEIVE = 520;
   public static final int MSG_SCM_ON_RECEIVE_FROM_NON_TCP = 525;
   public static final int MSG_SCM_SEND = 516;
   public static final int MSG_SCM_SYS_IDLE = 524;
   private int iLastWritePostion = 0;
   private int iTotalArrival = 0;
   private boolean isPause = false;
   private Context mContext = null;
   private boolean mListening = false;
   private NetworkCommandProcessor mNetworkCommandProcessor = null;
   private ServerCommProcessor.ConnectivityBroadcastReceiver mReceiver;
   private byte[] m_bMasterBuffer = null;
   private NetworkController nc = null;
   private ServerCommProcessor.ReadPacket packet = null;
   private final Object pauseLock = new Object();

   // $FF: synthetic method
   static boolean _get0/* $FF was: -get0*/(ServerCommProcessor var0) {
      return var0.isPause;
   }

   // $FF: synthetic method
   static NetworkCommandProcessor _get2/* $FF was: -get2*/(ServerCommProcessor var0) {
      return var0.mNetworkCommandProcessor;
   }

   // $FF: synthetic method
   static ServerCommProcessor.ReadPacket _get4/* $FF was: -get4*/(ServerCommProcessor var0) {
      return var0.packet;
   }

   // $FF: synthetic method
   static Object _get5/* $FF was: -get5*/(ServerCommProcessor var0) {
      return var0.pauseLock;
   }

   // $FF: synthetic method
   static boolean _set0/* $FF was: -set0*/(ServerCommProcessor var0, boolean var1) {
      var0.isPause = var1;
      return var1;
   }

   public ServerCommProcessor() {
      this.nc = new NetworkController(0, "10.4.0.51", 4444, this, "SCM read thread", "SCM write thread", true);
      this.packet = new ServerCommProcessor.ReadPacket("SCM command process thread");
      SuplServiceMgr.getInstance().setScmCommandProcessor(this);
   }

   public ServerCommProcessor(boolean var1, String var2, int var3, int var4, int var5) {
      this.msgBufferReset();
      this.nc = new NetworkController(0, var2, var3, this, "SCM read thread", "SCM write thread", true);
      this.nc.setServer_conn_Timeout_Retries(var4, var5);
      this.packet = new ServerCommProcessor.ReadPacket("SCM command process thread");
      this.mNetworkCommandProcessor = new NetworkCommandProcessor(this);
      SuplServiceMgr.getInstance().setScmCommandProcessor(this);
   }

   private void msgBufferReset() {
      this.m_bMasterBuffer = new byte[5000];
      Arrays.fill(this.m_bMasterBuffer, (byte)0);
   }

   public boolean init() {
      Log.i("SUPL20_SCM", "calling nc.connect for scm");
      return this.nc.connect((int[])null, false);
   }

   public void pause() {
      Thread var1 = new Thread() {
         public void run() {
            // $FF: Couldn't be decompiled
         }
      };
      var1.start();

      try {
         var1.join();
         StringBuilder var3 = new StringBuilder();
         Log.i("SUPL20_SCM", var3.append("SCM pause finished:").append(this.isPause).toString());
      } catch (InterruptedException var2) {
         Log.e("SUPL20_SCM", var2.getMessage(), var2);
      }

   }

   public void process(FromServer param1) {
      // $FF: Couldn't be decompiled
   }

   public void reInit() {
      Object var1 = this.pauseLock;
      synchronized(var1){}

      try {
         if (this.isPause) {
            Log.i("SUPL20_SCM", "SCM reInit invoked");
            String var3 = this.packet.getThreadName();
            ServerCommProcessor.ReadPacket var2 = new ServerCommProcessor.ReadPacket(var3);
            this.packet = var2;
            this.nc.initRead_WriteThread();
            this.isPause = false;
         }
      } finally {
         ;
      }

   }

   public void sendByeMessage() {
      SendToServer var2 = new SendToServer();
      byte[] var1 = new byte[12];
      IO.put4(var1, IO.put4(var1, 0, 8), 512);
      var2.m_bPacket = var1;
      this.nc.addPacket(var2);
   }

   public void sendHelloMessage() {
      SendToServer var1 = new SendToServer();
      byte[] var2 = new byte[12];
      IO.put4(var2, IO.put4(var2, IO.put4(var2, 0, 8), 517), -2125961885);
      var1.m_bPacket = var2;
      this.nc.addPacket(var1);
      this.startListening();
      Log.i("SUPL20_SCM", "sendHelloMessage");
   }

   public void sendServer(SendToServer var1) {
      this.nc.addPacket(var1);
   }

   public void setContext(Context var1) {
      this.mReceiver = new ServerCommProcessor.ConnectivityBroadcastReceiver((ServerCommProcessor.ConnectivityBroadcastReceiver)null);
      this.mContext = var1;
   }

   public void startListening() {
      synchronized(this){}

      try {
         if (!this.mListening) {
            IntentFilter var1 = new IntentFilter();
            var1.addAction("android.net.conn.CONNECTIVITY_CHANGE");
            this.mContext.registerReceiver(this.mReceiver, var1, "supl20servicePermission", (Handler)null);
            this.mListening = true;
         }
      } finally {
         ;
      }

   }

   public void stopListening() {
      synchronized(this){}

      try {
         if (this.mListening) {
            this.mContext.unregisterReceiver(this.mReceiver);
            this.mListening = false;
         }
      } finally {
         ;
      }

   }

   public void stopNetWork() {
      Log.i("SUPL20_SCM", "SCM stopNetWork invoked");
      this.packet.stopRead();
      this.stopListening();
      this.nc.stop(true, (Object)null, false);
      this.mNetworkCommandProcessor.disConnectAllNetWork();
   }

   public String toString() {
      return this.nc.getServerIPAddr() + " ," + this.nc.getNetWorkID() + " " + this.nc.toString();
   }

   public void writePacket(FromServer var1) throws NullPointerException {
      if (var1 == null) {
         throw new NullPointerException("fromServer object must not be null");
      } else {
         try {
            if (this.packet != null && this.packet.myJobDeque != null) {
               this.packet.myJobDeque.put(var1);
            } else {
               Log.i("SUPL20_SCM", "packet is null or deque is null");
            }
         } catch (InterruptedException var2) {
            Log.e("SUPL20_SCM", var2.getMessage(), var2);
         }

      }
   }

   private class ConnectivityBroadcastReceiver extends BroadcastReceiver {
      private ConnectivityBroadcastReceiver() {
      }

      // $FF: synthetic method
      ConnectivityBroadcastReceiver(ServerCommProcessor.ConnectivityBroadcastReceiver var2) {
         this();
      }

      public void onReceive(Context var1, Intent var2) {
         if (var2.getAction().equals("android.net.conn.CONNECTIVITY_CHANGE") && ServerCommProcessor.this.mListening) {
            boolean var4 = var2.getBooleanExtra("noConnectivity", false);
            SendToServer var6 = new SendToServer();
            byte[] var5 = new byte[8];
            int var3 = IO.put4(var5, 0, 4);
            if (var4) {
               IO.put4(var5, var3, 523);
            } else {
               IO.put4(var5, var3, 522);
            }

            Log.i("SUPL20_SCM", "Network connection " + (var4 ^ true));
            var6.m_bPacket = var5;
            ServerCommProcessor.this.nc.addPacket(var6);
         }
      }
   }

   private class ReadPacket extends Thread {
      private boolean isStopRead = false;
      private BlockingQueue myJobDeque = null;

      public ReadPacket(String var2) {
         this.myJobDeque = new LinkedBlockingQueue();
         this.setName(var2);
         this.start();
      }

      public String getThreadName() {
         return this.getName();
      }

      public void run() {
         // $FF: Couldn't be decompiled
      }

      public void stopRead() {
         this.interrupt();
         this.isStopRead = true;
      }
   }
}
