package com.android.supl.commprocessor;

import android.os.Handler;
import android.os.Message;
import android.util.Log;
import com.android.bytewriter.IO;
import com.android.supl.loc.SETLocationManager;
import com.android.supl.nc.NetworkController;
import com.android.supl.nc.SendToServer;
import com.android.supl.nc.SuplServiceMgr;
import com.android.supl.trigger.PeriodicTriggerHandler;
import java.util.Arrays;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import javax.crypto.SecretKey;

public class NDKCommProcessor implements CommandProcessor {
   private static final int EMERGENCY_REGISTER = 1;
   private static final int EMERGENCY_UN_REGISTER = 2;
   private static final int LOCATION_REGISTER = 3;
   private static final int LOCATION_UN_REGISTER = 4;
   private static final String LOG_TAG = "SUPL20_PCM";
   public static final int MASTER_BUFF_LEN = 5000;
   private static final int MSG_PCM_BYE = 256;
   public static final int MSG_PCM_EMERGENCY_CALL = 278;
   public static final int MSG_PCM_GET_HIST_KEY = 282;
   private static final int MSG_PCM_GET_LOCATION_ID = 259;
   public static final int MSG_PCM_GET_OTHER_MEAS = 275;
   private static final int MSG_PCM_GET_SET_ID = 258;
   public static final int MSG_PCM_GET_SIM_MCC_MNC = 280;
   private static final int MSG_PCM_HELLO_TO_PLAT_SRVC = 257;
   private static final int MSG_PCM_HELLO_TO_SUPL_CLIENT = 265;
   private static final int MSG_PCM_ON_SI_FAILURE = 264;
   private static final int MSG_PCM_ON_SI_LOCATION_REPORT = 262;
   public static final int MSG_PCM_ON_SI_SESSION_COMPLETE = 263;
   public static final int MSG_PCM_ON_SYSTEM_SHUTDOWN = 273;
   public static final int MSG_PCM_SYS_IDLE = 274;
   public static final int MSG_PCM_UPDATE_HIST_KEY = 283;
   public static final int MSG_PCM_UPDATE_LOCATION_ID = 267;
   public static final int MSG_PCM_UPDATE_OTHER_MEAS = 276;
   public static final int MSG_PCM_UPDATE_SET_ID = 266;
   public static final int MSG_PCM_UPDATE_SIM_MCC_MNC = 281;
   public static final int MSG_PCM_UPDATE_SLP_CONFIG = 277;
   private static final int PLAT_MSG_HELLO_TO_PLAT_SRVC_MAGIC_CODE = 1398314899;
   private static final int PLAT_MSG_HELLO_TO_SUPL_CLIENT_MAGIC_CODE = 826366246;
   private SecretKey final_key = null;
   private int iLastWritePostion = 0;
   private int iTotalArrival = 0;
   private boolean isPause = false;
   private SETLocationManager locationID_Manager = null;
   private Handler mHandler = new Handler() {
      public void handleMessage(Message var1) {
         switch(var1.what) {
         case 1:
            if (NDKCommProcessor.this.locationID_Manager != null) {
               try {
                  NDKCommProcessor.this.locationID_Manager.registerEmergencyReceiver();
               } catch (IllegalArgumentException var4) {
                  ;
               }
            }
            break;
         case 2:
            if (NDKCommProcessor.this.locationID_Manager != null) {
               try {
                  NDKCommProcessor.this.locationID_Manager.unregisterEmergencyReceiver();
               } catch (IllegalArgumentException var3) {
                  ;
               }
            }
            break;
         case 3:
            if (NDKCommProcessor.this.locationID_Manager != null) {
               NDKCommProcessor.this.locationID_Manager.startLocationIdListener();
            }
            break;
         case 4:
            if (NDKCommProcessor.this.locationID_Manager != null) {
               NDKCommProcessor.this.locationID_Manager.stopListening();
            }
         }

         super.handleMessage(var1);
      }
   };
   private PeriodicTriggerHandler mPeriodicTriggerHandler = null;
   private byte[] m_bMasterBuffer = null;
   private NetworkController nc = null;
   private final Object pauseLock = new Object();
   private NDKCommProcessor.ReadPacket readPacket = null;

   // $FF: synthetic method
   static boolean _get0/* $FF was: -get0*/(NDKCommProcessor var0) {
      return var0.isPause;
   }

   // $FF: synthetic method
   static NetworkController _get2/* $FF was: -get2*/(NDKCommProcessor var0) {
      return var0.nc;
   }

   // $FF: synthetic method
   static Object _get3/* $FF was: -get3*/(NDKCommProcessor var0) {
      return var0.pauseLock;
   }

   // $FF: synthetic method
   static NDKCommProcessor.ReadPacket _get4/* $FF was: -get4*/(NDKCommProcessor var0) {
      return var0.readPacket;
   }

   // $FF: synthetic method
   static boolean _set0/* $FF was: -set0*/(NDKCommProcessor var0, boolean var1) {
      var0.isPause = var1;
      return var1;
   }

   public NDKCommProcessor(boolean var1, String var2, int var3, SETLocationManager var4, int var5, int var6) {
      this.msgBufferReset();
      this.nc = new NetworkController(0, var2, var3, this, "PCM read thread", "PCM write thread", false);
      this.nc.setServer_conn_Timeout_Retries(var5, var6);
      this.readPacket = new NDKCommProcessor.ReadPacket("PCM command process thread");
      this.locationID_Manager = var4;
      this.locationID_Manager.setCommProcessor(this);
      SuplServiceMgr.getInstance().setPcmCommandProcessor(this);
      this.mPeriodicTriggerHandler = PeriodicTriggerHandler.getInstance();
      this.mPeriodicTriggerHandler.setNdkCommProcessor(this);
   }

   private void msgBufferReset() {
      this.m_bMasterBuffer = new byte[5000];
      Arrays.fill(this.m_bMasterBuffer, (byte)0);
   }

   public boolean init() {
      Log.i("SUPL20_PCM", "calling nc.connect for pcm");
      return this.nc.connect((int[])null, false);
   }

   public void pause() {
      Message var1 = this.mHandler.obtainMessage();
      var1.what = 2;
      this.mHandler.sendMessage(var1);
      var1 = this.mHandler.obtainMessage();
      var1.what = 4;
      this.mHandler.sendMessage(var1);
      Thread var3 = new Thread() {
         public void run() {
            // $FF: Couldn't be decompiled
         }
      };
      var3.start();

      try {
         var3.join();
         StringBuilder var4 = new StringBuilder();
         Log.i("SUPL20_PCM", var4.append("PCM pause finished:").append(this.isPause).toString());
      } catch (InterruptedException var2) {
         Log.e("SUPL20_PCM", var2.getMessage(), var2);
      }

   }

   public void process(FromServer param1) {
      // $FF: Couldn't be decompiled
   }

   public void reInit() {
      Object var1 = this.pauseLock;
      synchronized(var1){}

      try {
         if (this.isPause) {
            Log.i("SUPL20_PCM", "PCM reInit invoked");
            String var2 = this.readPacket.getThreadName();
            NDKCommProcessor.ReadPacket var3 = new NDKCommProcessor.ReadPacket(var2);
            this.readPacket = var3;
            this.nc.initRead_WriteThread();
            this.isPause = false;
         }
      } finally {
         ;
      }

   }

   public void sendByeMessage() {
      SendToServer var2 = new SendToServer();
      byte[] var1 = new byte[12];
      IO.put4(var1, IO.put4(var1, 0, 8), 256);
      var2.m_bPacket = var1;
      this.nc.addPacket(var2);
      Log.i("SUPL20_PCM", "sendByeMessage");
   }

   public void sendHelloMessage() {
      SendToServer var1 = new SendToServer();
      byte[] var2 = new byte[12];
      IO.put4(var2, IO.put4(var2, IO.put4(var2, 0, 8), 265), 826366246);
      var1.m_bPacket = var2;
      this.nc.addPacket(var1);
      Log.i("SUPL20_PCM", "sendHelloMessage");
      Message var3 = this.mHandler.obtainMessage();
      var3.what = 1;
      this.mHandler.sendMessage(var3);
   }

   public void sendServer(SendToServer var1) {
      this.nc.addPacket(var1);
   }

   public void stopNetWork() {
      Log.i("SUPL20_PCM", "PCM stopNetWork invoked");
      this.readPacket.stopRead();
      this.nc.stop(true, (Object)null, false);
   }

   public String toString() {
      return this.nc.getServerIPAddr() + " ," + this.nc.getNetWorkID() + " " + this.nc.toString();
   }

   public void writePacket(FromServer param1) throws NullPointerException {
      // $FF: Couldn't be decompiled
   }

   private class ReadPacket extends Thread {
      private boolean isStopRead = false;
      private BlockingQueue myJobDeque = null;

      // $FF: synthetic method
      static BlockingQueue _get0/* $FF was: -get0*/(NDKCommProcessor.ReadPacket var0) {
         return var0.myJobDeque;
      }

      public ReadPacket(String var2) {
         this.myJobDeque = new LinkedBlockingQueue();
         this.setName(var2);
         this.start();
      }

      public String getThreadName() {
         return this.getName();
      }

      public void run() {
         // $FF: Couldn't be decompiled
      }

      public void stopRead() {
         this.interrupt();
         this.isStopRead = true;
      }
   }
}
