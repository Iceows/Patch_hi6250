package com.android.supl.commprocessor;

public class FromServer {
   public byte[] m_bPacket = null;
}
