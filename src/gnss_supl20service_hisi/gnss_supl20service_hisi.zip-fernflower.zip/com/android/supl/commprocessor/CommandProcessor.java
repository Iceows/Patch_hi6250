package com.android.supl.commprocessor;

public interface CommandProcessor {
   int BYE_MSG_LEN = 8;
   int BYTE_SIZE = 1;
   int CANT_RESOLVE_FQDN = 0;
   int CLIENT_NOT_AUTHENTICATED = 3;
   int CONNECTION_ERROR_CODE_CANT_RESOLVE_FQDN = 0;
   int CONNECTION_ERROR_CODE_CLIENT_NOT_AUTHENTICATED = 3;
   int CONNECTION_ERROR_CODE_CONNECTION_FAILURE = 1;
   int CONNECTION_ERROR_CODE_NO_NETWORK = 5;
   int CONNECTION_ERROR_CODE_SERVER_NOT_AUTHENTICATED = 2;
   int CONNECTION_ERROR_CODE_TLS_ERROR = 4;
   int CONNECTION_FAILURE = 1;
   int CONNECT_MSG_LEN = 8;
   int HELLO_MSG_LEN = 8;
   int INT_SIZE = 4;
   int LONG_SIZE = 8;
   int MSG_CODE_LEN = 4;
   int MSG_COMMON_ALIVE = 768;
   int NW_SEESSIONID_LEN = 1;
   int ON_COMM_INTERFACE_STATUS_CHANGE_MSG_LEN = 8;
   int ON_NOT_CONNECT_MSG_LEN = 11;
   int ON_NW_SESSION_CLOSED_MSG_LEN = 9;
   int PACKET_LEN = 4;
   int REC_BUFF_LEN = 4;
   int REQ_ID_LEN = 1;
   int SERVER_NOT_AUTHENTICATED = 2;
   int SHORT_SIZE = 2;

   boolean init();

   void process(FromServer var1);

   void sendByeMessage();

   void sendHelloMessage();

   void writePacket(FromServer var1) throws NullPointerException;
}
