package com.android.supl.commprocessor;

import android.util.Log;
import com.android.bytewriter.IO;
import com.android.supl.config.ConfigManager;
import com.android.supl.nc.NetworkController;
import com.android.supl.nc.SendToServer;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class NetworkCommandProcessor implements CommandProcessor {
   private static final String LOG_TAG = "SUPL20_NetCP";
   private static final int MAX_NETWORK_ID = 255;
   public static int sNetworkID = -1;
   private ConfigManager configManager = ConfigManager.getInstance();
   private HashSet netWorkIDSet = null;
   private ServerCommProcessor scp = null;
   private HashMap slpSession = null;

   public NetworkCommandProcessor(ServerCommProcessor var1) {
      this.scp = var1;
   }

   private void removeConnectFailerSession(NetworkController var1, String var2) {
      HashMap var3 = this.slpSession;
      synchronized(var3){}

      try {
         if (var1.getConnectionCount() == 1) {
            NetworkController var7 = (NetworkController)this.slpSession.remove(var2);
            StringBuilder var6 = new StringBuilder();
            Log.i("SUPL20_NetCP", var6.append("Removed Session  :").append(var7).toString());
         } else {
            var1.decrementConnectionCount();
         }
      } finally {
         ;
      }

   }

   public boolean connect(final String var1, final int var2, final int var3, final int var4, final int var5, final int var6, final int var7) {
      final NetworkController var8 = this.getSNC(var1, var2, var3);
      Thread var9 = new Thread() {
         public void run() {
            int[] var2x = new int[1];
            if (var8 == null) {
               Log.e("SUPL20_NetCP", "id :" + var4 + " Req id :" + var5 + " is not connect for no more connection allowed");
               NetworkCommandProcessor.this.sendNotConnectionStatus(var4, var5, var2x);
            } else {
               String var1x = NetworkCommandProcessor.this.getNetKey(var1, var2, var3, var8.getNetWorkID());
               Log.i("SUPL20_NetCP", "id :" + var4 + " Req id :" + var5 + " is trying to connect to " + var8.getServerIPAddr());
               var8.SetTimeOuts(var6, var7);
               var8.setServer_conn_Timeout_Retries(var7, 1);
               if (var8.connect(var2x, false)) {
                  Log.i("SUPL20_NetCP", "id :" + var4 + " Req id :" + var5 + " is connected to " + var8.getServerIPAddr());
                  NetworkCommandProcessor.this.sendOnConnectionStatus(var4, var5, var8.getNetWorkID());
               } else {
                  Log.e("SUPL20_NetCP", "id :" + var4 + " Req id :" + var5 + " is not connected to " + var8.getServerIPAddr());
                  NetworkCommandProcessor.this.netWorkIDSet.remove(var8.getNetWorkID());
                  NetworkCommandProcessor.this.removeConnectFailerSession(var8, var1x);
                  NetworkCommandProcessor.this.sendNotConnectionStatus(var4, var5, var2x);
               }

            }
         }
      };
      if (var8 != null) {
         var8.setNetworkCommProceeor(this);
         if (!var8.isConnected()) {
            var9.setName("NetCM connection thread SID:" + var4);
            var9.start();
         } else {
            Log.i("SUPL20_NetCP", "id :" + var4 + " Req id :" + var5 + " is connected to " + var8.getServerIPAddr());
            this.sendOnConnectionStatus(var4, var5, var8.getNetWorkID());
         }
      } else {
         Log.e("SUPL20_NetCP", "id :" + var4 + " Req id :" + var5 + " is not connect for no more connection allowed");
         this.sendNotConnectionStatus(var4, var5, new int[]{1});
      }

      return false;
   }

   public void disConnectAllNetWork() {
      // $FF: Couldn't be decompiled
   }

   public void disconnectByNetworkID(int var1) {
      if (this.slpSession != null) {
         HashMap var2 = this.slpSession;
         synchronized(var2){}

         try {
            Iterator var3 = this.slpSession.keySet().iterator();

            while(var3.hasNext()) {
               String var4 = (String)var3.next();
               NetworkController var8 = (NetworkController)this.slpSession.get(var4);
               if (var8.isNetWorkMatch(var1)) {
                  StringBuilder var7 = new StringBuilder();
                  Log.i("SUPL20_NetCP", var7.append("Stop network by NeworkID").append(var1).toString());
                  var8.stop(true, (Object)null, false);
                  break;
               }
            }
         } finally {
            ;
         }
      }

   }

   public String getNetKey(String var1, int var2, int var3, int var4) {
      Log.d("SUPL20_NetCP", "getNetKey Entry with stIP" + var1 + "port:" + var2 + "iSecure:" + var3 + "NWID:" + var4);
      StringBuffer var5 = new StringBuffer();
      var5.append(var1);
      var5.append(var2);
      var5.append(var3);
      return var5.toString();
   }

   public NetworkController getSNC(String param1, int param2, int param3) {
      // $FF: Couldn't be decompiled
   }

   public boolean init() {
      return false;
   }

   public void process(FromServer var1) {
   }

   public void removeFailerSession(String var1) {
      HashMap var2 = this.slpSession;
      synchronized(var2){}

      try {
         NetworkController var6 = (NetworkController)this.slpSession.remove(var1);
         StringBuilder var3 = new StringBuilder();
         Log.i("SUPL20_NetCP", var3.append("Removed Session  :").append(var6).toString());
      } finally {
         ;
      }

   }

   public void sendByeMessage() {
   }

   public boolean sendDataByNetworkID(byte[] param1, int param2) {
      // $FF: Couldn't be decompiled
   }

   public void sendHelloMessage() {
   }

   public void sendNotConnectionStatus(int var1, int var2, int[] var3) {
      byte[] var4 = new byte[15];
      IO.put4(var4, IO.put1(var4, IO.put2(var4, IO.put4(var4, IO.put4(var4, 0, 11), 519), var1), var2), var3[0]);
      FromServer var5 = new FromServer();
      var5.m_bPacket = var4;
      this.writePacket(var5);
   }

   public void sendOnConnectionStatus(int var1, int var2, int var3) {
      Log.i("SUPL20_NetCP", "send sendOnConnectionStatus ");
      byte[] var5 = new byte[12];
      IO.put1(var5, IO.put1(var5, IO.put2(var5, IO.put4(var5, IO.put4(var5, 0, 8), 518), var1), var2), var3);
      FromServer var4 = new FromServer();
      var4.m_bPacket = var5;
      this.writePacket(var4);
   }

   public void sendOnNetWorkSessionClose(int var1) {
      Log.i("SUPL20_NetCP", "Network id :" + var1 + " is closed");
      byte[] var2 = new byte[13];
      if (IO.put4(var2, IO.put1(var2, IO.put4(var2, IO.put4(var2, 0, 9), 521), var1), 0) - 4 != 9) {
         System.out.println(" invalid length");
      }

      FromServer var3 = new FromServer();
      var3.m_bPacket = var2;
      this.writePacket(var3);
      HashMap var8 = this.slpSession;
      synchronized(var8){}

      try {
         Iterator var4 = this.slpSession.keySet().iterator();

         while(var4.hasNext()) {
            String var5 = (String)var4.next();
            NetworkController var9 = (NetworkController)this.slpSession.get(var5);
            if (var9.isNetWorkMatch(var1)) {
               this.slpSession.remove(var5);
               this.netWorkIDSet.remove(var1);
               StringBuilder var10 = new StringBuilder();
               Log.i("SUPL20_NetCP", var10.append(var9.toString()).append(" remove from SLP session ").toString());
               break;
            }
         }
      } finally {
         ;
      }

   }

   public String toString() {
      return "NetworkController" + sNetworkID;
   }

   public void writePacket(FromServer var1) throws NullPointerException {
      SendToServer var2 = new SendToServer();
      var2.m_bPacket = var1.m_bPacket;
      this.scp.sendServer(var2);
   }
}
