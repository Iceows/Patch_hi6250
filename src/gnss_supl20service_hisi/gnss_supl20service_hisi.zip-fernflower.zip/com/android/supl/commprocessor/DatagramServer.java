package com.android.supl.commprocessor;

import android.util.Log;
import java.net.DatagramSocket;

public class DatagramServer {
   public static final int D_PORT_NO = 7275;
   public static final String D_SERVER_ADDRESS = "127.0.0.1";
   private static final String LOG = "SUPL20_DGS";
   private int iPortNo = 7275;
   private ServerCommProcessor scm = null;
   private DatagramServer.ServerThread serverThread = null;
   private String stServerName = null;

   // $FF: synthetic method
   static int _get0/* $FF was: -get0*/(DatagramServer var0) {
      return var0.iPortNo;
   }

   // $FF: synthetic method
   static ServerCommProcessor _get1/* $FF was: -get1*/(DatagramServer var0) {
      return var0.scm;
   }

   public DatagramServer(int var1, String var2, ServerCommProcessor var3) {
      this.iPortNo = var1;
      this.stServerName = var2;
      this.scm = var3;
   }

   public void startServer() {
      Log.i("SUPL20_DGS", "startServer invoked");
      this.serverThread = new DatagramServer.ServerThread("UDP Server thread");
      this.serverThread.start();
   }

   public void stop() {
      if (this.serverThread != null) {
         Log.i("SUPL20_DGS", "stop invoked");
         this.serverThread.stopThread();
      }

   }

   private class ServerThread extends Thread {
      private boolean isStop = false;
      private byte[] receiveData = null;
      private DatagramSocket serverSocket = null;

      public ServerThread(String var2) {
         super(var2);
         this.receiveData = new byte[4096];
      }

      private void stopThread() {
         this.interrupt();
         this.isStop = true;
         if (this.serverSocket != null) {
            this.serverSocket.close();
         }

      }

      public void run() {
         // $FF: Couldn't be decompiled
      }
   }
}
