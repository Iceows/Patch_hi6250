package com.android.supl.commprocessor;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Binder;
import android.os.IBinder;
import android.telephony.TelephonyManager;
import android.util.Log;
import com.android.supl.GpsOnOffListener;
import com.android.supl.SUPLManager;
import com.android.supl.config.ConfigManager;
import java.lang.reflect.Method;

public class SUPLSCMService extends Service implements GpsOnOffListener {
   private static final int HOST_ADDRESS = 2130706433;
   public static final String SERVICE_NAME = SUPLSCMService.class.getCanonicalName();
   private final String LOG_TAG = "SUPL20_SCMService";
   DatagramServer datagramServer = null;
   private boolean isInit = false;
   private final IBinder mBinder = new SUPLSCMService.MyBinder();
   private Context mContext = null;
   private ServerCommProcessor mServerCommProcessor = null;
   private Thread scmThread = null;

   // $FF: synthetic method
   static ServerCommProcessor _get0/* $FF was: -get0*/(SUPLSCMService var0) {
      return var0.mServerCommProcessor;
   }

   public SUPLSCMService() {
      this.mContext = this;
   }

   public SUPLSCMService(Context var1) {
      this.mContext = var1;
      this.onCreate();
   }

   private void checkSupportMultiBearer() {
      if (ConfigManager.getInstance().isMultipleBearNetworkSupport()) {
         (new Thread(this.mContext) {
            // $FF: synthetic field
            final Context val$context;

            {
               this.val$context = var2;
            }

            public void run() {
               Log.i("SUPL20_SCMService", "Support for MultiBearer");
               SUPLSCMService.this.supportMultipleBearerNetwork(this.val$context);
            }
         }).start();
      } else {
         Log.i("SUPL20_SCMService", "No Support for MultiBearer");
      }

   }

   private boolean isBearerNetWorkSupported(int var1, String[] var2) {
      boolean var4 = false;
      Object var6 = null;
      boolean var3 = var4;
      String var5 = (String)var6;
      switch(var1) {
      case 0:
         var5 = "UNKNOWN";
         var3 = var4;
         break;
      case 1:
         var5 = "gsm";
         var3 = true;
         break;
      case 2:
         var5 = "gsm";
         var3 = true;
         break;
      case 3:
         var5 = "umb";
         var3 = true;
         break;
      case 4:
         var5 = "cdma";
         var3 = true;
      case 5:
      case 6:
      case 7:
      case 11:
      case 12:
         break;
      case 8:
         var5 = "wcdma";
         var3 = true;
         break;
      case 9:
         var5 = "wcdma";
         var3 = true;
         break;
      case 10:
         var5 = "wcdma";
         var3 = true;
         break;
      case 13:
         var5 = "lte";
         var3 = true;
         break;
      case 14:
         var5 = "hrpd";
         var3 = true;
         break;
      default:
         var5 = (String)var6;
         var3 = var4;
      }

      Log.i("SUPL20_SCMService", "network type:" + var1 + " ," + var5);
      if (var2 != null && var2.length != 0) {
         var2[0] = var5;
      }

      return var3;
   }

   private boolean isMobileDataEnabled(Context var1) {
      boolean var2 = false;
      ConnectivityManager var4 = (ConnectivityManager)var1.getSystemService("connectivity");

      boolean var3;
      try {
         Method var6 = Class.forName(var4.getClass().getName()).getDeclaredMethod("getMobileDataEnabled");
         var6.setAccessible(true);
         var3 = ((Boolean)var6.invoke(var4)).booleanValue();
      } catch (Exception var5) {
         return var2;
      }

      var2 = var3;
      return var2;
   }

   private Boolean isRoaming(Context var1) {
      return ((TelephonyManager)var1.getSystemService("phone")).isNetworkRoaming();
   }

   private void start() {
      this.isInit = true;
      ConfigManager var2 = ConfigManager.getInstance();
      int var1 = var2.getSCMPort();
      this.mServerCommProcessor = new ServerCommProcessor(false, var2.getSCMIpAdress(), var1, var2.getNwTimeout(), var2.getNwRetries());
      if (var2.isNiUdpEnabled()) {
         this.datagramServer = new DatagramServer(7275, "UDP SUPL server", this.mServerCommProcessor);
         Log.d("SUPL20_SCMService", "DataGramServer Created");
      }

      this.mServerCommProcessor.setContext(this.mContext);
      this.scmThread = new Thread(new SUPLSCMService.SCMConnectionThread());
      this.scmThread.setName("SCM handsake thread");
      this.scmThread.start();
      Log.d("SUPL20_SCMService", "SCM Service Created");
   }

   private void startSCM() {
      Log.d("SUPL20_SCMService", "Send startSCM");
      if (this.isInit) {
         this.mServerCommProcessor.reInit();
      } else {
         this.start();
      }

   }

   private void supportMultipleBearerNetwork(Context param1) {
      // $FF: Couldn't be decompiled
   }

   public IBinder onBind(Intent var1) {
      return this.mBinder;
   }

   public void onCreate() {
      ConfigManager.getInstance();
      Log.d("SUPL20_SCMService", "SUPL20 service version :2.13.2.0");
      this.start();
   }

   public void onDestroy() {
      if (this.mServerCommProcessor != null) {
         if (this.datagramServer != null) {
            this.datagramServer.stop();
         }

         this.mServerCommProcessor.stopListening();
         this.mServerCommProcessor.stopNetWork();
      }

      this.scmThread.interrupt();
      SUPLManager.getInstance(this.mContext).removeGpsListener(this);
   }

   public void onGPSLocationProviderDisabled() {
      Log.d("SUPL20_SCMService", " onGPSLocationProviderDisabled");
      if (this.isInit) {
         Log.d("SUPL20_SCMService", "SCM Service is running. Will pause it");
         this.mServerCommProcessor.pause();
      } else {
         Log.e("SUPL20_SCMService", "SCM Service not already created");
      }

   }

   public void onGPSLocationProviderEnabled() {
      Log.d("SUPL20_SCMService", " onGPSLocationProviderEnabled");
      this.startSCM();
   }

   public void onStart(Intent var1, int var2) {
   }

   public int onStartCommand(Intent var1, int var2, int var3) {
      return 1;
   }

   public class MyBinder extends Binder {
      public SUPLSCMService getService() {
         return SUPLSCMService.this;
      }
   }

   public class SCMConnectionThread implements Runnable {
      public void run() {
         // $FF: Couldn't be decompiled
      }
   }
}
