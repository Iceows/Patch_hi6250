package com.android.supl.trigger;

import android.util.Log;
import com.android.bytewriter.IO;
import com.android.supl.commprocessor.NDKCommProcessor;
import com.android.supl.nc.SendToServer;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Timer;
import java.util.TimerTask;

public class PeriodicTriggerHandler {
   private static final String LOG_TAG = "SUPL20_Trigger";
   public static final int MSG_PCM_ON_ERROR_TRIGGER_PERIODIC = 272;
   public static final int MSG_PCM_ON_TRIGGER_PERIODIC = 268;
   public static final int MSG_PCM_START_TRIGGER_PERIODIC = 260;
   public static final int MSG_PCM_STOP_TRIGGER_PERIODIC = 261;
   private static final int PERIODIC_TRIGGER_ERROR_CODE_CANT_SET_TRIGGER = 1;
   private static final int PERIODIC_TRIGGER_ERROR_CODE_OTHER = 2;
   private static final int PERIODIC_TRIGGER_ERROR_CODE_TRIGGER_NOT_AVAILABLE = 0;
   private static PeriodicTriggerHandler sPeriodicTriggerHandler = null;
   private HashMap hsTrigger = null;
   private NDKCommProcessor mNdkCommProcessor = null;

   private PeriodicTriggerHandler() {
      this.hsTrigger = new HashMap();
   }

   public static PeriodicTriggerHandler getInstance() {
      if (sPeriodicTriggerHandler == null) {
         sPeriodicTriggerHandler = new PeriodicTriggerHandler();
      }

      return sPeriodicTriggerHandler;
   }

   private String makeKey(int var1, short var2) {
      StringBuffer var3 = new StringBuffer();
      var3.append(var1);
      var3.append(":");
      var3.append(var2);
      return var3.toString();
   }

   public void OnErrorTriggerPeriodic(int var1, int var2, int var3) {
      byte[] var5 = new byte[15];
      if (IO.put4(var5, IO.put1(var5, IO.put2(var5, IO.put4(var5, IO.put4(var5, 0, 11), 272), var1), var2), var3) - 4 != 11) {
         System.out.println("OnErrorTriggerPeriodic length invalid");
      }

      Log.e("SUPL20_Trigger", "OnErrorTriggerPeriodic " + var1 + " " + var2 + " " + var3);
      SendToServer var4 = new SendToServer();
      var4.m_bPacket = var5;
      this.mNdkCommProcessor.sendServer(var4);
   }

   public void clear() {
      Iterator var2 = this.hsTrigger.keySet().iterator();

      while(var2.hasNext()) {
         String var1 = (String)var2.next();
         ((PeriodicTriggerHandler.RemainderTask)this.hsTrigger.get(var1)).stopTrigger();
      }

      this.hsTrigger.clear();
      sPeriodicTriggerHandler = null;
   }

   public void pause() {
      Iterator var2 = this.hsTrigger.keySet().iterator();

      while(var2.hasNext()) {
         String var1 = (String)var2.next();
         ((PeriodicTriggerHandler.RemainderTask)this.hsTrigger.get(var1)).stopTrigger();
      }

      this.hsTrigger.clear();
   }

   public void sendOnTriggerPeriodic(int var1, int var2, int var3) {
      byte[] var4 = new byte[15];
      if (IO.put4(var4, IO.put1(var4, IO.put2(var4, IO.put4(var4, IO.put4(var4, 0, 11), 268), var1), var2), var3) - 4 != 11) {
         System.out.println("sendOnTriggerPeriodic length invalid");
      }

      SendToServer var5 = new SendToServer();
      var5.m_bPacket = var4;
      this.mNdkCommProcessor.sendServer(var5);
   }

   public void setNdkCommProcessor(NDKCommProcessor var1) {
      this.mNdkCommProcessor = var1;
   }

   public boolean startTriggerPeriodic(DataInputStream var1) throws IOException {
      int var5 = var1.readUnsignedShort();
      short var2 = (short)var1.readUnsignedByte();
      int var4 = var1.readInt();
      int var3 = var1.readInt();
      String var7 = this.makeKey(var5, var2);
      if ((PeriodicTriggerHandler.RemainderTask)this.hsTrigger.get(var7) != null && var4 <= 0) {
         this.OnErrorTriggerPeriodic(var5, var2, 1);
      } else {
         PeriodicTriggerHandler.RemainderTask var6 = new PeriodicTriggerHandler.RemainderTask(var5, var4, var4, var2, var3);
         this.hsTrigger.put(var7, var6);
      }

      return true;
   }

   public boolean stopTriggerPeriodic(DataInputStream var1) throws IOException {
      int var3 = var1.readUnsignedShort();
      short var2 = (short)var1.readUnsignedByte();
      String var5 = this.makeKey(var3, var2);
      PeriodicTriggerHandler.RemainderTask var4 = (PeriodicTriggerHandler.RemainderTask)this.hsTrigger.get(var5);
      if (var4 == null) {
         this.OnErrorTriggerPeriodic(var3, var2, 0);
         Log.e("SUPL20_Trigger", "stopTriggerPeriodic invalid id or trigger id");
      } else {
         var4.stopTrigger();
         this.hsTrigger.remove(var5);
      }

      return true;
   }

   private class RemainderTask extends TimerTask {
      private Timer mTimer = null;
      private short m_ucTriggerId = 0;
      private int m_unPeriod = 0;
      private int m_unTime = 0;
      private int sSessionID = -1;

      public RemainderTask(int var2, int var3, int var4, short var5, int var6) {
         this.sSessionID = var2;
         this.m_unPeriod = var4;
         this.m_ucTriggerId = var5;
         this.m_unTime = var6;
         this.mTimer = new Timer("Trigger thr " + var2 + ":" + var5);
         this.mTimer.schedule(this, (long)var3, (long)this.m_unPeriod);
         Log.i("SUPL20_Trigger", "start Trigger SID:" + var2 + " TI:" + var5 + " TimeCount:" + var6 + " Delay to Start:" + var3 + " Interval Time:" + var4);
      }

      public void run() {
         Log.i("SUPL20_Trigger", "sendOnTriggerPeriodic SID:" + this.sSessionID + " TI:" + this.m_ucTriggerId + " TimeIX:" + this.m_unTime);
         PeriodicTriggerHandler.this.sendOnTriggerPeriodic(this.sSessionID, this.m_ucTriggerId, this.m_unTime);
         if (this.m_unTime != 0) {
            --this.m_unTime;
            if (this.m_unTime == 0) {
               this.stopTrigger();
            }
         }

      }

      public void stopTrigger() {
         Log.i("SUPL20_Trigger", "stopTrigger SID:" + this.sSessionID + " TI:" + this.m_ucTriggerId + " TimeIX:" + this.m_unTime);
         this.m_unTime = 0;
         String var1 = PeriodicTriggerHandler.this.makeKey(this.sSessionID, this.m_ucTriggerId);
         PeriodicTriggerHandler.this.hsTrigger.remove(var1);
         this.mTimer.cancel();
         this.cancel();
      }
   }
}
