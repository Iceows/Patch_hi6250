package com.android.supl;

import android.content.ContentQueryMap;
import android.content.ContentResolver;
import android.content.Context;
import android.os.Handler;
import android.provider.Settings.Secure;
import com.android.supl.commprocessor.SUPLSCMService;
import com.android.supl.config.ConfigManager;
import com.android.supl.loc.SUPLPlatformService;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;
import java.util.Vector;

public class SUPLManager {
   private static final String LOG_TAG = "SUPL20_SUPLManager";
   public static final String SUPL_SI = "supl20mgr";
   private static SUPLManager suplManager = null;
   private boolean isGpsEnableReceReg = false;
   private Context mContext = null;
   private SUPLPlatformService mPlatformService = null;
   private ContentQueryMap mSettings = null;
   private SUPLSCMService mSuplscmService = null;
   private Handler m_Handler = null;
   private SUPLManager.SettingsObserver settingsObserver = null;
   private Vector vecGpsListeners = null;

   private SUPLManager() {
   }

   public SUPLManager(Context var1) {
      if (suplManager == null) {
         suplManager = this;
         this.mContext = var1;
         this.init();
         this.mPlatformService = new SUPLPlatformService(var1);
         this.mSuplscmService = new SUPLSCMService(var1);
      } else {
         throw new IllegalAccessError("Instance already created. call getIntance method");
      }
   }

   private static boolean delimitedStringContains(String var0, char var1, String var2) {
      if (!isEmpty(var0) && !isEmpty(var2)) {
         int var3 = -1;
         int var5 = var0.length();

         int var6;
         do {
            int var4;
            do {
               var4 = var0.indexOf(var2, var3 + 1);
               if (var4 == -1) {
                  return false;
               }

               if (var4 <= 0) {
                  break;
               }

               var3 = var4;
            } while(var0.charAt(var4 - 1) != var1);

            var6 = var4 + var2.length();
            if (var6 == var5) {
               return true;
            }

            var3 = var4;
         } while(var0.charAt(var6) != var1);

         return true;
      } else {
         return false;
      }
   }

   private void deregisterSettingObserver() {
      if (this.isGpsEnableReceReg) {
         this.mSettings.deleteObserver(this.settingsObserver);
         this.isGpsEnableReceReg = false;
      }

   }

   public static SUPLManager getInstance(Context var0) {
      synchronized(SUPLManager.class){}

      SUPLManager var4;
      try {
         if (suplManager == null) {
            SUPLManager var1 = new SUPLManager();
            suplManager = var1;
            suplManager.mContext = var0;
            suplManager.init();
         }

         var4 = suplManager;
      } finally {
         ;
      }

      return var4;
   }

   private void init() {
      this.m_Handler = new Handler();
      if (ConfigManager.getInstance().getSUPLVersion() == 1) {
         this.vecGpsListeners = new Vector(2);
         this.registerSettingObserver();
      }

   }

   private static boolean isEmpty(CharSequence var0) {
      return var0 == null || var0.length() == 0;
   }

   private boolean isLocationProviderEnabled(ContentResolver var1, String var2) {
      return delimitedStringContains(Secure.getString(var1, "location_providers_allowed"), ',', var2);
   }

   private void notifytoALLGpsDisableChanges() {
      if (this.vecGpsListeners != null) {
         Iterator var1 = this.vecGpsListeners.iterator();

         while(var1.hasNext()) {
            GpsOnOffListener var2 = (GpsOnOffListener)var1.next();
            if (var2 != null) {
               var2.onGPSLocationProviderDisabled();
            }
         }
      }

   }

   private void notifytoALLGpsEnableChanges() {
      if (this.vecGpsListeners != null) {
         Iterator var1 = this.vecGpsListeners.iterator();

         while(var1.hasNext()) {
            GpsOnOffListener var2 = (GpsOnOffListener)var1.next();
            if (var2 != null) {
               var2.onGPSLocationProviderEnabled();
            }
         }
      }

   }

   private void registerSettingObserver() {
      if (!this.isGpsEnableReceReg) {
         this.mSettings = new ContentQueryMap(this.mContext.getContentResolver().query(Secure.CONTENT_URI, (String[])null, "(name=?)", new String[]{"location_providers_allowed"}, (String)null), "name", true, this.m_Handler);
         this.settingsObserver = new SUPLManager.SettingsObserver((SUPLManager.SettingsObserver)null);
         this.mSettings.addObserver(this.settingsObserver);
         this.isGpsEnableReceReg = true;
      }

   }

   private void startCommnMgrs(String var1) {
      if (this.isLocationProviderEnabled(this.mContext.getContentResolver(), var1)) {
         android.util.Log.d("SUPL20_SUPLManager", "Send GPS enable info");
         this.notifytoALLGpsEnableChanges();
      } else {
         android.util.Log.d("SUPL20_SUPLManager", "Send GPS disable info");
         this.notifytoALLGpsDisableChanges();
      }

   }

   public boolean addGpsListener(GpsOnOffListener var1) {
      boolean var3 = false;
      boolean var2 = var3;
      if (this.vecGpsListeners != null) {
         var2 = var3;
         if (var1 != null) {
            if (this.vecGpsListeners.size() == 0) {
               this.registerSettingObserver();
            }

            var2 = this.vecGpsListeners.add(var1);
         }
      }

      return var2;
   }

   public boolean removeGpsListener(GpsOnOffListener var1) {
      boolean var3 = false;
      boolean var2 = var3;
      if (this.vecGpsListeners != null) {
         var2 = var3;
         if (var1 != null) {
            var3 = this.vecGpsListeners.remove(var1);
            var2 = var3;
            if (this.vecGpsListeners.size() == 0) {
               this.deregisterSettingObserver();
               var2 = var3;
            }
         }
      }

      return var2;
   }

   private final class SettingsObserver implements Observer {
      private SettingsObserver() {
      }

      // $FF: synthetic method
      SettingsObserver(SUPLManager.SettingsObserver var2) {
         this();
      }

      public void update(Observable var1, Object var2) {
         SUPLManager.this.startCommnMgrs("gps");
      }
   }
}
