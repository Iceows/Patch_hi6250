package com.android.bytewriter;

public class IO {
   public static int get1(byte[] var0, int var1) {
      int var2 = 0;

      for(int var3 = 0; var3 < 1; ++var1) {
         byte var5 = var0[var1];
         int var4 = var5;
         if (var5 < 0) {
            var4 = var5 + 256;
         }

         var2 = (var2 << 8) + var4;
         ++var3;
      }

      return var2;
   }

   public static int get2(byte[] var0, int var1) {
      int var2 = 0;

      for(int var3 = 0; var3 < 2; ++var1) {
         byte var5 = var0[var1];
         int var4 = var5;
         if (var5 < 0) {
            var4 = var5 + 256;
         }

         var2 = (var2 << 8) + var4;
         ++var3;
      }

      return var2;
   }

   public static int get2r(byte[] var0, int var1) {
      int var2 = 0;

      for(int var3 = 1; var3 >= 0; --var3) {
         byte var5 = var0[var1 + var3];
         int var4 = var5;
         if (var5 < 0) {
            var4 = var5 + 256;
         }

         var2 = (var2 << 8) + var4;
      }

      return var2;
   }

   public static int get3(byte[] var0, int var1) {
      int var3 = 0;

      for(int var2 = 0; var2 < 3; ++var1) {
         byte var5 = var0[var1];
         int var4 = var5;
         if (var5 < 0) {
            var4 = var5 + 256;
         }

         var3 = (var3 << 8) + var4;
         ++var2;
      }

      return var3;
   }

   public static int get4(byte[] var0, int var1) {
      int var3 = 0;

      for(int var2 = 0; var2 < 4; ++var1) {
         byte var5 = var0[var1];
         int var4 = var5;
         if (var5 < 0) {
            var4 = var5 + 256;
         }

         var3 = (var3 << 8) + var4;
         ++var2;
      }

      return var3;
   }

   public static int get4l(byte[] var0, int var1) {
      int var3 = 0;

      for(int var2 = 3; var2 >= 0; --var2) {
         byte var5 = var0[var1 + var2];
         int var4 = var5;
         if (var5 < 0) {
            var4 = var5 + 256;
         }

         var3 = (var3 << 8) + var4;
      }

      return var3;
   }

   public static int get4r(byte[] var0, int var1) {
      int var3 = 0;

      for(int var2 = 3; var2 >= 0; --var2) {
         byte var5 = var0[var1 + var2];
         int var4 = var5;
         if (var5 < 0) {
            var4 = var5 + 256;
         }

         var3 = (var3 << 8) + var4;
      }

      return var3;
   }

   public static long get8(byte[] var0, int var1) {
      long var3 = 0L;

      for(int var2 = 0; var2 < 8; ++var1) {
         long var7 = (long)var0[var1];
         long var5 = var7;
         if (var7 < 0L) {
            var5 = var7 + 256L;
         }

         var3 = (var3 << 8) + var5;
         ++var2;
      }

      return var3;
   }

   public static long get8l(byte[] var0, int var1) {
      long var3 = 0L;

      for(int var2 = 7; var2 >= 0; --var2) {
         long var7 = (long)var0[var1 + var2];
         long var5 = var7;
         if (var7 < 0L) {
            var5 = var7 + 256L;
         }

         var3 = (var3 << 8) + var5;
      }

      return var3;
   }

   public static long get8r(byte[] var0, int var1) {
      long var3 = 0L;

      for(int var2 = 7; var2 >= 0; --var2) {
         long var7 = (long)var0[var1 + var2];
         long var5 = var7;
         if (var7 < 0L) {
            var5 = var7 + 256L;
         }

         var3 = (var3 << 8) + var5;
      }

      return var3;
   }

   public static int put1(byte[] var0, int var1, int var2) {
      var0[var1] = (byte)var2;
      return var1 + 1;
   }

   public static int put2(byte[] var0, int var1, int var2) {
      int var3 = var1 + 1;
      var0[var1] = (byte)(var2 >> 8);
      var0[var3] = (byte)(var2 & 255);
      return var3 + 1;
   }

   public static int put3(byte[] var0, int var1, int var2) {
      int var3 = var1 + 1;
      var0[var1] = (byte)(var2 >> 16 & 255);
      var1 = var3 + 1;
      var0[var3] = (byte)(var2 >> 8 & 255);
      var0[var1] = (byte)(var2 & 255);
      return var1 + 1;
   }

   public static int put4(byte[] var0, int var1, int var2) {
      int var3 = var1 + 1;
      var0[var1] = (byte)(var2 >> 24);
      var1 = var3 + 1;
      var0[var3] = (byte)(var2 >> 16 & 255);
      var3 = var1 + 1;
      var0[var1] = (byte)(var2 >> 8 & 255);
      var0[var3] = (byte)(var2 & 255);
      return var3 + 1;
   }

   public static int put5(byte[] var0, int var1, long var2) {
      int var5 = var1 + 1;
      var0[var1] = (byte)((int)(var2 >> 32 & 255L));
      int var4 = var5 + 1;
      var0[var5] = (byte)((int)(var2 >> 24 & 255L));
      var1 = var4 + 1;
      var0[var4] = (byte)((int)(var2 >> 16 & 255L));
      var4 = var1 + 1;
      var0[var1] = (byte)((int)(var2 >> 8 & 255L));
      var0[var4] = (byte)((int)(var2 & 255L));
      return var4 + 1;
   }

   public static int put8(byte[] var0, int var1, long var2) {
      int var5 = var1 + 1;
      var0[var1] = (byte)((int)(var2 >> 56 & 255L));
      int var4 = var5 + 1;
      var0[var5] = (byte)((int)(var2 >> 48 & 255L));
      var1 = var4 + 1;
      var0[var4] = (byte)((int)(var2 >> 40 & 255L));
      var4 = var1 + 1;
      var0[var1] = (byte)((int)(var2 >> 32 & 255L));
      var1 = var4 + 1;
      var0[var4] = (byte)((int)(var2 >> 24 & 255L));
      var4 = var1 + 1;
      var0[var1] = (byte)((int)(var2 >> 16 & 255L));
      var1 = var4 + 1;
      var0[var4] = (byte)((int)(var2 >> 8 & 255L));
      var0[var1] = (byte)((int)(var2 & 255L));
      return var1 + 1;
   }
}
